(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["archivos-archivos-module"],{

/***/ "662g":
/*!**********************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/auditoria/archivos/archivos.component.ts ***!
  \**********************************************************************************/
/*! exports provided: ArchivosComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ArchivosComponent", function() { return ArchivosComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");

class ArchivosComponent {
    constructor() { }
    ngOnInit() {
    }
}
ArchivosComponent.ɵfac = function ArchivosComponent_Factory(t) { return new (t || ArchivosComponent)(); };
ArchivosComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: ArchivosComponent, selectors: [["app-archivos"]], decls: 11, vars: 0, consts: [["id", "optionshome"], [1, "container-fluid"], [1, "row", "justify-content-center", 2, "height", "60vh", "width", "100%"], [1, "align-self-center"], [1, "d-flex", "flex-column", 2, "width", "504px"], [1, "descripcionPrimerLogin", 2, "margin-top", "34px"], [1, "row"], [1, "col-10"], ["src", "assets/icons/ico-residencial.png", "width", "30%", 1, "center"]], template: function ArchivosComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "section", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "img", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "Esta p\u00E1gina se encuentra en construcci\u00F3n.");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, styles: [".center[_ngcontent-%COMP%] {\r\n    display: block;\r\n    margin-left: auto;\r\n    margin-right: auto;\r\n  }\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFyY2hpdm9zLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxjQUFjO0lBQ2QsaUJBQWlCO0lBQ2pCLGtCQUFrQjtFQUNwQiIsImZpbGUiOiJhcmNoaXZvcy5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNlbnRlciB7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIG1hcmdpbi1sZWZ0OiBhdXRvO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xyXG4gIH0iXX0= */"] });


/***/ }),

/***/ "e/GJ":
/*!*******************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/auditoria/archivos/archivos.module.ts ***!
  \*******************************************************************************/
/*! exports provided: ArchivosModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ArchivosModule", function() { return ArchivosModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _archivos_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./archivos-routing.module */ "hTco");
/* harmony import */ var _archivos_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./archivos.component */ "662g");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




class ArchivosModule {
}
ArchivosModule.ɵfac = function ArchivosModule_Factory(t) { return new (t || ArchivosModule)(); };
ArchivosModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({ type: ArchivosModule });
ArchivosModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
            _archivos_routing_module__WEBPACK_IMPORTED_MODULE_1__["ArchivosRoutingModule"]
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](ArchivosModule, { declarations: [_archivos_component__WEBPACK_IMPORTED_MODULE_2__["ArchivosComponent"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
        _archivos_routing_module__WEBPACK_IMPORTED_MODULE_1__["ArchivosRoutingModule"]] }); })();


/***/ }),

/***/ "hTco":
/*!***************************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/auditoria/archivos/archivos-routing.module.ts ***!
  \***************************************************************************************/
/*! exports provided: ArchivosRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ArchivosRoutingModule", function() { return ArchivosRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _archivos_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./archivos.component */ "662g");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");




const routes = [{ path: '', component: _archivos_component__WEBPACK_IMPORTED_MODULE_1__["ArchivosComponent"] }];
class ArchivosRoutingModule {
}
ArchivosRoutingModule.ɵfac = function ArchivosRoutingModule_Factory(t) { return new (t || ArchivosRoutingModule)(); };
ArchivosRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: ArchivosRoutingModule });
ArchivosRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](ArchivosRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] }); })();


/***/ })

}]);
//# sourceMappingURL=archivos-archivos-module.js.map