(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["procesos-procesos-module"],{

/***/ "+U3K":
/*!************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/procesos/procesos.component.ts ***!
  \************************************************************************/
/*! exports provided: ProcesosComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProcesosComponent", function() { return ProcesosComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "tyNb");


class ProcesosComponent {
    constructor() { }
    ngOnInit() {
    }
}
ProcesosComponent.ɵfac = function ProcesosComponent_Factory(t) { return new (t || ProcesosComponent)(); };
ProcesosComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: ProcesosComponent, selectors: [["app-procesos"]], decls: 1, vars: 0, template: function ProcesosComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "router-outlet");
    } }, directives: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterOutlet"]], styles: [".wrapper[_ngcontent-%COMP%] {\r\n    display: flex;\r\n    flex-wrap: wrap;\r\n  }\r\n\r\n  .content[_ngcontent-%COMP%] {\r\n    width: 100%;\r\n    display: flex;\r\n    flex-wrap: wrap;\r\n    flex-direction: column;\r\n  }\r\n\r\n  div.container-selector-proceso[_ngcontent-%COMP%] {\r\n    width: auto;\r\n    height: 45px;\r\n\r\n    margin-bottom: 50px;\r\n    margin-top: 50px;\r\n  }\r\n\r\n  .selector-proceso[_ngcontent-%COMP%] {\r\n    width: auto;\r\n    height: 45px;\r\n    border-radius: 25px;\r\n    min-width: 328px;\r\n    margin-bottom: 50px;\r\n    margin-top: 50px;\r\n  }\r\n\r\n  .selector-proceso[_ngcontent-%COMP%]    > button[_ngcontent-%COMP%] {\r\n    width: 50%;\r\n    height: 45px;\r\n    height: 100%;\r\n    border: none;\r\n    background: white;\r\n    color: #464E7E;\r\n    font: bold 20px FS Elliot Pro;\r\n  }\r\n\r\n  .selector-proceso[_ngcontent-%COMP%]    > button[_ngcontent-%COMP%]:focus {\r\n    background-color: #7C69C3;\r\n    color: white;\r\n    transition: background 0.2s linear;\r\n    box-shadow: 3px 3px 5px #464E7E;\r\n  }\r\n\r\n  #right-button[_ngcontent-%COMP%] {\r\n    border-top-right-radius: 25px 25px;\r\n    border-bottom-right-radius: 25px 25px;\r\n  }\r\n\r\n  #left-button[_ngcontent-%COMP%] {\r\n    border-top-left-radius: 25px 25px;\r\n    border-bottom-left-radius: 25px 25px;\r\n  }\r\n\r\n  .botonActivado[_ngcontent-%COMP%]{\r\n    background-color: #035fa4;\r\n    color: white;\r\n  }\r\n\r\n  .container-procesos[_ngcontent-%COMP%] {\r\n    background: red;\r\n    display: flex;\r\n    flex: 1;\r\n    flex-wrap: wrap;\r\n    flex-direction: row;\r\n    align-content: center;\r\n    justify-content: center;\r\n    border-radius: 25px;\r\n    margin: 25px 0;\r\n    width: 95%;\r\n  }\r\n\r\n  div.card-calendario[_ngcontent-%COMP%] {\r\n    background: white;\r\n    display: flex;\r\n    width: 100%;\r\n    height: 285px;\r\n    min-width: 420px;\r\n    \r\n    margin: 25px 0;\r\n    margin-right: 5%;\r\n    margin-left: 5%;\r\n    flex-direction: column;\r\n    color: white;\r\n    align-items: center;\r\n    border-radius: 25px;\r\n    border-left: 10px solid #7C69C3;\r\n    box-shadow: 4px 4px 10px #00000033;\r\n  }\r\n\r\n  .card-calendario[_ngcontent-%COMP%]   div[_ngcontent-%COMP%] {\r\n    color: #464E7E;\r\n    border: black;\r\n    height: auto;\r\n    width: auto;\r\n    flex-grow: 1;\r\n    display: flex;\r\n    align-items: center;\r\n    font: bold 20px FS Elliot Pro;\r\n  }\r\n\r\n  .card-calendario[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]    > button[_ngcontent-%COMP%] {\r\n    background-color: #7C69C3;\r\n    color: white;\r\n    width: 296px;\r\n    height: 50px;\r\n    border-radius: 25px;\r\n    font: bold 20px FS Elliot Pro;\r\n    border: none;\r\n  }\r\n\r\n  div.card-lista-proceso[_ngcontent-%COMP%] {\r\n    width: auto;\r\n\r\n    min-width: 477px;\r\n    flex: auto;\r\n    display: flex;\r\n    flex-wrap: wrap;\r\n    vertical-align: middle;\r\n  }\r\n\r\n  table.listado-proceso[_ngcontent-%COMP%] {\r\n    color: white;\r\n    width: 100%;\r\n    margin: 25px 0;\r\n    margin-left: 5%;\r\n    margin-right: 5%;\r\n    text-align: center;\r\n    border-collapse: separate;\r\n    border-spacing: 0 6px;\r\n  }\r\n\r\n  table.listado-proceso[_ngcontent-%COMP%]   th[_ngcontent-%COMP%] {\r\n    background-color: #7C69C3;\r\n    font: bold 18px FS Elliot Pro;\r\n    height: 40px;\r\n    height: 40px;\r\n    font: bold 18px FS Elliot Pro;\r\n  }\r\n\r\n  table.listado-proceso[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\r\n    text-align: center;\r\n    background-color: white;\r\n    color: #707070;\r\n    font: 18px FS Elliot Pro;\r\n    height: 40px;\r\n    margin: 6px 0px;\r\n  }\r\n\r\n  .listado-proceso[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]:first-of-type {\r\n    border-top-left-radius: 25px;\r\n    border-bottom-left-radius: 25px;\r\n  }\r\n\r\n  .listado-proceso[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]:last-of-type {\r\n    border-top-right-radius: 25px;\r\n    border-bottom-right-radius: 25px;\r\n  }\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2Nlc29zLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxhQUFhO0lBQ2IsZUFBZTtFQUNqQjs7RUFFQTtJQUNFLFdBQVc7SUFDWCxhQUFhO0lBQ2IsZUFBZTtJQUNmLHNCQUFzQjtFQUN4Qjs7RUFFQTtJQUNFLFdBQVc7SUFDWCxZQUFZOztJQUVaLG1CQUFtQjtJQUNuQixnQkFBZ0I7RUFDbEI7O0VBRUE7SUFDRSxXQUFXO0lBQ1gsWUFBWTtJQUNaLG1CQUFtQjtJQUNuQixnQkFBZ0I7SUFDaEIsbUJBQW1CO0lBQ25CLGdCQUFnQjtFQUNsQjs7RUFFQTtJQUNFLFVBQVU7SUFDVixZQUFZO0lBQ1osWUFBWTtJQUNaLFlBQVk7SUFDWixpQkFBaUI7SUFDakIsY0FBYztJQUNkLDZCQUE2QjtFQUMvQjs7RUFDQTtJQUNFLHlCQUF5QjtJQUN6QixZQUFZO0lBQ1osa0NBQWtDO0lBQ2xDLCtCQUErQjtFQUNqQzs7RUFDQTtJQUNFLGtDQUFrQztJQUNsQyxxQ0FBcUM7RUFDdkM7O0VBRUE7SUFDRSxpQ0FBaUM7SUFDakMsb0NBQW9DO0VBQ3RDOztFQUVBO0lBQ0UseUJBQXlCO0lBQ3pCLFlBQVk7RUFDZDs7RUFFQTtJQUNFLGVBQWU7SUFDZixhQUFhO0lBQ2IsT0FBTztJQUNQLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIscUJBQXFCO0lBQ3JCLHVCQUF1QjtJQUN2QixtQkFBbUI7SUFDbkIsY0FBYztJQUNkLFVBQVU7RUFDWjs7RUFFQTtJQUNFLGlCQUFpQjtJQUNqQixhQUFhO0lBQ2IsV0FBVztJQUNYLGFBQWE7SUFDYixnQkFBZ0I7O0lBRWhCLGNBQWM7SUFDZCxnQkFBZ0I7SUFDaEIsZUFBZTtJQUNmLHNCQUFzQjtJQUN0QixZQUFZO0lBQ1osbUJBQW1CO0lBQ25CLG1CQUFtQjtJQUNuQiwrQkFBK0I7SUFDL0Isa0NBQWtDO0VBQ3BDOztFQUVBO0lBQ0UsY0FBYztJQUNkLGFBQWE7SUFDYixZQUFZO0lBQ1osV0FBVztJQUNYLFlBQVk7SUFDWixhQUFhO0lBQ2IsbUJBQW1CO0lBQ25CLDZCQUE2QjtFQUMvQjs7RUFFQTtJQUNFLHlCQUF5QjtJQUN6QixZQUFZO0lBQ1osWUFBWTtJQUNaLFlBQVk7SUFDWixtQkFBbUI7SUFDbkIsNkJBQTZCO0lBQzdCLFlBQVk7RUFDZDs7RUFFQTtJQUNFLFdBQVc7O0lBRVgsZ0JBQWdCO0lBQ2hCLFVBQVU7SUFDVixhQUFhO0lBQ2IsZUFBZTtJQUNmLHNCQUFzQjtFQUN4Qjs7RUFFQTtJQUNFLFlBQVk7SUFDWixXQUFXO0lBQ1gsY0FBYztJQUNkLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsa0JBQWtCO0lBQ2xCLHlCQUF5QjtJQUN6QixxQkFBcUI7RUFDdkI7O0VBRUE7SUFDRSx5QkFBeUI7SUFDekIsNkJBQTZCO0lBQzdCLFlBQVk7SUFDWixZQUFZO0lBQ1osNkJBQTZCO0VBQy9COztFQUNBO0lBQ0Usa0JBQWtCO0lBQ2xCLHVCQUF1QjtJQUN2QixjQUFjO0lBQ2Qsd0JBQXdCO0lBQ3hCLFlBQVk7SUFDWixlQUFlO0VBQ2pCOztFQUNBO0lBQ0UsNEJBQTRCO0lBQzVCLCtCQUErQjtFQUNqQzs7RUFDQTtJQUNFLDZCQUE2QjtJQUM3QixnQ0FBZ0M7RUFDbEMiLCJmaWxlIjoicHJvY2Vzb3MuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi53cmFwcGVyIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LXdyYXA6IHdyYXA7XHJcbiAgfVxyXG5cclxuICAuY29udGVudCB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LXdyYXA6IHdyYXA7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gIH1cclxuXHJcbiAgZGl2LmNvbnRhaW5lci1zZWxlY3Rvci1wcm9jZXNvIHtcclxuICAgIHdpZHRoOiBhdXRvO1xyXG4gICAgaGVpZ2h0OiA0NXB4O1xyXG5cclxuICAgIG1hcmdpbi1ib3R0b206IDUwcHg7XHJcbiAgICBtYXJnaW4tdG9wOiA1MHB4O1xyXG4gIH1cclxuXHJcbiAgLnNlbGVjdG9yLXByb2Nlc28ge1xyXG4gICAgd2lkdGg6IGF1dG87XHJcbiAgICBoZWlnaHQ6IDQ1cHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiAyNXB4O1xyXG4gICAgbWluLXdpZHRoOiAzMjhweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDUwcHg7XHJcbiAgICBtYXJnaW4tdG9wOiA1MHB4O1xyXG4gIH1cclxuXHJcbiAgLnNlbGVjdG9yLXByb2Nlc28gPiBidXR0b24ge1xyXG4gICAgd2lkdGg6IDUwJTtcclxuICAgIGhlaWdodDogNDVweDtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIGJvcmRlcjogbm9uZTtcclxuICAgIGJhY2tncm91bmQ6IHdoaXRlO1xyXG4gICAgY29sb3I6ICM0NjRFN0U7XHJcbiAgICBmb250OiBib2xkIDIwcHggRlMgRWxsaW90IFBybztcclxuICB9XHJcbiAgLnNlbGVjdG9yLXByb2Nlc28gPiBidXR0b246Zm9jdXMge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzdDNjlDMztcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIHRyYW5zaXRpb246IGJhY2tncm91bmQgMC4ycyBsaW5lYXI7XHJcbiAgICBib3gtc2hhZG93OiAzcHggM3B4IDVweCAjNDY0RTdFO1xyXG4gIH1cclxuICAjcmlnaHQtYnV0dG9uIHtcclxuICAgIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiAyNXB4IDI1cHg7XHJcbiAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMjVweCAyNXB4O1xyXG4gIH1cclxuXHJcbiAgI2xlZnQtYnV0dG9uIHtcclxuICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDI1cHggMjVweDtcclxuICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDI1cHggMjVweDtcclxuICB9XHJcblxyXG4gIC5ib3RvbkFjdGl2YWRve1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzAzNWZhNDtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICB9XHJcblxyXG4gIC5jb250YWluZXItcHJvY2Vzb3Mge1xyXG4gICAgYmFja2dyb3VuZDogcmVkO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGZsZXg6IDE7XHJcbiAgICBmbGV4LXdyYXA6IHdyYXA7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xyXG4gICAgYWxpZ24tY29udGVudDogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBib3JkZXItcmFkaXVzOiAyNXB4O1xyXG4gICAgbWFyZ2luOiAyNXB4IDA7XHJcbiAgICB3aWR0aDogOTUlO1xyXG4gIH1cclxuXHJcbiAgZGl2LmNhcmQtY2FsZW5kYXJpbyB7XHJcbiAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGhlaWdodDogMjg1cHg7XHJcbiAgICBtaW4td2lkdGg6IDQyMHB4O1xyXG4gICAgXHJcbiAgICBtYXJnaW46IDI1cHggMDtcclxuICAgIG1hcmdpbi1yaWdodDogNSU7XHJcbiAgICBtYXJnaW4tbGVmdDogNSU7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGJvcmRlci1yYWRpdXM6IDI1cHg7XHJcbiAgICBib3JkZXItbGVmdDogMTBweCBzb2xpZCAjN0M2OUMzO1xyXG4gICAgYm94LXNoYWRvdzogNHB4IDRweCAxMHB4ICMwMDAwMDAzMztcclxuICB9XHJcblxyXG4gIC5jYXJkLWNhbGVuZGFyaW8gZGl2IHtcclxuICAgIGNvbG9yOiAjNDY0RTdFO1xyXG4gICAgYm9yZGVyOiBibGFjaztcclxuICAgIGhlaWdodDogYXV0bztcclxuICAgIHdpZHRoOiBhdXRvO1xyXG4gICAgZmxleC1ncm93OiAxO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBmb250OiBib2xkIDIwcHggRlMgRWxsaW90IFBybztcclxuICB9XHJcblxyXG4gIC5jYXJkLWNhbGVuZGFyaW8gZGl2ID4gYnV0dG9uIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICM3QzY5QzM7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICB3aWR0aDogMjk2cHg7XHJcbiAgICBoZWlnaHQ6IDUwcHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiAyNXB4O1xyXG4gICAgZm9udDogYm9sZCAyMHB4IEZTIEVsbGlvdCBQcm87XHJcbiAgICBib3JkZXI6IG5vbmU7XHJcbiAgfVxyXG5cclxuICBkaXYuY2FyZC1saXN0YS1wcm9jZXNvIHtcclxuICAgIHdpZHRoOiBhdXRvO1xyXG5cclxuICAgIG1pbi13aWR0aDogNDc3cHg7XHJcbiAgICBmbGV4OiBhdXRvO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGZsZXgtd3JhcDogd3JhcDtcclxuICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XHJcbiAgfVxyXG5cclxuICB0YWJsZS5saXN0YWRvLXByb2Nlc28ge1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBtYXJnaW46IDI1cHggMDtcclxuICAgIG1hcmdpbi1sZWZ0OiA1JTtcclxuICAgIG1hcmdpbi1yaWdodDogNSU7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBib3JkZXItY29sbGFwc2U6IHNlcGFyYXRlO1xyXG4gICAgYm9yZGVyLXNwYWNpbmc6IDAgNnB4O1xyXG4gIH1cclxuXHJcbiAgdGFibGUubGlzdGFkby1wcm9jZXNvIHRoIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICM3QzY5QzM7XHJcbiAgICBmb250OiBib2xkIDE4cHggRlMgRWxsaW90IFBybztcclxuICAgIGhlaWdodDogNDBweDtcclxuICAgIGhlaWdodDogNDBweDtcclxuICAgIGZvbnQ6IGJvbGQgMThweCBGUyBFbGxpb3QgUHJvO1xyXG4gIH1cclxuICB0YWJsZS5saXN0YWRvLXByb2Nlc28gdGQge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgICBjb2xvcjogIzcwNzA3MDtcclxuICAgIGZvbnQ6IDE4cHggRlMgRWxsaW90IFBybztcclxuICAgIGhlaWdodDogNDBweDtcclxuICAgIG1hcmdpbjogNnB4IDBweDtcclxuICB9XHJcbiAgLmxpc3RhZG8tcHJvY2VzbyB0ciB0ZDpmaXJzdC1vZi10eXBlIHtcclxuICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDI1cHg7XHJcbiAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiAyNXB4O1xyXG4gIH1cclxuICAubGlzdGFkby1wcm9jZXNvIHRyIHRkOmxhc3Qtb2YtdHlwZSB7XHJcbiAgICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogMjVweDtcclxuICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAyNXB4O1xyXG4gIH1cclxuIl19 */"] });


/***/ }),

/***/ "GIVk":
/*!*********************************************************************!*\
  !*** ./src/app/pages/content/dashboard/procesos/procesos.module.ts ***!
  \*********************************************************************/
/*! exports provided: ProcesosModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProcesosModule", function() { return ProcesosModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _procesos_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./procesos-routing.module */ "oKwr");
/* harmony import */ var _procesos_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./procesos.component */ "+U3K");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




class ProcesosModule {
}
ProcesosModule.ɵfac = function ProcesosModule_Factory(t) { return new (t || ProcesosModule)(); };
ProcesosModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({ type: ProcesosModule });
ProcesosModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
            _procesos_routing_module__WEBPACK_IMPORTED_MODULE_1__["ProcesosRoutingModule"]
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](ProcesosModule, { declarations: [_procesos_component__WEBPACK_IMPORTED_MODULE_2__["ProcesosComponent"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
        _procesos_routing_module__WEBPACK_IMPORTED_MODULE_1__["ProcesosRoutingModule"]] }); })();


/***/ }),

/***/ "OGP1":
/*!**********************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/auditoria/procesos/procesos.component.ts ***!
  \**********************************************************************************/
/*! exports provided: ProcesosComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProcesosComponent", function() { return ProcesosComponent; });
/* harmony import */ var _ReduxStore_actions_usuarios_AUDGENUSUARIOS_actions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../../../../ReduxStore/actions/usuarios/AUDGENUSUARIOS.actions */ "n68H");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngrx/store */ "l7P3");
/* harmony import */ var _API_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../../API.service */ "iO9l");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "1kSV");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ngx-spinner */ "JqCM");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/services/auth.service */ "lGQG");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var ng_multiselect_dropdown__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ng-multiselect-dropdown */ "Egam");
/* harmony import */ var ngx_pagination__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ngx-pagination */ "oOf3");













function ProcesosComponent_section_0_div_26_div_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](6, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](7, " No existen registros para esta b\u00FAsqueda.");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} }
function ProcesosComponent_section_0_div_26_div_2_tr_13_Template(rf, ctx) { if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "td", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "td", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "td", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](7, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](8, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](9, "td", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](11, "td", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](12, "center");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](13, "img", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function ProcesosComponent_section_0_div_26_div_2_tr_13_Template_img_click_13_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r14); const itemAuditoria_r11 = ctx.$implicit; const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](4); return ctx_r13.openModal(itemAuditoria_r11); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const itemAuditoria_r11 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"]("", itemAuditoria_r11.PROCESOS.NOMBRE, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate2"]("", itemAuditoria_r11.USUARIO.NOMBRE, " ", itemAuditoria_r11.USUARIO.APELLIDO_PATERNO, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate2"]("", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind2"](7, 6, itemAuditoria_r11.FECHA, "dd/MM/yyyy"), " ", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind2"](8, 9, itemAuditoria_r11.FECHA, "mediumTime"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"]("", itemAuditoria_r11.PROCESOS.ACCION, " ");
} }
function ProcesosComponent_section_0_div_26_div_2_span_20_Template(rf, ctx) { if (rf & 1) {
    const _r16 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "span", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function ProcesosComponent_section_0_div_26_div_2_span_20_Template_span_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r16); _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵreference"](17); return _r7.previous(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1, " << ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} }
function ProcesosComponent_section_0_div_26_div_2_div_21_span_1_Template(rf, ctx) { if (rf & 1) {
    const _r22 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "span", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function ProcesosComponent_section_0_div_26_div_2_div_21_span_1_Template_span_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r22); const page_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit; _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵreference"](17); return _r7.setCurrent(page_r17.value); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const page_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](page_r17.label);
} }
function ProcesosComponent_section_0_div_26_div_2_div_21_div_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const page_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](page_r17.label);
} }
function ProcesosComponent_section_0_div_26_div_2_div_21_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](1, ProcesosComponent_section_0_div_26_div_2_div_21_span_1_Template, 2, 1, "span", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](2, ProcesosComponent_section_0_div_26_div_2_div_21_div_2_Template, 3, 1, "div", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const page_r17 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵreference"](17);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵclassProp"]("current", _r7.getCurrent() === page_r17.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", _r7.getCurrent() !== page_r17.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", _r7.getCurrent() === page_r17.value);
} }
function ProcesosComponent_section_0_div_26_div_2_span_23_Template(rf, ctx) { if (rf & 1) {
    const _r26 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "span", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function ProcesosComponent_section_0_div_26_div_2_span_23_Template_span_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r26); _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵreference"](17); return _r7.next(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1, " >> ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} }
const _c0 = function (a2) { return { id: "auditoria", itemsPerPage: 10, currentPage: a2 }; };
function ProcesosComponent_section_0_div_26_div_2_Template(rf, ctx) { if (rf & 1) {
    const _r28 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "table", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "th", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](4, "Proceso");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "th", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](6, "Usuario");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](7, "th", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](8, "Fecha");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](9, "th", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](10, "Acci\u00F3n");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](11, "th", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](12, "Detalle");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](13, ProcesosComponent_section_0_div_26_div_2_tr_13_Template, 14, 12, "tr", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](14, "paginate");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](15, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](16, "pagination-template", 34, 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("pageChange", function ProcesosComponent_section_0_div_26_div_2_Template_pagination_template_pageChange_16_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r28); const ctx_r27 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](3); return ctx_r27.paginaActual = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](18, "div", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](19, "div", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](20, ProcesosComponent_section_0_div_26_div_2_span_20_Template, 2, 0, "span", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](21, ProcesosComponent_section_0_div_26_div_2_div_21_Template, 3, 4, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](22, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](23, ProcesosComponent_section_0_div_26_div_2_span_23_Template, 2, 0, "span", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵreference"](17);
    const ListadoPantalla_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().ngIf;
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind2"](14, 8, ListadoPantalla_r3, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction1"](11, _c0, ctx_r5.paginaActual)));
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵclassProp"]("disabled", _r7.isFirstPage());
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", !_r7.isFirstPage());
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", _r7.pages);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵclassProp"]("disabled", _r7.isLastPage());
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", !_r7.isLastPage());
} }
function ProcesosComponent_section_0_div_26_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](1, ProcesosComponent_section_0_div_26_div_1_Template, 8, 0, "div", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](2, ProcesosComponent_section_0_div_26_div_2_Template, 24, 13, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ListadoPantalla_r3 = ctx.ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ListadoPantalla_r3.length === 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ListadoPantalla_r3.length !== 0);
} }
const _c1 = function () { return { standalone: true }; };
function ProcesosComponent_section_0_Template(rf, ctx) { if (rf & 1) {
    const _r31 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "section");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "ngx-spinner", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "p", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](3, " Cargando... ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](6, "Buscar por");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](7, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](8, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](9, "a", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function ProcesosComponent_section_0_Template_a_click_9_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r31); const ctx_r30 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); return ctx_r30.limpirarFiltro(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](10, "Eliminar Filtro ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](11, "img", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](12, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](13, "section", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](14, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](15, "ng-multiselect-dropdown", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function ProcesosComponent_section_0_Template_ng_multiselect_dropdown_ngModelChange_15_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r31); const ctx_r32 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); return ctx_r32.selectedItemsFiltroCatalogo = $event; })("onSelect", function ProcesosComponent_section_0_Template_ng_multiselect_dropdown_onSelect_15_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r31); const ctx_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); return ctx_r33.cambiarEtiquetaSeleccionadaGeneral("filtroCatalogo"); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](16, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](17, "ng-multiselect-dropdown", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function ProcesosComponent_section_0_Template_ng_multiselect_dropdown_ngModelChange_17_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r31); const ctx_r34 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); return ctx_r34.selectedItemsFiltroAccion = $event; })("onSelect", function ProcesosComponent_section_0_Template_ng_multiselect_dropdown_onSelect_17_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r31); const ctx_r35 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); return ctx_r35.cambiarEtiquetaSeleccionadaGeneral("filtroAccion"); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](18, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](19, "ng-multiselect-dropdown", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function ProcesosComponent_section_0_Template_ng_multiselect_dropdown_ngModelChange_19_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r31); const ctx_r36 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); return ctx_r36.selectedItemsFiltroCorreo = $event; })("onSelect", function ProcesosComponent_section_0_Template_ng_multiselect_dropdown_onSelect_19_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r31); const ctx_r37 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); return ctx_r37.cambiarEtiquetaSeleccionadaGeneral("filtroCorreo"); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](20, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](21, "input", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](22, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](23, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](24, "button", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function ProcesosComponent_section_0_Template_button_click_24_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r31); const ctx_r38 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); return ctx_r38.filtrar(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](25, "Buscar");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](26, ProcesosComponent_section_0_div_26_Template, 3, 2, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("fullScreen", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](11);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("formGroup", ctx_r0.filtroAuditoriaCatalogosForm);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("placeholder", "Proceso")("settings", ctx_r0.SettingsFiltroDeCatalogo)("data", ctx_r0.dropdownListFiltroCatalogo)("ngModel", ctx_r0.selectedItemsFiltroCatalogo)("ngModelOptions", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction0"](23, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("placeholder", "Acci\u00F3n")("settings", ctx_r0.SettingsFiltroDeAccion)("data", ctx_r0.dropdownListFiltroAccion)("ngModel", ctx_r0.selectedItemsFiltroAccion)("ngModelOptions", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction0"](24, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("placeholder", "Correo electr\u00F3nico")("settings", ctx_r0.SettingsFiltroDeCorreo)("data", ctx_r0.dropdownListFiltroCorreo)("ngModel", ctx_r0.selectedItemsFiltroCorreo)("ngModelOptions", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction0"](25, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpropertyInterpolate"]("max", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind2"](22, 20, ctx_r0.maxDate, "yyyy-MM-dd"));
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("value", ctx_r0.maxDate);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx_r0.ListadoPantalla);
} }
function ProcesosComponent_section_1_button_42_Template(rf, ctx) { if (rf & 1) {
    const _r41 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "button", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function ProcesosComponent_section_1_button_42_Template_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r41); const ctx_r40 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](2); return ctx_r40.redireccionProceso(ctx_r40.detalleCambios); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1, " Ver ejecuci\u00F3n ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} }
function ProcesosComponent_section_1_Template(rf, ctx) { if (rf & 1) {
    const _r43 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "section");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "div", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "p", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](6, "table", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](7, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](8, "th", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](9, "Realizado por");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](10, "th", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](11, "Fecha");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](12, "th", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](13, "Hora");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](14, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](15, "td", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](16);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](17, "td", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](18);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](19, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](20, "td", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](21);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](22, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](23, "table", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](24, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](25, "th", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](26, "Acci\u00F3n realizada");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](27, "th", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](28, "Resultado");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](29, "th", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](30, "Descripci\u00F3n");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](31, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](32, "td", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](33);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](34, "td", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](35);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](36, "td", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](37);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](38, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](39, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](40, "button", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function ProcesosComponent_section_1_Template_button_click_40_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r43); const ctx_r42 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); return ctx_r42.ocultarModal(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](41, " Cerrar ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](42, ProcesosComponent_section_1_button_42_Template, 2, 0, "button", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](ctx_r1.detalleCambios.proceso);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](11);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](ctx_r1.detalleCambios.usuario);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind2"](19, 8, ctx_r1.detalleCambios.fecha, "dd/MM/yyyy"));
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind2"](22, 11, ctx_r1.detalleCambios.fecha, "mediumTime"), " hrs ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](ctx_r1.detalleCambios.accion);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](ctx_r1.detalleCambios.estado);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](ctx_r1.detalleCambios.descripcion);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx_r1.valiarIdProceso(ctx_r1.detalleCambios));
} }
class ProcesosComponent {
    constructor(store, api, modalService, spinner, fb, router, authService) {
        this.store = store;
        this.api = api;
        this.modalService = modalService;
        this.spinner = spinner;
        this.fb = fb;
        this.router = router;
        this.authService = authService;
        this.itemsCorreos = [];
        this.itemsCatalogos = [];
        this.itemsAcciones = [];
        this.itemsTabla = [];
        this.dropdownListFiltroCatalogo = [];
        this.SettingsFiltroDeCatalogo = {};
        this.selectedItemsFiltroCatalogo = [];
        this.dropdownListFiltroAccion = [];
        this.SettingsFiltroDeAccion = {};
        this.selectedItemsFiltroAccion = [];
        this.dropdownListFiltroCorreo = [];
        this.SettingsFiltroDeCorreo = {};
        this.selectedItemsFiltroCorreo = [];
        this.paginaActual = 1;
        this.verModal = false;
        this.ListadoPantalla = [];
        this.ListadoOriginal = [];
        this.initSelects = () => {
            this.maxDate = new Date();
            this.filtroAuditoriaCatalogosForm = this.fb.group({
                filtroFecha: []
            });
            if (this.itemsCatalogos.length > 0) {
                let arregloCatalogos = [];
                for (let i in this.itemsCatalogos) {
                    arregloCatalogos.push({ item_id: this.itemsCatalogos[i], item_text: this.itemsCatalogos[i] });
                }
                this.dropdownListFiltroCatalogo = arregloCatalogos;
            }
            if (this.itemsAcciones.length > 0) {
                let arregloAcciones = [];
                for (let i in this.itemsAcciones) {
                    arregloAcciones.push({ item_id: this.itemsAcciones[i], item_text: this.itemsAcciones[i] });
                }
                this.dropdownListFiltroAccion = arregloAcciones;
            }
            if (this.itemsCorreos.length > 0) {
                let arregloCorreos = [];
                for (let i in this.itemsCorreos) {
                    arregloCorreos.push({ item_id: this.itemsCorreos[i], item_text: this.itemsCorreos[i] });
                }
                this.dropdownListFiltroCorreo = arregloCorreos;
            }
            this.SettingsFiltroDeCatalogo = {
                singleSelection: false,
                idField: 'item_id',
                textField: 'item_text',
                allowSearchFilter: false,
                clearSearchFilter: false,
                enableCheckAll: false,
                maxHeight: 200,
                itemsShowLimit: 3,
            };
            this.SettingsFiltroDeAccion = {
                singleSelection: false,
                idField: 'item_id',
                textField: 'item_text',
                allowSearchFilter: false,
                clearSearchFilter: false,
                enableCheckAll: false,
                maxHeight: 200,
                itemsShowLimit: 3,
            };
            this.SettingsFiltroDeCorreo = {
                singleSelection: false,
                idField: 'item_id',
                textField: 'item_text',
                allowSearchFilter: false,
                clearSearchFilter: false,
                enableCheckAll: false,
                maxHeight: 200,
                itemsShowLimit: 3,
            };
        };
        this.limpirarFiltro = () => {
            this.selectedItemsFiltroCatalogo = [];
            this.selectedItemsFiltroAccion = [];
            this.selectedItemsFiltroCorreo = [];
            this.ListadoPantalla = this.ListadoOriginal;
            this.filtroAuditoriaCatalogosForm.reset();
        };
        this.filtrar = () => {
            this.spinner.show();
            let FiltrarCatalogo = null;
            let FiltrarAccion = null;
            let FiltrarCorreo = null;
            let FiltrarFecha = this.filtroAuditoriaCatalogosForm.get('filtroFecha').value; //yyyy-mm-dd
            if (this.selectedItemsFiltroCatalogo.length !== 0) {
                let arrayFiltroCatalogo = [];
                this.selectedItemsFiltroCatalogo.forEach((e) => {
                    arrayFiltroCatalogo.push(e.item_id);
                });
                FiltrarCatalogo = arrayFiltroCatalogo;
            }
            //console.log(this.selectedItemsFiltroAccion)
            if (this.selectedItemsFiltroAccion.length !== 0) {
                let arrayFiltroAccion = [];
                this.selectedItemsFiltroAccion.forEach((e) => {
                    arrayFiltroAccion.push(e.item_id);
                });
                FiltrarAccion = arrayFiltroAccion;
            }
            if (this.selectedItemsFiltroCorreo.length !== 0) {
                let arrayFiltroCorreo = [];
                this.selectedItemsFiltroCorreo.forEach((e) => {
                    arrayFiltroCorreo.push(e.item_id);
                });
                FiltrarCorreo = arrayFiltroCorreo;
            }
            this.ListadoPantalla = this.filtrarCatalogosConAtributos(this.ListadoOriginal, FiltrarCatalogo, FiltrarAccion, FiltrarCorreo, FiltrarFecha);
            setTimeout(() => {
                this.spinner.hide();
            }, 300);
        };
        this.redireccionProceso = (detalleCambios) => {
            const url = 'procesos/diurno/' + detalleCambios.sigla;
            localStorage.setItem('audProcesos', JSON.stringify(detalleCambios));
            this.router.navigateByUrl(url).then(() => {
                //console.log("navigateByUrl", detalleCambios.proceso)
            });
        };
    }
    ngOnDestroy() {
        this.store.dispatch(Object(_ReduxStore_actions_usuarios_AUDGENUSUARIOS_actions__WEBPACK_IMPORTED_MODULE_0__["UnsetAUDGENUSUARIO"])());
    }
    enProceso() {
        return false;
    }
    mostrarDetalle() {
        return this.verModal;
    }
    cambiarEtiquetaSeleccionadaGeneral(elemento) {
        setTimeout(() => {
            $('#' + elemento)
                .find('.selected-item')
                .attr('class', 'etiquetasCatalogos');
        }, 1);
    }
    ngOnInit() {
        this.AUDGENUSUARIOS$ = this.store.select(({ AUDGENUSUARIOS }) => AUDGENUSUARIOS.AUDGENUSUARIOS).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])(res => {
            if (res === null)
                return res;
            else
                return res.slice().sort(function (a, b) { return new Date(b.FECHA).getTime() - new Date(a.FECHA).getTime(); });
        }));
        this.store.select(({ AUDGENUSUARIOS }) => AUDGENUSUARIOS.AUDGENUSUARIOS).subscribe(res => {
            for (let i in res) {
                if (!this.itemsCorreos.includes(res[i].CORREO)) {
                    this.itemsCorreos.push(res[i].CORREO);
                }
            }
            for (let i in res) {
                if (!this.itemsCatalogos.includes(res[i].PROCESOS.NOMBRE)) {
                    this.itemsCatalogos.push(res[i].PROCESOS.NOMBRE);
                }
            }
            for (let i in res) {
                if (!this.itemsAcciones.includes(res[i].PROCESOS.ACCION)) {
                    this.itemsAcciones.push(res[i].PROCESOS.ACCION);
                }
            }
            this.itemsCatalogos.sort();
            this.itemsAcciones.sort();
            this.itemsCorreos.sort();
            if (res === null) {
                //console.log("response", res)
            }
            else {
                let resp = res.slice().sort(function (a, b) { return new Date(b.FECHA).getTime() - new Date(a.FECHA).getTime(); });
                //console.log("response slice", resp)
                this.ListadoOriginal = resp;
            }
            this.ListadoPantalla = this.ListadoOriginal;
            this.initSelects();
        });
        this.store.dispatch(Object(_ReduxStore_actions_usuarios_AUDGENUSUARIOS_actions__WEBPACK_IMPORTED_MODULE_0__["LoadAUDGENUSUARIOS"])({ consult: { MODULO: 'PROCESOS' } }));
        /*
        this.api.ListAUDGENUSUARIOS('PROCESOS').then(res => {
          console.log("Response ListAUDGENUSUARIOS", res)
        })*/
    }
    ocultarModal() {
        this.verModal = false;
    }
    openModal(objetoDetalle) {
        //console.log("objetoDetalle", objetoDetalle)
        this.detalleCambios = {
            idProceso: objetoDetalle.PROCESOS.ID_PROCESO,
            sigla: objetoDetalle.PROCESOS.SIGLA,
            proceso: objetoDetalle.PROCESOS.NOMBRE,
            usuario: objetoDetalle.USUARIO.NOMBRE + ' ' + objetoDetalle.USUARIO.APELLIDO_PATERNO,
            fecha: objetoDetalle.FECHA,
            accion: objetoDetalle.PROCESOS.ACCION,
            estado: objetoDetalle.PROCESOS.ESTADO,
            descripcion: objetoDetalle.PROCESOS.DESCRIPCION,
        };
        //console.log("detalleCambios", this.detalleCambios)
        this.verModal = true;
    }
    filtrarCatalogosConAtributos(ListadoOriginal, FiltrarCatalogo, FiltrarAccion, FiltrarCorreo, FiltrarFecha) {
        let response = ListadoOriginal;
        if (FiltrarCatalogo != null) {
            let arrayTempPermiso = [];
            FiltrarCatalogo.forEach((FiltrarCatalogo) => {
                arrayTempPermiso = [
                    ...arrayTempPermiso,
                    ...response.filter((e) => e.PROCESOS.NOMBRE === FiltrarCatalogo),
                ];
            });
            response = arrayTempPermiso;
        }
        if (FiltrarAccion != null) {
            let arrayTempPermiso = [];
            FiltrarAccion.forEach((FiltrarAccion) => {
                arrayTempPermiso = [
                    ...arrayTempPermiso,
                    ...response.filter((e) => e.PROCESOS.ACCION === FiltrarAccion),
                ];
            });
            response = arrayTempPermiso;
        }
        if (FiltrarCorreo != null) {
            let arrayTempPermiso = [];
            FiltrarCorreo.forEach((FiltrarCorreo) => {
                arrayTempPermiso = [
                    ...arrayTempPermiso,
                    ...response.filter((e) => e.CORREO === FiltrarCorreo),
                ];
            });
            response = arrayTempPermiso;
        }
        if (FiltrarFecha != null) {
            let arrayTempFecha = [];
            arrayTempFecha = response.filter((e) => e.FECHA.includes(FiltrarFecha));
            response = arrayTempFecha;
        }
        return response;
    }
    valiarIdProceso(detalleCambios) {
        //console.log('idProceso', detalleCambios.idProceso)
        let flag = false;
        if (detalleCambios.idProceso) {
            if (detalleCambios.idProceso.length > 0) {
                flag = true;
            }
        }
        return flag;
    }
}
ProcesosComponent.ɵfac = function ProcesosComponent_Factory(t) { return new (t || ProcesosComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_ngrx_store__WEBPACK_IMPORTED_MODULE_3__["Store"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_API_service__WEBPACK_IMPORTED_MODULE_4__["APIService"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__["NgbModal"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_6__["NgxSpinnerService"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormBuilder"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_9__["AuthService"])); };
ProcesosComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({ type: ProcesosComponent, selectors: [["app-procesos"]], decls: 2, vars: 2, consts: [[4, "ngIf"], ["bdColor", "rgba(0,0,0,0.5)", "size", "default", "color", "#fff", "type", "ball-scale-ripple", 3, "fullScreen"], [2, "color", "white"], [1, "card-busqueda"], [1, "mt-4"], [2, "text-align", "right", "width", "100%", "justify-content", "flex-end", "direction", "rtl"], [2, "margin-right", "10%"], [1, "limpiarFiltro", 3, "click"], ["src", "assets/icons/Eliminar.svg", 1, "tamanioFiltroIcono"], ["name", "filtros", 3, "formGroup"], [1, "mt-3"], [1, "col2-row2"], ["id", "filtroCatalogo", 2, "width", "80%", "padding-left", "10px", 3, "placeholder", "settings", "data", "ngModel", "ngModelOptions", "ngModelChange", "onSelect"], ["id", "filtroAccion", 2, "width", "80%", 3, "placeholder", "settings", "data", "ngModel", "ngModelOptions", "ngModelChange", "onSelect"], ["id", "filtroCorreo", 2, "width", "80%", "padding-left", "10px", 3, "placeholder", "settings", "data", "ngModel", "ngModelOptions", "ngModelChange", "onSelect"], ["type", "date", "placeholder", "dd-MM-yyyy", "onfocus", "(this.type='date')", "id", "filtroFecha", "formControlName", "filtroFecha", "name", "filtroFecha", 2, "width", "80%", "padding-left", "10px", 3, "value", "max"], [2, "cursor", "pointer", 3, "click"], ["class", "d-flex col-md-12 col-sm-12 col-xs-12 col-lg-12 col-xl-12 justify-content-center", 4, "ngIf"], [1, "d-flex", "col-md-12", "col-sm-12", "col-xs-12", "col-lg-12", "col-xl-12", "justify-content-center"], ["class", "row justify-content-center", 4, "ngIf"], ["class", "card-lista-design-general", "style", "overflow-x: auto", 4, "ngIf"], [1, "row", "justify-content-center"], [1, "align-self-center"], [1, "d-flex", "flex-column", 2, "width", "504px"], [1, "descripcionNoAuditoria", 2, "margin-top", "34px"], [1, "row"], [1, "col-12"], [1, "card-lista-design-general", 2, "overflow-x", "auto"], [1, "table", "listado-design-general"], [2, "padding-left", "40px", "max-width", "300px"], [2, "padding-left", "30px", "max-width", "300px"], [2, "padding-left", "30px", "max-width", "150px"], [4, "ngFor", "ngForOf"], [1, "paginator", "align-items-left"], ["id", "auditoria", 1, "ngx-pagination", 3, "pageChange"], ["p", "paginationApi"], [1, "custom-pagination"], [1, "pagination-previous"], [3, "click", 4, "ngIf"], ["class", "page-number", 3, "current", 4, "ngFor", "ngForOf"], [1, "pagination-next"], [1, "justify-content-center", 2, "width", "200px"], [1, "detalle-icon", 2, "cursor", "pointer", 3, "click"], [3, "click"], [1, "page-number"], [1, "col-12", "row", "justify-content-center"], [1, "titulo-modal"], [1, "btn", "bottonCerrarModal", 3, "click"], ["class", "btn bottonContinuarModal", 3, "click", 4, "ngIf"], [1, "btn", "bottonContinuarModal", 3, "click"]], template: function ProcesosComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](0, ProcesosComponent_section_0_Template, 27, 26, "section", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](1, ProcesosComponent_section_1_Template, 43, 14, "section", 0);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", !ctx.mostrarDetalle());
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.mostrarDetalle());
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_10__["NgIf"], ngx_spinner__WEBPACK_IMPORTED_MODULE_6__["NgxSpinnerComponent"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormGroupDirective"], ng_multiselect_dropdown__WEBPACK_IMPORTED_MODULE_11__["MultiSelectComponent"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__["NgModel"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControlName"], _angular_common__WEBPACK_IMPORTED_MODULE_10__["NgForOf"], ngx_pagination__WEBPACK_IMPORTED_MODULE_12__["PaginationControlsDirective"]], pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_10__["DatePipe"], ngx_pagination__WEBPACK_IMPORTED_MODULE_12__["PaginatePipe"]], styles: [".center[_ngcontent-%COMP%] {\r\n  display: block;\r\n  margin-left: auto;\r\n  margin-right: auto;\r\n}\r\n\r\n.wrapper[_ngcontent-%COMP%] {\r\n  display: flex;\r\n  flex-wrap: wrap;\r\n}\r\n\r\n.content[_ngcontent-%COMP%] {\r\n  width: 100%;\r\n  display: flex;\r\n  flex-wrap: wrap;\r\n  flex-direction: column;\r\n}\r\n\r\ndiv.card-busqueda[_ngcontent-%COMP%] {\r\n  width: 90%;\r\n  background: #ffffff 0% 0% no-repeat padding-box;\r\n  border-radius: 30px;\r\n  opacity: 1;\r\n  display: flex;\r\n  margin: 25px 0;\r\n  margin-right: 5%;\r\n  margin-left: 5%;\r\n  flex-direction: column;\r\n  align-items: center;\r\n  border-radius: 25px;\r\n  border-left: 10px solid #035fa4;\r\n  box-shadow: 4px 4px 10px #00000033;\r\n}\r\n\r\n.card-busqueda[_ngcontent-%COMP%]   div[_ngcontent-%COMP%] {\r\n  color: #035fa4;\r\n  border: black;\r\n  height: auto;\r\n  width: auto;\r\n  flex-grow: 1;\r\n  display: flex;\r\n  align-items: center;\r\n  font: bold 20px FS Elliot Pro;\r\n}\r\n\r\n.card-busqueda[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]    > button[_ngcontent-%COMP%] {\r\n  background-color: #0091da;\r\n  color: white;\r\n  width: 296px;\r\n  height: 50px;\r\n  border-radius: 25px;\r\n  font: bold 20px FS Elliot Pro;\r\n  border: none;\r\n}\r\n\r\ndiv.card-lista-design-general[_ngcontent-%COMP%] {\r\n  width: auto;\r\n  min-width: 477px;\r\n  flex: auto;\r\n  display: flex;\r\n  flex-wrap: wrap;\r\n  vertical-align: middle;\r\n}\r\n\r\ntable.listado-design-general[_ngcontent-%COMP%]   th[_ngcontent-%COMP%] {\r\n  background-color: #035fa4;\r\n  font: bold 18px FS Elliot Pro;\r\n  height: 40px;\r\n  height: 40px;\r\n  font: bold 18px FS Elliot Pro;\r\n}\r\n\r\nsection[_ngcontent-%COMP%] {\r\n  display: flex;\r\n  flex-wrap: wrap;\r\n  justify-content: space-between;\r\n}\r\n\r\n.col2-row2[_ngcontent-%COMP%] {\r\n  display: flex;\r\n  justify-content: center;\r\n  align-items: center;\r\n  flex-grow: 0;\r\n  flex-shrink: 0;\r\n  flex-basis: 50%;\r\n  margin-bottom: 1.5%;\r\n}\r\n\r\n.selectList[_ngcontent-%COMP%] {\r\n  text-align: left;\r\n  font: normal normal normal 18px/45px FS Elliot Pro;\r\n  letter-spacing: 0px;\r\n  color: #707070;\r\n  width: 296px;\r\n  height: 35px;\r\n  font: bold 18px FS Elliot Pro;\r\n  background: #ffffff 0% 0% no-repeat padding-box;\r\n  border: 1px solid #d6d6d6;\r\n  border-radius: 9px;\r\n  opacity: 1;\r\n}\r\n\r\n#correo[_ngcontent-%COMP%] {\r\n  width: 100%;\r\n}\r\n\r\n#correo[_ngcontent-%COMP%]   .selected-item[_ngcontent-%COMP%] {\r\n  width: 200px !important;\r\n}\r\n\r\n.limpiarFiltro[_ngcontent-%COMP%] {\r\n  text-align: right;\r\n  text-decoration: underline;\r\n  font: normal normal normal 14px/22px FS Elliot Pro;\r\n  letter-spacing: 0px;\r\n  -webkit-text-decoration: underline #0091da !important;\r\n          text-decoration: underline #0091da !important;\r\n  color: #0091da !important;\r\n}\r\n\r\n.limpiarFiltro[_ngcontent-%COMP%]:hover {\r\n  cursor: pointer;\r\n}\r\n\r\n.tamanioFiltroIcono[_ngcontent-%COMP%] {\r\n  width: 12px;\r\n  height: 12px;\r\n  margin-top: -4px;\r\n}\r\n\r\n.modal-content[_ngcontent-%COMP%] {\r\n  background-color: red !important;\r\n}\r\n\r\n.detalle-icon[_ngcontent-%COMP%] {\r\n  background: transparent url(\"/../../../../assets/icons/icono-detalle.svg\") 0%\r\n    0% no-repeat padding-box;\r\n  width: 30px;\r\n  height: 30px;\r\n  opacity: 1;\r\n  margin: 0 15px;\r\n  padding: 15px;\r\n}\r\n\r\n.bottonCerrarModal[_ngcontent-%COMP%] {\r\n  border: 2px solid #0091da;\r\n  border-radius: 30px;\r\n  opacity: 1;\r\n  width: 184px;\r\n  text-decoration: none;\r\n  height: 48px;\r\n  color: #0091da;\r\n  margin-right: 22px;\r\n  margin-top: 15px;\r\n  margin-bottom: 15px;\r\n  font: normal normal bold 20px/25px FS Elliot Pro;\r\n}\r\n\r\n.bottonContinuarModal[_ngcontent-%COMP%] {\r\n  background: #0091da 0% 0% no-repeat padding-box;  \r\n  color: #ffffff;\r\n  border-radius: 30px;\r\n  opacity: 1;\r\n  width: 195px;\r\n  text-decoration: none;\r\n  height: 48px;\r\n  margin-right: 22px;\r\n  margin-top: 15px;\r\n  margin-bottom: 15px;\r\n  font: normal normal bold 20px/25px FS Elliot Pro;\r\n}\r\n\r\n.titulo[_ngcontent-%COMP%] {\r\n  font: bold 18px FS Elliot Pro;\r\n  color: #035fa4;\r\n}\r\n\r\n.titulo-modal[_ngcontent-%COMP%] {\r\n  font: bold 24px FS Elliot Pro;\r\n  color: #035fa4;\r\n}\r\n\r\n.texto-modal[_ngcontent-%COMP%] {\r\n  font: 18px FS Elliot Pro;\r\n  color: #035fa4;\r\n}\r\n\r\n.paginator[_ngcontent-%COMP%] {\r\n  margin-left: 5%;\r\n  margin-right: 5%;\r\n  margin-bottom: 5%;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2Nlc29zLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxjQUFjO0VBQ2QsaUJBQWlCO0VBQ2pCLGtCQUFrQjtBQUNwQjs7QUFFQTtFQUNFLGFBQWE7RUFDYixlQUFlO0FBQ2pCOztBQUVBO0VBQ0UsV0FBVztFQUNYLGFBQWE7RUFDYixlQUFlO0VBQ2Ysc0JBQXNCO0FBQ3hCOztBQUVBO0VBQ0UsVUFBVTtFQUNWLCtDQUErQztFQUMvQyxtQkFBbUI7RUFDbkIsVUFBVTtFQUNWLGFBQWE7RUFDYixjQUFjO0VBQ2QsZ0JBQWdCO0VBQ2hCLGVBQWU7RUFDZixzQkFBc0I7RUFDdEIsbUJBQW1CO0VBQ25CLG1CQUFtQjtFQUNuQiwrQkFBK0I7RUFDL0Isa0NBQWtDO0FBQ3BDOztBQUVBO0VBQ0UsY0FBYztFQUNkLGFBQWE7RUFDYixZQUFZO0VBQ1osV0FBVztFQUNYLFlBQVk7RUFDWixhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CLDZCQUE2QjtBQUMvQjs7QUFFQTtFQUNFLHlCQUF5QjtFQUN6QixZQUFZO0VBQ1osWUFBWTtFQUNaLFlBQVk7RUFDWixtQkFBbUI7RUFDbkIsNkJBQTZCO0VBQzdCLFlBQVk7QUFDZDs7QUFFQTtFQUNFLFdBQVc7RUFDWCxnQkFBZ0I7RUFDaEIsVUFBVTtFQUNWLGFBQWE7RUFDYixlQUFlO0VBQ2Ysc0JBQXNCO0FBQ3hCOztBQUVBO0VBQ0UseUJBQXlCO0VBQ3pCLDZCQUE2QjtFQUM3QixZQUFZO0VBQ1osWUFBWTtFQUNaLDZCQUE2QjtBQUMvQjs7QUFFQTtFQUNFLGFBQWE7RUFDYixlQUFlO0VBQ2YsOEJBQThCO0FBQ2hDOztBQUVBO0VBQ0UsYUFBYTtFQUNiLHVCQUF1QjtFQUN2QixtQkFBbUI7RUFDbkIsWUFBWTtFQUNaLGNBQWM7RUFDZCxlQUFlO0VBQ2YsbUJBQW1CO0FBQ3JCOztBQUVBO0VBQ0UsZ0JBQWdCO0VBQ2hCLGtEQUFrRDtFQUNsRCxtQkFBbUI7RUFDbkIsY0FBYztFQUNkLFlBQVk7RUFDWixZQUFZO0VBQ1osNkJBQTZCO0VBQzdCLCtDQUErQztFQUMvQyx5QkFBeUI7RUFDekIsa0JBQWtCO0VBQ2xCLFVBQVU7QUFDWjs7QUFFQTtFQUNFLFdBQVc7QUFDYjs7QUFFQTtFQUNFLHVCQUF1QjtBQUN6Qjs7QUFFQTtFQUNFLGlCQUFpQjtFQUNqQiwwQkFBMEI7RUFDMUIsa0RBQWtEO0VBQ2xELG1CQUFtQjtFQUNuQixxREFBNkM7VUFBN0MsNkNBQTZDO0VBQzdDLHlCQUF5QjtBQUMzQjs7QUFFQTtFQUNFLGVBQWU7QUFDakI7O0FBRUE7RUFDRSxXQUFXO0VBQ1gsWUFBWTtFQUNaLGdCQUFnQjtBQUNsQjs7QUFFQTtFQUNFLGdDQUFnQztBQUNsQzs7QUFFQTtFQUNFOzRCQUMwQjtFQUMxQixXQUFXO0VBQ1gsWUFBWTtFQUNaLFVBQVU7RUFDVixjQUFjO0VBQ2QsYUFBYTtBQUNmOztBQUVBO0VBQ0UseUJBQXlCO0VBQ3pCLG1CQUFtQjtFQUNuQixVQUFVO0VBQ1YsWUFBWTtFQUNaLHFCQUFxQjtFQUNyQixZQUFZO0VBQ1osY0FBYztFQUNkLGtCQUFrQjtFQUNsQixnQkFBZ0I7RUFDaEIsbUJBQW1CO0VBQ25CLGdEQUFnRDtBQUNsRDs7QUFFQTtFQUNFLCtDQUErQztFQUMvQyxjQUFjO0VBQ2QsbUJBQW1CO0VBQ25CLFVBQVU7RUFDVixZQUFZO0VBQ1oscUJBQXFCO0VBQ3JCLFlBQVk7RUFDWixrQkFBa0I7RUFDbEIsZ0JBQWdCO0VBQ2hCLG1CQUFtQjtFQUNuQixnREFBZ0Q7QUFDbEQ7O0FBRUE7RUFDRSw2QkFBNkI7RUFDN0IsY0FBYztBQUNoQjs7QUFFQTtFQUNFLDZCQUE2QjtFQUM3QixjQUFjO0FBQ2hCOztBQUVBO0VBQ0Usd0JBQXdCO0VBQ3hCLGNBQWM7QUFDaEI7O0FBRUE7RUFDRSxlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLGlCQUFpQjtBQUNuQiIsImZpbGUiOiJwcm9jZXNvcy5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNlbnRlciB7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgbWFyZ2luLWxlZnQ6IGF1dG87XHJcbiAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xyXG59XHJcblxyXG4ud3JhcHBlciB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LXdyYXA6IHdyYXA7XHJcbn1cclxuXHJcbi5jb250ZW50IHtcclxuICB3aWR0aDogMTAwJTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtd3JhcDogd3JhcDtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG59XHJcblxyXG5kaXYuY2FyZC1idXNxdWVkYSB7XHJcbiAgd2lkdGg6IDkwJTtcclxuICBiYWNrZ3JvdW5kOiAjZmZmZmZmIDAlIDAlIG5vLXJlcGVhdCBwYWRkaW5nLWJveDtcclxuICBib3JkZXItcmFkaXVzOiAzMHB4O1xyXG4gIG9wYWNpdHk6IDE7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBtYXJnaW46IDI1cHggMDtcclxuICBtYXJnaW4tcmlnaHQ6IDUlO1xyXG4gIG1hcmdpbi1sZWZ0OiA1JTtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgYm9yZGVyLXJhZGl1czogMjVweDtcclxuICBib3JkZXItbGVmdDogMTBweCBzb2xpZCAjMDM1ZmE0O1xyXG4gIGJveC1zaGFkb3c6IDRweCA0cHggMTBweCAjMDAwMDAwMzM7XHJcbn1cclxuXHJcbi5jYXJkLWJ1c3F1ZWRhIGRpdiB7XHJcbiAgY29sb3I6ICMwMzVmYTQ7XHJcbiAgYm9yZGVyOiBibGFjaztcclxuICBoZWlnaHQ6IGF1dG87XHJcbiAgd2lkdGg6IGF1dG87XHJcbiAgZmxleC1ncm93OiAxO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBmb250OiBib2xkIDIwcHggRlMgRWxsaW90IFBybztcclxufVxyXG5cclxuLmNhcmQtYnVzcXVlZGEgZGl2ID4gYnV0dG9uIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDA5MWRhO1xyXG4gIGNvbG9yOiB3aGl0ZTtcclxuICB3aWR0aDogMjk2cHg7XHJcbiAgaGVpZ2h0OiA1MHB4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDI1cHg7XHJcbiAgZm9udDogYm9sZCAyMHB4IEZTIEVsbGlvdCBQcm87XHJcbiAgYm9yZGVyOiBub25lO1xyXG59XHJcblxyXG5kaXYuY2FyZC1saXN0YS1kZXNpZ24tZ2VuZXJhbCB7XHJcbiAgd2lkdGg6IGF1dG87XHJcbiAgbWluLXdpZHRoOiA0NzdweDtcclxuICBmbGV4OiBhdXRvO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC13cmFwOiB3cmFwO1xyXG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XHJcbn1cclxuXHJcbnRhYmxlLmxpc3RhZG8tZGVzaWduLWdlbmVyYWwgdGgge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICMwMzVmYTQ7XHJcbiAgZm9udDogYm9sZCAxOHB4IEZTIEVsbGlvdCBQcm87XHJcbiAgaGVpZ2h0OiA0MHB4O1xyXG4gIGhlaWdodDogNDBweDtcclxuICBmb250OiBib2xkIDE4cHggRlMgRWxsaW90IFBybztcclxufVxyXG5cclxuc2VjdGlvbiB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LXdyYXA6IHdyYXA7XHJcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG59XHJcblxyXG4uY29sMi1yb3cyIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgZmxleC1ncm93OiAwO1xyXG4gIGZsZXgtc2hyaW5rOiAwO1xyXG4gIGZsZXgtYmFzaXM6IDUwJTtcclxuICBtYXJnaW4tYm90dG9tOiAxLjUlO1xyXG59XHJcblxyXG4uc2VsZWN0TGlzdCB7XHJcbiAgdGV4dC1hbGlnbjogbGVmdDtcclxuICBmb250OiBub3JtYWwgbm9ybWFsIG5vcm1hbCAxOHB4LzQ1cHggRlMgRWxsaW90IFBybztcclxuICBsZXR0ZXItc3BhY2luZzogMHB4O1xyXG4gIGNvbG9yOiAjNzA3MDcwO1xyXG4gIHdpZHRoOiAyOTZweDtcclxuICBoZWlnaHQ6IDM1cHg7XHJcbiAgZm9udDogYm9sZCAxOHB4IEZTIEVsbGlvdCBQcm87XHJcbiAgYmFja2dyb3VuZDogI2ZmZmZmZiAwJSAwJSBuby1yZXBlYXQgcGFkZGluZy1ib3g7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgI2Q2ZDZkNjtcclxuICBib3JkZXItcmFkaXVzOiA5cHg7XHJcbiAgb3BhY2l0eTogMTtcclxufVxyXG5cclxuI2NvcnJlbyB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbn1cclxuXHJcbiNjb3JyZW8gLnNlbGVjdGVkLWl0ZW0ge1xyXG4gIHdpZHRoOiAyMDBweCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4ubGltcGlhckZpbHRybyB7XHJcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XHJcbiAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XHJcbiAgZm9udDogbm9ybWFsIG5vcm1hbCBub3JtYWwgMTRweC8yMnB4IEZTIEVsbGlvdCBQcm87XHJcbiAgbGV0dGVyLXNwYWNpbmc6IDBweDtcclxuICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZSAjMDA5MWRhICFpbXBvcnRhbnQ7XHJcbiAgY29sb3I6ICMwMDkxZGEgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmxpbXBpYXJGaWx0cm86aG92ZXIge1xyXG4gIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG5cclxuLnRhbWFuaW9GaWx0cm9JY29ubyB7XHJcbiAgd2lkdGg6IDEycHg7XHJcbiAgaGVpZ2h0OiAxMnB4O1xyXG4gIG1hcmdpbi10b3A6IC00cHg7XHJcbn1cclxuXHJcbi5tb2RhbC1jb250ZW50IHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiByZWQgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmRldGFsbGUtaWNvbiB7XHJcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQgdXJsKFwiLy4uLy4uLy4uLy4uL2Fzc2V0cy9pY29ucy9pY29uby1kZXRhbGxlLnN2Z1wiKSAwJVxyXG4gICAgMCUgbm8tcmVwZWF0IHBhZGRpbmctYm94O1xyXG4gIHdpZHRoOiAzMHB4O1xyXG4gIGhlaWdodDogMzBweDtcclxuICBvcGFjaXR5OiAxO1xyXG4gIG1hcmdpbjogMCAxNXB4O1xyXG4gIHBhZGRpbmc6IDE1cHg7XHJcbn1cclxuXHJcbi5ib3R0b25DZXJyYXJNb2RhbCB7XHJcbiAgYm9yZGVyOiAycHggc29saWQgIzAwOTFkYTtcclxuICBib3JkZXItcmFkaXVzOiAzMHB4O1xyXG4gIG9wYWNpdHk6IDE7XHJcbiAgd2lkdGg6IDE4NHB4O1xyXG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuICBoZWlnaHQ6IDQ4cHg7XHJcbiAgY29sb3I6ICMwMDkxZGE7XHJcbiAgbWFyZ2luLXJpZ2h0OiAyMnB4O1xyXG4gIG1hcmdpbi10b3A6IDE1cHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTVweDtcclxuICBmb250OiBub3JtYWwgbm9ybWFsIGJvbGQgMjBweC8yNXB4IEZTIEVsbGlvdCBQcm87XHJcbn1cclxuXHJcbi5ib3R0b25Db250aW51YXJNb2RhbCB7XHJcbiAgYmFja2dyb3VuZDogIzAwOTFkYSAwJSAwJSBuby1yZXBlYXQgcGFkZGluZy1ib3g7ICBcclxuICBjb2xvcjogI2ZmZmZmZjtcclxuICBib3JkZXItcmFkaXVzOiAzMHB4O1xyXG4gIG9wYWNpdHk6IDE7XHJcbiAgd2lkdGg6IDE5NXB4O1xyXG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuICBoZWlnaHQ6IDQ4cHg7XHJcbiAgbWFyZ2luLXJpZ2h0OiAyMnB4O1xyXG4gIG1hcmdpbi10b3A6IDE1cHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTVweDtcclxuICBmb250OiBub3JtYWwgbm9ybWFsIGJvbGQgMjBweC8yNXB4IEZTIEVsbGlvdCBQcm87XHJcbn1cclxuXHJcbi50aXR1bG8ge1xyXG4gIGZvbnQ6IGJvbGQgMThweCBGUyBFbGxpb3QgUHJvO1xyXG4gIGNvbG9yOiAjMDM1ZmE0O1xyXG59XHJcblxyXG4udGl0dWxvLW1vZGFsIHtcclxuICBmb250OiBib2xkIDI0cHggRlMgRWxsaW90IFBybztcclxuICBjb2xvcjogIzAzNWZhNDtcclxufVxyXG5cclxuLnRleHRvLW1vZGFsIHtcclxuICBmb250OiAxOHB4IEZTIEVsbGlvdCBQcm87XHJcbiAgY29sb3I6ICMwMzVmYTQ7XHJcbn1cclxuXHJcbi5wYWdpbmF0b3Ige1xyXG4gIG1hcmdpbi1sZWZ0OiA1JTtcclxuICBtYXJnaW4tcmlnaHQ6IDUlO1xyXG4gIG1hcmdpbi1ib3R0b206IDUlO1xyXG59XHJcbiJdfQ== */"] });


/***/ }),

/***/ "Wvdv":
/*!***************************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/auditoria/procesos/procesos-routing.module.ts ***!
  \***************************************************************************************/
/*! exports provided: ProcesosRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProcesosRoutingModule", function() { return ProcesosRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _procesos_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./procesos.component */ "OGP1");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");




const routes = [{ path: '', component: _procesos_component__WEBPACK_IMPORTED_MODULE_1__["ProcesosComponent"] }];
class ProcesosRoutingModule {
}
ProcesosRoutingModule.ɵfac = function ProcesosRoutingModule_Factory(t) { return new (t || ProcesosRoutingModule)(); };
ProcesosRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: ProcesosRoutingModule });
ProcesosRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](ProcesosRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] }); })();


/***/ }),

/***/ "g5FI":
/*!*******************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/procesos/proceso/proceso.component.ts ***!
  \*******************************************************************************/
/*! exports provided: ProcesoComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProcesoComponent", function() { return ProcesoComponent; });
/* harmony import */ var _ReduxStore_actions_AUDGENPROCESO_actions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../../../../ReduxStore/actions/AUDGENPROCESO.actions */ "LB20");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var _validators_roles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../validators/roles */ "r6zK");
/* harmony import */ var src_app_ReduxStore_actions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/ReduxStore/actions */ "p8Vo");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngrx/store */ "l7P3");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/auth.service */ "lGQG");
/* harmony import */ var _API_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../API.service */ "iO9l");
/* harmony import */ var _services_usuarios_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../../services/usuarios.service */ "ESM5");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "1kSV");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ngx-spinner */ "JqCM");
/* harmony import */ var src_app_services_procesos_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! src/app/services/procesos.service */ "WFda");
/* harmony import */ var ngx_pagination__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ngx-pagination */ "oOf3");
















const _c0 = ["modalEstado"];
const _c1 = ["ejecucionesInexistentes"];
function ProcesoComponent_div_0_div_1_div_4_Template(rf, ctx) { if (rf & 1) {
    const _r15 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4, "Buscar por");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "form", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "section", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](9, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](11, "input", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](12, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](13, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](14, "input", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](15, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](16, "button", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ProcesoComponent_div_0_div_1_div_4_Template_button_click_16_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r15); const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](3); return ctx_r14.busquedaFiltros(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](17, "Buscar");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](18, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](19, "div", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](20, "div", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](21, "a", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ProcesoComponent_div_0_div_1_div_4_Template_a_click_21_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r15); const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](3); return ctx_r16.recargarEjecuciones(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](22, "Eliminar Filtro ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](23, "img", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("formGroup", ctx_r8.filtroEjecucionesForm);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpropertyInterpolate"]("max", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind2"](12, 3, ctx_r8.maxDate, "yyyy-MM-dd"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("value", ctx_r8.maxDate);
} }
const _c2 = function (a0, a1) { return { "error-log": a0, "success-log": a1 }; };
function ProcesoComponent_div_0_div_1_div_5_tr_15_Template(rf, ctx) { if (rf & 1) {
    const _r22 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "tr", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ProcesoComponent_div_0_div_1_div_5_tr_15_Template_tr_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r22); const AUDGENESTADOPROCESO_r19 = ctx.$implicit; const ctx_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](4); return ctx_r21.consultarDetalle(AUDGENESTADOPROCESO_r19.ID_PROCESO, AUDGENESTADOPROCESO_r19.FECHA_CREADO); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](5, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "td", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const AUDGENESTADOPROCESO_r19 = ctx.$implicit;
    const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](AUDGENESTADOPROCESO_r19.ID_PROCESO);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind2"](5, 4, ctx_r17.replazarCaracterEspecial(AUDGENESTADOPROCESO_r19.FECHA_ACTUALIZACION), "medium"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction2"](7, _c2, (AUDGENESTADOPROCESO_r19.ETAPA_FINAL_ESTADO_FINAL == "FALLIDO" || AUDGENESTADOPROCESO_r19.ETAPA_PROCESAMIENTO_ESTADO_FINAL == "FALLIDO" || AUDGENESTADOPROCESO_r19.ETAPA_INICIAL_ESTADO_FINAL == "FALLIDO") && AUDGENESTADOPROCESO_r19.ESTADO_EJECUCION == "TERMINADO", AUDGENESTADOPROCESO_r19.ETAPA_FINAL_ESTADO_FINAL == "EXITOSO" && AUDGENESTADOPROCESO_r19.ESTADO_EJECUCION == "TERMINADO"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", AUDGENESTADOPROCESO_r19.ESTADO_EJECUCION, "");
} }
function ProcesoComponent_div_0_div_1_div_5_pagination_template_18_span_4_Template(rf, ctx) { if (rf & 1) {
    const _r28 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "span", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ProcesoComponent_div_0_div_1_div_5_pagination_template_18_span_4_Template_span_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r28); _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); const _r23 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](1); return _r23.previous(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ProcesoComponent_div_0_div_1_div_5_pagination_template_18_div_5_span_1_Template(rf, ctx) { if (rf & 1) {
    const _r34 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "span", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ProcesoComponent_div_0_div_1_div_5_pagination_template_18_div_5_span_1_Template_span_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r34); const page_r29 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().$implicit; _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); const _r23 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](1); return _r23.setCurrent(page_r29.value); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const page_r29 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](page_r29.label);
} }
function ProcesoComponent_div_0_div_1_div_5_pagination_template_18_div_5_div_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const page_r29 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](page_r29.label);
} }
function ProcesoComponent_div_0_div_1_div_5_pagination_template_18_div_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](1, ProcesoComponent_div_0_div_1_div_5_pagination_template_18_div_5_span_1_Template, 2, 1, "span", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](2, ProcesoComponent_div_0_div_1_div_5_pagination_template_18_div_5_div_2_Template, 3, 1, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const page_r29 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    const _r23 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵclassProp"]("current", _r23.getCurrent() === page_r29.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", _r23.getCurrent() !== page_r29.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", _r23.getCurrent() === page_r29.value);
} }
function ProcesoComponent_div_0_div_1_div_5_pagination_template_18_span_7_Template(rf, ctx) { if (rf & 1) {
    const _r38 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "span", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ProcesoComponent_div_0_div_1_div_5_pagination_template_18_span_7_Template_span_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r38); _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); const _r23 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](1); return _r23.next(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " >> ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ProcesoComponent_div_0_div_1_div_5_pagination_template_18_Template(rf, ctx) { if (rf & 1) {
    const _r40 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "pagination-template", 42, 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("pageChange", function ProcesoComponent_div_0_div_1_div_5_pagination_template_18_Template_pagination_template_pageChange_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r40); const ctx_r39 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](4); return ctx_r39.paginaActualEjecucionesProceso = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](4, ProcesoComponent_div_0_div_1_div_5_pagination_template_18_span_4_Template, 1, 0, "span", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](5, ProcesoComponent_div_0_div_1_div_5_pagination_template_18_div_5_Template, 3, 4, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](7, ProcesoComponent_div_0_div_1_div_5_pagination_template_18_span_7_Template, 2, 0, "span", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const _r23 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵclassProp"]("disabled", _r23.isFirstPage());
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !_r23.isFirstPage());
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", _r23.pages);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵclassProp"]("disabled", _r23.isLastPage());
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !_r23.isLastPage());
} }
const _c3 = function (a0, a1) { return { "show-ejecuciones": a0, "hide-ejecuciones": a1 }; };
const _c4 = function (a2) { return { id: "ejecucionesProceso", itemsPerPage: 10, currentPage: a2 }; };
function ProcesoComponent_div_0_div_1_div_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "span", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "Listado de ejecuciones");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "table", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "thead");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](9, "ID Ejecuci\u00F3n");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](11, "Hora");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](12, "th", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](13, "Resultado ejecuci\u00F3n");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](14, "tbody");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](15, ProcesoComponent_div_0_div_1_div_5_tr_15_Template, 8, 10, "tr", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](16, "paginate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](17, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](18, ProcesoComponent_div_0_div_1_div_5_pagination_template_18_Template, 8, 7, "pagination-template", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const AUDGENESTADOPROCESOS_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().ngIf;
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction2"](6, _c3, ctx_r9.mostrarEjecucionesProcesos == true, ctx_r9.mostrarEjecucionesProcesos == false));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind2"](16, 3, AUDGENESTADOPROCESOS_r7, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction1"](9, _c4, ctx_r9.paginaActualEjecucionesProceso)));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", AUDGENESTADOPROCESOS_r7.length > 10);
} }
function ProcesoComponent_div_0_div_1_div_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "div", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7, " No existen registros de ejecuci\u00F3n para este proceso.");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ProcesoComponent_div_0_div_1_span_10_Template(rf, ctx) { if (rf & 1) {
    const _r43 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "span", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ProcesoComponent_div_0_div_1_span_10_Template_span_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r43); const ctx_r42 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](3); return ctx_r42.recargarEjecuciones(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, "Regresar");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ProcesoComponent_div_0_div_1_div_11_div_7_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, "Completado ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ProcesoComponent_div_0_div_1_div_11_div_8_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " En Proceso");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ProcesoComponent_div_0_div_1_div_11_div_9_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " Error");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ProcesoComponent_div_0_div_1_div_11_div_16_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " Completado");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ProcesoComponent_div_0_div_1_div_11_div_17_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " En Proceso");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ProcesoComponent_div_0_div_1_div_11_div_18_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " Error");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ProcesoComponent_div_0_div_1_div_11_div_25_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " Completado");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ProcesoComponent_div_0_div_1_div_11_div_26_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " En Proceso");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ProcesoComponent_div_0_div_1_div_11_div_27_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " Error");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
const _c5 = function (a0, a1) { return { "step-completado": a0, "step-incompleto": a1 }; };
const _c6 = function (a0, a1, a2, a3) { return { "step-proceso-disabled": a0, "step-proceso-enabled": a1, "step-completado": a2, "step-incompleto": a3 }; };
const _c7 = function (a0, a1, a2, a3) { return { "step-proceso-disabled": a0, "step-proceso-enabled": a1, "step-completado-final": a2, "step-incompleto": a3 }; };
function ProcesoComponent_div_0_div_1_div_11_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 58, 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5, "INICIAL");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](6, "div", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](7, ProcesoComponent_div_0_div_1_div_11_div_7_Template, 2, 0, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](8, ProcesoComponent_div_0_div_1_div_11_div_8_Template, 2, 0, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](9, ProcesoComponent_div_0_div_1_div_11_div_9_Template, 2, 0, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "div", 62);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](12, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](13, "PROCESAMIENTO");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](14, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](15, "div", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](16, ProcesoComponent_div_0_div_1_div_11_div_16_Template, 2, 0, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](17, ProcesoComponent_div_0_div_1_div_11_div_17_Template, 2, 0, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](18, ProcesoComponent_div_0_div_1_div_11_div_18_Template, 2, 0, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](19, "div", 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](20, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](21, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](22, "FINAL");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](23, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](24, "div", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](25, ProcesoComponent_div_0_div_1_div_11_div_25_Template, 2, 0, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](26, ProcesoComponent_div_0_div_1_div_11_div_26_Template, 2, 0, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](27, ProcesoComponent_div_0_div_1_div_11_div_27_Template, 2, 0, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const AUDGENEJECUCIONPROCESO_r44 = ctx.ngIf;
    const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction2"](13, _c3, ctx_r12.mostrarEjecucionesProcesos == false, ctx_r12.mostrarEjecucionesProcesos == true));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction2"](16, _c5, (AUDGENEJECUCIONPROCESO_r44 == null ? null : AUDGENEJECUCIONPROCESO_r44.ETAPA_INICIAL_ESTADO_FINAL) == "EXITOSO", (AUDGENEJECUCIONPROCESO_r44 == null ? null : AUDGENEJECUCIONPROCESO_r44.ETAPA_INICIAL_ESTADO_FINAL) == "FALLIDO"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (AUDGENEJECUCIONPROCESO_r44 == null ? null : AUDGENEJECUCIONPROCESO_r44.ETAPA_INICIAL_ESTADO_FINAL) === "EXITOSO");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (AUDGENEJECUCIONPROCESO_r44 == null ? null : AUDGENEJECUCIONPROCESO_r44.ETAPA_INICIAL_ESTADO_INICIAL) && (AUDGENEJECUCIONPROCESO_r44 == null ? null : AUDGENEJECUCIONPROCESO_r44.ETAPA_INICIAL_ESTADO_INICIAL) === "INICIADO" && !(AUDGENEJECUCIONPROCESO_r44 == null ? null : AUDGENEJECUCIONPROCESO_r44.ETAPA_INICIAL_ESTADO_FINAL));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (AUDGENEJECUCIONPROCESO_r44 == null ? null : AUDGENEJECUCIONPROCESO_r44.ETAPA_INICIAL_ESTADO_FINAL) === "FALLIDO");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction4"](19, _c6, (AUDGENEJECUCIONPROCESO_r44 == null ? null : AUDGENEJECUCIONPROCESO_r44.ETAPA_INICIAL_ESTADO_FINAL) != "EXITOSO", (AUDGENEJECUCIONPROCESO_r44 == null ? null : AUDGENEJECUCIONPROCESO_r44.ETAPA_INICIAL_ESTADO_FINAL) == "EXITOSO", (AUDGENEJECUCIONPROCESO_r44 == null ? null : AUDGENEJECUCIONPROCESO_r44.ETAPA_PROCESAMIENTO_ESTADO_FINAL) == "EXITOSO", (AUDGENEJECUCIONPROCESO_r44 == null ? null : AUDGENEJECUCIONPROCESO_r44.ETAPA_PROCESAMIENTO_ESTADO_FINAL) == "FALLIDO"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (AUDGENEJECUCIONPROCESO_r44 == null ? null : AUDGENEJECUCIONPROCESO_r44.ETAPA_PROCESAMIENTO_ESTADO_FINAL) === "EXITOSO");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (AUDGENEJECUCIONPROCESO_r44 == null ? null : AUDGENEJECUCIONPROCESO_r44.ETAPA_PROCESAMIENTO_ESTADO_INICIAL) === "INICIADO" && !(AUDGENEJECUCIONPROCESO_r44 == null ? null : AUDGENEJECUCIONPROCESO_r44.ETAPA_PROCESAMIENTO_ESTADO_FINAL));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (AUDGENEJECUCIONPROCESO_r44 == null ? null : AUDGENEJECUCIONPROCESO_r44.ETAPA_PROCESAMIENTO_ESTADO_FINAL) === "FALLIDO");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction4"](24, _c7, (AUDGENEJECUCIONPROCESO_r44 == null ? null : AUDGENEJECUCIONPROCESO_r44.ETAPA_PROCESAMIENTO_ESTADO_FINAL) != "EXITOSO", (AUDGENEJECUCIONPROCESO_r44 == null ? null : AUDGENEJECUCIONPROCESO_r44.ETAPA_PROCESAMIENTO_ESTADO_FINAL) == "EXITOSO", (AUDGENEJECUCIONPROCESO_r44 == null ? null : AUDGENEJECUCIONPROCESO_r44.ETAPA_FINAL_ESTADO_FINAL) == "EXITOSO", (AUDGENEJECUCIONPROCESO_r44 == null ? null : AUDGENEJECUCIONPROCESO_r44.ETAPA_FINAL_ESTADO_FINAL) == "FALLIDO"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (AUDGENEJECUCIONPROCESO_r44 == null ? null : AUDGENEJECUCIONPROCESO_r44.ETAPA_FINAL_ESTADO_FINAL) === "EXITOSO");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (AUDGENEJECUCIONPROCESO_r44 == null ? null : AUDGENEJECUCIONPROCESO_r44.ETAPA_FINAL_ESTADO_INICIAL) === "INICIADO" && !(AUDGENEJECUCIONPROCESO_r44 == null ? null : AUDGENEJECUCIONPROCESO_r44.ETAPA_FINAL_ESTADO_FINAL));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (AUDGENEJECUCIONPROCESO_r44 == null ? null : AUDGENEJECUCIONPROCESO_r44.ETAPA_FINAL_ESTADO_FINAL) === "FALLIDO");
} }
const _c8 = function (a0, a1, a2) { return { "error-log": a0, "info-log": a1, "aviso-log": a2 }; };
const _c9 = function (a0) { return { "error-log": a0 }; };
function ProcesoComponent_div_0_div_1_div_13_div_4_tr_13_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "td", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](5, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "td", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const AUDGENPROCESO_r60 = ctx.$implicit;
    const ctx_r59 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction3"](9, _c8, AUDGENPROCESO_r60.NIVEL === "FALLIDO", AUDGENPROCESO_r60.NIVEL === "INFO", AUDGENPROCESO_r60.NIVEL === "AVISO"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", AUDGENPROCESO_r60.NIVEL, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind2"](5, 6, ctx_r59.replazarCaracterEspecial(AUDGENPROCESO_r60.FECHA), "medium"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](AUDGENPROCESO_r60.ACTIVIDAD);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction1"](13, _c9, AUDGENPROCESO_r60.NIVEL === "FALLIDO"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", AUDGENPROCESO_r60.MENSAJE_SOPORTE, "");
} }
const _c10 = function (a2) { return { id: "detalleEjecucion", itemsPerPage: 10, currentPage: a2 }; };
function ProcesoComponent_div_0_div_1_div_13_div_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "table", 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "thead");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5, "Tipo");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7, "Hora");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](9, "Actividad");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "th", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](11, "Mensaje");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](12, "tbody");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](13, ProcesoComponent_div_0_div_1_div_13_div_4_tr_13_Template, 10, 15, "tr", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](14, "paginate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const AUDGENPROCESOS_r55 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().ngIf;
    const ctx_r56 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind2"](14, 1, AUDGENPROCESOS_r55, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction1"](4, _c10, ctx_r56.paginaActualProceso)));
} }
function ProcesoComponent_div_0_div_1_div_13_div_5_tr_11_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](3, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "td", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const AUDGENPROCESO_r64 = ctx.$implicit;
    const ctx_r63 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind2"](3, 4, ctx_r63.replazarCaracterEspecial(AUDGENPROCESO_r64.FECHA), "medium"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](AUDGENPROCESO_r64.ACTIVIDAD);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction1"](7, _c9, AUDGENPROCESO_r64.NIVEL === "FALLIDO"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", AUDGENPROCESO_r64.MENSAJE_NEGOCIO, "");
} }
function ProcesoComponent_div_0_div_1_div_13_div_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "table", 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "thead");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5, "Hora");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7, "Actividad");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "th", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](9, "Mensaje");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "tbody");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](11, ProcesoComponent_div_0_div_1_div_13_div_5_tr_11_Template, 8, 9, "tr", 68);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](12, "paginate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const AUDGENPROCESOS_r55 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().ngIf;
    const ctx_r57 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](11);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind2"](12, 1, AUDGENPROCESOS_r55, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction1"](4, _c10, ctx_r57.paginaActualProceso)));
} }
function ProcesoComponent_div_0_div_1_div_13_pagination_template_7_span_4_Template(rf, ctx) { if (rf & 1) {
    const _r72 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "span", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ProcesoComponent_div_0_div_1_div_13_pagination_template_7_span_4_Template_span_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r72); _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); const _r67 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](1); return _r67.previous(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " << ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ProcesoComponent_div_0_div_1_div_13_pagination_template_7_div_5_span_1_Template(rf, ctx) { if (rf & 1) {
    const _r78 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "span", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ProcesoComponent_div_0_div_1_div_13_pagination_template_7_div_5_span_1_Template_span_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r78); const page_r73 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().$implicit; _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); const _r67 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](1); return _r67.setCurrent(page_r73.value); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const page_r73 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](page_r73.label);
} }
function ProcesoComponent_div_0_div_1_div_13_pagination_template_7_div_5_div_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const page_r73 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](page_r73.label);
} }
function ProcesoComponent_div_0_div_1_div_13_pagination_template_7_div_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](1, ProcesoComponent_div_0_div_1_div_13_pagination_template_7_div_5_span_1_Template, 2, 1, "span", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](2, ProcesoComponent_div_0_div_1_div_13_pagination_template_7_div_5_div_2_Template, 3, 1, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const page_r73 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    const _r67 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵclassProp"]("current", _r67.getCurrent() === page_r73.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", _r67.getCurrent() !== page_r73.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", _r67.getCurrent() === page_r73.value);
} }
function ProcesoComponent_div_0_div_1_div_13_pagination_template_7_span_7_Template(rf, ctx) { if (rf & 1) {
    const _r82 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "span", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ProcesoComponent_div_0_div_1_div_13_pagination_template_7_span_7_Template_span_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r82); _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); const _r67 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](1); return _r67.next(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " >> ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ProcesoComponent_div_0_div_1_div_13_pagination_template_7_Template(rf, ctx) { if (rf & 1) {
    const _r84 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "pagination-template", 70, 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("pageChange", function ProcesoComponent_div_0_div_1_div_13_pagination_template_7_Template_pagination_template_pageChange_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r84); const ctx_r83 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](4); return ctx_r83.paginaActualProceso = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](4, ProcesoComponent_div_0_div_1_div_13_pagination_template_7_span_4_Template, 2, 0, "span", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](5, ProcesoComponent_div_0_div_1_div_13_pagination_template_7_div_5_Template, 3, 4, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](7, ProcesoComponent_div_0_div_1_div_13_pagination_template_7_span_7_Template, 2, 0, "span", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const _r67 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵclassProp"]("disabled", _r67.isFirstPage());
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !_r67.isFirstPage());
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", _r67.pages);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵclassProp"]("disabled", _r67.isLastPage());
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !_r67.isLastPage());
} }
const _c11 = function (a0) { return [a0]; };
function ProcesoComponent_div_0_div_1_div_13_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "span", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "Monitoreo de actividades ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](4, ProcesoComponent_div_0_div_1_div_13_div_4_Template, 15, 6, "div", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](5, ProcesoComponent_div_0_div_1_div_13_div_5_Template, 13, 6, "div", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](7, ProcesoComponent_div_0_div_1_div_13_pagination_template_7_Template, 8, 7, "pagination-template", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const AUDGENPROCESOS_r55 = ctx.ngIf;
    const DataUser_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2).ngIf;
    const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction2"](4, _c3, ctx_r13.mostrarEjecucionesProcesos == false, ctx_r13.mostrarEjecucionesProcesos == true));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r13.area == "SOPORTE");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r13.usuario.validarRolUsuario() && ctx_r13.rolesValids(DataUser_r1, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction1"](7, _c11, ctx_r13.Administrador)) && ctx_r13.area != "SOPORTE");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", AUDGENPROCESOS_r55.length > 10);
} }
function ProcesoComponent_div_0_div_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](4, ProcesoComponent_div_0_div_1_div_4_Template, 24, 6, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](5, ProcesoComponent_div_0_div_1_div_5_Template, 19, 11, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](6, ProcesoComponent_div_0_div_1_div_6_Template, 8, 0, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](9, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](10, ProcesoComponent_div_0_div_1_span_10_Template, 2, 0, "span", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](11, ProcesoComponent_div_0_div_1_div_11_Template, 28, 29, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](12, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](13, ProcesoComponent_div_0_div_1_div_13_Template, 8, 9, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](14, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const AUDGENESTADOPROCESOS_r7 = ctx.ngIf;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx_r2.titulo);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !ctx_r2.ocultarbusqueda);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", AUDGENESTADOPROCESOS_r7.length !== 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", AUDGENESTADOPROCESOS_r7.length === 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction2"](12, _c3, ctx_r2.mostrarEjecucionesProcesos == false, ctx_r2.mostrarEjecucionesProcesos == true));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !ctx_r2.mostrarEjecucionesProcesos);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](12, 8, ctx_r2.AUDGENEJECUCIONPROCESO$));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](14, 10, ctx_r2.AUDGENPROCESOS$));
} }
function ProcesoComponent_div_0_ng_template_3_Template(rf, ctx) { if (rf & 1) {
    const _r88 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4, "Busqueda por filtro");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "div", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "div", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7, "Ingresa un valor para realizar la busqueda");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "div", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](9, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "button", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ProcesoComponent_div_0_ng_template_3_Template_button_click_10_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r88); const ctx_r87 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2); return ctx_r87.cerrarModales(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](11, "Aceptar");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ProcesoComponent_div_0_ng_template_5_Template(rf, ctx) { if (rf & 1) {
    const _r91 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4, "Consulta de ejecuciones");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "div", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "div", 75);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7, "No existen ejecuciones para este proceso ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "div", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](9, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "button", 76);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ProcesoComponent_div_0_ng_template_5_Template_button_click_10_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r91); const ctx_r90 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2); return ctx_r90.cerrarModales(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](11, "Continuar");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ProcesoComponent_div_0_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](1, ProcesoComponent_div_0_div_1_Template, 15, 15, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](3, ProcesoComponent_div_0_ng_template_3_Template, 12, 0, "ng-template", 3, 4, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](5, ProcesoComponent_div_0_ng_template_5_Template, 12, 0, "ng-template", 5, 6, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](2, 1, ctx_r0.AUDGENESTADOPROCESOS$));
} }
class ProcesoComponent {
    constructor(store, rutaActiva, authService, api, usuario, fb, modalService, datepipe, spinner, ProcesosService) {
        this.store = store;
        this.rutaActiva = rutaActiva;
        this.authService = authService;
        this.api = api;
        this.usuario = usuario;
        this.fb = fb;
        this.modalService = modalService;
        this.datepipe = datepipe;
        this.spinner = spinner;
        this.ProcesosService = ProcesosService;
        this.Areas = [
            _validators_roles__WEBPACK_IMPORTED_MODULE_2__["EArea"].Contabilidad,
            _validators_roles__WEBPACK_IMPORTED_MODULE_2__["EArea"].Custodia,
            _validators_roles__WEBPACK_IMPORTED_MODULE_2__["EArea"].Inversiones_Riesgos,
            _validators_roles__WEBPACK_IMPORTED_MODULE_2__["EArea"].Tesoreria,
            _validators_roles__WEBPACK_IMPORTED_MODULE_2__["EArea"].Soporte,
        ];
        this.PROCESOS = new Array();
        this.ocultarbusqueda = false;
        this.paginaActualEjecucionesProceso = 1;
        this.paginaActualProceso = 1;
        this.mostrarEjecucionesProcesos = true;
        this.Administrador = _validators_roles__WEBPACK_IMPORTED_MODULE_2__["ERole"].Administrador;
        this.Ejecutor = _validators_roles__WEBPACK_IMPORTED_MODULE_2__["ERole"].Monitor;
        this.estado = '';
        this.replazarCaracterEspecial = (value) => {
            return new Date(value + 'Z').toString();
        };
        this.rolesValids = (User, roles) => {
            return this.authService.rolesValids(User, roles);
        };
        this.cerrarModales = () => {
            this.modalService.dismissAll();
        };
        this.Loading$ = this.store
            .select(({ AUDGENESTADOPROCESOS }) => AUDGENESTADOPROCESOS.error)
            .subscribe((res) => {
            this.spinner.show();
            if (res) {
            }
            else {
                this.spinner.hide();
            }
        });
    }
    ngOnDestroy() {
        this.store.dispatch(Object(_ReduxStore_actions_AUDGENPROCESO_actions__WEBPACK_IMPORTED_MODULE_0__["UnsetAUDGENPROCESO"])());
        this.store.dispatch(Object(src_app_ReduxStore_actions__WEBPACK_IMPORTED_MODULE_3__["UnsetAUDGENESTADOPROCESO"])());
        this.store.dispatch(Object(src_app_ReduxStore_actions__WEBPACK_IMPORTED_MODULE_3__["UnsetAUDGENEJECUCIONPROCESO"])());
        this.subscriptionName.unsubscribe();
    }
    ngAfterViewInit() {
    }
    ngOnInit() {
        this.subscriptionName = this.ProcesosService.getUpdate().subscribe(message => {
            this.messageReceived = JSON.parse(message.text).idProceso;
            this.estado = JSON.parse(message.text).estado;
            //console.log('subscriptionName', this.messageReceived, this.estado);
            if (this.estado === 'CONTINUAR') {
                this.consultarDetalle(this.messageReceived, null);
                this.estado = 'DETENER';
                this.subscriptionName.unsubscribe();
            }
        });
        this.authService.refreshToken();
        this.titulo = JSON.parse(localStorage.getItem('Titulo'));
        this.ocultarbusqueda = false;
        this.paginaActualProceso = 1;
        this.paginaActualEjecucionesProceso = 1;
        this.filtroEjecucionesForm = this.fb.group({
            fechaFiltrar: [],
            idProceso: [],
        });
        this.maxDate = new Date();
        this.fechaInicio = new Date();
        this.fechaInicio.setHours(0, 0, 0, 0);
        this.fechaFin = new Date();
        this.fechaFin.setHours(23, 59, 59, 999);
        this.DataUser$ = this.store.select(({ usuario }) => usuario.user);
        this.DataUser$.subscribe((res) => (this.DataUser = res)).unsubscribe();
        //console.log(this.DataUser.attributes['custom:negocio']);
        this.AUDGENESTADOPROCESOS$ = this.store
            .select(({ AUDGENESTADOPROCESOS }) => AUDGENESTADOPROCESOS.AUDGENESTADOPROCESO)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])((res) => {
            if (res === null)
                return res;
            else
                return res
                    .slice()
                    .sort(function (a, b) {
                    return (new Date(b.FECHA_ACTUALIZACION).getTime() -
                        new Date(a.FECHA_ACTUALIZACION).getTime());
                })
                    .filter((item, i, res) => {
                    return (res.indexOf(res.find((t) => t.ID_PROCESO === item.ID_PROCESO)) === i);
                });
            // .filter(item => {
            //   return item.ETAPA != ""
            // })
        }));
        // this.store
        //   .select(
        //     ({ AUDGENESTADOPROCESOS }) => AUDGENESTADOPROCESOS.AUDGENESTADOPROCESO
        //   )
        //   .subscribe((res) => console.log('que hay', res));
        this.store.select(({ AUDGENPROCESOS }) => AUDGENPROCESOS.AUDGENPROCESOS);
        this.store.select(({ AUDGENESTADOPROCESOS }) => AUDGENESTADOPROCESOS.AUDGENESTADOPROCESO);
        let body = {
            INTERFAZ: this.rutaActiva.snapshot.params.id,
            FECHA_INICIO: this.fechaInicio.toISOString().replace('0Z', ''),
            FECHA_FIN: this.fechaFin.toISOString().replace('9Z', ''),
        };
        this.store.dispatch(Object(src_app_ReduxStore_actions__WEBPACK_IMPORTED_MODULE_3__["LoadAUDGENESTADOPROCESOS"])({ consult: body }));
        // this.llenarTabla(this.page);
        this.AUDGENESTADOPROCESOS$.subscribe((res) => {
            if (res && res.length === 0) {
                this.ejecucionesInexistentesModal();
                //this.modalService.open(this.templateRefEjecuciones, { ariaLabelledBy: 'modal-basic-title' });
            }
            else
                this.cerrarModales();
        });
        // this.api
        //   .ListSiaGenAudEstadoProcesosDevs(
        //     this.rutaActiva.snapshot.params.id,
        //     this.fechaInicio.toISOString().replace('0Z', ''),
        //     this.fechaFin.toISOString().replace('9Z', '')
        //   )
        //   .then((res) => {
        //     console.log('Respuesta api: ', res);
        //   });
        this.store
            .select(({ notificacionSelect }) => notificacionSelect.notificacionSelect)
            .subscribe((res) => {
            let notificaciones = JSON.parse(localStorage.getItem('notProcesos'));
            console.log('notificaciones', notificaciones);
            if (res && notificaciones !== null) {
                console.log('notificacionSelect', res);
                this.spinner.show();
                let array = window.location.pathname.split('/');
                let bodyProcesos = {
                    filter: { TIPO: { eq: array[2].toUpperCase() } },
                    limit: 1000,
                };
                this.api
                    .ListCATPROCESOS(bodyProcesos.filter, bodyProcesos.limit)
                    .then(({ items }) => {
                    this.titulo = items.filter((item) => item.PROCESO === res.INTERFAZ)[0].DESCRIPCION;
                    this.consultarDetalle(res.ID_PROCESO, res.FECHA_CREADO);
                    this.spinner.hide();
                    localStorage.removeItem('notProcesos');
                });
            }
        });
        /*************************************/
        /********* A U D I T O R I A *********/
        /*************** inicio **************/
        let auditoria = JSON.parse(localStorage.getItem('audProcesos'));
        if (auditoria) {
            console.log('auditoria', auditoria);
            this.spinner.show();
            let array = window.location.pathname.split('/');
            let bodyProcesos = {
                filter: { TIPO: { eq: array[2].toUpperCase() } },
                limit: 1000,
            };
            this.api
                .ListCATPROCESOS(bodyProcesos.filter, bodyProcesos.limit)
                .then(({ items }) => {
                this.titulo = auditoria.proceso;
                this.consultarDetalle(auditoria.idProceso.toLowerCase(), null);
                this.spinner.hide();
            });
            localStorage.removeItem('audProcesos');
        }
        /**************** fin ****************/
        /********* A U D I T O R I A *********/
        /*************************************/
    }
    openModal() {
        this.modalService.open(this.templateRef, {
            ariaLabelledBy: 'modal-basic-title',
        });
    }
    obtenerArea() {
        let arrayTempArea = [];
        this.DataUser.groups.forEach((area) => {
            this.Areas.forEach((areaDef) => {
                if (area === areaDef) {
                    arrayTempArea.push(area);
                }
            });
        });
        if (arrayTempArea.length > 0)
            return arrayTempArea[0].toUpperCase();
        else
            'N/D';
    }
    recargarEjecuciones() {
        if (this.mostrarEjecucionesProcesos == false) {
            this.mostrarEjecucionesProcesos = !this.mostrarEjecucionesProcesos;
        }
        this.ocultarbusqueda = false;
        this.AUDGENESTADOPROCESOS$ = this.store
            .select(({ AUDGENESTADOPROCESOS }) => AUDGENESTADOPROCESOS.AUDGENESTADOPROCESO)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])((res) => {
            if (res === null)
                return res;
            else
                return res
                    .slice()
                    .sort(function (a, b) {
                    return (new Date(b.FECHA_ACTUALIZACION).getTime() -
                        new Date(a.FECHA_ACTUALIZACION).getTime());
                })
                    .filter((item, i, res) => {
                    return (res.indexOf(res.find((t) => t.ID_PROCESO === item.ID_PROCESO)) === i);
                });
            // .filter(item => {
            //   return item.ETAPA != ""
            // })
        }));
        let body = {
            INTERFAZ: this.rutaActiva.snapshot.params.id,
            FECHA_INICIO: this.fechaInicio.toISOString().replace('0Z', ''),
            FECHA_FIN: this.fechaFin.toISOString().replace('9Z', ''),
        };
        this.store.dispatch(Object(src_app_ReduxStore_actions__WEBPACK_IMPORTED_MODULE_3__["LoadAUDGENESTADOPROCESOS"])({ consult: body }));
        this.filtroEjecucionesForm.reset();
    }
    consultarDetalle(idProceso, fecha) {
        this.area = this.obtenerArea();
        // console.log(this.area);
        this.ocultarbusqueda = true;
        //  console.log(fecha);
        let format = this.datepipe.transform(fecha, 'yyyy-MM-dd');
        //  console.log(format);
        this.paginaActualProceso = 1;
        // this.api
        //   .ListAUDGENPROCESOS(idProceso, format)
        //   .then((res) => console.log('Resultado', res));
        this.AUDGENEJECUCIONPROCESO$ = this.store.select(({ AUDGENEJECUCIONESPROCESO }) => AUDGENEJECUCIONESPROCESO.AUDGENEJECUCIONESPROCESO);
        this.estado = 'FINAL';
        // .pipe(map(res => {
        //   if (res == null) return res
        //   else
        //     return res.filter((item, i, res) => {
        //       return res.indexOf(res.find(t => t.ID_PROCESO === item.ID_PROCESO)) === i
        //     })
        // }))
        // this.store.select(
        //   ({ AUDGENEJECUCIONESPROCESO }) => AUDGENEJECUCIONESPROCESO.AUDGENEJECUCIONESPROCESO
        // ).subscribe(res => console.log('AUDGENEJECUCIONESPROCESO',res))
        // this.store.select(
        //   ({ AUDGENPROCESOS }) => AUDGENPROCESOS.AUDGENPROCESOS
        // ).pipe(map(res => {
        //   if (res === null) return res
        //   else return res.slice().sort(function (a, b) { return new Date(b.FECHA).getTime() - new Date(a.FECHA).getTime() })
        // }
        // )).subscribe(res => console.log(res))
        if (this.rolesValids(this.DataUser, [this.Administrador]) &&
            this.area == 'SOPORTE') {
            this.AUDGENPROCESOS$ = this.store
                .select(({ AUDGENPROCESOS }) => AUDGENPROCESOS.AUDGENPROCESOS)
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])((res) => {
                if (res === null)
                    return res;
                else
                    return res.slice().sort(function (a, b) {
                        return (new Date(b.FECHA).getTime() - new Date(a.FECHA).getTime());
                    });
            }));
        }
        else if (this.rolesValids(this.DataUser, [this.Administrador])) {
            // console.log('entre al admin');
            this.AUDGENPROCESOS$ = this.store
                .select(({ AUDGENPROCESOS }) => AUDGENPROCESOS.AUDGENPROCESOS)
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])((res) => {
                if (res === null)
                    return res;
                else
                    return res
                        .slice()
                        .sort(function (a, b) {
                        return (new Date(b.FECHA).getTime() - new Date(a.FECHA).getTime());
                    })
                        .filter((item) => {
                        return item.MENSAJE_NEGOCIO != '';
                    });
            }));
        }
        else {
            this.AUDGENPROCESOS$ = this.store
                .select(({ AUDGENPROCESOS }) => AUDGENPROCESOS.AUDGENPROCESOS)
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])((res) => {
                if (res === null)
                    return res;
                else
                    return res.slice().sort(function (a, b) {
                        return (new Date(b.FECHA).getTime() - new Date(a.FECHA).getTime());
                    });
            }));
        }
        let body = {
            ID_PROCESO: idProceso,
        };
        let bodyProcesos = {
            ID_PROCESO: idProceso,
            FECHA: format,
        };
        // this.api.GetSiaGenAudEstadoProcesosDev(idProceso).then(res => { console.log('GetItem:', res)})
        this.store.dispatch(Object(src_app_ReduxStore_actions__WEBPACK_IMPORTED_MODULE_3__["LoadAUDGENEJECUCIONESPROCESO"])({ consult: body }));
        this.store.dispatch(Object(_ReduxStore_actions_AUDGENPROCESO_actions__WEBPACK_IMPORTED_MODULE_0__["LoadAUDGENPROCESOS"])({ consult: bodyProcesos }));
        this.mostrarEjecucionesProcesos = false;
    }
    busquedaFiltros() {
        this.paginaActualEjecucionesProceso = 1;
        if (this.filtroEjecucionesForm.valid) {
            let fechaInicialFiltro = this.filtroEjecucionesForm.get('fechaFiltrar').value;
            let fechaFinalFiltro = fechaInicialFiltro;
            if (this.filtroEjecucionesForm.get('fechaFiltrar').value != null) {
                let fechaInicialParseada = Date.parse(this.filtroEjecucionesForm.get('fechaFiltrar').value);
                fechaInicialFiltro = new Date(fechaInicialParseada);
                fechaInicialFiltro.setMinutes(fechaInicialFiltro.getMinutes() +
                    fechaInicialFiltro.getTimezoneOffset());
                fechaFinalFiltro = new Date(fechaInicialParseada);
                fechaFinalFiltro.setMinutes(fechaFinalFiltro.getMinutes() + fechaFinalFiltro.getTimezoneOffset());
                fechaFinalFiltro.setHours(23, 59, 59, 999);
                // console.log('FEcha filtrar: ', fechaInicialFiltro.toISOString())
                // console.log('FEcha filtrar final: ', fechaFinalFiltro.toISOString())
            }
            let idProceso = this.filtroEjecucionesForm.get('idProceso').value;
            // console.log(this.filtroEjecucionesForm.get('idProceso').value)
            this.AUDGENESTADOPROCESOS$ = this.store
                .select(({ AUDGENESTADOPROCESOS }) => AUDGENESTADOPROCESOS.AUDGENESTADOPROCESO)
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])((res) => {
                if (res === null)
                    return res;
                else
                    return res
                        .slice()
                        .sort(function (a, b) {
                        return (new Date(b.FECHA_ACTUALIZACION).getTime() -
                            new Date(a.FECHA_ACTUALIZACION).getTime());
                    })
                        .filter((item, i, res) => {
                        return (res.indexOf(res.find((t) => t.ID_PROCESO === item.ID_PROCESO)) === i);
                    });
                // .filter(item => {
                //   return item.ETAPA != ""
                // })
            }));
            // this.store.select(
            //   ({ AUDGENEJECUCIONESPROCESO }) => AUDGENEJECUCIONESPROCESO.AUDGENEJECUCIONESPROCESO
            // ).subscribe(res => console.log(res))
            if (fechaInicialFiltro === null && idProceso === null) {
                this.openModal();
            }
            else if (fechaInicialFiltro === null && idProceso !== null) {
                let body = {
                    ID_PROCESO: idProceso,
                };
                this.store.dispatch(Object(src_app_ReduxStore_actions__WEBPACK_IMPORTED_MODULE_3__["LoadAUDGENESTADOPROCESOS"])({ consult: body }));
            }
            else if (fechaInicialFiltro !== null && idProceso === null) {
                //console.log(fechaInicialFiltro.toISOString().replace('0Z', ''));
                //console.log(fechaFinalFiltro.toISOString().replace('0Z', ''));
                let body = {
                    INTERFAZ: this.rutaActiva.snapshot.params.id,
                    FECHA_INICIO: fechaInicialFiltro.toISOString().replace('0Z', ''),
                    FECHA_FIN: fechaFinalFiltro.toISOString().replace('9Z', ''),
                };
                this.store.dispatch(Object(src_app_ReduxStore_actions__WEBPACK_IMPORTED_MODULE_3__["LoadAUDGENESTADOPROCESOS"])({ consult: body }));
            }
            else {
                //console.log('else');
                //console.log(idProceso);
                //console.log(fechaInicialFiltro.toISOString().replace('0Z', ''));
                //console.log(fechaFinalFiltro.toISOString().replace('0Z', ''));
                let body = {
                    FECHA_INICIO: fechaInicialFiltro.toISOString().replace('0Z', ''),
                    FECHA_FIN: fechaFinalFiltro.toISOString().replace('9Z', ''),
                    ID_PROCESO: idProceso,
                };
                this.store.dispatch(Object(src_app_ReduxStore_actions__WEBPACK_IMPORTED_MODULE_3__["LoadAUDGENESTADOPROCESOS"])({ consult: body }));
            }
        }
    }
    ejecucionesInexistentesModal() {
        this.modalService.open(this.templateRefEjecuciones, {
            ariaLabelledBy: 'modal-basic-title',
        });
    }
    obtenerNotificaciones(fechaInicioSesion) {
        if (fechaInicioSesion) {
            let body = {
                filter: { FECHA_ACTUALIZACION: { gt: fechaInicioSesion } },
                limit: 1000,
            };
            this.store.dispatch(Object(src_app_ReduxStore_actions__WEBPACK_IMPORTED_MODULE_3__["LoadAUDGENESTADOPROCESOS"])({ consult: body }));
        }
    }
}
ProcesoComponent.ɵfac = function ProcesoComponent_Factory(t) { return new (t || ProcesoComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_ngrx_store__WEBPACK_IMPORTED_MODULE_5__["Store"]), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_6__["ActivatedRoute"]), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_7__["AuthService"]), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_API_service__WEBPACK_IMPORTED_MODULE_8__["APIService"]), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_services_usuarios_service__WEBPACK_IMPORTED_MODULE_9__["UsuariosService"]), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_10__["FormBuilder"]), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_11__["NgbModal"]), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_12__["DatePipe"]), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_13__["NgxSpinnerService"]), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_services_procesos_service__WEBPACK_IMPORTED_MODULE_14__["ProcesosService"])); };
ProcesoComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({ type: ProcesoComponent, selectors: [["app-proceso"]], viewQuery: function ProcesoComponent_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵviewQuery"](_c0, 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵviewQuery"](_c1, 1);
    } if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵloadQuery"]()) && (ctx.templateRef = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵloadQuery"]()) && (ctx.templateRefEjecuciones = _t.first);
    } }, decls: 2, vars: 3, consts: [["class", "container-fluid", 4, "ngIf"], [1, "container-fluid"], ["class", "flex-row-reverse justify-content-center", "style", "height: 50vh; width: 100%", 4, "ngIf"], ["id", "modalFiltro"], ["modalEstado", ""], ["id", "ejecucionesInexistentes"], ["ejecucionesInexistentes", ""], [1, "flex-row-reverse", "justify-content-center", 2, "height", "50vh", "width", "100%"], [1, "row", "justify-content-center"], [1, "titulo-proceso"], ["class", "row justify-content-center", 4, "ngIf"], ["class", "row justify-content-center container-referencias-log", 3, "ngClass", 4, "ngIf"], ["class", "row justify-content-center container-referencias-log", 4, "ngIf"], [1, "row", "justify-content-center", "hide-div", 3, "ngClass"], [1, "d-flex", "col-md-9", "col-xs-9", "col-sm-9", "col-lg-9", "mr-9", "col-9", "align-items-center", "justify-content-center"], [1, "show-info"], ["class", "show-info-button", 3, "click", 4, "ngIf"], ["class", "d-flex col-md-9 col-xs-9 col-sm-9 col-lg-9 mr-9 col-9 align-items-center justify-content-center container-progeso show-ejecuciones", "style", "height: 45px;", 3, "ngClass", 4, "ngIf"], [1, "card-calendario"], [1, "mt-4"], [3, "formGroup"], [1, "mt-3"], [1, "row", "align-items-center", "justify-content-center"], [1, "col-11", "inputs-busqueda"], [1, "col-4"], ["type", "date", "placeholder", "dd-MM-yyyy", "onfocus", "(this.type='date')", "formControlName", "fechaFiltrar", "id", "fechaFiltrar", "name", "fechaFiltrar", 2, "width", "100%", "padding-left", "10px", 3, "value", "max"], ["type", "text", "placeholder", "ID de ejecuci\u00F3n", "formControlName", "idProceso", "id", "idProceso", "name", "", 2, "width", "100%", "padding-left", "10px"], [1, "clickable", 3, "click"], [1, "row"], [2, "text-align", "right", "width", "100%", "justify-content", "flex-end", "direction", "rtl", "margin-bottom", "10px"], [2, "margin-right", "10%"], [1, "limpiarFiltro", "clickable", 3, "click"], ["src", "assets/icons/Eliminar.svg", 1, "tamanioFiltroIcono"], [1, "row", "justify-content-center", "container-referencias-log", 3, "ngClass"], [1, "d-flex", "col-md-9", "col-xs-9", "col-sm-9", "col-lg-9", "mr-9", "col-9", "align-items-left", "justify-content-left"], [1, "title-log-table"], [1, "listado-log", "listado-ejecuciones"], ["colspan", "12"], ["class", "clickable", 3, "click", 4, "ngFor", "ngForOf"], [1, "d-flex", "col-md-9", "col-xs-9", "col-sm-9", "col-lg-9", "mr-9", "col-9", "align-items-left"], ["id", "ejecucionesProceso", "class", "ngx-pagination", 3, "pageChange", 4, "ngIf"], [3, "ngClass"], ["id", "ejecucionesProceso", 1, "ngx-pagination", 3, "pageChange"], ["p", "paginationApi"], [1, "custom-pagination"], [1, "pagination-previous"], [3, "click", 4, "ngIf"], ["class", "page-number", 3, "current", 4, "ngFor", "ngForOf"], [1, "pagination-next"], [3, "click"], [1, "page-number"], [4, "ngIf"], [1, "row", "justify-content-center", "container-referencias-log"], [1, "align-self-center"], [1, "d-flex", "flex-column", 2, "width", "504px"], [1, "descripcionNoEjecuciones", 2, "margin-top", "34px"], [1, "col-12"], [1, "show-info-button", 3, "click"], [1, "d-flex", "col-md-9", "col-xs-9", "col-sm-9", "col-lg-9", "mr-9", "col-9", "align-items-center", "justify-content-center", "container-progeso", "show-ejecuciones", 2, "height", "45px", 3, "ngClass"], ["detalleProceso", ""], [1, "step-proceso", "step-proceso-enabled", 2, "margin-left", "-0px", 3, "ngClass"], [1, "separador-titulos"], [1, "step-1-proceso", 3, "ngClass"], [1, "step-4-proceso", 3, "ngClass"], ["class", "d-flex col-md-9 col-xs-9 col-sm-9 col-lg-9 mr-9 col-9 align-items-center justify-content-center", 4, "ngIf"], ["id", "detalleEjecucion", "class", "ngx-pagination", 3, "pageChange", 4, "ngIf"], [1, "listado-log"], ["colspan", "9"], [4, "ngFor", "ngForOf"], ["colspan", "9", 3, "ngClass"], ["id", "detalleEjecucion", 1, "ngx-pagination", 3, "pageChange"], [1, "modal-body"], [1, "col-12", "row", "justify-content-center", "align-items-center", 2, "height", "120px"], [1, "textoConfirmacionModalUsuarios"], [1, "col-12", "row"], [1, "col-12", "descripcionConfirmacionEjecucionProceso"], [1, "btn", "bottonConfirmarEjecucionProceso", 3, "click"]], template: function ProcesoComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](0, ProcesoComponent_div_0_Template, 7, 3, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](1, "async");
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](1, 1, ctx.DataUser$));
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_12__["NgIf"], _angular_common__WEBPACK_IMPORTED_MODULE_12__["NgClass"], _angular_forms__WEBPACK_IMPORTED_MODULE_10__["ɵangular_packages_forms_forms_ba"], _angular_forms__WEBPACK_IMPORTED_MODULE_10__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_10__["FormGroupDirective"], _angular_forms__WEBPACK_IMPORTED_MODULE_10__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_10__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_10__["FormControlName"], _angular_common__WEBPACK_IMPORTED_MODULE_12__["NgForOf"], ngx_pagination__WEBPACK_IMPORTED_MODULE_15__["PaginationControlsDirective"]], pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_12__["AsyncPipe"], _angular_common__WEBPACK_IMPORTED_MODULE_12__["DatePipe"], ngx_pagination__WEBPACK_IMPORTED_MODULE_15__["PaginatePipe"]], styles: [".container-progeso[_ngcontent-%COMP%] {\r\n    margin-top: 25px;\r\n    margin-left: auto;\r\n    margin-right: auto;\r\n    width: 100%;\r\n}\r\n \r\n.step-proceso[_ngcontent-%COMP%]{\r\n    background: #7C69C3;\r\n    width: auto;\r\n    border-radius: 50px;\r\n    height: 63px;\r\n    display: flex; \r\n    justify-content: center;\r\n    align-items: center;\r\n    font:  16px FS Elliot Pro;\r\n    color: white;\r\n    z-index: 6;\r\n    box-shadow: 3px 3px 5px #00000033;\r\n    padding: 0px !important;\r\n}\r\n \r\n.step-incompleto[_ngcontent-%COMP%]{\r\n    background: #FF9231 !important;\r\n}\r\n \r\n.step-completado[_ngcontent-%COMP%]{\r\n    background: #7C69C3 !important;\r\n}\r\n \r\n.step-completado-final[_ngcontent-%COMP%]{\r\n    background: #464E7E !important;\r\n}\r\n \r\n.step-proceso-disabled[_ngcontent-%COMP%]{\r\n    margin-left: -25px;\r\n    background: #D6D6D6;\r\n    border-top-right-radius: 50px;\r\n    border-bottom-right-radius: 50px;\r\n    width: 100%;\r\n    min-width: 200px;\r\n    height: 63px;\r\n    display: flex; \r\n    justify-content: center;\r\n    align-items: center;\r\n    font: 16px FS Elliot Pro;\r\n    color: white;\r\n    padding: 30px;\r\n}\r\n \r\n.step-proceso-enabled[_ngcontent-%COMP%]{\r\n    margin-left: -50px;\r\n    background: #7C69C3;\r\n    width: 100%;\r\n    min-width: 200px;\r\n    border-radius: 50px;\r\n    border-top-left-radius: -50px;\r\n    border-bottom-left-radius: -50px;\r\n    height: 63px;\r\n    display: flex; \r\n    justify-content: center;\r\n    align-items: center;\r\n    font:  16px FS Elliot Pro;\r\n    color: white;\r\n    box-shadow: 3px 3px 5px #00000033;\r\n    padding-left: 60px;\r\n    padding-right: 25px;\r\n\r\n}\r\n \r\n.step-1-proceso[_ngcontent-%COMP%]{\r\n    z-index: 4;\r\n}\r\n \r\n.step-2-proceso[_ngcontent-%COMP%]{\r\n    z-index: 3;\r\n}\r\n \r\n.step-3-proceso[_ngcontent-%COMP%]{\r\n    z-index: 2;\r\n}\r\n \r\n.step-4-proceso[_ngcontent-%COMP%]{\r\n    z-index: 1;\r\n}\r\n \r\n.step-4-proceso-finalizado[_ngcontent-%COMP%]{\r\n    z-index: 1;\r\n    background: #464E7E;\r\n}\r\n \r\n.container-referencias-log[_ngcontent-%COMP%]{\r\n    margin-top: 30px;   \r\n}\r\n \r\n.show-ejecuciones[_ngcontent-%COMP%]{\r\n    visibility: visible;\r\n    max-height: 30px;\r\n    opacity: 1;\r\n    transition: visibility 0.3s, opacity 0.3s, max-height 0.5s linear;\r\n}\r\n \r\n.hide-ejecuciones[_ngcontent-%COMP%]{\r\n    visibility: hidden;\r\n    max-height: 0px;\r\n    opacity: 0;\r\n    transition: visibility 0.3s, opacity 0.3s, max-height 0.3s linear;\r\n  \r\n  }\r\n \r\n.container-referencias-log[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\r\n    font: 20px FS Elliot Pro;\r\n}\r\n \r\n.container-referencias-log[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover {\r\n    color: #7C69C3;\r\n    text-decoration: underline ;\r\n}\r\n \r\n.title-log-table[_ngcontent-%COMP%]{\r\n    font: normal normal bold 18px/45px FS Elliot Pro;\r\n \r\n}\r\n \r\ntable.listado-log[_ngcontent-%COMP%]{\r\n    background: #FFFFFF 0% 0% no-repeat padding-box;\r\n    align-content: left;\r\n    width: 100%;\r\n    margin: 15px 0;\r\n    border-spacing: 0 6px;\r\n    text-align: center;\r\n    font: normal normal normal 15px/18px FS Elliot Pro ;\r\n}\r\n \r\ntable.listado-log[_ngcontent-%COMP%]   th[_ngcontent-%COMP%]{\r\n    color: white;\r\n    padding-left: 20px;\r\n    margin-left: 20px;\r\n    background-color: #464E7E ;\r\n    font: bold 18px FS Elliot Pro;\r\n    height: 40px;\r\n    height: 40px;\r\n    font: bold 18px FS Elliot Pro;\r\n    table-layout:fixed;\r\n    text-align: left;\r\n    align-content: center;\r\n}\r\n \r\ntable.listado-log[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]{\r\n    padding-left: 20px;\r\n    margin-left: 20px;\r\n    background-color: #FFFFFF ;\r\n    color: #707070;\r\n    font: 15px FS Elliot Pro;\r\n    height: 40px;\r\n    margin: 6px 0px;\r\n    text-align: left;\r\n    align-content: center;\r\n    vertical-align: middle;\r\n}\r\n \r\ntable.listado-log[_ngcontent-%COMP%]   td.wideRow[_ngcontent-%COMP%], table[_ngcontent-%COMP%]   th.wideRow[_ngcontent-%COMP%]{\r\n    width: 300px;\r\n    }\r\n \r\n.error-log[_ngcontent-%COMP%]{\r\n    color: #C00000 !important;\r\n}\r\n \r\n.success-log[_ngcontent-%COMP%]{\r\n    color: #4BB543 !important;\r\n}\r\n \r\n.warning-log[_ngcontent-%COMP%]{\r\n    color: #FF7000 !important;\r\n}\r\n \r\n.info-log[_ngcontent-%COMP%]{\r\n    color: #1791DA !important;\r\n}\r\n \r\n.aviso-log[_ngcontent-%COMP%]{\r\n    color: #FF7000 !important;\r\n}\r\n \r\ntable.listado-ejecuciones[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]:hover   td[_ngcontent-%COMP%] {\r\n    background-color: #c5c5c5;\r\n    text-decoration: none;\r\n    transition: all 0.3s;\r\n}\r\n \r\n.clickable[_ngcontent-%COMP%] {\r\n    \r\n    cursor: pointer;\r\n  }\r\n \r\n.titulo-proceso[_ngcontent-%COMP%]{\r\n    color: #464E7E;\r\n    font: normal normal bold 20px/20px FS Elliot Pro;\r\n    letter-spacing: 0px;\r\n    margin-top: 10px;\r\n}\r\n \r\n.show-info[_ngcontent-%COMP%]{\r\n    width: 80%;\r\n    height: 1px;\r\n    margin-right: 5px;\r\n    \r\n    background: #a0a0a0  !important;\r\n}\r\n \r\n.show-info-button[_ngcontent-%COMP%]:hover {\r\n    cursor: pointer\r\n\r\n}\r\n \r\n.hide-div[_ngcontent-%COMP%] {\r\n    margin: 0;\r\n}\r\n \r\ndiv.card-calendario[_ngcontent-%COMP%]{\r\n    width: 100%;\r\n    background: #ffffff 0% 0% no-repeat padding-box;\r\n    border-radius: 30px;\r\n    opacity: 1;\r\n    display: flex;\r\n    margin: 25px 0;\r\n    flex-direction: column;\r\n    align-items: center;\r\n    border-radius: 25px;\r\n    border-left: 10px solid #464E7E;\r\n    box-shadow: 4px 4px 10px #00000033;\r\n  }\r\n \r\n.card-calendario[_ngcontent-%COMP%]   div[_ngcontent-%COMP%] {\r\n    color: #464E7E;\r\n    border: black;\r\n    height: auto;\r\n    width: auto;\r\n    flex-grow: 1;\r\n    display: flex;\r\n    align-items: center;\r\n    font: bold 20px FS Elliot Pro;\r\n  }\r\n \r\n.card-calendario[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]    > button[_ngcontent-%COMP%] {\r\n    background-color: #7C69C3;\r\n    color: white;\r\n    width: 296px;\r\n    height: 45px;\r\n    border-radius: 25px;\r\n    font: bold 20px FS Elliot Pro;\r\n    border: none;\r\n  }\r\n \r\n.inputs-busqueda[_ngcontent-%COMP%] {\r\n    margin-bottom: 25px;\r\n  }\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2Nlc28uY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLGdCQUFnQjtJQUNoQixpQkFBaUI7SUFDakIsa0JBQWtCO0lBQ2xCLFdBQVc7QUFDZjs7QUFFQTtJQUNJLG1CQUFtQjtJQUNuQixXQUFXO0lBQ1gsbUJBQW1CO0lBQ25CLFlBQVk7SUFDWixhQUFhO0lBQ2IsdUJBQXVCO0lBQ3ZCLG1CQUFtQjtJQUNuQix5QkFBeUI7SUFDekIsWUFBWTtJQUNaLFVBQVU7SUFDVixpQ0FBaUM7SUFDakMsdUJBQXVCO0FBQzNCOztBQUdBO0lBQ0ksOEJBQThCO0FBQ2xDOztBQUVBO0lBQ0ksOEJBQThCO0FBQ2xDOztBQUVBO0lBQ0ksOEJBQThCO0FBQ2xDOztBQUNBO0lBQ0ksa0JBQWtCO0lBQ2xCLG1CQUFtQjtJQUNuQiw2QkFBNkI7SUFDN0IsZ0NBQWdDO0lBQ2hDLFdBQVc7SUFDWCxnQkFBZ0I7SUFDaEIsWUFBWTtJQUNaLGFBQWE7SUFDYix1QkFBdUI7SUFDdkIsbUJBQW1CO0lBQ25CLHdCQUF3QjtJQUN4QixZQUFZO0lBQ1osYUFBYTtBQUNqQjs7QUFFQTtJQUNJLGtCQUFrQjtJQUNsQixtQkFBbUI7SUFDbkIsV0FBVztJQUNYLGdCQUFnQjtJQUNoQixtQkFBbUI7SUFDbkIsNkJBQTZCO0lBQzdCLGdDQUFnQztJQUNoQyxZQUFZO0lBQ1osYUFBYTtJQUNiLHVCQUF1QjtJQUN2QixtQkFBbUI7SUFDbkIseUJBQXlCO0lBQ3pCLFlBQVk7SUFDWixpQ0FBaUM7SUFDakMsa0JBQWtCO0lBQ2xCLG1CQUFtQjs7QUFFdkI7O0FBRUE7SUFDSSxVQUFVO0FBQ2Q7O0FBRUE7SUFDSSxVQUFVO0FBQ2Q7O0FBRUE7SUFDSSxVQUFVO0FBQ2Q7O0FBRUE7SUFDSSxVQUFVO0FBQ2Q7O0FBQ0E7SUFDSSxVQUFVO0lBQ1YsbUJBQW1CO0FBQ3ZCOztBQUdBO0lBQ0ksZ0JBQWdCO0FBQ3BCOztBQUVBO0lBQ0ksbUJBQW1CO0lBQ25CLGdCQUFnQjtJQUNoQixVQUFVO0lBQ1YsaUVBQWlFO0FBQ3JFOztBQUdBO0lBQ0ksa0JBQWtCO0lBQ2xCLGVBQWU7SUFDZixVQUFVO0lBQ1YsaUVBQWlFOztFQUVuRTs7QUFDRjtJQUNJLHdCQUF3QjtBQUM1Qjs7QUFDQTtJQUNJLGNBQWM7SUFDZCwyQkFBMkI7QUFDL0I7O0FBRUE7SUFDSSxnREFBZ0Q7O0FBRXBEOztBQUNBO0lBQ0ksK0NBQStDO0lBQy9DLG1CQUFtQjtJQUNuQixXQUFXO0lBQ1gsY0FBYztJQUNkLHFCQUFxQjtJQUNyQixrQkFBa0I7SUFDbEIsbURBQW1EO0FBQ3ZEOztBQUVBO0lBQ0ksWUFBWTtJQUNaLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsMEJBQTBCO0lBQzFCLDZCQUE2QjtJQUM3QixZQUFZO0lBQ1osWUFBWTtJQUNaLDZCQUE2QjtJQUM3QixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHFCQUFxQjtBQUN6Qjs7QUFDQTtJQUNJLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsMEJBQTBCO0lBQzFCLGNBQWM7SUFDZCx3QkFBd0I7SUFDeEIsWUFBWTtJQUNaLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIscUJBQXFCO0lBQ3JCLHNCQUFzQjtBQUMxQjs7QUFFQTtJQUNJLFlBQVk7SUFDWjs7QUFHSjtJQUNJLHlCQUF5QjtBQUM3Qjs7QUFDQTtJQUNJLHlCQUF5QjtBQUM3Qjs7QUFFQTtJQUNJLHlCQUF5QjtBQUM3Qjs7QUFFQTtJQUNJLHlCQUF5QjtBQUM3Qjs7QUFFQTtJQUNJLHlCQUF5QjtBQUM3Qjs7QUFHQTtJQUNJLHlCQUF5QjtJQUN6QixxQkFBcUI7SUFDckIsb0JBQW9CO0FBQ3hCOztBQUNBOztJQUVJLGVBQWU7RUFDakI7O0FBRUY7SUFDSSxjQUFjO0lBQ2QsZ0RBQWdEO0lBQ2hELG1CQUFtQjtJQUNuQixnQkFBZ0I7QUFDcEI7O0FBRUE7SUFDSSxVQUFVO0lBQ1YsV0FBVztJQUNYLGlCQUFpQjs7SUFFakIsK0JBQStCO0FBQ25DOztBQUVBO0lBQ0k7O0FBRUo7O0FBQ0E7SUFDSSxTQUFTO0FBQ2I7O0FBRUE7SUFDSSxXQUFXO0lBQ1gsK0NBQStDO0lBQy9DLG1CQUFtQjtJQUNuQixVQUFVO0lBQ1YsYUFBYTtJQUNiLGNBQWM7SUFDZCxzQkFBc0I7SUFDdEIsbUJBQW1CO0lBQ25CLG1CQUFtQjtJQUNuQiwrQkFBK0I7SUFDL0Isa0NBQWtDO0VBQ3BDOztBQUVBO0lBQ0UsY0FBYztJQUNkLGFBQWE7SUFDYixZQUFZO0lBQ1osV0FBVztJQUNYLFlBQVk7SUFDWixhQUFhO0lBQ2IsbUJBQW1CO0lBQ25CLDZCQUE2QjtFQUMvQjs7QUFFQTtJQUNFLHlCQUF5QjtJQUN6QixZQUFZO0lBQ1osWUFBWTtJQUNaLFlBQVk7SUFDWixtQkFBbUI7SUFDbkIsNkJBQTZCO0lBQzdCLFlBQVk7RUFDZDs7QUFFQTtJQUNFLG1CQUFtQjtFQUNyQiIsImZpbGUiOiJwcm9jZXNvLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY29udGFpbmVyLXByb2dlc28ge1xyXG4gICAgbWFyZ2luLXRvcDogMjVweDtcclxuICAgIG1hcmdpbi1sZWZ0OiBhdXRvO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbn1cclxuIFxyXG4uc3RlcC1wcm9jZXNve1xyXG4gICAgYmFja2dyb3VuZDogIzdDNjlDMztcclxuICAgIHdpZHRoOiBhdXRvO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTBweDtcclxuICAgIGhlaWdodDogNjNweDtcclxuICAgIGRpc3BsYXk6IGZsZXg7IFxyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgZm9udDogIDE2cHggRlMgRWxsaW90IFBybztcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIHotaW5kZXg6IDY7XHJcbiAgICBib3gtc2hhZG93OiAzcHggM3B4IDVweCAjMDAwMDAwMzM7XHJcbiAgICBwYWRkaW5nOiAwcHggIWltcG9ydGFudDtcclxufVxyXG5cclxuXHJcbi5zdGVwLWluY29tcGxldG97XHJcbiAgICBiYWNrZ3JvdW5kOiAjRkY5MjMxICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5zdGVwLWNvbXBsZXRhZG97XHJcbiAgICBiYWNrZ3JvdW5kOiAjN0M2OUMzICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5zdGVwLWNvbXBsZXRhZG8tZmluYWx7XHJcbiAgICBiYWNrZ3JvdW5kOiAjNDY0RTdFICFpbXBvcnRhbnQ7XHJcbn1cclxuLnN0ZXAtcHJvY2Vzby1kaXNhYmxlZHtcclxuICAgIG1hcmdpbi1sZWZ0OiAtMjVweDtcclxuICAgIGJhY2tncm91bmQ6ICNENkQ2RDY7XHJcbiAgICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogNTBweDtcclxuICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiA1MHB4O1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBtaW4td2lkdGg6IDIwMHB4O1xyXG4gICAgaGVpZ2h0OiA2M3B4O1xyXG4gICAgZGlzcGxheTogZmxleDsgXHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBmb250OiAxNnB4IEZTIEVsbGlvdCBQcm87XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBwYWRkaW5nOiAzMHB4O1xyXG59XHJcblxyXG4uc3RlcC1wcm9jZXNvLWVuYWJsZWR7XHJcbiAgICBtYXJnaW4tbGVmdDogLTUwcHg7XHJcbiAgICBiYWNrZ3JvdW5kOiAjN0M2OUMzO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBtaW4td2lkdGg6IDIwMHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTBweDtcclxuICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IC01MHB4O1xyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogLTUwcHg7XHJcbiAgICBoZWlnaHQ6IDYzcHg7XHJcbiAgICBkaXNwbGF5OiBmbGV4OyBcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGZvbnQ6ICAxNnB4IEZTIEVsbGlvdCBQcm87XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBib3gtc2hhZG93OiAzcHggM3B4IDVweCAjMDAwMDAwMzM7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDYwcHg7XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiAyNXB4O1xyXG5cclxufVxyXG5cclxuLnN0ZXAtMS1wcm9jZXNve1xyXG4gICAgei1pbmRleDogNDtcclxufVxyXG5cclxuLnN0ZXAtMi1wcm9jZXNve1xyXG4gICAgei1pbmRleDogMztcclxufVxyXG5cclxuLnN0ZXAtMy1wcm9jZXNve1xyXG4gICAgei1pbmRleDogMjtcclxufVxyXG5cclxuLnN0ZXAtNC1wcm9jZXNve1xyXG4gICAgei1pbmRleDogMTtcclxufVxyXG4uc3RlcC00LXByb2Nlc28tZmluYWxpemFkb3tcclxuICAgIHotaW5kZXg6IDE7XHJcbiAgICBiYWNrZ3JvdW5kOiAjNDY0RTdFO1xyXG59XHJcblxyXG5cclxuLmNvbnRhaW5lci1yZWZlcmVuY2lhcy1sb2d7XHJcbiAgICBtYXJnaW4tdG9wOiAzMHB4OyAgIFxyXG59XHJcblxyXG4uc2hvdy1lamVjdWNpb25lc3tcclxuICAgIHZpc2liaWxpdHk6IHZpc2libGU7XHJcbiAgICBtYXgtaGVpZ2h0OiAzMHB4O1xyXG4gICAgb3BhY2l0eTogMTtcclxuICAgIHRyYW5zaXRpb246IHZpc2liaWxpdHkgMC4zcywgb3BhY2l0eSAwLjNzLCBtYXgtaGVpZ2h0IDAuNXMgbGluZWFyO1xyXG59XHJcblxyXG5cclxuLmhpZGUtZWplY3VjaW9uZXN7XHJcbiAgICB2aXNpYmlsaXR5OiBoaWRkZW47XHJcbiAgICBtYXgtaGVpZ2h0OiAwcHg7XHJcbiAgICBvcGFjaXR5OiAwO1xyXG4gICAgdHJhbnNpdGlvbjogdmlzaWJpbGl0eSAwLjNzLCBvcGFjaXR5IDAuM3MsIG1heC1oZWlnaHQgMC4zcyBsaW5lYXI7XHJcbiAgXHJcbiAgfVxyXG4uY29udGFpbmVyLXJlZmVyZW5jaWFzLWxvZyAgYSB7XHJcbiAgICBmb250OiAyMHB4IEZTIEVsbGlvdCBQcm87XHJcbn1cclxuLmNvbnRhaW5lci1yZWZlcmVuY2lhcy1sb2cgIGE6aG92ZXIge1xyXG4gICAgY29sb3I6ICM3QzY5QzM7XHJcbiAgICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZSA7XHJcbn1cclxuXHJcbi50aXRsZS1sb2ctdGFibGV7XHJcbiAgICBmb250OiBub3JtYWwgbm9ybWFsIGJvbGQgMThweC80NXB4IEZTIEVsbGlvdCBQcm87XHJcbiBcclxufVxyXG50YWJsZS5saXN0YWRvLWxvZ3tcclxuICAgIGJhY2tncm91bmQ6ICNGRkZGRkYgMCUgMCUgbm8tcmVwZWF0IHBhZGRpbmctYm94O1xyXG4gICAgYWxpZ24tY29udGVudDogbGVmdDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgbWFyZ2luOiAxNXB4IDA7XHJcbiAgICBib3JkZXItc3BhY2luZzogMCA2cHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBmb250OiBub3JtYWwgbm9ybWFsIG5vcm1hbCAxNXB4LzE4cHggRlMgRWxsaW90IFBybyA7XHJcbn1cclxuXHJcbnRhYmxlLmxpc3RhZG8tbG9nICB0aHtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIHBhZGRpbmctbGVmdDogMjBweDtcclxuICAgIG1hcmdpbi1sZWZ0OiAyMHB4O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzQ2NEU3RSA7XHJcbiAgICBmb250OiBib2xkIDE4cHggRlMgRWxsaW90IFBybztcclxuICAgIGhlaWdodDogNDBweDtcclxuICAgIGhlaWdodDogNDBweDtcclxuICAgIGZvbnQ6IGJvbGQgMThweCBGUyBFbGxpb3QgUHJvO1xyXG4gICAgdGFibGUtbGF5b3V0OmZpeGVkO1xyXG4gICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgIGFsaWduLWNvbnRlbnQ6IGNlbnRlcjtcclxufVxyXG50YWJsZS5saXN0YWRvLWxvZyAgdGR7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDIwcHg7XHJcbiAgICBtYXJnaW4tbGVmdDogMjBweDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNGRkZGRkYgO1xyXG4gICAgY29sb3I6ICM3MDcwNzA7XHJcbiAgICBmb250OiAxNXB4IEZTIEVsbGlvdCBQcm87XHJcbiAgICBoZWlnaHQ6IDQwcHg7XHJcbiAgICBtYXJnaW46IDZweCAwcHg7XHJcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gICAgYWxpZ24tY29udGVudDogY2VudGVyO1xyXG4gICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcclxufVxyXG5cclxudGFibGUubGlzdGFkby1sb2cgdGQud2lkZVJvdywgdGFibGUgdGgud2lkZVJvd3tcclxuICAgIHdpZHRoOiAzMDBweDtcclxuICAgIH1cclxuXHJcblxyXG4uZXJyb3ItbG9ne1xyXG4gICAgY29sb3I6ICNDMDAwMDAgIWltcG9ydGFudDtcclxufVxyXG4uc3VjY2Vzcy1sb2d7XHJcbiAgICBjb2xvcjogIzRCQjU0MyAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4ud2FybmluZy1sb2d7XHJcbiAgICBjb2xvcjogI0ZGNzAwMCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uaW5mby1sb2d7XHJcbiAgICBjb2xvcjogIzE3OTFEQSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uYXZpc28tbG9ne1xyXG4gICAgY29sb3I6ICNGRjcwMDAgIWltcG9ydGFudDtcclxufVxyXG5cclxuXHJcbnRhYmxlLmxpc3RhZG8tZWplY3VjaW9uZXMgdHI6aG92ZXIgdGQge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2M1YzVjNTtcclxuICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuICAgIHRyYW5zaXRpb246IGFsbCAwLjNzO1xyXG59XHJcbi5jbGlja2FibGUge1xyXG4gICAgXHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgfVxyXG5cclxuLnRpdHVsby1wcm9jZXNve1xyXG4gICAgY29sb3I6ICM0NjRFN0U7XHJcbiAgICBmb250OiBub3JtYWwgbm9ybWFsIGJvbGQgMjBweC8yMHB4IEZTIEVsbGlvdCBQcm87XHJcbiAgICBsZXR0ZXItc3BhY2luZzogMHB4O1xyXG4gICAgbWFyZ2luLXRvcDogMTBweDtcclxufVxyXG5cclxuLnNob3ctaW5mb3tcclxuICAgIHdpZHRoOiA4MCU7XHJcbiAgICBoZWlnaHQ6IDFweDtcclxuICAgIG1hcmdpbi1yaWdodDogNXB4O1xyXG4gICAgXHJcbiAgICBiYWNrZ3JvdW5kOiAjYTBhMGEwICAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uc2hvdy1pbmZvLWJ1dHRvbjpob3ZlciB7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXJcclxuXHJcbn1cclxuLmhpZGUtZGl2IHtcclxuICAgIG1hcmdpbjogMDtcclxufVxyXG5cclxuZGl2LmNhcmQtY2FsZW5kYXJpb3tcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgYmFja2dyb3VuZDogI2ZmZmZmZiAwJSAwJSBuby1yZXBlYXQgcGFkZGluZy1ib3g7XHJcbiAgICBib3JkZXItcmFkaXVzOiAzMHB4O1xyXG4gICAgb3BhY2l0eTogMTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBtYXJnaW46IDI1cHggMDtcclxuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMjVweDtcclxuICAgIGJvcmRlci1sZWZ0OiAxMHB4IHNvbGlkICM0NjRFN0U7XHJcbiAgICBib3gtc2hhZG93OiA0cHggNHB4IDEwcHggIzAwMDAwMDMzO1xyXG4gIH1cclxuICBcclxuICAuY2FyZC1jYWxlbmRhcmlvIGRpdiB7XHJcbiAgICBjb2xvcjogIzQ2NEU3RTtcclxuICAgIGJvcmRlcjogYmxhY2s7XHJcbiAgICBoZWlnaHQ6IGF1dG87XHJcbiAgICB3aWR0aDogYXV0bztcclxuICAgIGZsZXgtZ3JvdzogMTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgZm9udDogYm9sZCAyMHB4IEZTIEVsbGlvdCBQcm87XHJcbiAgfVxyXG4gIFxyXG4gIC5jYXJkLWNhbGVuZGFyaW8gZGl2ID4gYnV0dG9uIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICM3QzY5QzM7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICB3aWR0aDogMjk2cHg7XHJcbiAgICBoZWlnaHQ6IDQ1cHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiAyNXB4O1xyXG4gICAgZm9udDogYm9sZCAyMHB4IEZTIEVsbGlvdCBQcm87XHJcbiAgICBib3JkZXI6IG5vbmU7XHJcbiAgfVxyXG5cclxuICAuaW5wdXRzLWJ1c3F1ZWRhIHtcclxuICAgIG1hcmdpbi1ib3R0b206IDI1cHg7XHJcbiAgfSJdfQ== */"] });


/***/ }),

/***/ "oKwr":
/*!*****************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/procesos/procesos-routing.module.ts ***!
  \*****************************************************************************/
/*! exports provided: ProcesosRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProcesosRoutingModule", function() { return ProcesosRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _proceso_proceso_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./proceso/proceso.component */ "g5FI");
/* harmony import */ var _procesos_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./procesos.component */ "+U3K");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");





const routes = [
    {
        path: '',
        component: _procesos_component__WEBPACK_IMPORTED_MODULE_2__["ProcesosComponent"],
        children: [
            {
                path: '',
                loadChildren: () => __webpack_require__.e(/*! import() | procesos-pantalla-general-procesos-pantalla-general-module */ "procesos-pantalla-general-procesos-pantalla-general-module").then(__webpack_require__.bind(null, /*! ./procesos-pantalla-general/procesos-pantalla-general.module */ "yKHc")).then((m) => m.ProcesosPantallaGeneralModule),
            },
            {
                path: ':id', component: _proceso_proceso_component__WEBPACK_IMPORTED_MODULE_1__["ProcesoComponent"]
            },
            {
                path: ':id/:proceso', component: _proceso_proceso_component__WEBPACK_IMPORTED_MODULE_1__["ProcesoComponent"]
            },
        ],
    },
];
class ProcesosRoutingModule {
}
ProcesosRoutingModule.ɵfac = function ProcesosRoutingModule_Factory(t) { return new (t || ProcesosRoutingModule)(); };
ProcesosRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({ type: ProcesosRoutingModule });
ProcesosRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](ProcesosRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] }); })();


/***/ }),

/***/ "oy6u":
/*!*******************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/auditoria/procesos/procesos.module.ts ***!
  \*******************************************************************************/
/*! exports provided: ProcesosModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProcesosModule", function() { return ProcesosModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _procesos_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./procesos-routing.module */ "Wvdv");
/* harmony import */ var _procesos_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./procesos.component */ "OGP1");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var ng_multiselect_dropdown__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ng-multiselect-dropdown */ "Egam");
/* harmony import */ var ngx_pagination__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ngx-pagination */ "oOf3");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ngx-spinner */ "JqCM");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ "fXoL");









class ProcesosModule {
}
ProcesosModule.ɵfac = function ProcesosModule_Factory(t) { return new (t || ProcesosModule)(); };
ProcesosModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineNgModule"]({ type: ProcesosModule });
ProcesosModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
            _procesos_routing_module__WEBPACK_IMPORTED_MODULE_1__["ProcesosRoutingModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            ngx_spinner__WEBPACK_IMPORTED_MODULE_6__["NgxSpinnerModule"],
            ngx_pagination__WEBPACK_IMPORTED_MODULE_5__["NgxPaginationModule"],
            ng_multiselect_dropdown__WEBPACK_IMPORTED_MODULE_4__["NgMultiSelectDropDownModule"].forRoot(),
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵsetNgModuleScope"](ProcesosModule, { declarations: [_procesos_component__WEBPACK_IMPORTED_MODULE_2__["ProcesosComponent"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
        _procesos_routing_module__WEBPACK_IMPORTED_MODULE_1__["ProcesosRoutingModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
        ngx_spinner__WEBPACK_IMPORTED_MODULE_6__["NgxSpinnerModule"],
        ngx_pagination__WEBPACK_IMPORTED_MODULE_5__["NgxPaginationModule"], ng_multiselect_dropdown__WEBPACK_IMPORTED_MODULE_4__["NgMultiSelectDropDownModule"]] }); })();


/***/ })

}]);
//# sourceMappingURL=procesos-procesos-module.js.map