(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["usuarios-usuarios-module"],{

/***/ "+rhq":
/*!******************************************!*\
  !*** ./src/app/pipes/quitarcoma.pipe.ts ***!
  \******************************************/
/*! exports provided: QuitarcomaPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QuitarcomaPipe", function() { return QuitarcomaPipe; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");

class QuitarcomaPipe {
    transform(palabraconcoma) {
        return palabraconcoma ? Object.assign({}, { palabraconcoma: palabraconcoma })['palabraconcoma'].split(',').join('  ') : '';
    }
}
QuitarcomaPipe.ɵfac = function QuitarcomaPipe_Factory(t) { return new (t || QuitarcomaPipe)(); };
QuitarcomaPipe.ɵpipe = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefinePipe"]({ name: "quitarcoma", type: QuitarcomaPipe, pure: true });


/***/ }),

/***/ "2I5K":
/*!********************************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/administracion/usuarios/usuarios-routing.module.ts ***!
  \********************************************************************************************/
/*! exports provided: UsuariosRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsuariosRoutingModule", function() { return UsuariosRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _usuarios_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./usuarios.component */ "zKnR");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");




const routes = [{ path: '', component: _usuarios_component__WEBPACK_IMPORTED_MODULE_1__["UsuariosComponent"] }];
class UsuariosRoutingModule {
}
UsuariosRoutingModule.ɵfac = function UsuariosRoutingModule_Factory(t) { return new (t || UsuariosRoutingModule)(); };
UsuariosRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: UsuariosRoutingModule });
UsuariosRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](UsuariosRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] }); })();


/***/ }),

/***/ "FVhR":
/*!**********************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/auditoria/usuarios/usuarios.component.ts ***!
  \**********************************************************************************/
/*! exports provided: UsuariosComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsuariosComponent", function() { return UsuariosComponent; });
/* harmony import */ var _ReduxStore_actions_usuarios_AUDGENUSUARIOS_actions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../../../../ReduxStore/actions/usuarios/AUDGENUSUARIOS.actions */ "n68H");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var src_app_validators_opcionesDeFiltroAccionesAuditoriaUsuariios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/validators/opcionesDeFiltroAccionesAuditoriaUsuariios */ "jix7");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngrx/store */ "l7P3");
/* harmony import */ var _API_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../../API.service */ "iO9l");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "1kSV");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ngx-spinner */ "JqCM");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var ng_multiselect_dropdown__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ng-multiselect-dropdown */ "Egam");
/* harmony import */ var ngx_pagination__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ngx-pagination */ "oOf3");












function UsuariosComponent_section_0_div_23_div_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](4, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](6, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](7, " No existen registros para esta b\u00FAsqueda.");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} }
function UsuariosComponent_section_0_div_23_div_2_tr_13_Template(rf, ctx) { if (rf & 1) {
    const _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "td", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "td", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "td", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](7, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](8, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](9, "td", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](11, "td", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](12, "center");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](13, "img", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function UsuariosComponent_section_0_div_23_div_2_tr_13_Template_img_click_13_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r13); const AUDGENUSUARIO_r10 = ctx.$implicit; const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](4); return ctx_r12.openModal(AUDGENUSUARIO_r10); });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const AUDGENUSUARIO_r10 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate2"]("", AUDGENUSUARIO_r10.USUARIO.NOMBRE, " ", AUDGENUSUARIO_r10.USUARIO.APELLIDO_PATERNO, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"]("", AUDGENUSUARIO_r10.CORREO, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate2"]("", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind2"](7, 6, AUDGENUSUARIO_r10.FECHA, "dd/MM/yyyy"), " ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind2"](8, 9, AUDGENUSUARIO_r10.FECHA, "mediumTime"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"]("", AUDGENUSUARIO_r10.PERMISOS_USUARIOS[0].ACCION, " ");
} }
const _c0 = function (a2) { return { id: "Usuarios", itemsPerPage: 10, currentPage: a2 }; };
function UsuariosComponent_section_0_div_23_div_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "table", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "th", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](4, "Nombre");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "th", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](6, "Usuario");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](7, "th", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](8, "Fecha");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](9, "th", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](10, "Acci\u00F3n");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](11, "th", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](12, "Detalle");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](13, UsuariosComponent_section_0_div_23_div_2_tr_13_Template, 14, 12, "tr", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](14, "paginate");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const AUDGENUSUARIOS_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]().ngIf;
    const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind2"](14, 1, AUDGENUSUARIOS_r6, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction1"](4, _c0, ctx_r8.paginaActualUsuarios)));
} }
function UsuariosComponent_section_0_div_23_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, UsuariosComponent_section_0_div_23_div_1_Template, 8, 0, "div", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](2, UsuariosComponent_section_0_div_23_div_2_Template, 15, 6, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r4.ListadoUsuariosPantalla.length === 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r4.ListadoUsuariosPantalla.length !== 0);
} }
function UsuariosComponent_section_0_pagination_template_24_span_4_Template(rf, ctx) { if (rf & 1) {
    const _r20 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "span", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function UsuariosComponent_section_0_pagination_template_24_span_4_Template_span_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r20); _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](); const _r15 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵreference"](1); return _r15.previous(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " << ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} }
function UsuariosComponent_section_0_pagination_template_24_div_5_span_1_Template(rf, ctx) { if (rf & 1) {
    const _r26 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "span", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function UsuariosComponent_section_0_pagination_template_24_div_5_span_1_Template_span_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r26); const page_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]().$implicit; _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](); const _r15 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵreference"](1); return _r15.setCurrent(page_r21.value); });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const page_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](page_r21.label);
} }
function UsuariosComponent_section_0_pagination_template_24_div_5_div_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const page_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate"](page_r21.label);
} }
function UsuariosComponent_section_0_pagination_template_24_div_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, UsuariosComponent_section_0_pagination_template_24_div_5_span_1_Template, 2, 1, "span", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](2, UsuariosComponent_section_0_pagination_template_24_div_5_div_2_Template, 3, 1, "div", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const page_r21 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    const _r15 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵreference"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassProp"]("current", _r15.getCurrent() === page_r21.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", _r15.getCurrent() !== page_r21.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", _r15.getCurrent() === page_r21.value);
} }
function UsuariosComponent_section_0_pagination_template_24_span_7_Template(rf, ctx) { if (rf & 1) {
    const _r30 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "span", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function UsuariosComponent_section_0_pagination_template_24_span_7_Template_span_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r30); _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](); const _r15 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵreference"](1); return _r15.next(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " >> ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} }
function UsuariosComponent_section_0_pagination_template_24_Template(rf, ctx) { if (rf & 1) {
    const _r32 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "pagination-template", 34, 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("pageChange", function UsuariosComponent_section_0_pagination_template_24_Template_pagination_template_pageChange_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r32); const ctx_r31 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2); return ctx_r31.paginaActualUsuarios = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "div", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "div", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](4, UsuariosComponent_section_0_pagination_template_24_span_4_Template, 2, 0, "span", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](5, UsuariosComponent_section_0_pagination_template_24_div_5_Template, 3, 4, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](6, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](7, UsuariosComponent_section_0_pagination_template_24_span_7_Template, 2, 0, "span", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const _r15 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵreference"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassProp"]("disabled", _r15.isFirstPage());
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", !_r15.isFirstPage());
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngForOf", _r15.pages);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassProp"]("disabled", _r15.isLastPage());
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", !_r15.isLastPage());
} }
const _c1 = function () { return { standalone: true }; };
function UsuariosComponent_section_0_Template(rf, ctx) { if (rf & 1) {
    const _r34 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "section");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3, "Buscar por");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](4, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](6, "a", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function UsuariosComponent_section_0_Template_a_click_6_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r34); const ctx_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](); return ctx_r33.limpiarFiltro(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](7, "Eliminar Filtro ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](8, "img", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](9, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](10, "section", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](11, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](12, "ng-multiselect-dropdown", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("ngModelChange", function UsuariosComponent_section_0_Template_ng_multiselect_dropdown_ngModelChange_12_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r34); const ctx_r35 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](); return ctx_r35.selectedItemsFiltroNombres = $event; })("onSelect", function UsuariosComponent_section_0_Template_ng_multiselect_dropdown_onSelect_12_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r34); const ctx_r36 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](); return ctx_r36.cambiarEtiquetaSeleccionadaGeneral("filtroNombre"); });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](13, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](14, "ng-multiselect-dropdown", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("ngModelChange", function UsuariosComponent_section_0_Template_ng_multiselect_dropdown_ngModelChange_14_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r34); const ctx_r37 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](); return ctx_r37.selectedItemsFiltroAccion = $event; })("onSelect", function UsuariosComponent_section_0_Template_ng_multiselect_dropdown_onSelect_14_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r34); const ctx_r38 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](); return ctx_r38.cambiarEtiquetaSeleccionadaGeneral("filtroAccion"); });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](15, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](16, "ng-multiselect-dropdown", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("ngModelChange", function UsuariosComponent_section_0_Template_ng_multiselect_dropdown_ngModelChange_16_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r34); const ctx_r39 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](); return ctx_r39.selectedItemsFiltroCorreos = $event; })("onSelect", function UsuariosComponent_section_0_Template_ng_multiselect_dropdown_onSelect_16_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r34); const ctx_r40 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](); return ctx_r40.cambiarEtiquetaSeleccionadaGeneral("filtroCorreo"); });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](17, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](18, "input", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](19, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](20, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](21, "button", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function UsuariosComponent_section_0_Template_button_click_21_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r34); const ctx_r41 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](); return ctx_r41.filtrar(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](22, "Buscar");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](23, UsuariosComponent_section_0_div_23_Template, 3, 2, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](24, UsuariosComponent_section_0_pagination_template_24_Template, 8, 7, "pagination-template", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("formGroup", ctx_r0.filtroAuditoriaUsuariosForm);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("placeholder", "Nombre")("settings", ctx_r0.SettingsFiltroDeNombres)("data", ctx_r0.dropdownListFiltroNombres)("ngModel", ctx_r0.selectedItemsFiltroNombres)("ngModelOptions", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction0"](23, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("placeholder", "Acci\u00F3n")("settings", ctx_r0.SettingsFiltroDeAccion)("data", ctx_r0.dropdownListFiltroAccion)("ngModel", ctx_r0.selectedItemsFiltroAccion)("ngModelOptions", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction0"](24, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("placeholder", "Correo electr\u00F3nico")("settings", ctx_r0.SettingsFiltroDeCorreos)("data", ctx_r0.dropdownListFiltroCorreos)("ngModel", ctx_r0.selectedItemsFiltroCorreos)("ngModelOptions", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction0"](25, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpropertyInterpolate"]("max", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind2"](19, 20, ctx_r0.maxDate, "yyyy-MM-dd"));
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("value", ctx_r0.maxDate);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r0.ListadoUsuariosPantalla);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r0.verPaginado());
} }
function UsuariosComponent_section_1_tr_20_td_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "td", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](2, "titlecase");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r43 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](2, 1, item_r43.valor), " ");
} }
function UsuariosComponent_section_1_tr_20_td_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "td", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r43 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"]("", item_r43.antes, " ");
} }
function UsuariosComponent_section_1_tr_20_td_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "td", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r43 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"]("", item_r43.despues, " ");
} }
function UsuariosComponent_section_1_tr_20_td_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "td", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](2, "titlecase");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r43 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"]("", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](2, 1, item_r43.valor), " ");
} }
function UsuariosComponent_section_1_tr_20_td_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "td", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r43 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"]("", item_r43.antes, " ");
} }
function UsuariosComponent_section_1_tr_20_td_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "td", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r43 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"]("", item_r43.despues, " ");
} }
function UsuariosComponent_section_1_tr_20_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, UsuariosComponent_section_1_tr_20_td_1_Template, 3, 3, "td", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](2, UsuariosComponent_section_1_tr_20_td_2_Template, 2, 1, "td", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](3, UsuariosComponent_section_1_tr_20_td_3_Template, 2, 1, "td", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](4, UsuariosComponent_section_1_tr_20_td_4_Template, 3, 3, "td", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](5, UsuariosComponent_section_1_tr_20_td_5_Template, 2, 1, "td", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](6, UsuariosComponent_section_1_tr_20_td_6_Template, 2, 1, "td", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r43 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", item_r43.cambio);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", item_r43.cambio);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", item_r43.cambio);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", !item_r43.cambio);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", !item_r43.cambio);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", !item_r43.cambio);
} }
function UsuariosComponent_section_1_Template(rf, ctx) { if (rf & 1) {
    const _r57 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "section");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](4, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "p", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](7, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](8, "p", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](10, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](11, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](12, "table", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](13, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](14, "th", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](15, "Campo");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](16, "th", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](17, "Valor previo");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](18, "th", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](19, "Valor actual");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](20, UsuariosComponent_section_1_tr_20_Template, 7, 6, "tr", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](21, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](22, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](23, "button", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function UsuariosComponent_section_1_Template_button_click_23_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r57); const ctx_r56 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](); return ctx_r56.ocultarModal(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](24, " Cerrar ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](25, "br");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"]("Detalle de cambios sobre usuario ", ctx_r1.detalleCambios.nombre, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate3"](" Realizados por ", ctx_r1.detalleCambios.usuario, " el ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind2"](10, 5, ctx_r1.detalleCambios.fecha, "dd/MM/yyyy"), " a las ", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind2"](11, 8, ctx_r1.detalleCambios.fecha, "mediumTime"), ".");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](11);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngForOf", ctx_r1.itemsTabla);
} }
function UsuariosComponent_ng_template_2_div_13_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r62 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", item_r62, " ");
} }
function UsuariosComponent_ng_template_2_div_17_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r63 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", item_r63, " ");
} }
function UsuariosComponent_ng_template_2_div_21_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r64 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", item_r64, " ");
} }
function UsuariosComponent_ng_template_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "h4", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3, "Detalle de los cambios");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](4, "button", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function UsuariosComponent_ng_template_2_Template_button_click_4_listener() { const modal_r58 = ctx.$implicit; return modal_r58.dismiss(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "span", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](6, "\u00D7");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](7, "div", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](8, "div", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](9, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](10, "div", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](11, "p", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](12, "Campo");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](13, UsuariosComponent_ng_template_2_div_13_Template, 2, 1, "div", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](14, "div", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](15, "p", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](16, "Antes");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](17, UsuariosComponent_ng_template_2_div_17_Template, 2, 1, "div", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](18, "div", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](19, "p", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](20, "Despu\u00E9s");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](21, UsuariosComponent_ng_template_2_div_21_Template, 2, 1, "div", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](22, "div", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](23, "button", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function UsuariosComponent_ng_template_2_Template_button_click_23_listener() { const modal_r58 = ctx.$implicit; return modal_r58.close(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](24, " Cerrar ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngForOf", ctx_r3.itemsValor);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngForOf", ctx_r3.itemsAntes);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngForOf", ctx_r3.itemsDespues);
} }
class UsuariosComponent {
    constructor(store, api, modalService, fb, spinner) {
        this.store = store;
        this.api = api;
        this.modalService = modalService;
        this.fb = fb;
        this.spinner = spinner;
        this.itemsAntes = [];
        this.itemsDespues = [];
        this.itemsValor = [];
        this.itemsTabla = [];
        this.ListadoUsuariosPantalla = [];
        this.dropdownListFiltroPermisos = [];
        this.SettingsFiltroDePermisos = {};
        this.selectedItemsFiltroaPermisos = [];
        this.dropdownListFiltroCorreos = [];
        this.SettingsFiltroDeCorreos = {};
        this.selectedItemsFiltroCorreos = [];
        this.dropdownListFiltroNombres = [];
        this.SettingsFiltroDeNombres = {};
        this.selectedItemsFiltroNombres = [];
        this.dropdownListFiltroAccion = [];
        this.SettingsFiltroDeAccion = {};
        this.selectedItemsFiltroAccion = [];
        this.verModal = false;
        this.initSelects = () => {
            this.maxDate = new Date();
            this.filtroAuditoriaUsuariosForm = this.fb.group({
                filtroFecha: []
            });
            this.dropdownListFiltroAccion = [
                { item_id: src_app_validators_opcionesDeFiltroAccionesAuditoriaUsuariios__WEBPACK_IMPORTED_MODULE_2__["ValorFiltrarAcciones"].Actualizar, item_text: src_app_validators_opcionesDeFiltroAccionesAuditoriaUsuariios__WEBPACK_IMPORTED_MODULE_2__["ValorFiltrarAcciones"].Actualizar },
                { item_id: src_app_validators_opcionesDeFiltroAccionesAuditoriaUsuariios__WEBPACK_IMPORTED_MODULE_2__["ValorFiltrarAcciones"].Eliminar, item_text: src_app_validators_opcionesDeFiltroAccionesAuditoriaUsuariios__WEBPACK_IMPORTED_MODULE_2__["ValorFiltrarAcciones"].Eliminar }
            ];
            this.SettingsFiltroDePermisos = {
                singleSelection: false,
                idField: 'item_id',
                textField: 'item_text',
                allowSearchFilter: false,
                clearSearchFilter: false,
                enableCheckAll: false,
                maxHeight: 200,
                itemsShowLimit: 3,
            };
            this.SettingsFiltroDeAccion = {
                singleSelection: false,
                idField: 'item_id',
                textField: 'item_text',
                allowSearchFilter: false,
                clearSearchFilter: false,
                enableCheckAll: false,
                maxHeight: 200,
                itemsShowLimit: 3,
            };
            this.SettingsFiltroDeCorreos = {
                singleSelection: false,
                idField: 'item_id',
                textField: 'item_text',
                allowSearchFilter: true,
                clearSearchFilter: true,
                enableCheckAll: false,
                maxHeight: 200,
                itemsShowLimit: 3,
                searchPlaceholderText: 'Buscar Correo electrónico',
            };
            this.SettingsFiltroDeNombres = {
                singleSelection: false,
                idField: 'item_id',
                textField: 'item_text',
                allowSearchFilter: true,
                clearSearchFilter: true,
                enableCheckAll: false,
                maxHeight: 200,
                itemsShowLimit: 3,
                searchPlaceholderText: 'Buscar Correo electrónico',
            };
        };
        this.limpiarFiltro = () => {
            this.selectedItemsFiltroNombres = [];
            this.selectedItemsFiltroAccion = [];
            this.selectedItemsFiltroCorreos = [];
            this.ListadoUsuariosPantalla = this.listadoOriginalUsuarios;
            this.filtroAuditoriaUsuariosForm.reset();
        };
        this.filtrar = () => {
            this.spinner.show();
            let FiltrarNombre = null;
            let FiltrarAccion = null;
            let FiltrarCorreo = null;
            let FiltrarFecha = this.filtroAuditoriaUsuariosForm.get('filtroFecha').value;
            console.log(this.selectedItemsFiltroNombres);
            if (this.selectedItemsFiltroNombres.length !== 0) {
                let arrayFiltroNombres = [];
                this.selectedItemsFiltroNombres.forEach((e) => {
                    arrayFiltroNombres.push(e.item_id);
                });
                FiltrarNombre = arrayFiltroNombres;
            }
            if (this.selectedItemsFiltroAccion.length !== 0) {
                let arrayFiltroAccion = [];
                this.selectedItemsFiltroAccion.forEach((e) => {
                    arrayFiltroAccion.push(e.item_id);
                });
                FiltrarAccion = arrayFiltroAccion;
            }
            if (this.selectedItemsFiltroCorreos.length !== 0) {
                let arrayFiltroCorreo = [];
                this.selectedItemsFiltroCorreos.forEach((e) => {
                    arrayFiltroCorreo.push(e.item_id);
                });
                FiltrarCorreo = arrayFiltroCorreo;
            }
            this.ListadoUsuariosPantalla = this.FiltrarNombresConAtributos(this.listadoOriginalUsuarios, FiltrarNombre, FiltrarAccion, FiltrarCorreo, FiltrarFecha);
            setTimeout(() => {
                this.spinner.hide();
            }, 300);
        };
        this.verPaginado = () => {
            if (this.ListadoUsuariosPantalla) {
                if (this.ListadoUsuariosPantalla.length > 10) {
                    return true;
                }
                else {
                    false;
                }
            }
            else {
                return false;
            }
        };
    }
    ngOnDestroy() {
        this.store.dispatch(Object(_ReduxStore_actions_usuarios_AUDGENUSUARIOS_actions__WEBPACK_IMPORTED_MODULE_0__["UnsetAUDGENUSUARIO"])());
        this.AUDGENUSUARIOS$.unsubscribe();
    }
    enProceso() {
        return false;
    }
    ngOnInit() {
        this.initSelects();
        //console.log('Acciones: ', this.dropdownListFiltroAccion)
        this.AUDGENUSUARIOS$ = this.store.select(({ AUDGENUSUARIOS }) => AUDGENUSUARIOS.AUDGENUSUARIOS).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])(res => {
            if (res === null)
                return res;
            else
                return res.slice().sort(function (a, b) { return new Date(b.FECHA).getTime() - new Date(a.FECHA).getTime(); });
        })).subscribe(usuarios => {
            this.listadoUsuarios = usuarios;
            let arrayCorreos = [];
            let arrayNombres = [];
            if (this.listadoUsuarios) {
                this.listadoUsuarios.forEach((e) => {
                    if (this.dropdownListFiltroCorreos.filter((f) => f.item_id == e.CORREO).length === 0) {
                        let index = arrayCorreos.findIndex(x => x.item_id == e.CORREO);
                        index === -1 ? arrayCorreos.push({
                            item_id: e.CORREO,
                            item_text: e.CORREO,
                        }) : null;
                        index === -1 ? arrayNombres.push({
                            item_id: e.USUARIO.NOMBRE + e.USUARIO.APELLIDO_PATERNO,
                            item_text: e.USUARIO.NOMBRE + ' ' + e.USUARIO.APELLIDO_PATERNO
                        }) : null;
                    }
                });
                if (this.dropdownListFiltroCorreos.length === 0) {
                    this.dropdownListFiltroCorreos = [...new Set(arrayCorreos)];
                    this.dropdownListFiltroNombres = [...new Set(arrayNombres)];
                }
            }
            this.ListadoUsuariosPantalla = usuarios;
            this.listadoOriginalUsuarios = usuarios;
        });
        // this.store.select(
        //   ({ AUDGENUSUARIOS }) => AUDGENUSUARIOS.AUDGENUSUARIOS
        // ).subscribe(res => { console.log(res)})
        this.store.dispatch(Object(_ReduxStore_actions_usuarios_AUDGENUSUARIOS_actions__WEBPACK_IMPORTED_MODULE_0__["LoadAUDGENUSUARIOS"])({ consult: { MODULO: 'USUARIOS' } }));
        // this.api.ListAUDGENUSUARIOS('USUARIOS').then(res => {
        //   console.log(res)
        // })
    }
    cambiarEtiquetaSeleccionadaGeneral(elemento) {
        setTimeout(() => {
            $('#' + elemento)
                .find('.selected-item')
                .attr('class', 'etiquetasCatalogos');
        }, 1);
    }
    mostrarDetalle() {
        return this.verModal;
    }
    ocultarModal() {
        this.verModal = false;
    }
    openModal(objetoDetalle) {
        console.log(objetoDetalle);
        this.itemsTabla = [];
        const accion = objetoDetalle.PERMISOS_USUARIOS[0].ACCION;
        let valores = [];
        let tabla = [];
        let arregloAntes = [];
        let arregloDespues = [];
        let cambiosAntes = objetoDetalle.PERMISOS_USUARIOS[0].DETALLE_MODIFICACIONES[0].valorAnterior;
        let cambiosDespues = objetoDetalle.PERMISOS_USUARIOS[0].DETALLE_MODIFICACIONES[0].valorNuevo;
        let valorAntes;
        let valorDespues;
        let banderaCambio = false;
        this.detalleCambios = {
            nombre: objetoDetalle.PERMISOS_USUARIOS[0].NOMBRE + ' ' + objetoDetalle.PERMISOS_USUARIOS[0].APELLIDO_PATERNO,
            usuario: objetoDetalle.USUARIO.NOMBRE + ' ' + objetoDetalle.USUARIO.APELLIDO_PATERNO,
            fecha: objetoDetalle.FECHA
        };
        this.itemsValor = [];
        this.itemsAntes = [];
        this.itemsDespues = [];
        //console.log("Entrando al modal", objetoDetalle)
        if (cambiosAntes !== null) {
            cambiosAntes = cambiosAntes.replace('{', '');
            cambiosAntes = cambiosAntes.replace('}', '');
            let arregloAntes = cambiosAntes.split(",");
            let resAntes = [];
            for (let i in arregloAntes) {
                let valor = arregloAntes[i].toString().split("=");
                resAntes.push(valor[1]);
            }
            this.itemsAntes = resAntes;
            //console.log("cambiosAntes", arregloAntes)
        }
        if (cambiosAntes !== null) {
            cambiosAntes = cambiosAntes.replace('{', '');
            cambiosAntes = cambiosAntes.replace('}', '');
        }
        if (cambiosDespues !== null) {
            cambiosDespues = cambiosDespues.replace('{', '');
            cambiosDespues = cambiosDespues.replace('}', '');
        }
        if (accion === 'ELIMINAR') {
            const getValor = cambiosAntes.split(', ');
            for (let i in getValor) {
                if (getValor) {
                    let valor = getValor[i].toString().split('=');
                    valores.push(valor[0]);
                }
            }
            arregloAntes = cambiosAntes.split(', ');
        }
        else {
            const getValor = cambiosDespues.split(', ');
            console.log('getValor: ', getValor);
            for (let i in getValor) {
                if (getValor) {
                    let valor = getValor[i].toString().split('=');
                    //console.log('Valor',valor[0])          
                    valores.push(valor[0]);
                }
            }
            if (cambiosAntes !== null) {
                arregloAntes = cambiosAntes.split(', ');
                arregloDespues = cambiosDespues.split(', ');
            }
        }
        if (valores !== null) {
            console.log('Valores: ', valores);
            for (let i in valores) {
                if (valores) {
                    if (arregloAntes.length > 0) {
                        // if(!arregloAntes.find(e => e.includes(valores[i])).split('=')[1]){
                        //   valorAntes = ''
                        // }else
                        // console.log('Valores i: ', valores[i])
                        // console.log(arregloAntes.length)
                        // console.log('Que es este valor: ', arregloAntes.find(e => e.includes(valores[i])).split('='))
                        valorAntes = arregloAntes.find(e => e.includes(valores[i])) ? arregloAntes.find(e => e.includes(valores[i])).split('=')[1] : '';
                    }
                    else {
                        valorAntes = '';
                    }
                    if (arregloDespues.length > 0) {
                        valorDespues = arregloDespues.find(e => e.includes(valores[i])) ? arregloDespues.find(e => e.includes(valores[i])).split('=')[1] : '';
                    }
                    else {
                        valorDespues = '';
                    }
                    if (valorAntes === valorDespues) {
                        banderaCambio = false;
                    }
                    else {
                        banderaCambio = true;
                    }
                    if (valores[i] === 'area') {
                        valores[i] = 'área';
                    }
                    tabla.push({ valor: valores[i], antes: valorAntes, despues: valorDespues, cambio: banderaCambio });
                }
            }
        }
        this.itemsTabla = tabla;
        console.log(this.itemsTabla);
        this.verModal = true;
        console.log(this.verModal);
        // if (cambiosDespues !== null) {
        //   cambiosDespues = cambiosDespues.replace('{', '');
        //   cambiosDespues = cambiosDespues.replace('}', '');
        //   let arregloDespues = cambiosDespues.split(",");
        //   let resDespues = [];
        //   for (let i in arregloDespues) {
        //     let valor = arregloDespues[i].toString().split("=");
        //     resDespues.push(valor[1]);
        //   }
        //   this.itemsDespues = resDespues;
        //   //console.log("cambiosDespues", arregloDespues)
        // }
        // if (cambiosAntes !== null) {
        //   let getValor = cambiosAntes.split(",");
        //   let resultado = [];
        //   for (let i in getValor) {
        //     let valor = getValor[i].toString().split("=");
        //     resultado.push(valor[0]);
        //   }
        //   this.itemsValor = resultado;
        //   //console.log("result", resultado)
        // }
        // else if (cambiosDespues !== null) {
        //   let getValor = cambiosDespues.split(",");
        //   let resultado = [];
        //   for (let i in getValor) {
        //     let valor = getValor[i].toString().split("=");
        //     resultado.push(valor[0]);
        //   }
        //   this.itemsValor = resultado;
        //   //console.log("result", resultado)
        // }
        // // console.log("itemsValor", this.itemsValor)
        // // console.log("itemsAntes", this.itemsAntes)
        // // console.log("itemsDespues", this.itemsDespues)
        // this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' });
    }
    FiltrarNombresConAtributos(ListadoOriginal, FiltrarNombre, FiltrarAccion, FiltrarCorreo, FiltrarFecha) {
        let response = ListadoOriginal;
        if (FiltrarNombre != null) {
            let arrayTempPermiso = [];
            FiltrarNombre.forEach((FiltrarNombre) => {
                arrayTempPermiso = [
                    ...arrayTempPermiso,
                    ...response.filter((e) => e.USUARIO.NOMBRE + e.USUARIO.APELLIDO_PATERNO === FiltrarNombre),
                ];
            });
            response = arrayTempPermiso;
        }
        console.log('Filtro Acción: ', FiltrarAccion);
        if (FiltrarAccion != null) {
            let arrayTempPermiso = [];
            FiltrarAccion.forEach((FiltrarAccion) => {
                arrayTempPermiso = [
                    ...arrayTempPermiso,
                    ...response.filter((e) => e.PERMISOS_USUARIOS[0].ACCION === FiltrarAccion.toUpperCase()),
                ];
            });
            response = arrayTempPermiso;
        }
        if (FiltrarCorreo != null) {
            let arrayTempPermiso = [];
            FiltrarCorreo.forEach((FiltrarCorreo) => {
                arrayTempPermiso = [
                    ...arrayTempPermiso,
                    ...response.filter((e) => e.CORREO === FiltrarCorreo),
                ];
            });
            response = arrayTempPermiso;
        }
        console.log(FiltrarFecha);
        if (FiltrarFecha != null) {
            let arrayTempFecha = [];
            arrayTempFecha = response.filter((e) => e.FECHA.includes(FiltrarFecha));
            response = arrayTempFecha;
        }
        const uniqueArr = [...new Set(response.map(data => data.ID))];
        //console.log(uniqueArr)
        return response;
    }
}
UsuariosComponent.ɵfac = function UsuariosComponent_Factory(t) { return new (t || UsuariosComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_ngrx_store__WEBPACK_IMPORTED_MODULE_4__["Store"]), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_API_service__WEBPACK_IMPORTED_MODULE_5__["APIService"]), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_6__["NgbModal"]), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormBuilder"]), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_8__["NgxSpinnerService"])); };
UsuariosComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({ type: UsuariosComponent, selectors: [["app-usuarios"]], decls: 4, vars: 2, consts: [[4, "ngIf"], ["content", ""], [1, "card-busqueda"], [1, "mt-4"], [2, "text-align", "right", "width", "100%", "justify-content", "flex-end", "direction", "rtl"], [2, "margin-right", "10%"], [1, "limpiarFiltro", 3, "click"], ["src", "assets/icons/Eliminar.svg", 1, "tamanioFiltroIcono"], ["name", "filtros", 3, "formGroup"], [1, "mt-3"], [1, "col2-row2"], ["id", "filtroNombre", 2, "width", "80%", "padding-left", "10px", 3, "placeholder", "settings", "data", "ngModel", "ngModelOptions", "ngModelChange", "onSelect"], ["id", "filtroAccion", 2, "width", "80%", 3, "placeholder", "settings", "data", "ngModel", "ngModelOptions", "ngModelChange", "onSelect"], ["id", "filtroCorreo", 2, "width", "80%", "padding-left", "10px", 3, "placeholder", "settings", "data", "ngModel", "ngModelOptions", "ngModelChange", "onSelect"], ["type", "date", "placeholder", "dd-MM-yyyy", "onfocus", "(this.type='date')", "formControlName", "filtroFecha", "id", "filtroFecha", "name", "filtroFecha", 2, "width", "80%", "padding-left", "10px", 3, "value", "max"], [2, "cursor", "pointer", 3, "click"], ["class", " d-flex col-md-12 col-sm-12 col-xs-12 col-lg-12 col-xl-12 justify-content-center", 4, "ngIf"], ["id", "Usuarios", "class", "ngx-pagination", 3, "pageChange", 4, "ngIf"], [1, "d-flex", "col-md-12", "col-sm-12", "col-xs-12", "col-lg-12", "col-xl-12", "justify-content-center"], ["class", "row justify-content-center", 4, "ngIf"], ["class", "card-lista-design-general", "style", "overflow-x: auto", 4, "ngIf"], [1, "row", "justify-content-center"], [1, "align-self-center"], [1, "d-flex", "flex-column", 2, "width", "504px"], [1, "descripcionNoAuditoria", 2, "margin-top", "34px"], [1, "row"], [1, "col-12"], [1, "card-lista-design-general", 2, "overflow-x", "auto"], [1, "table", "listado-design-general"], [2, "padding-left", "40px", "max-width", "300px"], [2, "padding-left", "40px", "max-width", "150px"], [4, "ngFor", "ngForOf"], [1, "justify-content-center", 2, "width", "200px"], [1, "detalle-icon", 2, "cursor", "pointer", 3, "click"], ["id", "Usuarios", 1, "ngx-pagination", 3, "pageChange"], ["p", "paginationApi"], [1, "custom-pagination"], [1, "pagination-previous"], [3, "click", 4, "ngIf"], ["class", "page-number", 3, "current", 4, "ngFor", "ngForOf"], [1, "pagination-next"], [3, "click"], [1, "page-number"], [1, "titulo-modal"], [1, "texto-modal"], [2, "padding-left", "30px", "max-width", "300px"], [2, "padding-left", "30px", "max-width", "150px"], [1, "btn", "bottonCerrarModal", 3, "click"], ["style", "padding-left: 30px; max-width: 150px; background-color:#0091DA; color: #ffffff", 4, "ngIf"], ["style", "padding-left: 30px; max-width: 150px", 4, "ngIf"], [2, "padding-left", "30px", "max-width", "150px", "background-color", "#0091DA", "color", "#ffffff"], [1, "modal-header"], ["id", "modal-basic-title", 1, "modal-title"], ["type", "button", "aria-label", "Close", 3, "click"], ["aria-hidden", "true"], [1, "modal-body"], [1, "container"], [1, "col-sm"], [1, "titulo"], [1, "modal-footer"], ["type", "button", "data-dismiss", "modal", 1, "btn", "bottonCerrarModal", 3, "click"]], template: function UsuariosComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](0, UsuariosComponent_section_0_Template, 25, 26, "section", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, UsuariosComponent_section_1_Template, 26, 11, "section", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](2, UsuariosComponent_ng_template_2_Template, 25, 3, "ng-template", null, 1, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplateRefExtractor"]);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", !ctx.mostrarDetalle());
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.mostrarDetalle());
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_9__["NgIf"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormGroupDirective"], ng_multiselect_dropdown__WEBPACK_IMPORTED_MODULE_10__["MultiSelectComponent"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__["NgModel"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControlName"], _angular_common__WEBPACK_IMPORTED_MODULE_9__["NgForOf"], ngx_pagination__WEBPACK_IMPORTED_MODULE_11__["PaginationControlsDirective"]], pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_9__["DatePipe"], ngx_pagination__WEBPACK_IMPORTED_MODULE_11__["PaginatePipe"], _angular_common__WEBPACK_IMPORTED_MODULE_9__["TitleCasePipe"]], styles: [".center[_ngcontent-%COMP%] {\r\n  display: block;\r\n  margin-left: auto;\r\n  margin-right: auto;\r\n}\r\n\r\n.wrapper[_ngcontent-%COMP%] {\r\n  display: flex;\r\n  flex-wrap: wrap;\r\n}\r\n\r\n.content[_ngcontent-%COMP%] {\r\n  width: 100%;\r\n  display: flex;\r\n  flex-wrap: wrap;\r\n  flex-direction: column;\r\n}\r\n\r\ndiv.card-busqueda[_ngcontent-%COMP%] {\r\n  width: 90%;\r\n  background: #ffffff 0% 0% no-repeat padding-box;\r\n  border-radius: 30px;\r\n  opacity: 1;\r\n  display: flex;\r\n  margin: 25px 0;\r\n  margin-right: 5%;\r\n  margin-left: 5%;\r\n  flex-direction: column;\r\n  align-items: center;\r\n  border-radius: 25px;\r\n  border-left: 10px solid #035fa4;\r\n  box-shadow: 4px 4px 10px #00000033;\r\n}\r\n\r\n.card-busqueda[_ngcontent-%COMP%]   div[_ngcontent-%COMP%] {\r\n  color: #035fa4;\r\n  border: black;\r\n  height: auto;\r\n  width: auto;\r\n  flex-grow: 1;\r\n  display: flex;\r\n  align-items: center;\r\n  font: bold 20px FS Elliot Pro;\r\n}\r\n\r\n.card-busqueda[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]    > button[_ngcontent-%COMP%] {\r\n  background-color: #0091da;\r\n  color: white;\r\n  width: 296px;\r\n  height: 50px;\r\n  border-radius: 25px;\r\n  font: bold 20px FS Elliot Pro;\r\n  border: none;\r\n}\r\n\r\ndiv.card-lista-design-general[_ngcontent-%COMP%] {\r\n  width: auto;\r\n  min-width: 477px;\r\n  flex: auto;\r\n  display: flex;\r\n  flex-wrap: wrap;\r\n  vertical-align: middle;\r\n}\r\n\r\ntable.listado-design-general[_ngcontent-%COMP%]   th[_ngcontent-%COMP%] {\r\n  background-color: #035fa4;\r\n  font: bold 18px FS Elliot Pro;\r\n  height: 40px;\r\n  height: 40px;\r\n  font: bold 18px FS Elliot Pro;\r\n}\r\n\r\nsection[_ngcontent-%COMP%] {\r\n  display: flex;\r\n  flex-wrap: wrap;\r\n  justify-content: space-between;\r\n}\r\n\r\n.col2-row2[_ngcontent-%COMP%] {\r\n  display: flex;\r\n  justify-content: center;\r\n  align-items: center;\r\n  flex-grow: 0;\r\n  flex-shrink: 0;\r\n  flex-basis: 50%;\r\n  margin-bottom: 1.5%;\r\n}\r\n\r\n.selectList[_ngcontent-%COMP%] {\r\n  text-align: left;\r\n  font: normal normal normal 18px/45px FS Elliot Pro;\r\n  letter-spacing: 0px;\r\n  color: #707070;\r\n  width: 296px;\r\n  height: 35px;\r\n  font: bold 18px FS Elliot Pro;\r\n  background: #ffffff 0% 0% no-repeat padding-box;\r\n  border: 1px solid #d6d6d6;\r\n  border-radius: 9px;\r\n  opacity: 1;\r\n}\r\n\r\n#correo[_ngcontent-%COMP%] {\r\n  width: 100%;\r\n}\r\n\r\n#correo[_ngcontent-%COMP%]   .selected-item[_ngcontent-%COMP%] {\r\n  width: 200px !important;\r\n}\r\n\r\n.limpiarFiltro[_ngcontent-%COMP%] {\r\n  text-align: right;\r\n  text-decoration: underline;\r\n  font: normal normal normal 14px/22px FS Elliot Pro;\r\n  letter-spacing: 0px;\r\n  -webkit-text-decoration: underline #0091da !important;\r\n          text-decoration: underline #0091da !important;\r\n  color: #0091da !important;\r\n}\r\n\r\n.limpiarFiltro[_ngcontent-%COMP%]:hover {\r\n  cursor: pointer;\r\n}\r\n\r\n.tamanioFiltroIcono[_ngcontent-%COMP%] {\r\n  width: 12px;\r\n  height: 12px;\r\n  margin-top: -4px;\r\n}\r\n\r\n.modal-content[_ngcontent-%COMP%] {\r\n  background-color: red !important;\r\n}\r\n\r\n.detalle-icon[_ngcontent-%COMP%] {\r\n  background: transparent url(\"/../../../../assets/icons/icono-detalle.svg\") 0%\r\n    0% no-repeat padding-box;\r\n  width: 30px;\r\n  height: 30px;\r\n  opacity: 1;\r\n  margin: 0 15px;\r\n  padding: 15px;\r\n}\r\n\r\n.bottonCerrarModal[_ngcontent-%COMP%] {\r\n  border: 2px solid #0091da;\r\n  border-radius: 30px;\r\n  opacity: 1;\r\n  width: 184px;\r\n  text-decoration: none;\r\n  height: 48px;\r\n  color: #0091da;\r\n  margin-right: 22px;\r\n  margin-top: 15px;\r\n  margin-bottom: 15px;\r\n  font: normal normal bold 20px/25px FS Elliot Pro;\r\n}\r\n\r\n.titulo[_ngcontent-%COMP%] {\r\n  font: bold 18px FS Elliot Pro;\r\n  color: #035fa4;\r\n}\r\n\r\n.titulo-modal[_ngcontent-%COMP%] {\r\n  font: bold 24px FS Elliot Pro;\r\n  color: #035fa4;\r\n}\r\n\r\n.texto-modal[_ngcontent-%COMP%] {\r\n  font: 18px FS Elliot Pro;\r\n  color: #035fa4;\r\n}\r\n\r\n.paginator[_ngcontent-%COMP%] {\r\n  margin-left: 5%;\r\n  margin-right: 5%;\r\n  margin-bottom: 5%;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzdWFyaW9zLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxjQUFjO0VBQ2QsaUJBQWlCO0VBQ2pCLGtCQUFrQjtBQUNwQjs7QUFFQTtFQUNFLGFBQWE7RUFDYixlQUFlO0FBQ2pCOztBQUVBO0VBQ0UsV0FBVztFQUNYLGFBQWE7RUFDYixlQUFlO0VBQ2Ysc0JBQXNCO0FBQ3hCOztBQUVBO0VBQ0UsVUFBVTtFQUNWLCtDQUErQztFQUMvQyxtQkFBbUI7RUFDbkIsVUFBVTtFQUNWLGFBQWE7RUFDYixjQUFjO0VBQ2QsZ0JBQWdCO0VBQ2hCLGVBQWU7RUFDZixzQkFBc0I7RUFDdEIsbUJBQW1CO0VBQ25CLG1CQUFtQjtFQUNuQiwrQkFBK0I7RUFDL0Isa0NBQWtDO0FBQ3BDOztBQUVBO0VBQ0UsY0FBYztFQUNkLGFBQWE7RUFDYixZQUFZO0VBQ1osV0FBVztFQUNYLFlBQVk7RUFDWixhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CLDZCQUE2QjtBQUMvQjs7QUFFQTtFQUNFLHlCQUF5QjtFQUN6QixZQUFZO0VBQ1osWUFBWTtFQUNaLFlBQVk7RUFDWixtQkFBbUI7RUFDbkIsNkJBQTZCO0VBQzdCLFlBQVk7QUFDZDs7QUFFQTtFQUNFLFdBQVc7RUFDWCxnQkFBZ0I7RUFDaEIsVUFBVTtFQUNWLGFBQWE7RUFDYixlQUFlO0VBQ2Ysc0JBQXNCO0FBQ3hCOztBQUVBO0VBQ0UseUJBQXlCO0VBQ3pCLDZCQUE2QjtFQUM3QixZQUFZO0VBQ1osWUFBWTtFQUNaLDZCQUE2QjtBQUMvQjs7QUFFQTtFQUNFLGFBQWE7RUFDYixlQUFlO0VBQ2YsOEJBQThCO0FBQ2hDOztBQUVBO0VBQ0UsYUFBYTtFQUNiLHVCQUF1QjtFQUN2QixtQkFBbUI7RUFDbkIsWUFBWTtFQUNaLGNBQWM7RUFDZCxlQUFlO0VBQ2YsbUJBQW1CO0FBQ3JCOztBQUVBO0VBQ0UsZ0JBQWdCO0VBQ2hCLGtEQUFrRDtFQUNsRCxtQkFBbUI7RUFDbkIsY0FBYztFQUNkLFlBQVk7RUFDWixZQUFZO0VBQ1osNkJBQTZCO0VBQzdCLCtDQUErQztFQUMvQyx5QkFBeUI7RUFDekIsa0JBQWtCO0VBQ2xCLFVBQVU7QUFDWjs7QUFFQTtFQUNFLFdBQVc7QUFDYjs7QUFFQTtFQUNFLHVCQUF1QjtBQUN6Qjs7QUFFQTtFQUNFLGlCQUFpQjtFQUNqQiwwQkFBMEI7RUFDMUIsa0RBQWtEO0VBQ2xELG1CQUFtQjtFQUNuQixxREFBNkM7VUFBN0MsNkNBQTZDO0VBQzdDLHlCQUF5QjtBQUMzQjs7QUFFQTtFQUNFLGVBQWU7QUFDakI7O0FBRUE7RUFDRSxXQUFXO0VBQ1gsWUFBWTtFQUNaLGdCQUFnQjtBQUNsQjs7QUFFQTtFQUNFLGdDQUFnQztBQUNsQzs7QUFFQTtFQUNFOzRCQUMwQjtFQUMxQixXQUFXO0VBQ1gsWUFBWTtFQUNaLFVBQVU7RUFDVixjQUFjO0VBQ2QsYUFBYTtBQUNmOztBQUVBO0VBQ0UseUJBQXlCO0VBQ3pCLG1CQUFtQjtFQUNuQixVQUFVO0VBQ1YsWUFBWTtFQUNaLHFCQUFxQjtFQUNyQixZQUFZO0VBQ1osY0FBYztFQUNkLGtCQUFrQjtFQUNsQixnQkFBZ0I7RUFDaEIsbUJBQW1CO0VBQ25CLGdEQUFnRDtBQUNsRDs7QUFFQTtFQUNFLDZCQUE2QjtFQUM3QixjQUFjO0FBQ2hCOztBQUVBO0VBQ0UsNkJBQTZCO0VBQzdCLGNBQWM7QUFDaEI7O0FBRUE7RUFDRSx3QkFBd0I7RUFDeEIsY0FBYztBQUNoQjs7QUFFQTtFQUNFLGVBQWU7RUFDZixnQkFBZ0I7RUFDaEIsaUJBQWlCO0FBQ25CIiwiZmlsZSI6InVzdWFyaW9zLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY2VudGVyIHtcclxuICBkaXNwbGF5OiBibG9jaztcclxuICBtYXJnaW4tbGVmdDogYXV0bztcclxuICBtYXJnaW4tcmlnaHQ6IGF1dG87XHJcbn1cclxuXHJcbi53cmFwcGVyIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtd3JhcDogd3JhcDtcclxufVxyXG5cclxuLmNvbnRlbnQge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC13cmFwOiB3cmFwO1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbn1cclxuXHJcbmRpdi5jYXJkLWJ1c3F1ZWRhIHtcclxuICB3aWR0aDogOTAlO1xyXG4gIGJhY2tncm91bmQ6ICNmZmZmZmYgMCUgMCUgbm8tcmVwZWF0IHBhZGRpbmctYm94O1xyXG4gIGJvcmRlci1yYWRpdXM6IDMwcHg7XHJcbiAgb3BhY2l0eTogMTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIG1hcmdpbjogMjVweCAwO1xyXG4gIG1hcmdpbi1yaWdodDogNSU7XHJcbiAgbWFyZ2luLWxlZnQ6IDUlO1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBib3JkZXItcmFkaXVzOiAyNXB4O1xyXG4gIGJvcmRlci1sZWZ0OiAxMHB4IHNvbGlkICMwMzVmYTQ7XHJcbiAgYm94LXNoYWRvdzogNHB4IDRweCAxMHB4ICMwMDAwMDAzMztcclxufVxyXG5cclxuLmNhcmQtYnVzcXVlZGEgZGl2IHtcclxuICBjb2xvcjogIzAzNWZhNDtcclxuICBib3JkZXI6IGJsYWNrO1xyXG4gIGhlaWdodDogYXV0bztcclxuICB3aWR0aDogYXV0bztcclxuICBmbGV4LWdyb3c6IDE7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIGZvbnQ6IGJvbGQgMjBweCBGUyBFbGxpb3QgUHJvO1xyXG59XHJcblxyXG4uY2FyZC1idXNxdWVkYSBkaXYgPiBidXR0b24ge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICMwMDkxZGE7XHJcbiAgY29sb3I6IHdoaXRlO1xyXG4gIHdpZHRoOiAyOTZweDtcclxuICBoZWlnaHQ6IDUwcHg7XHJcbiAgYm9yZGVyLXJhZGl1czogMjVweDtcclxuICBmb250OiBib2xkIDIwcHggRlMgRWxsaW90IFBybztcclxuICBib3JkZXI6IG5vbmU7XHJcbn1cclxuXHJcbmRpdi5jYXJkLWxpc3RhLWRlc2lnbi1nZW5lcmFsIHtcclxuICB3aWR0aDogYXV0bztcclxuICBtaW4td2lkdGg6IDQ3N3B4O1xyXG4gIGZsZXg6IGF1dG87XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LXdyYXA6IHdyYXA7XHJcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcclxufVxyXG5cclxudGFibGUubGlzdGFkby1kZXNpZ24tZ2VuZXJhbCB0aCB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzAzNWZhNDtcclxuICBmb250OiBib2xkIDE4cHggRlMgRWxsaW90IFBybztcclxuICBoZWlnaHQ6IDQwcHg7XHJcbiAgaGVpZ2h0OiA0MHB4O1xyXG4gIGZvbnQ6IGJvbGQgMThweCBGUyBFbGxpb3QgUHJvO1xyXG59XHJcblxyXG5zZWN0aW9uIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtd3JhcDogd3JhcDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbn1cclxuXHJcbi5jb2wyLXJvdzIge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBmbGV4LWdyb3c6IDA7XHJcbiAgZmxleC1zaHJpbms6IDA7XHJcbiAgZmxleC1iYXNpczogNTAlO1xyXG4gIG1hcmdpbi1ib3R0b206IDEuNSU7XHJcbn1cclxuXHJcbi5zZWxlY3RMaXN0IHtcclxuICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gIGZvbnQ6IG5vcm1hbCBub3JtYWwgbm9ybWFsIDE4cHgvNDVweCBGUyBFbGxpb3QgUHJvO1xyXG4gIGxldHRlci1zcGFjaW5nOiAwcHg7XHJcbiAgY29sb3I6ICM3MDcwNzA7XHJcbiAgd2lkdGg6IDI5NnB4O1xyXG4gIGhlaWdodDogMzVweDtcclxuICBmb250OiBib2xkIDE4cHggRlMgRWxsaW90IFBybztcclxuICBiYWNrZ3JvdW5kOiAjZmZmZmZmIDAlIDAlIG5vLXJlcGVhdCBwYWRkaW5nLWJveDtcclxuICBib3JkZXI6IDFweCBzb2xpZCAjZDZkNmQ2O1xyXG4gIGJvcmRlci1yYWRpdXM6IDlweDtcclxuICBvcGFjaXR5OiAxO1xyXG59XHJcblxyXG4jY29ycmVvIHtcclxuICB3aWR0aDogMTAwJTtcclxufVxyXG5cclxuI2NvcnJlbyAuc2VsZWN0ZWQtaXRlbSB7XHJcbiAgd2lkdGg6IDIwMHB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5saW1waWFyRmlsdHJvIHtcclxuICB0ZXh0LWFsaWduOiByaWdodDtcclxuICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcclxuICBmb250OiBub3JtYWwgbm9ybWFsIG5vcm1hbCAxNHB4LzIycHggRlMgRWxsaW90IFBybztcclxuICBsZXR0ZXItc3BhY2luZzogMHB4O1xyXG4gIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lICMwMDkxZGEgIWltcG9ydGFudDtcclxuICBjb2xvcjogIzAwOTFkYSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4ubGltcGlhckZpbHRybzpob3ZlciB7XHJcbiAgY3Vyc29yOiBwb2ludGVyO1xyXG59XHJcblxyXG4udGFtYW5pb0ZpbHRyb0ljb25vIHtcclxuICB3aWR0aDogMTJweDtcclxuICBoZWlnaHQ6IDEycHg7XHJcbiAgbWFyZ2luLXRvcDogLTRweDtcclxufVxyXG5cclxuLm1vZGFsLWNvbnRlbnQge1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHJlZCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uZGV0YWxsZS1pY29uIHtcclxuICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudCB1cmwoXCIvLi4vLi4vLi4vLi4vYXNzZXRzL2ljb25zL2ljb25vLWRldGFsbGUuc3ZnXCIpIDAlXHJcbiAgICAwJSBuby1yZXBlYXQgcGFkZGluZy1ib3g7XHJcbiAgd2lkdGg6IDMwcHg7XHJcbiAgaGVpZ2h0OiAzMHB4O1xyXG4gIG9wYWNpdHk6IDE7XHJcbiAgbWFyZ2luOiAwIDE1cHg7XHJcbiAgcGFkZGluZzogMTVweDtcclxufVxyXG5cclxuLmJvdHRvbkNlcnJhck1vZGFsIHtcclxuICBib3JkZXI6IDJweCBzb2xpZCAjMDA5MWRhO1xyXG4gIGJvcmRlci1yYWRpdXM6IDMwcHg7XHJcbiAgb3BhY2l0eTogMTtcclxuICB3aWR0aDogMTg0cHg7XHJcbiAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xyXG4gIGhlaWdodDogNDhweDtcclxuICBjb2xvcjogIzAwOTFkYTtcclxuICBtYXJnaW4tcmlnaHQ6IDIycHg7XHJcbiAgbWFyZ2luLXRvcDogMTVweDtcclxuICBtYXJnaW4tYm90dG9tOiAxNXB4O1xyXG4gIGZvbnQ6IG5vcm1hbCBub3JtYWwgYm9sZCAyMHB4LzI1cHggRlMgRWxsaW90IFBybztcclxufVxyXG5cclxuLnRpdHVsbyB7XHJcbiAgZm9udDogYm9sZCAxOHB4IEZTIEVsbGlvdCBQcm87XHJcbiAgY29sb3I6ICMwMzVmYTQ7XHJcbn1cclxuXHJcbi50aXR1bG8tbW9kYWwge1xyXG4gIGZvbnQ6IGJvbGQgMjRweCBGUyBFbGxpb3QgUHJvO1xyXG4gIGNvbG9yOiAjMDM1ZmE0O1xyXG59XHJcblxyXG4udGV4dG8tbW9kYWwge1xyXG4gIGZvbnQ6IDE4cHggRlMgRWxsaW90IFBybztcclxuICBjb2xvcjogIzAzNWZhNDtcclxufVxyXG5cclxuLnBhZ2luYXRvciB7XHJcbiAgbWFyZ2luLWxlZnQ6IDUlO1xyXG4gIG1hcmdpbi1yaWdodDogNSU7XHJcbiAgbWFyZ2luLWJvdHRvbTogNSU7XHJcbn1cclxuIl19 */"] });


/***/ }),

/***/ "Fd4u":
/*!***************************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/auditoria/usuarios/usuarios-routing.module.ts ***!
  \***************************************************************************************/
/*! exports provided: UsuariosRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsuariosRoutingModule", function() { return UsuariosRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _usuarios_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./usuarios.component */ "FVhR");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");




const routes = [{ path: '', component: _usuarios_component__WEBPACK_IMPORTED_MODULE_1__["UsuariosComponent"] }];
class UsuariosRoutingModule {
}
UsuariosRoutingModule.ɵfac = function UsuariosRoutingModule_Factory(t) { return new (t || UsuariosRoutingModule)(); };
UsuariosRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: UsuariosRoutingModule });
UsuariosRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](UsuariosRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] }); })();


/***/ }),

/***/ "TjSY":
/*!********************************************!*\
  !*** ./src/app/helpers/FuncionesUtiles.ts ***!
  \********************************************/
/*! exports provided: retornarStringSiexiste */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "retornarStringSiexiste", function() { return retornarStringSiexiste; });
const retornarStringSiexiste = (object, attribute) => {
    if (object.hasOwnProperty(attribute)) {
        return object[attribute];
    }
    else {
        return '';
    }
};


/***/ }),

/***/ "aQ0i":
/*!*******************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/auditoria/usuarios/usuarios.module.ts ***!
  \*******************************************************************************/
/*! exports provided: UsuariosModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsuariosModule", function() { return UsuariosModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _usuarios_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./usuarios-routing.module */ "Fd4u");
/* harmony import */ var _usuarios_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./usuarios.component */ "FVhR");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var ng_multiselect_dropdown__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ng-multiselect-dropdown */ "Egam");
/* harmony import */ var ngx_pagination__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ngx-pagination */ "oOf3");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ngx-spinner */ "JqCM");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ "fXoL");









class UsuariosModule {
}
UsuariosModule.ɵfac = function UsuariosModule_Factory(t) { return new (t || UsuariosModule)(); };
UsuariosModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineNgModule"]({ type: UsuariosModule });
UsuariosModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
            _usuarios_routing_module__WEBPACK_IMPORTED_MODULE_1__["UsuariosRoutingModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            ngx_spinner__WEBPACK_IMPORTED_MODULE_6__["NgxSpinnerModule"],
            ngx_pagination__WEBPACK_IMPORTED_MODULE_5__["NgxPaginationModule"],
            ng_multiselect_dropdown__WEBPACK_IMPORTED_MODULE_4__["NgMultiSelectDropDownModule"].forRoot(),
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵsetNgModuleScope"](UsuariosModule, { declarations: [_usuarios_component__WEBPACK_IMPORTED_MODULE_2__["UsuariosComponent"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
        _usuarios_routing_module__WEBPACK_IMPORTED_MODULE_1__["UsuariosRoutingModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
        ngx_spinner__WEBPACK_IMPORTED_MODULE_6__["NgxSpinnerModule"],
        ngx_pagination__WEBPACK_IMPORTED_MODULE_5__["NgxPaginationModule"], ng_multiselect_dropdown__WEBPACK_IMPORTED_MODULE_4__["NgMultiSelectDropDownModule"]] }); })();


/***/ }),

/***/ "jix7":
/*!**************************************************************************!*\
  !*** ./src/app/validators/opcionesDeFiltroAccionesAuditoriaUsuariios.ts ***!
  \**************************************************************************/
/*! exports provided: ValorFiltrarAcciones */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ValorFiltrarAcciones", function() { return ValorFiltrarAcciones; });
var ValorFiltrarAcciones;
(function (ValorFiltrarAcciones) {
    ValorFiltrarAcciones["Actualizar"] = "Actualizar";
    ValorFiltrarAcciones["Eliminar"] = "Eliminar";
})(ValorFiltrarAcciones || (ValorFiltrarAcciones = {}));


/***/ }),

/***/ "k/wk":
/*!*****************************************************!*\
  !*** ./src/app/pipes/oredenascEmailusurios.pipe.ts ***!
  \*****************************************************/
/*! exports provided: OredenascEmailusuriosPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OredenascEmailusuriosPipe", function() { return OredenascEmailusuriosPipe; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");

class OredenascEmailusuriosPipe {
    transform(ListadoUsuarios, key) {
        return [...ListadoUsuarios].sort((a, b) => {
            if (!a.Attributes.hasOwnProperty(key) ||
                !b.Attributes.hasOwnProperty(key)) {
                // property doesn't exist on either object
                return 0;
            }
            const varA = typeof a.Attributes.email === 'string'
                ? a.Attributes.email.toUpperCase()
                : a.Attributes.email;
            const varB = typeof b.Attributes.email === 'string'
                ? b.Attributes.email.toUpperCase()
                : b.Attributes.email;
            let comparison = 0;
            if (varA > varB) {
                comparison = 1;
            }
            else if (varA < varB) {
                comparison = -1;
            }
            return comparison;
        });
    }
}
OredenascEmailusuriosPipe.ɵfac = function OredenascEmailusuriosPipe_Factory(t) { return new (t || OredenascEmailusuriosPipe)(); };
OredenascEmailusuriosPipe.ɵpipe = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefinePipe"]({ name: "oredenascEmailusurios", type: OredenascEmailusuriosPipe, pure: true });


/***/ }),

/***/ "zBaW":
/*!************************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/administracion/usuarios/usuarios.module.ts ***!
  \************************************************************************************/
/*! exports provided: UsuariosModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsuariosModule", function() { return UsuariosModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _usuarios_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./usuarios-routing.module */ "2I5K");
/* harmony import */ var _usuarios_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./usuarios.component */ "zKnR");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _pipes_oredenascEmailusurios_pipe__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../../pipes/oredenascEmailusurios.pipe */ "k/wk");
/* harmony import */ var ng_multiselect_dropdown__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ng-multiselect-dropdown */ "Egam");
/* harmony import */ var ngx_pagination__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ngx-pagination */ "oOf3");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-spinner */ "JqCM");
/* harmony import */ var _pipes_quitarcoma_pipe__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../pipes/quitarcoma.pipe */ "+rhq");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ "fXoL");











class UsuariosModule {
}
UsuariosModule.ɵfac = function UsuariosModule_Factory(t) { return new (t || UsuariosModule)(); };
UsuariosModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineNgModule"]({ type: UsuariosModule });
UsuariosModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
            _usuarios_routing_module__WEBPACK_IMPORTED_MODULE_1__["UsuariosRoutingModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            ngx_spinner__WEBPACK_IMPORTED_MODULE_7__["NgxSpinnerModule"],
            ngx_pagination__WEBPACK_IMPORTED_MODULE_6__["NgxPaginationModule"],
            ng_multiselect_dropdown__WEBPACK_IMPORTED_MODULE_5__["NgMultiSelectDropDownModule"].forRoot(),
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵsetNgModuleScope"](UsuariosModule, { declarations: [_usuarios_component__WEBPACK_IMPORTED_MODULE_2__["UsuariosComponent"],
        _pipes_oredenascEmailusurios_pipe__WEBPACK_IMPORTED_MODULE_4__["OredenascEmailusuriosPipe"],
        _pipes_quitarcoma_pipe__WEBPACK_IMPORTED_MODULE_8__["QuitarcomaPipe"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
        _usuarios_routing_module__WEBPACK_IMPORTED_MODULE_1__["UsuariosRoutingModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
        ngx_spinner__WEBPACK_IMPORTED_MODULE_7__["NgxSpinnerModule"],
        ngx_pagination__WEBPACK_IMPORTED_MODULE_6__["NgxPaginationModule"], ng_multiselect_dropdown__WEBPACK_IMPORTED_MODULE_5__["NgMultiSelectDropDownModule"]] }); })();


/***/ }),

/***/ "zKnR":
/*!***************************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/administracion/usuarios/usuarios.component.ts ***!
  \***************************************************************************************/
/*! exports provided: UsuariosComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsuariosComponent", function() { return UsuariosComponent; });
/* harmony import */ var _ReduxStore_actions_loaderProcesoCambios_actions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../../../../ReduxStore/actions/loaderProcesoCambios.actions */ "tONv");
/* harmony import */ var _validators_roles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../../../../validators/roles */ "r6zK");
/* harmony import */ var _ReduxStore_actions_listaUsuarios_actions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../../../ReduxStore/actions/listaUsuarios.actions */ "i2/L");
/* harmony import */ var _helpers_FuncionesUtiles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../helpers/FuncionesUtiles */ "TjSY");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngrx/store */ "l7P3");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "1kSV");
/* harmony import */ var _services_usuarios_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../../services/usuarios.service */ "ESM5");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ngx-spinner */ "JqCM");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var ng_multiselect_dropdown__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ng-multiselect-dropdown */ "Egam");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var ngx_pagination__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ngx-pagination */ "oOf3");
/* harmony import */ var _pipes_oredenascEmailusurios_pipe__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../../../../pipes/oredenascEmailusurios.pipe */ "k/wk");
/* harmony import */ var _pipes_quitarcoma_pipe__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../../../../pipes/quitarcoma.pipe */ "+rhq");
















function UsuariosComponent_a_5_Template(rf, ctx) { if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "a", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function UsuariosComponent_a_5_Template_a_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r10); const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return ctx_r9.limpirarFiltro(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, "Eliminar Filtro ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](2, "img", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function UsuariosComponent_table_23_tr_14_Template(rf, ctx) { if (rf & 1) {
    const _r16 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "td", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "td", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "td", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "td", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](9, "td", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](11);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](12, "quitarcoma");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](13, "td", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](14, "img", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function UsuariosComponent_table_23_tr_14_Template_img_click_14_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r16); const usuario_r13 = ctx.$implicit; const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2); const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](26); return ctx_r15.openModal(_r3, usuario_r13, usuario_r13.GrupoQuePertenece); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](15, "img", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function UsuariosComponent_table_23_tr_14_Template_img_click_15_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r16); const usuario_r13 = ctx.$implicit; const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2); const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](28); return ctx_r17.openModalConfirmacionBaja(_r5, usuario_r13, usuario_r13.GrupoQuePertenece); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const usuario_r13 = ctx.$implicit;
    const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate2"](" ", ctx_r12.retornarStringSiexiste(usuario_r13.Attributes, "given_name"), " ", ctx_r12.retornarStringSiexiste(usuario_r13.Attributes, "family_name"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", ctx_r12.retornarStringSiexiste(usuario_r13.Attributes, "email"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", usuario_r13.GrupoQuePertenece, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", ctx_r12.retornarStringSiexiste(usuario_r13.Attributes, "custom:rol"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](12, 6, ctx_r12.retornarStringSiexiste(usuario_r13.Attributes, "custom:negocio")), " ");
} }
const _c0 = function (a2) { return { id: "Usuarios", itemsPerPage: 10, currentPage: a2 }; };
function UsuariosComponent_table_23_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "table", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "th", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "Nombre");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "th", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5, "Correo");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "th", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7, "\u00C1rea");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "th", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](9, "Permisos");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "th", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](11, "Negocio");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](12, "th", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](13, "Acciones");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](14, UsuariosComponent_table_23_tr_14_Template, 16, 8, "tr", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](15, "paginate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](16, "oredenascEmailusurios");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind2"](15, 1, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind2"](16, 4, ctx_r1.ListadoUsuariosPantalla, "email"), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction1"](7, _c0, ctx_r1.paginaActualUsuarios)));
} }
function UsuariosComponent_pagination_template_24_span_4_Template(rf, ctx) { if (rf & 1) {
    const _r23 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "span", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function UsuariosComponent_pagination_template_24_span_4_Template_span_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r23); _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); const _r18 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](1); return _r18.previous(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " << ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function UsuariosComponent_pagination_template_24_div_5_span_1_Template(rf, ctx) { if (rf & 1) {
    const _r29 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "span", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function UsuariosComponent_pagination_template_24_div_5_span_1_Template_span_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r29); const page_r24 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().$implicit; _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); const _r18 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](1); return _r18.setCurrent(page_r24.value); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const page_r24 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](page_r24.label);
} }
function UsuariosComponent_pagination_template_24_div_5_div_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const page_r24 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](page_r24.label);
} }
function UsuariosComponent_pagination_template_24_div_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](1, UsuariosComponent_pagination_template_24_div_5_span_1_Template, 2, 1, "span", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](2, UsuariosComponent_pagination_template_24_div_5_div_2_Template, 3, 1, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const page_r24 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    const _r18 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵclassProp"]("current", _r18.getCurrent() === page_r24.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", _r18.getCurrent() !== page_r24.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", _r18.getCurrent() === page_r24.value);
} }
function UsuariosComponent_pagination_template_24_span_7_Template(rf, ctx) { if (rf & 1) {
    const _r33 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "span", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function UsuariosComponent_pagination_template_24_span_7_Template_span_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r33); _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); const _r18 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](1); return _r18.next(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " >> ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function UsuariosComponent_pagination_template_24_Template(rf, ctx) { if (rf & 1) {
    const _r35 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "pagination-template", 31, 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("pageChange", function UsuariosComponent_pagination_template_24_Template_pagination_template_pageChange_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r35); const ctx_r34 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return ctx_r34.paginaActualUsuarios = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](4, UsuariosComponent_pagination_template_24_span_4_Template, 2, 0, "span", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](5, UsuariosComponent_pagination_template_24_div_5_Template, 3, 4, "div", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "div", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](7, UsuariosComponent_pagination_template_24_span_7_Template, 2, 0, "span", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const _r18 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵclassProp"]("disabled", _r18.isFirstPage());
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !_r18.isFirstPage());
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", _r18.pages);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵclassProp"]("disabled", _r18.isLastPage());
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !_r18.isLastPage());
} }
function UsuariosComponent_ng_template_25_option_15_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "option", 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const Area_r38 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("value", Area_r38);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", Area_r38, " ");
} }
function UsuariosComponent_ng_template_25_Template(rf, ctx) { if (rf & 1) {
    const _r41 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "h4", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "Cambiar permiso");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "button", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function UsuariosComponent_ng_template_25_Template_button_click_4_listener() { const modal_r36 = ctx.$implicit; return modal_r36.dismiss(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "span", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](6, "\u00D7");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "div", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](9, "label", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](10, "\u00C1rea");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](12, "select", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("ngModelChange", function UsuariosComponent_ng_template_25_Template_select_ngModelChange_12_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r41); const ctx_r40 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return ctx_r40.SelectCamabiarArea = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](13, "option", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](14, "\u00C1rea");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](15, UsuariosComponent_ng_template_25_option_15_Template, 2, 2, "option", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](16, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](17, "label", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](18, "Permiso");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](19, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](20, "select", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("ngModelChange", function UsuariosComponent_ng_template_25_Template_select_ngModelChange_20_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r41); const ctx_r42 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return ctx_r42.SelectCamabiarPermiso = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](21, "option", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](22, "Permiso");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](23, "option", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](24, "Administrador");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](25, "option", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](26, "Monitor");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](27, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](28, "label", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](29, "Negocio");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](30, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](31, "ng-multiselect-dropdown", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("ngModelChange", function UsuariosComponent_ng_template_25_Template_ng_multiselect_dropdown_ngModelChange_31_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r41); const ctx_r43 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return ctx_r43.selectedItemsCambioDeNegocio = $event; })("onSelect", function UsuariosComponent_ng_template_25_Template_ng_multiselect_dropdown_onSelect_31_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r41); const ctx_r44 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return ctx_r44.cambiarEtiquetaSeleccionadaGeneral("cambiarnegocio"); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](32, "div", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](33, "button", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function UsuariosComponent_ng_template_25_Template_button_click_33_listener() { const modal_r36 = ctx.$implicit; return modal_r36.close(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](34, " Cerrar ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](35, "button", 58);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function UsuariosComponent_ng_template_25_Template_button_click_35_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r41); const ctx_r46 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](30); return ctx_r46.openModalConfirmacionEdicion(_r7); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](36, " Guardar cambio ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngModel", ctx_r4.SelectCamabiarArea);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx_r4.Areas);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngModel", ctx_r4.SelectCamabiarPermiso);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](11);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("placeholder", "Negocio")("settings", ctx_r4.SettingsCambioDeNegocio)("data", ctx_r4.dropdownListCambioDeNegocio)("ngModel", ctx_r4.selectedItemsCambioDeNegocio);
} }
function UsuariosComponent_ng_template_27_Template(rf, ctx) { if (rf & 1) {
    const _r50 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4, "Cofirmar baja de usuario");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "div", 62);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "div", 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7, "Se eliminar\u00E1 el usuario:");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "div", 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "div", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](12, "button", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function UsuariosComponent_ng_template_27_Template_button_click_12_listener() { const modal_r47 = ctx.$implicit; return modal_r47.close(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](13, "Cancelar");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](14, "button", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function UsuariosComponent_ng_template_27_Template_button_click_14_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r50); const ctx_r49 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return ctx_r49.darDeBajaUsuario(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](15, "Continuar");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate2"](" ", ctx_r6.ObjectUsuarioCambiar.Attributes.given_name, " ", ctx_r6.ObjectUsuarioCambiar.Attributes.family_name, " ");
} }
function UsuariosComponent_ng_template_29_Template(rf, ctx) { if (rf & 1) {
    const _r54 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4, "Cofirmar edici\u00F3n de usuario");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "div", 62);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "div", 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7, "Se editar\u00E1 el usuario:");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "div", 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "div", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](12, "button", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function UsuariosComponent_ng_template_29_Template_button_click_12_listener() { const modal_r51 = ctx.$implicit; return modal_r51.close(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](13, "Cancelar");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](14, "button", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function UsuariosComponent_ng_template_29_Template_button_click_14_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r54); const ctx_r53 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return ctx_r53.guardarCambioPermisoUsuario(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](15, "Continuar");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate2"](" ", ctx_r8.ObjectUsuarioCambiar.Attributes.given_name, " ", ctx_r8.ObjectUsuarioCambiar.Attributes.family_name, " ");
} }
class UsuariosComponent {
    constructor(store, modalService, UsuariosService, spinner) {
        this.store = store;
        this.modalService = modalService;
        this.UsuariosService = UsuariosService;
        this.spinner = spinner;
        this.Roles = [
            {
                label: 'Administrador',
                value: _validators_roles__WEBPACK_IMPORTED_MODULE_1__["ERole"].Administrador,
            },
            {
                label: 'Monitor',
                value: _validators_roles__WEBPACK_IMPORTED_MODULE_1__["ERole"].Monitor,
            }
        ];
        this.Areas = [
            _validators_roles__WEBPACK_IMPORTED_MODULE_1__["EArea"].Contabilidad,
            _validators_roles__WEBPACK_IMPORTED_MODULE_1__["EArea"].Custodia,
            _validators_roles__WEBPACK_IMPORTED_MODULE_1__["EArea"].Inversiones_Riesgos,
            _validators_roles__WEBPACK_IMPORTED_MODULE_1__["EArea"].Tesoreria,
            _validators_roles__WEBPACK_IMPORTED_MODULE_1__["EArea"].Soporte,
        ];
        this.Permisos = [_validators_roles__WEBPACK_IMPORTED_MODULE_1__["ERole"].Administrador, _validators_roles__WEBPACK_IMPORTED_MODULE_1__["ERole"].Monitor];
        this.Negocios = [_validators_roles__WEBPACK_IMPORTED_MODULE_1__["ENegocio"].Afore, _validators_roles__WEBPACK_IMPORTED_MODULE_1__["ENegocio"].Fondos];
        this.ListadoUsuariosOriginal = [];
        this.ListadoUsuariosPantalla = [];
        this.insertarValores = false;
        this.grupoPertenece = '';
        this.dropdownListCambioDeNegocio = [];
        this.dropdownListFiltroCorreos = [];
        this.dropdownListFiltroPermisos = [];
        this.dropdownListFiltroAreas = [];
        this.SettingsCambioDeNegocio = {};
        this.SettingsFiltroDeCorreos = {};
        this.SettingsFiltroDePermisos = {};
        this.SettingsFiltroDeArea = {};
        ///aqui va ir los inputs que se iniciaran para el modal
        this.selectedItemsFiltroAreas = [];
        this.selectedItemsFiltroCorreos = [];
        this.selectedItemsFiltroaPermisos = [];
        this.selectedItemsCambioDeNegocio = [];
        this.SelectCamabiarPermiso = 'Permiso';
        this.SelectCamabiarArea = 'Area';
        this.paginaActualUsuarios = 1;
        this.loading = true;
        this.filtroActivo = false;
        this.initicializarLosSelects = () => {
            this.dropdownListCambioDeNegocio = [
                { item_id: _validators_roles__WEBPACK_IMPORTED_MODULE_1__["ENegocio"].Afore, item_text: _validators_roles__WEBPACK_IMPORTED_MODULE_1__["ENegocio"].Afore },
                { item_id: _validators_roles__WEBPACK_IMPORTED_MODULE_1__["ENegocio"].Fondos, item_text: _validators_roles__WEBPACK_IMPORTED_MODULE_1__["ENegocio"].Fondos },
            ];
            this.dropdownListFiltroPermisos = [
                { item_id: _validators_roles__WEBPACK_IMPORTED_MODULE_1__["ERole"].Administrador, item_text: _validators_roles__WEBPACK_IMPORTED_MODULE_1__["ERole"].Administrador },
                { item_id: _validators_roles__WEBPACK_IMPORTED_MODULE_1__["ERole"].Monitor, item_text: _validators_roles__WEBPACK_IMPORTED_MODULE_1__["ERole"].Monitor }
            ];
            this.dropdownListFiltroAreas = [
                { item_id: _validators_roles__WEBPACK_IMPORTED_MODULE_1__["EArea"].Contabilidad, item_text: _validators_roles__WEBPACK_IMPORTED_MODULE_1__["EArea"].Contabilidad },
                { item_id: _validators_roles__WEBPACK_IMPORTED_MODULE_1__["EArea"].Custodia, item_text: _validators_roles__WEBPACK_IMPORTED_MODULE_1__["EArea"].Custodia },
                {
                    item_id: _validators_roles__WEBPACK_IMPORTED_MODULE_1__["EArea"].Inversiones_Riesgos,
                    item_text: _validators_roles__WEBPACK_IMPORTED_MODULE_1__["EArea"].Inversiones_Riesgos,
                },
                {
                    item_id: _validators_roles__WEBPACK_IMPORTED_MODULE_1__["EArea"].Tesoreria,
                    item_text: _validators_roles__WEBPACK_IMPORTED_MODULE_1__["EArea"].Tesoreria,
                },
                {
                    item_id: _validators_roles__WEBPACK_IMPORTED_MODULE_1__["EArea"].Soporte,
                    item_text: _validators_roles__WEBPACK_IMPORTED_MODULE_1__["EArea"].Soporte,
                },
            ];
            this.SettingsFiltroDePermisos = {
                singleSelection: false,
                idField: 'item_id',
                textField: 'item_text',
                allowSearchFilter: false,
                clearSearchFilter: false,
                enableCheckAll: false,
                maxHeight: 200,
                itemsShowLimit: 3,
            };
            this.SettingsFiltroDeArea = {
                singleSelection: false,
                idField: 'item_id',
                textField: 'item_text',
                allowSearchFilter: false,
                clearSearchFilter: false,
                enableCheckAll: false,
                maxHeight: 200,
            };
            this.SettingsFiltroDeCorreos = {
                singleSelection: false,
                idField: 'item_id',
                textField: 'item_text',
                allowSearchFilter: true,
                clearSearchFilter: true,
                enableCheckAll: false,
                maxHeight: 200,
                itemsShowLimit: 3,
                searchPlaceholderText: 'Buscar Correo electrónico',
            };
            /*
            singleSelection?: boolean;
            idField?: string;
            textField?: string;
            disabledField?: string;
            enableCheckAll?: boolean;
            selectAllText?: string;
            unSelectAllText?: string;
            allowSearchFilter?: boolean;
            clearSearchFilter?: boolean;
            maxHeight?: number;
            itemsShowLimit?: number;
            limitSelection?: number;
            searchPlaceholderText?: string;
            noDataAvailablePlaceholderText?: string;
            closeDropDownOnSelection?: boolean;
            showSelectedItemsAtTop?: boolean;
            defaultOpen?: boolean;
            allowRemoteDataSearch?: boolean;
        
        */
            this.SettingsCambioDeNegocio = {
                singleSelection: false,
                idField: 'item_id',
                textField: 'item_text',
                allowSearchFilter: false,
                enableCheckAll: false,
                maxHeight: 150,
            };
        };
        this.cerrarModal = (modal) => {
            modal.close();
        };
        this.openModalConfirmacionEdicion = (modal) => {
            this.modalService.open(modal, { ariaLabelledBy: 'modal-basic-title', windowClass: 'confirmacionUsuariosModal' });
        };
        this.limpirarFiltro = () => {
            this.spinner.show();
            this.filtroActivo = false;
            this.ListadoUsuariosPantalla = this.ListadoUsuariosOriginal;
            this.selectedItemsFiltroAreas = [];
            this.selectedItemsFiltroCorreos = [];
            this.selectedItemsFiltroaPermisos = [];
            this.selectedItemsCambioDeNegocio = [];
            setTimeout(() => {
                this.spinner.hide();
            }, 300);
        };
        this.guardarCambioPermisoUsuario = () => {
            if (this.SelectCamabiarPermiso === 'Permiso' &&
                this.selectedItemsCambioDeNegocio.length === 0 &&
                this.SelectCamabiarArea === 'Area') {
                return;
            }
            let arraySeleccionados = [];
            this.selectedItemsCambioDeNegocio.forEach((e) => {
                arraySeleccionados.push(e.item_id);
            });
            if (this.SelectCamabiarArea === 'Soporte') {
                this.SelectCamabiarPermiso = 'Administrador';
            }
            const UserAttributes = [
                {
                    Name: 'custom:negocio',
                    Value: arraySeleccionados.toString(),
                },
                {
                    Name: 'custom:rol',
                    Value: this.SelectCamabiarPermiso,
                },
            ];
            const Attributos = {
                UserAttributes: UserAttributes,
                Username: this.ObjectUsuarioCambiar.Username,
            };
            //console.log('AREA CHANGE', this.SelectCamabiarArea);
            const Grupo = {
                Grupo: this.SelectCamabiarArea,
                Username: this.ObjectUsuarioCambiar.Username,
                GrupoOriginal: this.grupoPertenece,
            };
            this.UsuariosService.validacionDeProcesosInsertar(Attributos, Grupo);
        };
        this.salirYRestablecer = () => {
            this.store.dispatch(Object(_ReduxStore_actions_listaUsuarios_actions__WEBPACK_IMPORTED_MODULE_2__["LoadListaUsuarios"])({ consulta: null }));
            this.modalService.dismissAll();
        };
        this.cerrarModales = () => {
            this.modalService.dismissAll();
        };
        this.retornarStringSiexiste = (object, attribute) => {
            return Object(_helpers_FuncionesUtiles__WEBPACK_IMPORTED_MODULE_3__["retornarStringSiexiste"])(object, attribute);
        };
        this.verPaginado = () => {
            if (this.ListadoUsuariosPantalla) {
                if (this.ListadoUsuariosPantalla.length > 10) {
                    return true;
                }
                else {
                    false;
                }
            }
            else {
                return false;
            }
        };
        this.filtrar = () => {
            this.spinner.show();
            this.paginaActualUsuarios = 1;
            this.filtroActivo = true;
            let FiltrarRol = null;
            let FiltrarArea = null;
            if (this.selectedItemsFiltroaPermisos.length !== 0) {
                let arrayFiltroRol = [];
                this.selectedItemsFiltroaPermisos.forEach((e) => {
                    arrayFiltroRol.push(e.item_id);
                });
                FiltrarRol = arrayFiltroRol;
            }
            if (this.selectedItemsFiltroAreas.length !== 0) {
                let arrayFiltroArea = [];
                this.selectedItemsFiltroAreas.forEach((e) => {
                    arrayFiltroArea.push(e.item_id);
                });
                FiltrarArea = arrayFiltroArea;
            }
            let FiltrarCorreo = null;
            if (this.selectedItemsFiltroCorreos.length !== 0) {
                let arrayFiltroCorreo = [];
                this.selectedItemsFiltroCorreos.forEach((e) => {
                    arrayFiltroCorreo.push(e.item_id);
                });
                FiltrarCorreo = arrayFiltroCorreo;
            }
            this.ListadoUsuariosPantalla = this.UsuariosService.filtrarUsuariosConAtributos(this.ListadoUsuariosOriginal, FiltrarRol, FiltrarArea, FiltrarCorreo);
            setTimeout(() => {
                this.spinner.hide();
            }, 300);
        };
        this.darDeBajaUsuario = () => {
            this.UsuariosService.eliminarUsuarioPromesa(this.ObjectUsuarioCambiar.Username).then(() => {
                console.log("Entrando a darDeBajaUsuario");
                const obj = this.ObjectUsuarioCambiar;
                //console.log('ObjectUsuario', ObjectUsuario);
                const ObjectUsuarioString = {
                    area: obj.GrupoQuePertenece,
                    permiso: obj.Attributes['custom:rol'],
                    negocio: obj.Attributes['custom:negocio'],
                };
                const datosUsuario = {
                    usuario: obj.Attributes.email,
                    nombre: obj.Attributes['given_name'],
                    apellidoPaterno: obj.Attributes['family_name'],
                    accion: "ELIMINAR"
                };
                //console.log('ObjectUsuarioString', ObjectUsuarioString);
                localStorage.setItem('ObjectOldUser', JSON.stringify(ObjectUsuarioString));
                localStorage.setItem('ObjectDataUser', JSON.stringify(datosUsuario));
                this.UsuariosService.generarAuditoria();
                this.cerrarModales();
                this.store.dispatch(Object(_ReduxStore_actions_listaUsuarios_actions__WEBPACK_IMPORTED_MODULE_2__["LoadListaUsuarios"])({ consulta: null }));
            });
        };
    }
    ngOnDestroy() {
        this.store.dispatch(Object(_ReduxStore_actions_listaUsuarios_actions__WEBPACK_IMPORTED_MODULE_2__["UnsetListaUsuarios"])());
        this.ListadoUsuarios$.unsubscribe();
        this.EstadoProceso.unsubscribe();
        this.Loading$.unsubscribe();
    }
    cambiarEtiquetaSeleccionada() {
        setTimeout(() => {
            $('#correo')
                .find('.selected-item')
                .attr('class', 'etiquetaSelecetCustom');
        }, 1);
    }
    cambiarEtiquetaSeleccionadaGeneral(elemento) {
        setTimeout(() => {
            $('#' + elemento)
                .find('.selected-item')
                .attr('class', 'etiquetasUsuarios');
        }, 1);
    }
    ngOnInit() {
        this.initicializarLosSelects();
        this.Loading$ = this.store
            .select(({ ListaUsuarios }) => ListaUsuarios.loading)
            .subscribe((res) => {
            this.loading = res;
            if (res) {
                this.spinner.show();
            }
            else {
                this.spinner.hide();
            }
        });
        this.ListadoUsuarios$ = this.store
            .select(({ ListaUsuarios }) => ListaUsuarios.ListaUsuarios)
            .subscribe((ListadoDeUsuarios) => {
            this.ListadoUsuariosOriginal = ListadoDeUsuarios;
            let arrayCorreos = [];
            if (this.ListadoUsuariosOriginal) {
                this.ListadoUsuariosOriginal.forEach((e) => {
                    if (this.dropdownListFiltroCorreos.filter((f) => f.item_id === e.Attributes.email).length === 0) {
                        arrayCorreos.push({
                            item_id: e.Attributes.email,
                            item_text: e.Attributes.email,
                        });
                    }
                });
                if (this.dropdownListFiltroCorreos.length === 0) {
                    this.dropdownListFiltroCorreos = arrayCorreos;
                }
            }
            this.ListadoUsuariosPantalla = ListadoDeUsuarios;
            if (this.filtroActivo && this.ListadoUsuariosPantalla.length > 0) {
                this.filtrar();
            }
        });
        this.store.dispatch(Object(_ReduxStore_actions_listaUsuarios_actions__WEBPACK_IMPORTED_MODULE_2__["LoadListaUsuarios"])({ consulta: null }));
        this.EstadoProceso = this.store
            .select(({ ProcesoCambios }) => ProcesoCambios.terminado)
            .subscribe((estado) => {
            if (estado) {
                this.salirYRestablecer();
                this.store.dispatch(Object(_ReduxStore_actions_loaderProcesoCambios_actions__WEBPACK_IMPORTED_MODULE_0__["ProcesoLimpiar"])());
            }
        });
    }
    openModalConfirmacionBaja(content, ObjectUsuario, grupoPertenece) {
        this.ObjectUsuarioCambiar = ObjectUsuario;
        this.grupoPertenece = grupoPertenece;
        this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title', windowClass: 'confirmacionUsuariosModal' });
    }
    openModal(content, ObjectUsuario, grupoPertenece) {
        //console.log('ObjectUsuario', ObjectUsuario);
        const ObjectUsuarioString = {
            area: ObjectUsuario.GrupoQuePertenece,
            permiso: ObjectUsuario.Attributes['custom:rol'],
            negocio: ObjectUsuario.Attributes['custom:negocio'],
        };
        const datosUsuario = {
            usuario: ObjectUsuario.Attributes.email,
            nombre: ObjectUsuario.Attributes['given_name'],
            apellidoPaterno: ObjectUsuario.Attributes['family_name'],
            accion: "ACTUALIZAR"
        };
        //console.log('ObjectUsuarioString', ObjectUsuarioString);
        localStorage.setItem('ObjectOldUser', JSON.stringify(ObjectUsuarioString));
        localStorage.setItem('ObjectDataUser', JSON.stringify(datosUsuario));
        this.ObjectUsuarioCambiar = ObjectUsuario;
        this.grupoPertenece = grupoPertenece;
        this.cambiarEtiquetaSeleccionadaGeneral('cambiarnegocio');
        if (!Object(_helpers_FuncionesUtiles__WEBPACK_IMPORTED_MODULE_3__["retornarStringSiexiste"])(ObjectUsuario.Attributes, 'custom:rol')) {
            this.SelectCamabiarPermiso = 'Permiso';
        }
        else {
            if (ObjectUsuario.Attributes['custom:rol'] === '') {
                this.SelectCamabiarPermiso = 'Permiso';
            }
            else {
                this.SelectCamabiarPermiso = ObjectUsuario.Attributes['custom:rol'];
            }
        }
        if (!Object(_helpers_FuncionesUtiles__WEBPACK_IMPORTED_MODULE_3__["retornarStringSiexiste"])(ObjectUsuario.Attributes, 'custom:negocio')) {
            this.selectedItemsCambioDeNegocio = [];
        }
        else {
            if (ObjectUsuario.Attributes['custom:negocio'] === '') {
                this.selectedItemsCambioDeNegocio = [];
            }
            else {
                const newObject = Object.assign({}, { negocio: ObjectUsuario.Attributes['custom:negocio'] });
                let { negocio } = newObject;
                let tempSelect = [];
                negocio.split(',').forEach((e) => {
                    tempSelect.push({
                        item_id: e,
                        item_text: e,
                    });
                });
                this.selectedItemsCambioDeNegocio = tempSelect;
            }
        }
        if (this.grupoPertenece === '') {
            this.SelectCamabiarArea = 'Area';
        }
        else {
            this.SelectCamabiarArea = this.grupoPertenece;
        }
        this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' });
    }
}
UsuariosComponent.ɵfac = function UsuariosComponent_Factory(t) { return new (t || UsuariosComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_ngrx_store__WEBPACK_IMPORTED_MODULE_5__["Store"]), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_6__["NgbModal"]), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_services_usuarios_service__WEBPACK_IMPORTED_MODULE_7__["UsuariosService"]), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_8__["NgxSpinnerService"])); };
UsuariosComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({ type: UsuariosComponent, selectors: [["app-usuarios"]], decls: 31, vars: 16, consts: [[1, "card-busqueda"], [1, "mt-4"], [2, "text-align", "right", "width", "100%", "justify-content", "flex-end", "direction", "rtl"], [2, "margin-right", "10%"], ["class", "limpiarFiltro", 3, "click", 4, "ngIf"], [1, "mt-3"], [1, "col2-row2"], ["id", "correo", 2, "width", "100%", 3, "placeholder", "settings", "data", "ngModel", "ngModelChange", "onSelect"], ["id", "filtroPermiso", 2, "width", "100%", "padding-left", "10px", 3, "placeholder", "settings", "data", "ngModel", "ngModelChange", "onSelect"], ["id", "filtroArea", 2, "width", "100%", 3, "placeholder", "settings", "data", "ngModel", "ngModelChange", "onSelect"], [2, "cursor", "pointer", 3, "click"], [1, "row", "justify-content-center"], [1, "d-flex", "col-md-12", "col-sm-12", "col-xs-12", "col-lg-12", "col-xl-12", "justify-content-center"], [1, "card-lista-design-general", 2, "overflow-x", "auto"], ["bdColor", "rgba(0,0,0,0.5)", "size", "default", "color", "#fff", "type", "ball-scale-ripple", 3, "fullScreen"], [2, "color", "white"], ["class", "table listado-design-general", 4, "ngIf"], ["id", "Usuarios", "class", "ngx-pagination", 3, "pageChange", 4, "ngIf"], ["content", ""], ["id", "confirmacion"], ["confrimacion", ""], ["confrimacionEditar", ""], [1, "limpiarFiltro", 3, "click"], ["src", "assets/icons/Eliminar.svg", 1, "tamanioFiltroIcono"], [1, "table", "listado-design-general"], [2, "padding-left", "40px", "max-width", "300px"], [2, "padding-left", "40px", "max-width", "150px"], [4, "ngFor", "ngForOf"], [2, "width", "200px"], [1, "editar-icon", 2, "cursor", "pointer", 3, "click"], [1, "eliminar-icon", 2, "cursor", "pointer", 3, "click"], ["id", "Usuarios", 1, "ngx-pagination", 3, "pageChange"], ["p", "paginationApi"], [1, "custom-pagination"], [1, "pagination-previous"], [3, "click", 4, "ngIf"], ["class", "page-number", 3, "current", 4, "ngFor", "ngForOf"], [1, "pagination-next"], [3, "click"], [1, "page-number"], [4, "ngIf"], [1, "modal-header"], ["id", "modal-basic-title", 1, "modal-title"], ["type", "button", "aria-label", "Close", 3, "click"], ["aria-hidden", "true"], [1, "modal-body"], [1, "form-group"], ["for", "dateOfBirth"], [1, "input-group"], [1, "form-control", 3, "ngModel", "ngModelChange"], ["disabled", "", "selected", "", "value", "Area"], [3, "value", 4, "ngFor", "ngForOf"], ["disabled", "", "selected", "", "value", "Permiso"], ["value", "Administrador"], ["value", "Monitor"], ["id", "cambiarnegocio", 2, "width", "100%", 3, "placeholder", "settings", "data", "ngModel", "ngModelChange", "onSelect"], [1, "modal-footer"], ["type", "button", "data-dismiss", "modal", 1, "btn", "bottonCancelarModalUsuario", 3, "click"], ["type", "button", 1, "btn", "bottonConfirmar", 2, "background-color", "#00c4d9", 3, "click"], [3, "value"], [1, "col-12", "row", "justify-content-center", "align-items-center", 2, "height", "120px"], [1, "textoConfirmacionModalUsuarios"], [1, "col-12", "row"], [1, "col-12", "descripcionConfirmacionModalUsuarios"], [1, "btn", "bottonCancelarModalUsuario", 3, "click"], [1, "btn", "bottonConfirmar", 3, "click"]], template: function UsuariosComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2, "Buscar usuario por");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](5, UsuariosComponent_a_5_Template, 3, 0, "a", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "div");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "section", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](9, "ng-multiselect-dropdown", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("ngModelChange", function UsuariosComponent_Template_ng_multiselect_dropdown_ngModelChange_9_listener($event) { return ctx.selectedItemsFiltroCorreos = $event; })("onSelect", function UsuariosComponent_Template_ng_multiselect_dropdown_onSelect_9_listener() { return ctx.cambiarEtiquetaSeleccionada(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "ng-multiselect-dropdown", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("ngModelChange", function UsuariosComponent_Template_ng_multiselect_dropdown_ngModelChange_11_listener($event) { return ctx.selectedItemsFiltroaPermisos = $event; })("onSelect", function UsuariosComponent_Template_ng_multiselect_dropdown_onSelect_11_listener() { return ctx.cambiarEtiquetaSeleccionadaGeneral("filtroPermiso"); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](12, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](13, "ng-multiselect-dropdown", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("ngModelChange", function UsuariosComponent_Template_ng_multiselect_dropdown_ngModelChange_13_listener($event) { return ctx.selectedItemsFiltroAreas = $event; })("onSelect", function UsuariosComponent_Template_ng_multiselect_dropdown_onSelect_13_listener() { return ctx.cambiarEtiquetaSeleccionadaGeneral("filtroArea"); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](14, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](15, "button", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function UsuariosComponent_Template_button_click_15_listener() { return ctx.filtrar(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](16, "Buscar");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](17, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](18, "div", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](19, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](20, "ngx-spinner", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](21, "p", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](22, " Cargando... ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](23, UsuariosComponent_table_23_Template, 17, 9, "table", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](24, UsuariosComponent_pagination_template_24_Template, 8, 7, "pagination-template", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](25, UsuariosComponent_ng_template_25_Template, 37, 7, "ng-template", null, 18, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](27, UsuariosComponent_ng_template_27_Template, 16, 2, "ng-template", 19, 20, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](29, UsuariosComponent_ng_template_29_Template, 16, 2, "ng-template", null, 21, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.filtroActivo);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("placeholder", "Correo electr\u00F3nico")("settings", ctx.SettingsFiltroDeCorreos)("data", ctx.dropdownListFiltroCorreos)("ngModel", ctx.selectedItemsFiltroCorreos);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("placeholder", "Permiso")("settings", ctx.SettingsFiltroDePermisos)("data", ctx.dropdownListFiltroPermisos)("ngModel", ctx.selectedItemsFiltroaPermisos);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("placeholder", "Area")("settings", ctx.SettingsFiltroDeArea)("data", ctx.dropdownListFiltroAreas)("ngModel", ctx.selectedItemsFiltroAreas);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("fullScreen", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.ListadoUsuariosPantalla);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.verPaginado());
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_9__["NgIf"], ng_multiselect_dropdown__WEBPACK_IMPORTED_MODULE_10__["MultiSelectComponent"], _angular_forms__WEBPACK_IMPORTED_MODULE_11__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_11__["NgModel"], ngx_spinner__WEBPACK_IMPORTED_MODULE_8__["NgxSpinnerComponent"], _angular_common__WEBPACK_IMPORTED_MODULE_9__["NgForOf"], ngx_pagination__WEBPACK_IMPORTED_MODULE_12__["PaginationControlsDirective"], _angular_forms__WEBPACK_IMPORTED_MODULE_11__["SelectControlValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_11__["NgSelectOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_11__["ɵangular_packages_forms_forms_z"]], pipes: [ngx_pagination__WEBPACK_IMPORTED_MODULE_12__["PaginatePipe"], _pipes_oredenascEmailusurios_pipe__WEBPACK_IMPORTED_MODULE_13__["OredenascEmailusuriosPipe"], _pipes_quitarcoma_pipe__WEBPACK_IMPORTED_MODULE_14__["QuitarcomaPipe"]], styles: [".wrapper[_ngcontent-%COMP%] {\r\n  display: flex;\r\n  flex-wrap: wrap;\r\n}\r\n\r\n.content[_ngcontent-%COMP%] {\r\n  width: 100%;\r\n  display: flex;\r\n  flex-wrap: wrap;\r\n  flex-direction: column;\r\n}\r\n\r\ndiv.card-busqueda[_ngcontent-%COMP%] {\r\n  width: 90%;\r\n  background: #ffffff 0% 0% no-repeat padding-box;\r\n  border-radius: 30px;\r\n  opacity: 1;\r\n  display: flex;\r\n  margin: 25px 0;\r\n  margin-right: 5%;\r\n  margin-left: 5%;\r\n  flex-direction: column;\r\n  align-items: center;\r\n  border-radius: 25px;\r\n  border-left: 10px solid #0a8299;\r\n  box-shadow: 4px 4px 10px #00000033;\r\n}\r\n\r\n.card-busqueda[_ngcontent-%COMP%]   div[_ngcontent-%COMP%] {\r\n  color: #0a8299;\r\n  border: black;\r\n  height: auto;\r\n  width: auto;\r\n  flex-grow: 1;\r\n  display: flex;\r\n  align-items: center;\r\n  font: bold 20px FS Elliot Pro;\r\n}\r\n\r\n.card-busqueda[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]    > button[_ngcontent-%COMP%] {\r\n  background-color: #00c4d9;\r\n  color: white;\r\n  width: 296px;\r\n  height: 50px;\r\n  border-radius: 25px;\r\n  font: bold 20px FS Elliot Pro;\r\n  border: none;\r\n}\r\n\r\ndiv.card-lista-design-general[_ngcontent-%COMP%] {\r\n  width: auto;\r\n  min-width: 477px;\r\n  flex: auto;\r\n  display: flex;\r\n  flex-wrap: wrap;\r\n  vertical-align: middle;\r\n}\r\n\r\ntable.listado-design-general[_ngcontent-%COMP%]   th[_ngcontent-%COMP%] {\r\n  background-color: #0a8299;\r\n  font: bold 18px FS Elliot Pro;\r\n  height: 40px;\r\n  height: 40px;\r\n  font: bold 18px FS Elliot Pro;\r\n}\r\n\r\nsection[_ngcontent-%COMP%] {\r\n  display: flex;\r\n  flex-wrap: wrap;\r\n  justify-content: space-between;\r\n}\r\n\r\n.col2-row2[_ngcontent-%COMP%] {\r\n  display: flex;\r\n  justify-content: center;\r\n  align-items: center;\r\n  flex-grow: 0;\r\n  flex-shrink: 0;\r\n  flex-basis: 50%;\r\n  margin-bottom: 1.5%;\r\n}\r\n\r\n.selectList[_ngcontent-%COMP%] {\r\n  text-align: left;\r\n  font: normal normal normal 18px/45px FS Elliot Pro;\r\n  letter-spacing: 0px;\r\n  color: #707070;\r\n  width: 296px;\r\n  height: 35px;\r\n  font: bold 18px FS Elliot Pro;\r\n  background: #ffffff 0% 0% no-repeat padding-box;\r\n  border: 1px solid #d6d6d6;\r\n  border-radius: 9px;\r\n  opacity: 1;\r\n}\r\n\r\n#correo[_ngcontent-%COMP%] {\r\n  width: 100%;\r\n}\r\n\r\n#correo[_ngcontent-%COMP%]   .selected-item[_ngcontent-%COMP%] {\r\n  width: 200px !important;\r\n}\r\n\r\n.limpiarFiltro[_ngcontent-%COMP%] {\r\n  text-align: right;\r\n  text-decoration: underline;\r\n  font: normal normal normal 14px/22px FS Elliot Pro;\r\n  letter-spacing: 0px;\r\n  -webkit-text-decoration: underline #67dce8 !important;\r\n          text-decoration: underline #67dce8 !important;\r\n  color: #67dce8 !important;\r\n}\r\n\r\n.limpiarFiltro[_ngcontent-%COMP%]:hover{\r\n  cursor: pointer;\r\n}\r\n\r\n.tamanioFiltroIcono[_ngcontent-%COMP%]{\r\n  width:12px;\r\n  height:12px;\r\n  margin-top: -4px;\r\n}\r\n\r\n.modal-content[_ngcontent-%COMP%]{\r\n  background-color: red !important;  \r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzdWFyaW9zLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxhQUFhO0VBQ2IsZUFBZTtBQUNqQjs7QUFFQTtFQUNFLFdBQVc7RUFDWCxhQUFhO0VBQ2IsZUFBZTtFQUNmLHNCQUFzQjtBQUN4Qjs7QUFFQTtFQUNFLFVBQVU7RUFDViwrQ0FBK0M7RUFDL0MsbUJBQW1CO0VBQ25CLFVBQVU7RUFDVixhQUFhO0VBQ2IsY0FBYztFQUNkLGdCQUFnQjtFQUNoQixlQUFlO0VBQ2Ysc0JBQXNCO0VBQ3RCLG1CQUFtQjtFQUNuQixtQkFBbUI7RUFDbkIsK0JBQStCO0VBQy9CLGtDQUFrQztBQUNwQzs7QUFFQTtFQUNFLGNBQWM7RUFDZCxhQUFhO0VBQ2IsWUFBWTtFQUNaLFdBQVc7RUFDWCxZQUFZO0VBQ1osYUFBYTtFQUNiLG1CQUFtQjtFQUNuQiw2QkFBNkI7QUFDL0I7O0FBRUE7RUFDRSx5QkFBeUI7RUFDekIsWUFBWTtFQUNaLFlBQVk7RUFDWixZQUFZO0VBQ1osbUJBQW1CO0VBQ25CLDZCQUE2QjtFQUM3QixZQUFZO0FBQ2Q7O0FBRUE7RUFDRSxXQUFXO0VBQ1gsZ0JBQWdCO0VBQ2hCLFVBQVU7RUFDVixhQUFhO0VBQ2IsZUFBZTtFQUNmLHNCQUFzQjtBQUN4Qjs7QUFFQTtFQUNFLHlCQUF5QjtFQUN6Qiw2QkFBNkI7RUFDN0IsWUFBWTtFQUNaLFlBQVk7RUFDWiw2QkFBNkI7QUFDL0I7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsZUFBZTtFQUNmLDhCQUE4QjtBQUNoQzs7QUFFQTtFQUNFLGFBQWE7RUFDYix1QkFBdUI7RUFDdkIsbUJBQW1CO0VBQ25CLFlBQVk7RUFDWixjQUFjO0VBQ2QsZUFBZTtFQUNmLG1CQUFtQjtBQUNyQjs7QUFFQTtFQUNFLGdCQUFnQjtFQUNoQixrREFBa0Q7RUFDbEQsbUJBQW1CO0VBQ25CLGNBQWM7RUFDZCxZQUFZO0VBQ1osWUFBWTtFQUNaLDZCQUE2QjtFQUM3QiwrQ0FBK0M7RUFDL0MseUJBQXlCO0VBQ3pCLGtCQUFrQjtFQUNsQixVQUFVO0FBQ1o7O0FBRUE7RUFDRSxXQUFXO0FBQ2I7O0FBRUE7RUFDRSx1QkFBdUI7QUFDekI7O0FBRUE7RUFDRSxpQkFBaUI7RUFDakIsMEJBQTBCO0VBQzFCLGtEQUFrRDtFQUNsRCxtQkFBbUI7RUFDbkIscURBQTZDO1VBQTdDLDZDQUE2QztFQUM3Qyx5QkFBeUI7QUFDM0I7O0FBQ0E7RUFDRSxlQUFlO0FBQ2pCOztBQUVBO0VBQ0UsVUFBVTtFQUNWLFdBQVc7RUFDWCxnQkFBZ0I7QUFDbEI7O0FBRUE7RUFDRSxnQ0FBZ0M7QUFDbEMiLCJmaWxlIjoidXN1YXJpb3MuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi53cmFwcGVyIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtd3JhcDogd3JhcDtcclxufVxyXG5cclxuLmNvbnRlbnQge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC13cmFwOiB3cmFwO1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbn1cclxuXHJcbmRpdi5jYXJkLWJ1c3F1ZWRhIHtcclxuICB3aWR0aDogOTAlO1xyXG4gIGJhY2tncm91bmQ6ICNmZmZmZmYgMCUgMCUgbm8tcmVwZWF0IHBhZGRpbmctYm94O1xyXG4gIGJvcmRlci1yYWRpdXM6IDMwcHg7XHJcbiAgb3BhY2l0eTogMTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIG1hcmdpbjogMjVweCAwO1xyXG4gIG1hcmdpbi1yaWdodDogNSU7XHJcbiAgbWFyZ2luLWxlZnQ6IDUlO1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBib3JkZXItcmFkaXVzOiAyNXB4O1xyXG4gIGJvcmRlci1sZWZ0OiAxMHB4IHNvbGlkICMwYTgyOTk7XHJcbiAgYm94LXNoYWRvdzogNHB4IDRweCAxMHB4ICMwMDAwMDAzMztcclxufVxyXG5cclxuLmNhcmQtYnVzcXVlZGEgZGl2IHtcclxuICBjb2xvcjogIzBhODI5OTtcclxuICBib3JkZXI6IGJsYWNrO1xyXG4gIGhlaWdodDogYXV0bztcclxuICB3aWR0aDogYXV0bztcclxuICBmbGV4LWdyb3c6IDE7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIGZvbnQ6IGJvbGQgMjBweCBGUyBFbGxpb3QgUHJvO1xyXG59XHJcblxyXG4uY2FyZC1idXNxdWVkYSBkaXYgPiBidXR0b24ge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICMwMGM0ZDk7XHJcbiAgY29sb3I6IHdoaXRlO1xyXG4gIHdpZHRoOiAyOTZweDtcclxuICBoZWlnaHQ6IDUwcHg7XHJcbiAgYm9yZGVyLXJhZGl1czogMjVweDtcclxuICBmb250OiBib2xkIDIwcHggRlMgRWxsaW90IFBybztcclxuICBib3JkZXI6IG5vbmU7XHJcbn1cclxuXHJcbmRpdi5jYXJkLWxpc3RhLWRlc2lnbi1nZW5lcmFsIHtcclxuICB3aWR0aDogYXV0bztcclxuICBtaW4td2lkdGg6IDQ3N3B4O1xyXG4gIGZsZXg6IGF1dG87XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LXdyYXA6IHdyYXA7XHJcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcclxufVxyXG5cclxudGFibGUubGlzdGFkby1kZXNpZ24tZ2VuZXJhbCB0aCB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzBhODI5OTtcclxuICBmb250OiBib2xkIDE4cHggRlMgRWxsaW90IFBybztcclxuICBoZWlnaHQ6IDQwcHg7XHJcbiAgaGVpZ2h0OiA0MHB4O1xyXG4gIGZvbnQ6IGJvbGQgMThweCBGUyBFbGxpb3QgUHJvO1xyXG59XHJcblxyXG5zZWN0aW9uIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtd3JhcDogd3JhcDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbn1cclxuXHJcbi5jb2wyLXJvdzIge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBmbGV4LWdyb3c6IDA7XHJcbiAgZmxleC1zaHJpbms6IDA7XHJcbiAgZmxleC1iYXNpczogNTAlO1xyXG4gIG1hcmdpbi1ib3R0b206IDEuNSU7XHJcbn1cclxuXHJcbi5zZWxlY3RMaXN0IHtcclxuICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gIGZvbnQ6IG5vcm1hbCBub3JtYWwgbm9ybWFsIDE4cHgvNDVweCBGUyBFbGxpb3QgUHJvO1xyXG4gIGxldHRlci1zcGFjaW5nOiAwcHg7XHJcbiAgY29sb3I6ICM3MDcwNzA7XHJcbiAgd2lkdGg6IDI5NnB4O1xyXG4gIGhlaWdodDogMzVweDtcclxuICBmb250OiBib2xkIDE4cHggRlMgRWxsaW90IFBybztcclxuICBiYWNrZ3JvdW5kOiAjZmZmZmZmIDAlIDAlIG5vLXJlcGVhdCBwYWRkaW5nLWJveDtcclxuICBib3JkZXI6IDFweCBzb2xpZCAjZDZkNmQ2O1xyXG4gIGJvcmRlci1yYWRpdXM6IDlweDtcclxuICBvcGFjaXR5OiAxO1xyXG59XHJcblxyXG4jY29ycmVvIHtcclxuICB3aWR0aDogMTAwJTtcclxufVxyXG5cclxuI2NvcnJlbyAuc2VsZWN0ZWQtaXRlbSB7XHJcbiAgd2lkdGg6IDIwMHB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5saW1waWFyRmlsdHJvIHtcclxuICB0ZXh0LWFsaWduOiByaWdodDtcclxuICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcclxuICBmb250OiBub3JtYWwgbm9ybWFsIG5vcm1hbCAxNHB4LzIycHggRlMgRWxsaW90IFBybztcclxuICBsZXR0ZXItc3BhY2luZzogMHB4O1xyXG4gIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lICM2N2RjZTggIWltcG9ydGFudDtcclxuICBjb2xvcjogIzY3ZGNlOCAhaW1wb3J0YW50O1xyXG59XHJcbi5saW1waWFyRmlsdHJvOmhvdmVye1xyXG4gIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG5cclxuLnRhbWFuaW9GaWx0cm9JY29ub3tcclxuICB3aWR0aDoxMnB4O1xyXG4gIGhlaWdodDoxMnB4O1xyXG4gIG1hcmdpbi10b3A6IC00cHg7XHJcbn1cclxuXHJcbi5tb2RhbC1jb250ZW50e1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHJlZCAhaW1wb3J0YW50OyAgXHJcbn1cclxuXHJcblxyXG4iXX0= */"] });


/***/ })

}]);
//# sourceMappingURL=usuarios-usuarios-module.js.map