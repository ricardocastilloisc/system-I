(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["auditoriageneral-auditoriageneral-module"],{

/***/ "7WP3":
/*!*******************************************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/auditoria/auditoriageneral/auditoriageneral-routing.module.ts ***!
  \*******************************************************************************************************/
/*! exports provided: AuditoriageneralRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuditoriageneralRoutingModule", function() { return AuditoriageneralRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _auditoriageneral_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./auditoriageneral.component */ "VaQm");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");




const routes = [{ path: '', component: _auditoriageneral_component__WEBPACK_IMPORTED_MODULE_1__["AuditoriageneralComponent"] }];
class AuditoriageneralRoutingModule {
}
AuditoriageneralRoutingModule.ɵfac = function AuditoriageneralRoutingModule_Factory(t) { return new (t || AuditoriageneralRoutingModule)(); };
AuditoriageneralRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: AuditoriageneralRoutingModule });
AuditoriageneralRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](AuditoriageneralRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] }); })();


/***/ }),

/***/ "VaQm":
/*!**************************************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/auditoria/auditoriageneral/auditoriageneral.component.ts ***!
  \**************************************************************************************************/
/*! exports provided: AuditoriageneralComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuditoriageneralComponent", function() { return AuditoriageneralComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _services_auditoria_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../services/auditoria.service */ "/ap+");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");



class AuditoriageneralComponent {
    constructor(auditoria) {
        this.auditoria = auditoria;
    }
    ngOnInit() {
        this.auditoria.enviarMensaje();
    }
}
AuditoriageneralComponent.ɵfac = function AuditoriageneralComponent_Factory(t) { return new (t || AuditoriageneralComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_services_auditoria_service__WEBPACK_IMPORTED_MODULE_1__["AuditoriaService"])); };
AuditoriageneralComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: AuditoriageneralComponent, selectors: [["app-auditoriageneral"]], decls: 16, vars: 0, consts: [["id", "auditoria", 1, "paddingIzquierdaDerecha"], [1, "container-fluid"], [1, "d-flex", 2, "height", "75vh", "width", "95%"], [1, "row", 2, "width", "100%"], [1, "col-lg-6", "col-md-12", "col-sm-12", "col-xs-12"], ["routerLink", "/auditoria/archivos", 1, "card"], ["src", "assets/imgs/auditoria/archivos2x.png", 1, "heighImgAuditoria", 2, "height", "100%"], ["routerLink", "/auditoria/procesos", 1, "card"], ["src", "assets/imgs/auditoria/procesos2x.png", 1, "heighImgAuditoria", 2, "height", "100%"], ["routerLink", "/auditoria/catalogos", 1, "card"], ["src", "assets/imgs/auditoria/catalogos2x.png", 1, "heighImgAuditoria", 2, "height", "100%"], ["routerLink", "/auditoria/usuarios", 1, "card"], ["src", "assets/imgs/auditoria/usuarios2x.png", 1, "heighImgAuditoria", 2, "height", "100%"]], template: function AuditoriageneralComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "section", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](6, "img", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](9, "img", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](12, "img", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "div", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](15, "img", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, directives: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterLink"]], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhdWRpdG9yaWFnZW5lcmFsLmNvbXBvbmVudC5jc3MifQ== */"] });


/***/ }),

/***/ "kd5d":
/*!***********************************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/auditoria/auditoriageneral/auditoriageneral.module.ts ***!
  \***********************************************************************************************/
/*! exports provided: AuditoriageneralModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuditoriageneralModule", function() { return AuditoriageneralModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _auditoriageneral_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./auditoriageneral-routing.module */ "7WP3");
/* harmony import */ var _auditoriageneral_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./auditoriageneral.component */ "VaQm");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




class AuditoriageneralModule {
}
AuditoriageneralModule.ɵfac = function AuditoriageneralModule_Factory(t) { return new (t || AuditoriageneralModule)(); };
AuditoriageneralModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({ type: AuditoriageneralModule });
AuditoriageneralModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
            _auditoriageneral_routing_module__WEBPACK_IMPORTED_MODULE_1__["AuditoriageneralRoutingModule"]
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](AuditoriageneralModule, { declarations: [_auditoriageneral_component__WEBPACK_IMPORTED_MODULE_2__["AuditoriageneralComponent"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
        _auditoriageneral_routing_module__WEBPACK_IMPORTED_MODULE_1__["AuditoriageneralRoutingModule"]] }); })();


/***/ })

}]);
//# sourceMappingURL=auditoriageneral-auditoriageneral-module.js.map