(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["common"],{

/***/ "/ap+":
/*!***********************************************!*\
  !*** ./src/app/services/auditoria.service.ts ***!
  \***********************************************/
/*! exports provided: AuditoriaService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuditoriaService", function() { return AuditoriaService; });
/* harmony import */ var aws_amplify__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! aws-amplify */ "AL3R");
/* harmony import */ var aws_sdk__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! aws-sdk */ "Sp1i");
/* harmony import */ var aws_sdk__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(aws_sdk__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../environments/environment */ "AytR");
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! uuid */ "4USb");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");





aws_amplify__WEBPACK_IMPORTED_MODULE_0__["default"].configure(_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].amplifyConfig);
var sqs = new aws_sdk__WEBPACK_IMPORTED_MODULE_1__["SQS"]();
var payload = {
    areaNegocio: "TESORERÍA",
    rol: "Soporte",
    correo: "garcia.diego@principal.com",
    fecha: "2021-03-22T20:32:43.838-06:00",
    usuario: {
        apellidoPaterno: "Garcia",
        apellidoMaterno: "Diaz",
        nombre: "Diego",
        correo: "bernal.pablo@principal.com",
        inicioSesion: "2021-03-22T20:32:43.838-06:00",
        finSesion: "2021-03-22T20:32:43.838-06:00"
    },
    seccion: {
        nombre: "ARCHIVOS",
        subseccion: "PROCESOS",
        accion: "BUSQUEDA DE ARCHIVOS POR FECHA"
    },
    catalogos: {
        nombre: "MD",
        accion: "MODIFICAR",
        descripcion: "MODIFICACIÓN SATISFACTORIA DEL CATÁLOGO PARA LA INTERFAZ DE MD",
        estado: "EXITOSA",
        detalleModificaciones: [{
                campo: "valor",
                valorAnterior: "Valor_MO_1",
                valorNuevo: "Valor_MO_2"
            }]
    },
    procesos: {
        tipo: "DIURNO",
        nombre: "MO",
        descripcion: "SE INICIA EL PROCESO DE AIMS Y EXCEDENTES",
        accion: "INICIAR",
        estado: "INICIO EXITOSO",
        usuario: "bgalcia@spsolutions.com"
    },
    permisosUsuarios: [{
            nombre: "Leticia",
            apellidoPaterno: "Santos",
            apellidoMaterno: "",
            correo: "lsantos@principal.com",
            accion: "ACTIVAR",
            estado: "EXITOSO",
            rol: "EJECUTOR",
            detalleModificaciones: [{
                    campo: "permisos",
                    usuario: "bgalcia@spsolutions.com",
                    valorAnterior: "Adimistrar catálogos",
                    valorNuevo: "Monitoreo procesos"
                }]
        }]
};
var payloadString = JSON.stringify(payload);
class AuditoriaService {
    constructor() {
        this.params = {
            MessageBody: payloadString,
            MessageDeduplicationId: Object(uuid__WEBPACK_IMPORTED_MODULE_3__["v4"])(),
            MessageGroupId: Object(uuid__WEBPACK_IMPORTED_MODULE_3__["v4"])(),
            QueueUrl: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].API.endpoints.find((el) => el.name === 'sqs-auditoria')['endpoint']
        };
        this.paramsReceive = {
            AttributeNames: [
                "SentTimestamp"
            ],
            MaxNumberOfMessages: 10,
            MessageAttributeNames: [
                "All"
            ],
            QueueUrl: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].API.endpoints.find((el) => el.name === 'sqs-auditoria')['endpoint'],
            VisibilityTimeout: 20,
            WaitTimeSeconds: 0
        };
    }
    enviarMensaje() {
        sqs.sendMessage(this.params, function (err, data) {
            if (err) {
                console.log("Error.", err);
            }
            else {
                console.log("Success.", data.MessageId);
            }
        });
    }
    recibirMensaje() {
        sqs.receiveMessage(this.paramsReceive, function (err, data) {
            if (err) {
                console.log("Receive Error", err);
            }
            else if (data.Messages) {
                var deleteParams = {
                    QueueUrl: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].API.endpoints.find((el) => el.name === 'sqs-auditoria')['endpoint'],
                    ReceiptHandle: data.Messages[0].ReceiptHandle
                };
                sqs.deleteMessage(deleteParams, function (err, data) {
                    if (err) {
                        console.log("Delete Error", err);
                    }
                    else {
                        console.log("Message Deleted", data);
                    }
                });
            }
        });
    }
}
AuditoriaService.ɵfac = function AuditoriaService_Factory(t) { return new (t || AuditoriaService)(); };
AuditoriaService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjectable"]({ token: AuditoriaService, factory: AuditoriaService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ "H8iN":
/*!************************************************************************************!*\
  !*** ./node_modules/@aws-amplify/ui-components/dist/esm/storage-types-f257c0f2.js ***!
  \************************************************************************************/
/*! exports provided: A */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "A", function() { return AccessLevel; });
var AccessLevel;
(function (AccessLevel) {
    AccessLevel["Public"] = "public";
    AccessLevel["Private"] = "private";
    AccessLevel["Protected"] = "protected";
})(AccessLevel || (AccessLevel = {}));




/***/ }),

/***/ "WFda":
/*!**********************************************!*\
  !*** ./src/app/services/procesos.service.ts ***!
  \**********************************************/
/*! exports provided: ProcesosService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProcesosService", function() { return ProcesosService; });
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! uuid */ "4USb");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../environments/environment */ "AytR");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./auth.service */ "lGQG");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ "tk/3");





class ProcesosService {
    constructor(authService, http) {
        this.authService = authService;
        this.http = http;
    }
    iniciarProceso(idProceso, correoUsuario, rolUsuario) {
        let response;
        let uuid = Object(uuid__WEBPACK_IMPORTED_MODULE_0__["v4"])();
        var axios = __webpack_require__(/*! axios */ "vDqi");
        var data = JSON.stringify({
            "rol": rolUsuario,
            "correo": correoUsuario,
            "uuid": uuid
        });
        var endpoint = _environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].API.endpoints.find((el) => el.name === idProceso)['endpoint'];
        var config = {
            method: 'post',
            url: endpoint,
            headers: {
                'Authorization': 'Bearer ' + this.authService.getToken(),
                'Content-Type': 'application/json'
            },
            data: data
        };
        var headers = {
            'Authorization': 'Bearer ' + this.authService.getToken(),
            'Content-Type': 'application/json'
        };
        return this.http.post(endpoint, config.data, { headers }).toPromise().then(function (response) {
            return response = {
                codigo: 'EXITO',
                descripcion: 'La solicitud fue exitosa.'
            };
        })
            .catch(function (error) {
            return response = {
                codigo: 'FALLO',
                descripcion: error.message
            };
        });
        ;
    }
}
ProcesosService.ɵfac = function ProcesosService_Factory(t) { return new (t || ProcesosService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"])); };
ProcesosService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({ token: ProcesosService, factory: ProcesosService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ "Y0ez":
/*!**************************************************************************************!*\
  !*** ./node_modules/@aws-amplify/ui-components/dist/esm/storage-helpers-48c373a0.js ***!
  \**************************************************************************************/
/*! exports provided: a, c, g, i, p */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return getTextSource; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return calcKey; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "g", function() { return getStorageObject; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "i", function() { return imageFileType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "p", function() { return putStorageObject; });
/* harmony import */ var _constants_d1abe7de_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./constants-d1abe7de.js */ "/vcS");
/* harmony import */ var _aws_amplify_storage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @aws-amplify/storage */ "l1VB");



const imageFileType = new Set([
    'apng',
    'bmp',
    'gif',
    'ico',
    'cur',
    'jpg',
    'jpeg',
    'jfif',
    'pjpeg',
    'pjp',
    'png',
    'svg',
    'tif',
    'tiff',
    'webp',
]);
const calcKey = (file, fileToKey) => {
    const { name, size, type } = file;
    let key = encodeURI(name);
    if (fileToKey) {
        if (typeof fileToKey === 'string') {
            key = fileToKey;
        }
        else if (typeof fileToKey === 'function') {
            key = fileToKey({ name, size, type });
        }
        else {
            key = encodeURI(JSON.stringify(fileToKey));
        }
        if (!key) {
            key = 'empty_key';
        }
    }
    return key.replace(/\s/g, '_');
};
const getStorageObject = async (key, level, track, identityId, logger) => {
    if (!_aws_amplify_storage__WEBPACK_IMPORTED_MODULE_1__["Storage"] || typeof _aws_amplify_storage__WEBPACK_IMPORTED_MODULE_1__["Storage"].get !== 'function') {
        throw new Error(_constants_d1abe7de_js__WEBPACK_IMPORTED_MODULE_0__["e"]);
    }
    try {
        const src = await _aws_amplify_storage__WEBPACK_IMPORTED_MODULE_1__["Storage"].get(key, { level, track, identityId });
        logger.debug('Storage image get', src);
        return src;
    }
    catch (error) {
        throw new Error(error);
    }
};
const readFileAsync = (blob) => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
            resolve(reader.result);
        };
        reader.onerror = () => {
            reject('Failed to read file!');
            reader.abort();
        };
        reader.readAsText(blob);
    });
};
const getTextSource = async (key, level, track, identityId, logger) => {
    if (!_aws_amplify_storage__WEBPACK_IMPORTED_MODULE_1__["Storage"] || typeof _aws_amplify_storage__WEBPACK_IMPORTED_MODULE_1__["Storage"].get !== 'function') {
        throw new Error(_constants_d1abe7de_js__WEBPACK_IMPORTED_MODULE_0__["e"]);
    }
    try {
        const textSrc = await _aws_amplify_storage__WEBPACK_IMPORTED_MODULE_1__["Storage"].get(key, {
            download: true,
            level,
            track,
            identityId,
        });
        logger.debug(textSrc);
        const text = (await readFileAsync(textSrc['Body']));
        return text;
    }
    catch (error) {
        throw new Error(error);
    }
};
const putStorageObject = async (key, body, level, track, contentType, logger) => {
    if (!_aws_amplify_storage__WEBPACK_IMPORTED_MODULE_1__["Storage"] || typeof _aws_amplify_storage__WEBPACK_IMPORTED_MODULE_1__["Storage"].put !== 'function') {
        throw new Error(_constants_d1abe7de_js__WEBPACK_IMPORTED_MODULE_0__["e"]);
    }
    try {
        const data = await _aws_amplify_storage__WEBPACK_IMPORTED_MODULE_1__["Storage"].put(key, body, {
            contentType,
            level,
            track,
        });
        logger.debug('Upload data', data);
    }
    catch (error) {
        throw new Error(error);
    }
};




/***/ }),

/***/ "gUIQ":
/*!***********************************************************************************!*\
  !*** ./node_modules/@aws-amplify/ui-components/dist/esm/auth-helpers-99c6a1db.js ***!
  \***********************************************************************************/
/*! exports provided: c, h */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return checkContact; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "h", function() { return handleSignIn; });
/* harmony import */ var _aws_amplify_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @aws-amplify/core */ "GOuw");
/* harmony import */ var _auth_types_78df304e_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./auth-types-78df304e.js */ "s1tr");
/* harmony import */ var _aws_amplify_auth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @aws-amplify/auth */ "AO/9");
/* harmony import */ var _Translations_c833f663_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Translations-c833f663.js */ "sPRy");
/* harmony import */ var _constants_d1abe7de_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./constants-d1abe7de.js */ "/vcS");
/* harmony import */ var _helpers_4afef5ab_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./helpers-4afef5ab.js */ "eGR6");







const logger = new _aws_amplify_core__WEBPACK_IMPORTED_MODULE_0__["Logger"]('auth-helpers');
async function checkContact(user, handleAuthStateChange) {
    if (!_aws_amplify_auth__WEBPACK_IMPORTED_MODULE_2__["Auth"] || typeof _aws_amplify_auth__WEBPACK_IMPORTED_MODULE_2__["Auth"].verifiedContact !== 'function') {
        throw new Error(_constants_d1abe7de_js__WEBPACK_IMPORTED_MODULE_4__["N"]);
    }
    // If `user` is a federated user, we shouldn't call `verifiedContact`
    // since `user` isn't `CognitoUser`
    if (!isCognitoUser(user)) {
        handleAuthStateChange(_auth_types_78df304e_js__WEBPACK_IMPORTED_MODULE_1__["A"].SignedIn, user);
        return;
    }
    try {
        const data = await _aws_amplify_auth__WEBPACK_IMPORTED_MODULE_2__["Auth"].verifiedContact(user);
        if (!Object(_aws_amplify_core__WEBPACK_IMPORTED_MODULE_0__["isEmpty"])(data.verified) || Object(_aws_amplify_core__WEBPACK_IMPORTED_MODULE_0__["isEmpty"])(data.unverified)) {
            handleAuthStateChange(_auth_types_78df304e_js__WEBPACK_IMPORTED_MODULE_1__["A"].SignedIn, user);
        }
        else {
            const newUser = Object.assign(user, data);
            handleAuthStateChange(_auth_types_78df304e_js__WEBPACK_IMPORTED_MODULE_1__["A"].VerifyContact, newUser);
        }
    }
    catch (error) {
        Object(_helpers_4afef5ab_js__WEBPACK_IMPORTED_MODULE_5__["a"])(error);
    }
}
const handleSignIn = async (username, password, handleAuthStateChange) => {
    if (!_aws_amplify_auth__WEBPACK_IMPORTED_MODULE_2__["Auth"] || typeof _aws_amplify_auth__WEBPACK_IMPORTED_MODULE_2__["Auth"].signIn !== 'function') {
        throw new Error(_constants_d1abe7de_js__WEBPACK_IMPORTED_MODULE_4__["N"]);
    }
    try {
        const user = await _aws_amplify_auth__WEBPACK_IMPORTED_MODULE_2__["Auth"].signIn(username, password);
        logger.debug(user);
        if (user.challengeName === _auth_types_78df304e_js__WEBPACK_IMPORTED_MODULE_1__["C"].SMSMFA || user.challengeName === _auth_types_78df304e_js__WEBPACK_IMPORTED_MODULE_1__["C"].SoftwareTokenMFA) {
            logger.debug('confirm user with ' + user.challengeName);
            handleAuthStateChange(_auth_types_78df304e_js__WEBPACK_IMPORTED_MODULE_1__["A"].ConfirmSignIn, user);
        }
        else if (user.challengeName === _auth_types_78df304e_js__WEBPACK_IMPORTED_MODULE_1__["C"].NewPasswordRequired) {
            logger.debug('require new password', user.challengeParam);
            handleAuthStateChange(_auth_types_78df304e_js__WEBPACK_IMPORTED_MODULE_1__["A"].ResetPassword, user);
        }
        else if (user.challengeName === _auth_types_78df304e_js__WEBPACK_IMPORTED_MODULE_1__["C"].MFASetup) {
            logger.debug('TOTP setup', user.challengeParam);
            handleAuthStateChange(_auth_types_78df304e_js__WEBPACK_IMPORTED_MODULE_1__["A"].TOTPSetup, user);
        }
        else if (user.challengeName === _auth_types_78df304e_js__WEBPACK_IMPORTED_MODULE_1__["C"].CustomChallenge &&
            user.challengeParam &&
            user.challengeParam.trigger === 'true') {
            logger.debug('custom challenge', user.challengeParam);
            handleAuthStateChange(_auth_types_78df304e_js__WEBPACK_IMPORTED_MODULE_1__["A"].CustomConfirmSignIn, user);
        }
        else {
            await checkContact(user, handleAuthStateChange);
        }
    }
    catch (error) {
        if (error.code === 'UserNotConfirmedException') {
            logger.debug('the user is not confirmed');
            handleAuthStateChange(_auth_types_78df304e_js__WEBPACK_IMPORTED_MODULE_1__["A"].ConfirmSignUp, { username });
        }
        else if (error.code === 'PasswordResetRequiredException') {
            logger.debug('the user requires a new password');
            handleAuthStateChange(_auth_types_78df304e_js__WEBPACK_IMPORTED_MODULE_1__["A"].ForgotPassword, { username });
        }
        else if (error.code === 'InvalidParameterException' && password === '') {
            logger.debug('Password cannot be empty');
            error.message = _Translations_c833f663_js__WEBPACK_IMPORTED_MODULE_3__["T"].EMPTY_PASSWORD;
        }
        Object(_helpers_4afef5ab_js__WEBPACK_IMPORTED_MODULE_5__["a"])(error);
    }
};
const isCognitoUser = (user) => {
    return user instanceof _aws_amplify_auth__WEBPACK_IMPORTED_MODULE_2__["CognitoUser"];
};




/***/ })

}]);
//# sourceMappingURL=common.js.map