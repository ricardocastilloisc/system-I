(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "+uQQ":
/*!********************************************************************************************************************************************************!*\
  !*** ./node_modules/@aws-amplify/ui-components/dist/esm lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \********************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./amplify-amazon-button_5.entry.js": [
		"pptk",
		0,
		13
	],
	"./amplify-auth-fields_9.entry.js": [
		"5Azo",
		3
	],
	"./amplify-authenticator.entry.js": [
		"HaBs",
		0,
		"common",
		14
	],
	"./amplify-button_3.entry.js": [
		"W1Jz",
		0,
		15
	],
	"./amplify-chatbot.entry.js": [
		"OkRK",
		4
	],
	"./amplify-checkbox.entry.js": [
		"jZr9",
		16
	],
	"./amplify-confirm-sign-in_7.entry.js": [
		"VFVT",
		0,
		"common",
		17
	],
	"./amplify-container.entry.js": [
		"l2YT",
		18
	],
	"./amplify-federated-buttons_2.entry.js": [
		"4pA8",
		0,
		19
	],
	"./amplify-federated-sign-in.entry.js": [
		"GWfx",
		9
	],
	"./amplify-form-field_4.entry.js": [
		"svTr",
		20
	],
	"./amplify-greetings.entry.js": [
		"2uVw",
		0,
		21
	],
	"./amplify-icon-button.entry.js": [
		"5+i5",
		22
	],
	"./amplify-icon.entry.js": [
		"ATNG",
		1,
		23
	],
	"./amplify-link.entry.js": [
		"CLig",
		24
	],
	"./amplify-nav_2.entry.js": [
		"29kL",
		0,
		25
	],
	"./amplify-photo-picker.entry.js": [
		"fEjz",
		10
	],
	"./amplify-picker.entry.js": [
		"TkC1",
		11
	],
	"./amplify-radio-button_2.entry.js": [
		"bVH+",
		0,
		"common",
		26
	],
	"./amplify-s3-album.entry.js": [
		"GV60",
		"common",
		5
	],
	"./amplify-s3-image-picker.entry.js": [
		"V0P2",
		"common",
		6
	],
	"./amplify-s3-image.entry.js": [
		"mwoW",
		"common",
		12
	],
	"./amplify-s3-text-picker.entry.js": [
		"/MiJ",
		"common",
		7
	],
	"./amplify-s3-text.entry.js": [
		"Kukj",
		"common",
		8
	],
	"./amplify-select-mfa-type.entry.js": [
		"oogQ",
		2
	],
	"./amplify-sign-in-button.entry.js": [
		"DW50",
		1,
		27
	],
	"./amplify-toast.entry.js": [
		"QOpS",
		28
	],
	"./amplify-tooltip.entry.js": [
		"vSUa",
		29
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "+uQQ";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "/6nF":
/*!*************************************************************************!*\
  !*** ./src/app/ReduxStore/reducers/catalogos/catalogoDetail.reducer.ts ***!
  \*************************************************************************/
/*! exports provided: DetailCatalogosState, DetailCatologosReducer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DetailCatalogosState", function() { return DetailCatalogosState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DetailCatologosReducer", function() { return DetailCatologosReducer; });
/* harmony import */ var _actions_catalogos_catalogoDetail_actions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../actions/catalogos/catalogoDetail.actions */ "5zl/");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ngrx/store */ "l7P3");


const DetailCatalogosState = {
    DetailCatalogos: [],
    error: null,
    loading: false,
};
const _DetailCatologosReducer = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_1__["createReducer"])(DetailCatalogosState, Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_1__["on"])(_actions_catalogos_catalogoDetail_actions__WEBPACK_IMPORTED_MODULE_0__["loadingDetailCatalogos"], (state) => (Object.assign(Object.assign({}, state), { loading: true }))), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_1__["on"])(_actions_catalogos_catalogoDetail_actions__WEBPACK_IMPORTED_MODULE_0__["cargarDetailCatalogos"], (state) => (Object.assign({}, state))), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_1__["on"])(_actions_catalogos_catalogoDetail_actions__WEBPACK_IMPORTED_MODULE_0__["caragarDetailCatalogosSucces"], (state, { DetailCatalogos }) => (Object.assign(Object.assign({}, state), { DetailCatalogos: DetailCatalogos, loading: false, error: null }))), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_1__["on"])(_actions_catalogos_catalogoDetail_actions__WEBPACK_IMPORTED_MODULE_0__["caragarDetailCatalogosError"], (state, { payload }) => (Object.assign(Object.assign({}, state), { loading: false, error: payload }))), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_1__["on"])(_actions_catalogos_catalogoDetail_actions__WEBPACK_IMPORTED_MODULE_0__["unSetDetailCatalogos"], (state) => (Object.assign(Object.assign({}, state), { loading: false, error: null, DetailCatalogos: [] }))));
let DetailCatologosReducer = (state, action) => _DetailCatologosReducer(state, action);


/***/ }),

/***/ "/ap+":
/*!***********************************************!*\
  !*** ./src/app/services/auditoria.service.ts ***!
  \***********************************************/
/*! exports provided: AuditoriaService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuditoriaService", function() { return AuditoriaService; });
/* harmony import */ var aws_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! aws-sdk */ "Sp1i");
/* harmony import */ var aws_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(aws_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../environments/environment */ "AytR");
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! uuid */ "4USb");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




aws_sdk__WEBPACK_IMPORTED_MODULE_0__["config"].update({
    accessKeyId: _environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].SESConfig.accessKeyId,
    secretAccessKey: _environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].SESConfig.secretAccessKey,
    region: _environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].SESConfig.region
});
var sqs = new aws_sdk__WEBPACK_IMPORTED_MODULE_0__["SQS"]();
class AuditoriaService {
    constructor() { }
    enviarBitacoraUsuarios(objetoBitacora) {
        const params = {
            MessageBody: objetoBitacora,
            MessageDeduplicationId: Object(uuid__WEBPACK_IMPORTED_MODULE_2__["v4"])(),
            MessageGroupId: Object(uuid__WEBPACK_IMPORTED_MODULE_2__["v4"])(),
            QueueUrl: _environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].API.endpoints.find((el) => el.name === 'sqs-auditoria')['endpoint']
        };
        sqs.sendMessage(params, function (err, data) {
            if (err) {
                // console.log("Error.", err);
            }
            else {
                // console.log("Success.", data.MessageId);
            }
        });
    }
}
AuditoriaService.ɵfac = function AuditoriaService_Factory(t) { return new (t || AuditoriaService)(); };
AuditoriaService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({ token: AuditoriaService, factory: AuditoriaService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Code\Principal\front-maquetado\system-I\src\main.ts */"zUnb");


/***/ }),

/***/ "0rus":
/*!**************************************************************!*\
  !*** ./src/app/ReduxStore/reducers/AUDGENPROCESO.reducer.ts ***!
  \**************************************************************/
/*! exports provided: AUDGENPROCESOState, AUDGENPROCESOReducer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AUDGENPROCESOState", function() { return AUDGENPROCESOState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AUDGENPROCESOReducer", function() { return AUDGENPROCESOReducer; });
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/store */ "l7P3");
/* harmony import */ var _actions_AUDGENPROCESO_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../actions/AUDGENPROCESO.actions */ "LB20");


const AUDGENPROCESOState = {
    AUDGENPROCESOS: [],
    consult: null,
    error: null,
};
const _AUDGENPROCESOReducer = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createReducer"])(AUDGENPROCESOState, Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions_AUDGENPROCESO_actions__WEBPACK_IMPORTED_MODULE_1__["LoadAUDGENPROCESOS"], (state, { consult }) => (Object.assign({}, state))), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions_AUDGENPROCESO_actions__WEBPACK_IMPORTED_MODULE_1__["LoadAUDGENPROCESOSuccess"], (state, { AUDGENPROCESOS }) => (Object.assign(Object.assign({}, state), { AUDGENPROCESOS: [...AUDGENPROCESOS], error: null }))), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions_AUDGENPROCESO_actions__WEBPACK_IMPORTED_MODULE_1__["UnsetAUDGENPROCESO"], (state) => (Object.assign(Object.assign({}, state), { AUDGENPROCESOS: null, error: null, consult: null }))), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions_AUDGENPROCESO_actions__WEBPACK_IMPORTED_MODULE_1__["LoadAUDGENPROCESOError"], (state, { payload }) => (Object.assign(Object.assign({}, state), { error: payload }))));
let AUDGENPROCESOReducer = (state, action) => _AUDGENPROCESOReducer(state, action);


/***/ }),

/***/ 1:
/*!************************!*\
  !*** crypto (ignored) ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 2:
/*!********************!*\
  !*** fs (ignored) ***!
  \********************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ "2CCq":
/*!*************************************************************************************!*\
  !*** ./src/app/ReduxStore/actions/notificacionSelect/notificacionSelect.actions.ts ***!
  \*************************************************************************************/
/*! exports provided: notificacionSelect */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "notificacionSelect", function() { return notificacionSelect; });
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/store */ "l7P3");

const notificacionSelect = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[Notificacion] Notificacion Select', Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());


/***/ }),

/***/ "4rUU":
/*!****************************************!*\
  !*** ./src/app/model/usuario.model.ts ***!
  \****************************************/
/*! exports provided: Usuario */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Usuario", function() { return Usuario; });
class Usuario {
    constructor(name, email, groups, attributes) {
        this.name = name;
        this.email = email;
        this.groups = groups;
        this.attributes = attributes;
    }
    static fromAmplify({ email, name, groups, attributes }) {
        return new Usuario(name, email, groups, attributes);
    }
}


/***/ }),

/***/ "4ujS":
/*!***********************************************!*\
  !*** ./src/app/services/catalogos.service.ts ***!
  \***********************************************/
/*! exports provided: CatalogosService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CatalogosService", function() { return CatalogosService; });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../environments/environment */ "AytR");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngrx/store */ "l7P3");
/* harmony import */ var _auditoria_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./auditoria.service */ "/ap+");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./auth.service */ "lGQG");







class CatalogosService {
    constructor(httpClient, store, auditoria, authServcie) {
        this.httpClient = httpClient;
        this.store = store;
        this.auditoria = auditoria;
        this.authServcie = authServcie;
        this.UrlCatalogos = _environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].API.endpoints.find((el) => el.name === 'catalogos')['endpoint'];
        this.getCatalogos = () => {
            const area = localStorage.getItem('area');
            /*if (area.split(',').includes(EArea.Soporte)) {
                  return this.httpClient.get(this.UrlCatalogos + 'catalogos', {
                    headers: this.authServcie.userHeaders(),
                  });
                }*/
            let QueryParams = new _angular_common_http__WEBPACK_IMPORTED_MODULE_0__["HttpParams"]();
            QueryParams = QueryParams.append('negocio', localStorage.getItem('negocio'));
            QueryParams = QueryParams.append('area', localStorage.getItem('area'));
            return this.httpClient.get(this.UrlCatalogos + 'catalogos', {
                params: QueryParams,
                headers: this.authServcie.userHeaders(),
            });
        };
        this.structureCat = () => {
            let array = null;
            this.httpClient
                .get(this.UrlCatalogos + 'catalogos/' + localStorage.getItem('nameCat'), {
                headers: this.authServcie.userHeaders(),
            })
                .toPromise()
                .then((res) => {
                const arrayTemp = [];
                res
                    .filter((e) => e.llavePrimaria === true)
                    .forEach((r) => arrayTemp.push(r));
                res
                    .filter((e) => e.llavePrimaria === false)
                    .forEach((r) => arrayTemp.push(r));
                array = arrayTemp;
            });
            return new Promise((resolve) => {
                const intervalo = setInterval(() => {
                    if (array) {
                        resolve(array);
                        clearInterval(intervalo);
                    }
                }, 100);
            });
        };
        this.getDetailsCat = () => {
            let nextTokenValidator = 'next';
            let arrayRes = [];
            this.httpClient
                .get(this.UrlCatalogos +
                'catalogos/' +
                localStorage.getItem('nameCat') +
                '/registros', {
                headers: this.authServcie.userHeaders(),
            })
                .toPromise()
                .then(({ nextToken, registros }) => {
                arrayRes = [...registros];
                nextTokenValidator = nextToken;
            });
            return new Promise((resolve) => {
                const intervalo = setInterval(() => {
                    if (nextTokenValidator === null) {
                        resolve({ registros: arrayRes });
                        clearInterval(intervalo);
                    }
                    else {
                        if (nextTokenValidator !== 'next') {
                            let QueryParams = new _angular_common_http__WEBPACK_IMPORTED_MODULE_0__["HttpParams"]();
                            QueryParams = QueryParams.append('nextToken', nextTokenValidator);
                            this.httpClient
                                .get(this.UrlCatalogos +
                                'catalogos/' +
                                localStorage.getItem('nameCat') +
                                '/registros', {
                                params: QueryParams,
                                headers: this.authServcie.userHeaders(),
                            })
                                .toPromise()
                                .then(({ nextToken, registros }) => {
                                if (!arrayRes.includes(registros[0])) {
                                    arrayRes = [...arrayRes, ...registros];
                                }
                                if (nextTokenValidator !== nextToken) {
                                    if (nextTokenValidator) {
                                        nextTokenValidator = nextToken;
                                    }
                                }
                            });
                        }
                    }
                }, 1000);
            });
        };
        this.updateDetailsCat = (object) => {
            return this.httpClient
                .put(this.UrlCatalogos +
                'catalogos/' +
                localStorage.getItem('nameCat') +
                '/registros', object, {
                headers: this.authServcie.userHeaders(),
            })
                .toPromise();
        };
        this.addDetailsCat = (object) => {
            return this.httpClient
                .post(this.UrlCatalogos +
                'catalogos/' +
                localStorage.getItem('nameCat') +
                '/registros', object, {
                headers: this.authServcie.userHeaders(),
            })
                .toPromise();
        };
        this.deleteDetailsCat = (registro) => {
            let stringCode = '';
            if (typeof registro === 'string') {
                stringCode = registro;
            }
            else {
                stringCode = registro.toString();
            }
            return this.httpClient
                .delete(this.UrlCatalogos +
                'catalogos/' +
                localStorage.getItem('nameCat') +
                '/registros/' +
                window.btoa(unescape(encodeURIComponent(registro))), {
                headers: this.authServcie.userHeaders(),
            })
                .toPromise();
        };
    }
    generarAuditoria(estado) {
        const catalogo = localStorage.getItem('nameCat');
        const descripcion = localStorage.getItem('negocioCat');
        const newRegister = localStorage.getItem('ObjectNewRegister');
        const oldRegister = localStorage.getItem('ObjectOldRegister');
        const accion = localStorage.getItem('RegisterAction');
        const today = new Date().toISOString();
        let area = '';
        let rol = '';
        let correo = '';
        let apellidoPaterno = '';
        let nombre = '';
        this.store
            .select(({ usuario }) => usuario.user)
            .subscribe((res) => {
            rol = res.attributes['custom:rol'];
            correo = res.email;
            nombre = res.attributes.given_name;
            apellidoPaterno = res.attributes.family_name;
        });
        this.store
            .select(({ usuario }) => usuario.area)
            .subscribe((res) => {
            area = res;
        });
        const payload = {
            areaNegocio: area,
            rol: rol,
            correo: correo,
            fecha: today,
            modulo: 'CATALOGOS',
            usuario: {
                apellidoPaterno: apellidoPaterno,
                nombre: nombre,
            },
            catalogos: {
                nombre: catalogo,
                accion: accion,
                estado: estado,
                descripcion: descripcion,
                detalleModificaciones: [
                    {
                        valorAnterior: JSON.parse(oldRegister),
                        valorNuevo: JSON.parse(newRegister),
                    },
                ],
            },
        };
        const payloadString = JSON.stringify(payload);
        this.auditoria.enviarBitacoraUsuarios(payloadString);
        localStorage.removeItem('RegisterAction');
        localStorage.removeItem('ObjectNewRegister');
        localStorage.removeItem('ObjectOldRegister');
    }
}
CatalogosService.ɵfac = function CatalogosService_Factory(t) { return new (t || CatalogosService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_0__["HttpClient"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_ngrx_store__WEBPACK_IMPORTED_MODULE_3__["Store"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_auditoria_service__WEBPACK_IMPORTED_MODULE_4__["AuditoriaService"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_auth_service__WEBPACK_IMPORTED_MODULE_5__["AuthService"])); };
CatalogosService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({ token: CatalogosService, factory: CatalogosService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ "5zl/":
/*!************************************************************************!*\
  !*** ./src/app/ReduxStore/actions/catalogos/catalogoDetail.actions.ts ***!
  \************************************************************************/
/*! exports provided: loadingDetailCatalogos, cargarDetailCatalogos, caragarDetailCatalogosSucces, caragarDetailCatalogosError, unSetDetailCatalogos */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "loadingDetailCatalogos", function() { return loadingDetailCatalogos; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cargarDetailCatalogos", function() { return cargarDetailCatalogos; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "caragarDetailCatalogosSucces", function() { return caragarDetailCatalogosSucces; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "caragarDetailCatalogosError", function() { return caragarDetailCatalogosError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "unSetDetailCatalogos", function() { return unSetDetailCatalogos; });
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/store */ "l7P3");

const loadingDetailCatalogos = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[DetailCatalogos] Loading DetailCatalogos');
const cargarDetailCatalogos = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[DetailCatalogos] Cargar DetailCatalogos');
const caragarDetailCatalogosSucces = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[DetailCatalogos] Cargar DetailCatalogos Success', Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
const caragarDetailCatalogosError = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[DetailCatalogos] Cargar DetailCatalogos Error', Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
const unSetDetailCatalogos = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[DetailCatalogos] unSetDetailCatalogos');


/***/ }),

/***/ "AMCz":
/*!*********************************************!*\
  !*** ./src/app/ReduxStore/effects/index.ts ***!
  \*********************************************/
/*! exports provided: EffectsArrays */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EffectsArrays", function() { return EffectsArrays; });
/* harmony import */ var _AUDGENPROCESOS_effects__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./AUDGENPROCESOS.effects */ "rhVg");
/* harmony import */ var _AUDGENESTADOPROCESO_effects__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./AUDGENESTADOPROCESO.effects */ "Mdjv");
/* harmony import */ var _listaUsuarios_effects__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./listaUsuarios.effects */ "H+nS");
/* harmony import */ var _AUDGENEJECUCIONESPROCESO_effects__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./AUDGENEJECUCIONESPROCESO.effects */ "Lrx8");
/* harmony import */ var _CATPROCESOS_effects__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./CATPROCESOS.effects */ "vacT");
/* harmony import */ var _CATPERMISOS_effects__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./CATPERMISOS.effects */ "D2Mh");
/* harmony import */ var _catalogos_catalogos_effects__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./catalogos/catalogos.effects */ "vUHb");
/* harmony import */ var _catalogos_catalogoDetail_effects__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./catalogos/catalogoDetail.effects */ "sa/g");
/* harmony import */ var _usuarios_AUDGENUSUARIOS_effects__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./usuarios/AUDGENUSUARIOS.effects */ "IvGi");









const EffectsArrays = [
    _AUDGENPROCESOS_effects__WEBPACK_IMPORTED_MODULE_0__["AUDGENPROCESOSEfffects"],
    _listaUsuarios_effects__WEBPACK_IMPORTED_MODULE_2__["ListadoUsuariosEfffects"],
    _AUDGENESTADOPROCESO_effects__WEBPACK_IMPORTED_MODULE_1__["AUDGENESTADOPROCESOEfffects"],
    _AUDGENEJECUCIONESPROCESO_effects__WEBPACK_IMPORTED_MODULE_3__["AUDGENEJECUCIONESPROCESOEfffects"],
    _CATPROCESOS_effects__WEBPACK_IMPORTED_MODULE_4__["CATPROCESOSEfffects"],
    _catalogos_catalogos_effects__WEBPACK_IMPORTED_MODULE_6__["CatalogosEfffects"],
    _CATPERMISOS_effects__WEBPACK_IMPORTED_MODULE_5__["CATPERMISOSEfffects"],
    _catalogos_catalogoDetail_effects__WEBPACK_IMPORTED_MODULE_7__["CatalogoDetailEfffects"],
    _usuarios_AUDGENUSUARIOS_effects__WEBPACK_IMPORTED_MODULE_8__["AUDGENUSUARIOSEfffects"]
];


/***/ }),

/***/ "AytR":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
const environment = {
    production: false,
    SESConfig: {
        accessKeyId: 'AKIAU4J45SEJH3NKEMHX',
        secretAccessKey: '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',
        region: 'us-east-1',
    },
    urlExternalLogin: 'https://sia-app-up.auth.us-east-1.amazoncognito.com/oauth2/authorize?identity_provider=Azure&redirect_uri=https://dev.d23mbxjbgl0msz.amplifyapp.com/&response_type=code&client_id=5cvq4jop6octili7583n597kd1&scope=phone%20email%20openid%20profile',
    // urlExternalLogin: 'https://sia-app-up.auth.us-east-1.amazoncognito.com/oauth2/authorize?identity_provider=Azure&redirect_uri=http://localhost:4200/dashboard&response_type=code&client_id=5cvq4jop6octili7583n597kd1&scope=phone%20email%20openid%20profile',
    amplifyConfig: {
        Auth: {
            region: 'us-east-1',
            userPoolId: 'us-east-1_Ftm7m3Om2',
            userPoolWebClientId: '5cvq4jop6octili7583n597kd1',
            limit: 50,
            oauth: {
                domain: 'sia-app-up.auth.us-east-1.amazoncognito.com',
                scope: ['phone', 'email', 'openid', 'profile'],
                redirectSignIn: 'https://dev.d23mbxjbgl0msz.amplifyapp.com/',
                redirectSignOut: 'https://dev.d23mbxjbgl0msz.amplifyapp.com/',
                /*
                        redirectSignIn: 'http://localhost:4200/dashboard',
                        redirectSignOut: 'http://localhost:4200',
                */
                responseType: 'code'
            },
        }
    },
    API: {
        endpoints: [
            {
                name: 'sqs-auditoria',
                endpoint: 'https://sqs.us-east-1.amazonaws.com/335672086802/sia-utileria-encolamiento-mensajes-monitoreo-dev.fifo'
            },
            {
                name: 'catalogos',
                endpoint: 'https://ixsp0lvu2h.execute-api.us-east-1.amazonaws.com/dev/sia/utileria/'
            },
            {
                name: 'auditoria',
                endpoint: 'https://ixsp0lvu2h.execute-api.us-east-1.amazonaws.com/dev/sia/utileria/auditoria/interfaces'
            },
            {
                name: 'AIMS Y EXCEDENTES',
                endpoint: 'https://ixsp0lvu2h.execute-api.us-east-1.amazonaws.com/dev/sia/afore/aimsexcedentes'
            },
            {
                name: 'MD',
                endpoint: 'https://ixsp0lvu2h.execute-api.us-east-1.amazonaws.com/dev/sia/afore/md'
            },
            {
                name: 'INT CASH',
                endpoint: 'https://ixsp0lvu2h.execute-api.us-east-1.amazonaws.com/dev/sia/afore/intcash'
            },
            {
                name: 'MO',
                endpoint: 'https://ixsp0lvu2h.execute-api.us-east-1.amazonaws.com/dev/sia/afore/mo'
            },
            {
                name: 'CRD',
                endpoint: 'https://ixsp0lvu2h.execute-api.us-east-1.amazonaws.com/dev/sia/fondos/crd'
            },
            {
                name: 'MANDATOS',
                endpoint: 'https://ixsp0lvu2h.execute-api.us-east-1.amazonaws.com/dev/sia/fondos/mandatos'
            }
        ],
    },
};


/***/ }),

/***/ "D2Mh":
/*!***********************************************************!*\
  !*** ./src/app/ReduxStore/effects/CATPERMISOS.effects.ts ***!
  \***********************************************************/
/*! exports provided: CATPERMISOSEfffects */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CATPERMISOSEfffects", function() { return CATPERMISOSEfffects; });
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/effects */ "9jGm");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/observable/fromPromise */ "3gwn");
/* harmony import */ var rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _actions_CATPERMISOS_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../actions/CATPERMISOS.actions */ "NHAl");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _API_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./../../API.service */ "iO9l");








class CATPERMISOSEfffects {
    constructor(actions$, api) {
        this.actions$ = actions$;
        this.api = api;
        this.loadAUDGENPROCESO$ = Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_0__["createEffect"])(() => this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_0__["ofType"])(_actions_CATPERMISOS_actions__WEBPACK_IMPORTED_MODULE_4__["LoadCATPERMISOS"]), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["mergeMap"])(({ consult }) => {
            if (consult) {
                return Object(rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3__["fromPromise"])(this.api.ListCATPERMISOS(consult.NEGOCIOS, consult.AREA, consult.ROL)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])(({ items }) => _actions_CATPERMISOS_actions__WEBPACK_IMPORTED_MODULE_4__["LoadCATPERMISOSuccess"]({
                    CATPERMISOS: items,
                })), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["catchError"])((error) => Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(_actions_CATPERMISOS_actions__WEBPACK_IMPORTED_MODULE_4__["LoadCATPERMISOError"]({ payload: error }))));
            }
            else {
                return Object(rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3__["fromPromise"])(this.api.ListCATPERMISOS()).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])(({ items }) => _actions_CATPERMISOS_actions__WEBPACK_IMPORTED_MODULE_4__["LoadCATPERMISOSuccess"]({
                    CATPERMISOS: items,
                })), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["catchError"])((error) => Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(_actions_CATPERMISOS_actions__WEBPACK_IMPORTED_MODULE_4__["LoadCATPERMISOError"]({ payload: error }))));
            }
        })));
    }
}
CATPERMISOSEfffects.ɵfac = function CATPERMISOSEfffects_Factory(t) { return new (t || CATPERMISOSEfffects)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_ngrx_effects__WEBPACK_IMPORTED_MODULE_0__["Actions"]), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_API_service__WEBPACK_IMPORTED_MODULE_6__["APIService"])); };
CATPERMISOSEfffects.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjectable"]({ token: CATPERMISOSEfffects, factory: CATPERMISOSEfffects.ɵfac });


/***/ }),

/***/ "D8EZ":
/*!************************************************!*\
  !*** ./src/app/pages/login/login.component.ts ***!
  \************************************************/
/*! exports provided: LoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginComponent", function() { return LoginComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _services_usuarios_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../services/usuarios.service */ "ESM5");
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/auth.service */ "lGQG");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngrx/store */ "l7P3");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "ofXK");





function LoginComponent_div_16_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "p", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "Contacta a Mesa de Ayuda para que te proporcione el acceso a la aplicaci\u00F3n.");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} }
class LoginComponent {
    constructor(usuario, auth, store) {
        this.usuario = usuario;
        this.auth = auth;
        this.store = store;
        this.login = () => {
            const time = new Date().getTime();
            localStorage.setItem("SIA", time.toString());
            this.auth.signIn();
        };
    }
    ngOnInit() {
        /*
        const UserAttributes = [
          {
            Name: 'custom:negocio',
            Value: 'Afore',
          },
          {
            Name: 'custom:rol',
            Value: 'Administrador',
          },
        ];
        const Username = 'azure_jyjzfei0rp_hdfd7jh_j8halgegmlsfiudwyrgnw2ya';
        this.usuario.actualizarAtributosUsuarioCallback(UserAttributes, Username);
        */
        if (localStorage.getItem("SIA")) {
            let start, end;
            start = localStorage.getItem("SIA");
            end = new Date().getTime();
            start = parseInt(localStorage.getItem("SIA"));
            const time = end - start;
            console.log(time);
            if (localStorage.getItem("SIA").length > 0 && time > 180000) {
                localStorage.removeItem("SIA");
            }
        }
    }
    validarInicioSesion() {
        let flag = false;
        if (localStorage.getItem("SIA")) {
            let start, end;
            start = localStorage.getItem("SIA");
            end = new Date().getTime();
            start = parseInt(localStorage.getItem("SIA"));
            const time = end - start;
            if (localStorage.getItem("SIA").length > 0 && time > 1000) {
                flag = true;
            }
        }
        return flag;
    }
}
LoginComponent.ɵfac = function LoginComponent_Factory(t) { return new (t || LoginComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_services_usuarios_service__WEBPACK_IMPORTED_MODULE_1__["UsuariosService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_services_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_ngrx_store__WEBPACK_IMPORTED_MODULE_3__["Store"])); };
LoginComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: LoginComponent, selectors: [["app-login"]], decls: 17, vars: 1, consts: [[1, "container-fluid", "bg"], [1, "d-flex", "flex-row-reverse", "align-items-center", 2, "height", "100vh", "width", "100%"], [1, "col-md-6", "col-sm-7", "col-xs-12", "col-lg-5", "mr-2"], [1, "card", "card-pre-login"], [1, "d-flex", "flex-column", "align-items-center", "container-card-login"], [1, "p-2", "d-flex", "flex-column", "align-items-center", "justify-content-end"], [1, "logo-principal-login"], [1, "p-2", "d-flex", "flex-column", "align-items-center", "justify-content-center"], [1, "text-title-1"], [1, "text-title-2", "mt-1"], [1, "mt-4"], ["type", "button", 1, "btn", "button-login"], [1, "label-btn-login", 3, "click"], ["class", "mt-4", 4, "ngIf"], [1, "mesa-ayuda"]], template: function LoginComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](9, "Sistema Integral");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](10, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](11, "Automatizado");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](12, "div", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](13, "button", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "span", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function LoginComponent_Template_span_click_14_listener() { return ctx.login(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](15, " Iniciar sesi\u00F3n ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](16, LoginComponent_div_16_Template, 3, 0, "div", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](16);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.validarInicioSesion());
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_4__["NgIf"]], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJsb2dpbi5jb21wb25lbnQuY3NzIn0= */"] });


/***/ }),

/***/ "ESM5":
/*!**********************************************!*\
  !*** ./src/app/services/usuarios.service.ts ***!
  \**********************************************/
/*! exports provided: UsuariosService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsuariosService", function() { return UsuariosService; });
/* harmony import */ var _ReduxStore_actions_loaderProcesoCambios_actions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../ReduxStore/actions/loaderProcesoCambios.actions */ "tONv");
/* harmony import */ var aws_sdk__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! aws-sdk */ "Sp1i");
/* harmony import */ var aws_sdk__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(aws_sdk__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../environments/environment */ "AytR");
/* harmony import */ var _validators_roles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../validators/roles */ "r6zK");
/* harmony import */ var _validators_opcionesDeFiltroUsuarioAdmininistracion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../validators/opcionesDeFiltroUsuarioAdmininistracion */ "F3a3");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngrx/store */ "l7P3");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./auth.service */ "lGQG");
/* harmony import */ var _auditoria_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./auditoria.service */ "/ap+");









aws_sdk__WEBPACK_IMPORTED_MODULE_1__["config"].update(_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].SESConfig);
var cognitoidentityserviceprovider = new aws_sdk__WEBPACK_IMPORTED_MODULE_1__["CognitoIdentityServiceProvider"]();
var result = [];
var objFiltrado = [];
class UsuariosService {
    constructor(store, authService, auditoria) {
        this.store = store;
        this.authService = authService;
        this.auditoria = auditoria;
        this.Roles = [_validators_roles__WEBPACK_IMPORTED_MODULE_3__["ERole"].Administrador, _validators_roles__WEBPACK_IMPORTED_MODULE_3__["ERole"].Monitor];
        this.Areas = [
            _validators_roles__WEBPACK_IMPORTED_MODULE_3__["EArea"].Contabilidad,
            _validators_roles__WEBPACK_IMPORTED_MODULE_3__["EArea"].Custodia,
            _validators_roles__WEBPACK_IMPORTED_MODULE_3__["EArea"].Inversiones_Riesgos,
            _validators_roles__WEBPACK_IMPORTED_MODULE_3__["EArea"].Tesoreria,
            _validators_roles__WEBPACK_IMPORTED_MODULE_3__["EArea"].Soporte,
        ];
        this.Negocios = [
            _validators_roles__WEBPACK_IMPORTED_MODULE_3__["ENegocio"].Afore,
            _validators_roles__WEBPACK_IMPORTED_MODULE_3__["ENegocio"].Fondos,
        ];
        this.params = {
            GroupName: 'Tesoreria' /* es un dato de entrada de la pantalla (grupo al que se agrega o remueve el usuario) */,
            UserPoolId: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].amplifyConfig.Auth.userPoolId,
            Username: 'azure_rwayeowx9nsigogmrb6adqmpgrl2hohoivn5bgsobja' /* identificador del usuario en al user pool */,
        };
        this.paramsUser = {
            UserPoolId: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].amplifyConfig.Auth.userPoolId,
            Username: 'azure_rwayeowx9nsigogmrb6adqmpgrl2hohoivn5bgsobja' /* identificador del usuario en al user pool */,
        };
        this.paramsGroups = {
            UserPoolId: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].amplifyConfig.Auth.userPoolId,
        };
        this.paramsUserGroups = {
            GroupName: 'Tesoreria' /* es un dato de entrada de la pantalla */,
            Limit: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].amplifyConfig.Auth.limit,
            UserPoolId: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].amplifyConfig.Auth.userPoolId,
        };
        this.paramsAtributos = {
            UserAttributes: [
                {
                    Name: 'custom:negocio',
                    Value: 'Afore' /* campo de entrada identificado como negocio */,
                },
                {
                    Name: 'custom:rol',
                    Value: 'Soporte' /* campo de entrada identificado como permiso */,
                },
            ],
            Username: 'azure_rwayeowx9nsigogmrb6adqmpgrl2hohoivn5bgsobja' /* identificador del usuario en el user pool */,
            UserPoolId: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].amplifyConfig.Auth.userPoolId,
        };
        this.paramsGrupoUsuario = {
            Username: 'azure_rwayeowx9nsigogmrb6adqmpgrl2hohoivn5bgsobja' /* identificador del usuario en el user pool */,
            UserPoolId: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].amplifyConfig.Auth.userPoolId,
        };
        this.paramsDeleteUser = {
            Username: 'azure_hgjelpfjjwxffms6_5oti6ydqcjh7jhjdxn9706cxf0' /* identificador del usuario en el user pool */,
            UserPoolId: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].amplifyConfig.Auth.userPoolId,
        };
        this.numeroDeProcesos = 0;
        this.paramSignOut = {
            Username: this.authService.getToken(),
            UserPoolId: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].amplifyConfig.Auth.userPoolId,
        };
        this.eliminarUsuarioPromesa = (Username) => {
            // metodo para eliminar un usuario del user pool
            const paramsDeleteUser = {
                Username: Username,
                UserPoolId: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].amplifyConfig.Auth.userPoolId,
            };
            return cognitoidentityserviceprovider.adminDeleteUser(paramsDeleteUser).promise();
        };
        this.consultarUsuariosEnGrupo = (grupo) => {
            // método para consultar todos los usuarios que existen en un grupo del user pool
            const params = {
                GroupName: grupo,
                Limit: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].amplifyConfig.Auth.limit,
                UserPoolId: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].amplifyConfig.Auth.userPoolId,
            };
            return cognitoidentityserviceprovider.listUsersInGroup(params);
        };
        this.consultarUsuarios = () => {
            // metodo para consultar todos los usuarios del user pool
            return cognitoidentityserviceprovider.listUsers(this.paramsGroups);
        };
        this.consultaSinFiltroYConFiltro = (consulta) => {
            let promesa = this.consultarUsuarios();
            if (consulta) {
                switch (consulta.tipo) {
                    case _validators_opcionesDeFiltroUsuarioAdmininistracion__WEBPACK_IMPORTED_MODULE_4__["ValorFiltrarGrupo"].Grupo:
                        promesa = this.consultarUsuariosEnGrupo(consulta.parametro);
                }
            }
            return promesa.promise();
        };
        this.consultaUsuariosMultipleFactor = (parametro) => {
            return new Promise((resolve) => {
                let ObjectUsers = [];
                let UserList = [];
                this.consultaSinFiltroYConFiltro(parametro).then(({ Users }) => {
                    for (let i in Users) {
                        if (Users[i].UserStatus === 'EXTERNAL_PROVIDER') {
                            ObjectUsers.push(Users[i]);
                        }
                    }
                    //ObjectUsers = [...Users];
                    //console.log("TST ...Users", ObjectUsers)
                    if (ObjectUsers.length === 0) {
                        resolve(ObjectUsers);
                    }
                    const flagDeTerminado = ObjectUsers.length;
                    let comparacion = 0;
                    ObjectUsers.forEach((UserElement, index) => {
                        if (UserElement.UserStatus === 'EXTERNAL_PROVIDER') {
                            this.obtenerGrupoUsuarioPromise(UserElement.Username).then(({ Groups }) => {
                                Groups.forEach((e, indexGroup) => {
                                    let tempString = '';
                                    if (e.hasOwnProperty('GroupName')) {
                                        tempString = e.GroupName;
                                    }
                                    this.Areas.forEach((validador) => {
                                        if (validador === tempString) {
                                            ObjectUsers[index].GrupoQuePertenece = tempString;
                                        }
                                    });
                                    if (indexGroup + 1 === Groups.length) {
                                        UserList.push(this.reformatearArrayDeUsuarios(ObjectUsers[index]));
                                    }
                                    if (indexGroup + 1 === Groups.length) {
                                        comparacion = comparacion + 1;
                                    }
                                });
                            });
                        }
                    });
                    new Promise((resolve2) => {
                        const intervalo = setInterval(() => {
                            if (comparacion === flagDeTerminado) {
                                resolve2('ok');
                                clearInterval(intervalo);
                            }
                        }, 100);
                    }).then(() => {
                        resolve(UserList);
                    });
                });
            });
        };
        this.eliminarYAgregarGrupo = (Grupo, Username, GrupoOriginal) => {
            const params = {
                GroupName: GrupoOriginal,
                UserPoolId: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].amplifyConfig.Auth.userPoolId,
                Username: Username,
            };
            let terminado = null;
            if (GrupoOriginal.trim().length === 0) {
                terminado = 1;
            }
            else {
                cognitoidentityserviceprovider.adminRemoveUserFromGroup(params, (err, data) => {
                    if (err) {
                        terminado = 1;
                    }
                    else {
                        terminado = 1;
                    }
                });
            }
            new Promise((resolve) => {
                const intervalo = setInterval(() => {
                    if (terminado) {
                        resolve('ok');
                        clearInterval(intervalo);
                    }
                }, 100);
            }).then(() => {
                this.agregarUsuarioGrupoCallback(Grupo, Username);
            });
        };
        this.actualizarAtributosUsuarioCallback = (UserAttributes, Username) => {
            const paramsAtributos = {
                UserAttributes: UserAttributes,
                Username: Username /* identificador del usuario en el user pool */,
                UserPoolId: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].amplifyConfig.Auth.userPoolId,
            };
            let terminado = null;
            cognitoidentityserviceprovider.adminUpdateUserAttributes(paramsAtributos, (err, data) => {
                if (err) {
                    terminado = 1;
                    // console.log('err', err, 'data', data);
                }
                else {
                    terminado = 1;
                    // console.log('err', err, 'data', data);
                }
            });
            new Promise((resolve) => {
                const intervalo = setInterval(() => {
                    if (terminado) {
                        resolve('ok');
                        clearInterval(intervalo);
                    }
                }, 100);
            }).then(() => {
                this.numeroDeProcesos++;
            });
        };
        this.validacionDeProcesosInsertar = (Attributos, paramGrupo) => {
            let numeroProcesosComparar = 2;
            const { Grupo, Username, GrupoOriginal } = paramGrupo;
            const { UserAttributes } = Attributos;
            this.eliminarYAgregarGrupo(Grupo, Username, GrupoOriginal);
            this.actualizarAtributosUsuarioCallback(UserAttributes, Username);
            new Promise((resolve) => {
                const intervalo = setInterval(() => {
                    if (numeroProcesosComparar === this.numeroDeProcesos) {
                        resolve('ok');
                        clearInterval(intervalo);
                    }
                }, 100);
            }).then(() => {
                this.numeroDeProcesos = 0;
                this.store.dispatch(Object(_ReduxStore_actions_loaderProcesoCambios_actions__WEBPACK_IMPORTED_MODULE_0__["ProcesoTerminado"])());
            });
            let usuario = '';
            this.store.select(({ usuario }) => usuario.user.email).subscribe(res => {
                //console.log(res);
                usuario = res;
            });
            const ObjectUsuarioString = {
                area: paramGrupo.Grupo,
                permiso: Attributos.UserAttributes.find(el => el.Name === 'custom:rol')['Value'],
                negocio: Attributos.UserAttributes.find(el => el.Name === 'custom:negocio')['Value']
            };
            //console.log('ObjectUsuarioString', ObjectUsuarioString);
            localStorage.setItem('ObjectNewUser', JSON.stringify(ObjectUsuarioString));
            this.generarAuditoria();
        };
        this.actualizarAtributosUsuario = (UserAttributes, Username) => {
            // metodo para actualizar los valores de los atributos del usuario en el user pool
            const paramsAtributos = {
                UserAttributes: UserAttributes,
                Username: Username /* identificador del usuario en el user pool */,
                UserPoolId: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].amplifyConfig.Auth.userPoolId,
            };
            return cognitoidentityserviceprovider
                .adminUpdateUserAttributes(paramsAtributos)
                .promise();
        };
        this.obtenerGrupoUsuarioPromise = (usuario) => {
            let params = {
                Username: usuario /* identificador del usuario en el user pool */,
                UserPoolId: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].amplifyConfig.Auth.userPoolId,
            };
            return cognitoidentityserviceprovider
                .adminListGroupsForUser(params)
                .promise();
        };
        this.callbackAws = (err, data) => {
            /*
            if (err) console.log(err, err.stack);
            else console.log(JSON.stringify(data));*/
        };
        this.callbackAwsDetalle = (err, data) => {
            if (err)
                console.log(err, err.stack);
            else
                console.log(JSON.stringify(data));
        };
        /*
      ayuda de atibutos: {Name: "sub", Value: "42ae1b55-8029-4a09-8c81-8c805c650aaf"}
      1: {Name: "identities", Value: "[{"userId":"PY5dp6qYCyodowdB_EBAmPy3aF9cV6iO1-k6Ue…null,"primary":true,"dateCreated":1618943540138}]"}
      2: {Name: "email_verified", Value: "false"}
      3: {Name: "given_name", Value: "Diego"}
      4: {Name: "family_name", Value: "Garcia"}
      5: {Name: "email", Value: "garcia.diego@principal.com"}
      */
        this.reformatearArrayDeUsuarios = (objectUser) => {
            let object = {
                UserCreateDate: objectUser.UserCreateDate,
                UserLastModifiedDate: objectUser.UserLastModifiedDate,
                Enabled: objectUser.Enabled,
                UserStatus: objectUser.UserStatus,
                Username: objectUser.Username,
                GrupoQuePertenece: objectUser.hasOwnProperty('GrupoQuePertenece')
                    ? objectUser.GrupoQuePertenece
                    : '',
                Attributes: {},
            };
            objectUser.Attributes.forEach((attribute) => {
                object.Attributes[attribute.Name] = attribute.Value;
            });
            return object;
        };
        this.filtrarUsuariosConAtributos = (usuarios, permiso, areas, Correo) => {
            let Usuarios = [...usuarios];
            if (Correo != null) {
                let arrayTempCorreo = [];
                Correo.forEach((Correo) => {
                    arrayTempCorreo = [
                        ...arrayTempCorreo,
                        ...Usuarios.filter((e) => e.Attributes['email'] === Correo),
                    ];
                });
                Usuarios = arrayTempCorreo;
            }
            if (permiso != null) {
                let arrayTempPermiso = [];
                permiso.forEach((permiso) => {
                    arrayTempPermiso = [
                        ...arrayTempPermiso,
                        ...Usuarios.filter((e) => e.Attributes['custom:rol'] === permiso),
                    ];
                });
                Usuarios = arrayTempPermiso;
            }
            if (areas != null) {
                let arrayTempArea = [];
                areas.forEach((area) => {
                    Usuarios.forEach((usuario) => {
                        let areaArrayAtributoTemp = usuario.GrupoQuePertenece.trim().length === 0
                            ? []
                            : usuario.GrupoQuePertenece.split(',');
                        if (areaArrayAtributoTemp.includes(area)) {
                            arrayTempArea = [...arrayTempArea, usuario];
                        }
                    });
                });
                Usuarios = arrayTempArea;
            }
            return Usuarios;
        };
    }
    logout() {
        cognitoidentityserviceprovider.adminUserGlobalSignOut(this.paramSignOut, this.callbackAws);
    }
    eliminarUsuario() {
        // metodo para eliminar un usuario del user pool
        cognitoidentityserviceprovider.adminDeleteUser(this.paramsDeleteUser, this.callbackAws);
    }
    consultarGrupos() {
        // metodo para consultar todos los grupos del user pool
        cognitoidentityserviceprovider.listGroups(this.paramsGroups, this.callbackAws);
    }
    obtenerDetalleUsuario() {
        // metodo para obtener el los datos a detalle del usuario
        cognitoidentityserviceprovider.adminGetUser(this.paramsUser, this.callbackAwsDetalle);
    }
    agregarUsuarioGrupo(grupo, usuario) {
        const params = {
            GroupName: grupo,
            UserPoolId: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].amplifyConfig.Auth.userPoolId,
            Username: usuario,
        };
        // metodo para agregar a un usuario habilitado en el user pool a un grupo en especifico
        return cognitoidentityserviceprovider.adminAddUserToGroup(params).promise();
    }
    eliminarUsuarioGrupo(grupo, usuario) {
        const params = {
            GroupName: grupo,
            UserPoolId: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].amplifyConfig.Auth.userPoolId,
            Username: usuario,
        };
        let terminado = null;
        if (grupo.trim().length === 0) {
            terminado = 1;
        }
        else {
            cognitoidentityserviceprovider.adminRemoveUserFromGroup(params, (err, data) => {
                if (err) {
                    terminado = 1;
                }
                else {
                    terminado = 1;
                }
            });
        }
        new Promise((resolve) => {
            const intervalo = setInterval(() => {
                if (terminado) {
                    resolve('ok');
                    clearInterval(intervalo);
                }
            }, 100);
        }).then(() => {
            this.numeroDeProcesos++;
        });
    }
    agregarUsuarioGrupoCallback(grupo, usuario) {
        const params = {
            GroupName: grupo,
            UserPoolId: _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].amplifyConfig.Auth.userPoolId,
            Username: usuario,
        };
        let terminado = null;
        cognitoidentityserviceprovider.adminAddUserToGroup(params, (err, data) => {
            if (err) {
                terminado = 1;
            }
            else {
                terminado = 1;
            }
        });
        new Promise((resolve) => {
            const intervalo = setInterval(() => {
                if (terminado) {
                    resolve('ok');
                    clearInterval(intervalo);
                }
            }, 100);
        }).then(() => {
            this.numeroDeProcesos++;
        });
    }
    generarAuditoria() {
        //console.log("generar auditoria");
        const userOld = localStorage.getItem('ObjectOldUser');
        const userNew = localStorage.getItem('ObjectNewUser');
        const dataUsuario = JSON.parse(localStorage.getItem('ObjectDataUser'));
        const today = new Date().toISOString();
        let area = '';
        let rol = '';
        let correo = '';
        let apellidoPaterno = '';
        let nombre = '';
        this.store.select(({ usuario }) => usuario.user).subscribe(res => {
            //console.log(res);
            rol = res.attributes['custom:rol'];
            correo = res.email;
            nombre = res.attributes.given_name;
            apellidoPaterno = res.attributes.family_name;
        });
        this.store.select(({ usuario }) => usuario.area).subscribe(res => {
            //console.log(res)
            area = res;
        });
        let payload = {
            areaNegocio: area,
            rol: rol,
            correo: correo,
            fecha: today,
            modulo: "USUARIOS",
            usuario: {
                apellidoPaterno: apellidoPaterno,
                nombre: nombre
            },
            permisosUsuarios: [{
                    nombre: dataUsuario.nombre,
                    apellidoPaterno: dataUsuario.apellidoPaterno,
                    correo: dataUsuario.usuario,
                    accion: dataUsuario.accion,
                    estado: "EXITO",
                    detalleModificaciones: [{
                            valorAnterior: JSON.parse(userOld),
                            valorNuevo: JSON.parse(userNew)
                        }]
                }]
        };
        const payloadString = JSON.stringify(payload);
        this.auditoria.enviarBitacoraUsuarios(payloadString);
        localStorage.removeItem('ObjectOldUser');
        localStorage.removeItem('ObjectNewUser');
        localStorage.removeItem('ObjectDataUser');
    }
    obtenerGruposUsuario() {
        // metodo para consultar los grupos a los que pertenece un usuario del user pool
        cognitoidentityserviceprovider.adminListGroupsForUser(this.paramsGrupoUsuario, this.callbackAws);
    }
    validarRolUsuario() {
        let flagValidate = false;
        this.store
            .select(({ usuario }) => usuario.user)
            .subscribe((res) => {
            // console.log(attributes);
            if (res) {
                const { attributes } = res;
                if (!attributes.hasOwnProperty('custom:rol')) {
                    return flagValidate;
                }
                else {
                    if (this.Roles.includes(attributes['custom:rol'])) {
                        flagValidate = true;
                    }
                }
            }
        });
        return flagValidate;
    }
    filtrarUsuarios(usuarios, permiso, negocio, correo) {
        // filtrado por permiso
        console.log(usuarios);
        if (permiso != null) {
            for (var i = 0; i < usuarios.Users.length; i++) {
                if (usuarios.Users[i]['Attributes'].find((elemento) => elemento.Name === 'custom:rol')) {
                    var atrPermiso = usuarios.Users[i]['Attributes'].find((elemento) => elemento.Name === 'custom:rol')['Value'];
                    if (atrPermiso === permiso) {
                        result.push(usuarios.Users[i]);
                    }
                }
            }
        }
        // filtrado por negocio
        if (negocio != null) {
            for (var i = 0; i < usuarios.Users.length; i++) {
                if (usuarios.Users[i]['Attributes'].find((elemento) => elemento.Name === 'custom:negocio')) {
                    var atrNegocio = usuarios.Users[i]['Attributes'].find((elemento) => elemento.Name === 'custom:negocio')['Value'];
                    if (atrNegocio === negocio) {
                        result.push(usuarios.Users[i]);
                    }
                }
            }
        }
        // filtrado por correo
        if (correo != null) {
            for (var i = 0; i < usuarios.Users.length; i++) {
                if (usuarios.Users[i]['Attributes'].find((elemento) => elemento.Name === 'email')) {
                    var atrCorreo = usuarios.Users[i]['Attributes'].find((elemento) => elemento.Name === 'email')['Value'];
                    if (atrCorreo === correo) {
                        result.push(usuarios.Users[i]);
                    }
                }
            }
        }
        // distinct array result
        const map = new Map();
        for (const item of result) {
            if (!map.has(item.Username)) {
                map.set(item.Username, true);
                objFiltrado.push(item);
            }
        }
        console.log(JSON.stringify(objFiltrado));
        return objFiltrado;
    }
}
UsuariosService.ɵfac = function UsuariosService_Factory(t) { return new (t || UsuariosService)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_ngrx_store__WEBPACK_IMPORTED_MODULE_6__["Store"]), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_auth_service__WEBPACK_IMPORTED_MODULE_7__["AuthService"]), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_auditoria_service__WEBPACK_IMPORTED_MODULE_8__["AuditoriaService"])); };
UsuariosService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjectable"]({ token: UsuariosService, factory: UsuariosService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ "F3a3":
/*!***********************************************************************!*\
  !*** ./src/app/validators/opcionesDeFiltroUsuarioAdmininistracion.ts ***!
  \***********************************************************************/
/*! exports provided: ValorFiltrarGrupo */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ValorFiltrarGrupo", function() { return ValorFiltrarGrupo; });
var ValorFiltrarGrupo;
(function (ValorFiltrarGrupo) {
    ValorFiltrarGrupo["Grupo"] = "Grupo";
    ValorFiltrarGrupo["Correo"] = "Correo";
    ValorFiltrarGrupo["Area"] = "Area";
})(ValorFiltrarGrupo || (ValorFiltrarGrupo = {}));


/***/ }),

/***/ "FDLz":
/*!**************************************************************!*\
  !*** ./src/app/ReduxStore/reducers/listaUsuarios.reducer.ts ***!
  \**************************************************************/
/*! exports provided: ListaUsuariosState, ListadoUsuariosReducer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ListaUsuariosState", function() { return ListaUsuariosState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ListadoUsuariosReducer", function() { return ListadoUsuariosReducer; });
/* harmony import */ var _actions_listaUsuarios_actions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../actions/listaUsuarios.actions */ "i2/L");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ngrx/store */ "l7P3");



const ListaUsuariosState = {
    ListaUsuarios: [],
    consulta: null,
    error: null,
    loading: false,
};
const _ListadoUsuariosReducer = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_1__["createReducer"])(ListaUsuariosState, Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_1__["on"])(_actions_listaUsuarios_actions__WEBPACK_IMPORTED_MODULE_0__["LoadListaUsuarios"], (state, { consulta }) => (Object.assign(Object.assign({}, state), { loading: true, consulta: consulta }))), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_1__["on"])(_actions_listaUsuarios_actions__WEBPACK_IMPORTED_MODULE_0__["LoadListaUsuariosSuccess"], (state, { ListaUsuarios }) => (Object.assign(Object.assign({}, state), { ListaUsuarios: [...ListaUsuarios], loading: false, error: null }))), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_1__["on"])(_actions_listaUsuarios_actions__WEBPACK_IMPORTED_MODULE_0__["UnsetListaUsuarios"], (state) => (Object.assign(Object.assign({}, state), { ListaUsuarios: null, loading: false, consulta: null, error: null }))), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_1__["on"])(_actions_listaUsuarios_actions__WEBPACK_IMPORTED_MODULE_0__["LoadListaUsuariosError"], (state, { payload }) => (Object.assign(Object.assign({}, state), { loading: false, error: payload }))));
let ListadoUsuariosReducer = (state, action) => _ListadoUsuariosReducer(state, action);


/***/ }),

/***/ "H+nS":
/*!*************************************************************!*\
  !*** ./src/app/ReduxStore/effects/listaUsuarios.effects.ts ***!
  \*************************************************************/
/*! exports provided: ListadoUsuariosEfffects */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ListadoUsuariosEfffects", function() { return ListadoUsuariosEfffects; });
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/effects */ "9jGm");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/observable/fromPromise */ "3gwn");
/* harmony import */ var rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _actions_listaUsuarios_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../actions/listaUsuarios.actions */ "i2/L");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _services_usuarios_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../services/usuarios.service */ "ESM5");








class ListadoUsuariosEfffects {
    constructor(actions$, UsuariosService) {
        this.actions$ = actions$;
        this.UsuariosService = UsuariosService;
        this.listadoUsuarios$ = Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_0__["createEffect"])(() => this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_0__["ofType"])(_actions_listaUsuarios_actions__WEBPACK_IMPORTED_MODULE_4__["LoadListaUsuarios"]), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["mergeMap"])(({ consulta }) => {
            return Object(rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3__["fromPromise"])(this.UsuariosService.consultaUsuariosMultipleFactor(consulta)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])((data) => _actions_listaUsuarios_actions__WEBPACK_IMPORTED_MODULE_4__["LoadListaUsuariosSuccess"]({
                ListaUsuarios: data
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["catchError"])((error) => Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(_actions_listaUsuarios_actions__WEBPACK_IMPORTED_MODULE_4__["LoadListaUsuariosError"]({
                payload: error,
            })))));
        })));
    }
}
ListadoUsuariosEfffects.ɵfac = function ListadoUsuariosEfffects_Factory(t) { return new (t || ListadoUsuariosEfffects)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_ngrx_effects__WEBPACK_IMPORTED_MODULE_0__["Actions"]), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_services_usuarios_service__WEBPACK_IMPORTED_MODULE_6__["UsuariosService"])); };
ListadoUsuariosEfffects.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjectable"]({ token: ListadoUsuariosEfffects, factory: ListadoUsuariosEfffects.ɵfac });


/***/ }),

/***/ "IvGi":
/*!***********************************************************************!*\
  !*** ./src/app/ReduxStore/effects/usuarios/AUDGENUSUARIOS.effects.ts ***!
  \***********************************************************************/
/*! exports provided: AUDGENUSUARIOSEfffects */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AUDGENUSUARIOSEfffects", function() { return AUDGENUSUARIOSEfffects; });
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/effects */ "9jGm");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/observable/fromPromise */ "3gwn");
/* harmony import */ var rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _actions_usuarios_AUDGENUSUARIOS_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../actions/usuarios/AUDGENUSUARIOS.actions */ "n68H");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _API_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./../../../API.service */ "iO9l");








class AUDGENUSUARIOSEfffects {
    constructor(actions$, api) {
        this.actions$ = actions$;
        this.api = api;
        this.loadAUDGENUSUARIO$ = Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_0__["createEffect"])(() => this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_0__["ofType"])(_actions_usuarios_AUDGENUSUARIOS_actions__WEBPACK_IMPORTED_MODULE_4__["LoadAUDGENUSUARIOS"]), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["mergeMap"])(({ consult }) => {
            //console.log("AudGenUsuarios Effect - Modulo", consult)
            if (consult) {
                return Object(rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3__["fromPromise"])(this.api.ListAUDGENUSUARIOS(consult.MODULO)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])(({ items }) => _actions_usuarios_AUDGENUSUARIOS_actions__WEBPACK_IMPORTED_MODULE_4__["LoadAUDGENUSUARIOSuccess"]({
                    AUDGENUSUARIOS: items,
                })), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["catchError"])((error) => Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(_actions_usuarios_AUDGENUSUARIOS_actions__WEBPACK_IMPORTED_MODULE_4__["LoadAUDGENUSUARIOError"]({ payload: error }))));
            }
            else {
                return Object(rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3__["fromPromise"])(this.api.ListAUDGENUSUARIOS()).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])(({ items }) => _actions_usuarios_AUDGENUSUARIOS_actions__WEBPACK_IMPORTED_MODULE_4__["LoadAUDGENUSUARIOSuccess"]({
                    AUDGENUSUARIOS: items,
                })), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["catchError"])((error) => Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(_actions_usuarios_AUDGENUSUARIOS_actions__WEBPACK_IMPORTED_MODULE_4__["LoadAUDGENUSUARIOError"]({ payload: error }))));
            }
        })));
    }
}
AUDGENUSUARIOSEfffects.ɵfac = function AUDGENUSUARIOSEfffects_Factory(t) { return new (t || AUDGENUSUARIOSEfffects)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_ngrx_effects__WEBPACK_IMPORTED_MODULE_0__["Actions"]), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_API_service__WEBPACK_IMPORTED_MODULE_6__["APIService"])); };
AUDGENUSUARIOSEfffects.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjectable"]({ token: AUDGENUSUARIOSEfffects, factory: AUDGENUSUARIOSEfffects.ɵfac });


/***/ }),

/***/ "LB20":
/*!*************************************************************!*\
  !*** ./src/app/ReduxStore/actions/AUDGENPROCESO.actions.ts ***!
  \*************************************************************/
/*! exports provided: LoadAUDGENPROCESOS, LoadAUDGENPROCESOSuccess, LoadAUDGENPROCESOError, UnsetAUDGENPROCESO */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadAUDGENPROCESOS", function() { return LoadAUDGENPROCESOS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadAUDGENPROCESOSuccess", function() { return LoadAUDGENPROCESOSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadAUDGENPROCESOError", function() { return LoadAUDGENPROCESOError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UnsetAUDGENPROCESO", function() { return UnsetAUDGENPROCESO; });
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/store */ "l7P3");

const LoadAUDGENPROCESOS = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[AUDGENPROCESO] AUDGENPROCESO Load', Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
const LoadAUDGENPROCESOSuccess = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[AUDGENPROCESO Succes] AUDGENPROCESO Success', Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
const LoadAUDGENPROCESOError = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[AUDGENPROCESO Error] AUDGENPROCESO Errors', Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
const UnsetAUDGENPROCESO = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[AUDGENPROCESO Unset] AUDGENPROCESO Unset');


/***/ }),

/***/ "Lrx8":
/*!************************************************************************!*\
  !*** ./src/app/ReduxStore/effects/AUDGENEJECUCIONESPROCESO.effects.ts ***!
  \************************************************************************/
/*! exports provided: AUDGENEJECUCIONESPROCESOEfffects */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AUDGENEJECUCIONESPROCESOEfffects", function() { return AUDGENEJECUCIONESPROCESOEfffects; });
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/effects */ "9jGm");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/observable/fromPromise */ "3gwn");
/* harmony import */ var rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _actions_AUDGENEJECUCIONESPROCESO_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../actions/AUDGENEJECUCIONESPROCESO.actions */ "eWzz");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _API_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./../../API.service */ "iO9l");








class AUDGENEJECUCIONESPROCESOEfffects {
    constructor(actions$, api) {
        this.actions$ = actions$;
        this.api = api;
        this.loadAUDGENEJECUCIONESPROCESO$ = Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_0__["createEffect"])(() => this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_0__["ofType"])(_actions_AUDGENEJECUCIONESPROCESO_actions__WEBPACK_IMPORTED_MODULE_4__["LoadAUDGENEJECUCIONESPROCESO"]), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["mergeMap"])(({ consult }) => {
            if (consult) {
                return Object(rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3__["fromPromise"])(this.api.GetSiaGenAudEstadoProcesosDev(consult.ID_PROCESO)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])((data) => _actions_AUDGENEJECUCIONESPROCESO_actions__WEBPACK_IMPORTED_MODULE_4__["LoadAUDGENEJECUCIONPROCESOSuccess"]({
                    AUDGENEJECUCIONESPROCESO: data,
                })), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["catchError"])((error) => Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(_actions_AUDGENEJECUCIONESPROCESO_actions__WEBPACK_IMPORTED_MODULE_4__["LoadAUDGENEJECUCIONPROCESOError"]({ payload: error }))));
            }
        })));
    }
}
AUDGENEJECUCIONESPROCESOEfffects.ɵfac = function AUDGENEJECUCIONESPROCESOEfffects_Factory(t) { return new (t || AUDGENEJECUCIONESPROCESOEfffects)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_ngrx_effects__WEBPACK_IMPORTED_MODULE_0__["Actions"]), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_API_service__WEBPACK_IMPORTED_MODULE_6__["APIService"])); };
AUDGENEJECUCIONESPROCESOEfffects.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjectable"]({ token: AUDGENEJECUCIONESPROCESOEfffects, factory: AUDGENEJECUCIONESPROCESOEfffects.ɵfac });


/***/ }),

/***/ "MYY7":
/*!********************************************************************!*\
  !*** ./src/app/ReduxStore/reducers/AUDGENESTADOPROCESO.reducer.ts ***!
  \********************************************************************/
/*! exports provided: AUDGENESTADOPROCESOtate, AUDGENESTADOPROCESOReducer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AUDGENESTADOPROCESOtate", function() { return AUDGENESTADOPROCESOtate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AUDGENESTADOPROCESOReducer", function() { return AUDGENESTADOPROCESOReducer; });
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/store */ "l7P3");
/* harmony import */ var _actions_AUDGENESTADOPROCESO_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../actions/AUDGENESTADOPROCESO.actions */ "v+gz");


const AUDGENESTADOPROCESOtate = {
    AUDGENESTADOPROCESO: [],
    consult: null,
    error: null,
};
const _AUDGENESTADOPROCESOReducer = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createReducer"])(AUDGENESTADOPROCESOtate, Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions_AUDGENESTADOPROCESO_actions__WEBPACK_IMPORTED_MODULE_1__["LoadAUDGENESTADOPROCESOS"], (state, { consult }) => (Object.assign({}, state))), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions_AUDGENESTADOPROCESO_actions__WEBPACK_IMPORTED_MODULE_1__["LoadAUDGENESTADOPROCESOSuccess"], (state, { AUDGENESTADOPROCESOS }) => (Object.assign(Object.assign({}, state), { AUDGENESTADOPROCESO: [...AUDGENESTADOPROCESOS], error: null }))), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions_AUDGENESTADOPROCESO_actions__WEBPACK_IMPORTED_MODULE_1__["UnsetAUDGENESTADOPROCESO"], (state) => (Object.assign(Object.assign({}, state), { AUDGENESTADOPROCESO: null, error: null, consult: null }))), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions_AUDGENESTADOPROCESO_actions__WEBPACK_IMPORTED_MODULE_1__["LoadAUDGENESTADOPROCESOError"], (state, { payload }) => (Object.assign(Object.assign({}, state), { error: payload }))));
let AUDGENESTADOPROCESOReducer = (state, action) => _AUDGENESTADOPROCESOReducer(state, action);


/***/ }),

/***/ "Mdjv":
/*!*******************************************************************!*\
  !*** ./src/app/ReduxStore/effects/AUDGENESTADOPROCESO.effects.ts ***!
  \*******************************************************************/
/*! exports provided: AUDGENESTADOPROCESOEfffects */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AUDGENESTADOPROCESOEfffects", function() { return AUDGENESTADOPROCESOEfffects; });
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/effects */ "9jGm");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/observable/fromPromise */ "3gwn");
/* harmony import */ var rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _actions_AUDGENESTADOPROCESO_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../actions/AUDGENESTADOPROCESO.actions */ "v+gz");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _API_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./../../API.service */ "iO9l");








class AUDGENESTADOPROCESOEfffects {
    constructor(actions$, api) {
        this.actions$ = actions$;
        this.api = api;
        this.loadAUDGENPROCESO$ = Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_0__["createEffect"])(() => this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_0__["ofType"])(_actions_AUDGENESTADOPROCESO_actions__WEBPACK_IMPORTED_MODULE_4__["LoadAUDGENESTADOPROCESOS"]), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["mergeMap"])(({ consult }) => {
            if (consult) {
                return Object(rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3__["fromPromise"])(this.api.ListSiaGenAudEstadoProcesosDevs(consult.INTERFAZ, consult.FECHA_INICIO, consult.FECHA_FIN, consult.ID_PROCESO)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])(({ items }) => _actions_AUDGENESTADOPROCESO_actions__WEBPACK_IMPORTED_MODULE_4__["LoadAUDGENESTADOPROCESOSuccess"]({
                    AUDGENESTADOPROCESOS: items,
                })), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["catchError"])((error) => Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(_actions_AUDGENESTADOPROCESO_actions__WEBPACK_IMPORTED_MODULE_4__["LoadAUDGENESTADOPROCESOError"]({ payload: error }))));
            }
            else {
                return Object(rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3__["fromPromise"])(this.api.ListSiaGenAudEstadoProcesosDevs()).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])(({ items }) => _actions_AUDGENESTADOPROCESO_actions__WEBPACK_IMPORTED_MODULE_4__["LoadAUDGENESTADOPROCESOSuccess"]({
                    AUDGENESTADOPROCESOS: items,
                })), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["catchError"])((error) => Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(_actions_AUDGENESTADOPROCESO_actions__WEBPACK_IMPORTED_MODULE_4__["LoadAUDGENESTADOPROCESOError"]({ payload: error }))));
            }
        })));
    }
}
AUDGENESTADOPROCESOEfffects.ɵfac = function AUDGENESTADOPROCESOEfffects_Factory(t) { return new (t || AUDGENESTADOPROCESOEfffects)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_ngrx_effects__WEBPACK_IMPORTED_MODULE_0__["Actions"]), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_API_service__WEBPACK_IMPORTED_MODULE_6__["APIService"])); };
AUDGENESTADOPROCESOEfffects.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjectable"]({ token: AUDGENESTADOPROCESOEfffects, factory: AUDGENESTADOPROCESOEfffects.ɵfac });


/***/ }),

/***/ "NHAl":
/*!***********************************************************!*\
  !*** ./src/app/ReduxStore/actions/CATPERMISOS.actions.ts ***!
  \***********************************************************/
/*! exports provided: LoadCATPERMISOS, LoadCATPERMISOSuccess, LoadCATPERMISOError, UnsetCATPERMISO */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadCATPERMISOS", function() { return LoadCATPERMISOS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadCATPERMISOSuccess", function() { return LoadCATPERMISOSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadCATPERMISOError", function() { return LoadCATPERMISOError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UnsetCATPERMISO", function() { return UnsetCATPERMISO; });
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/store */ "l7P3");

const LoadCATPERMISOS = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[CATPERMISO] CATPERMISO Load', Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
const LoadCATPERMISOSuccess = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[CATPERMISO Succes] CATPERMISO Success', Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
const LoadCATPERMISOError = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[CATPERMISO Error] CATPERMISO Errors', Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
const UnsetCATPERMISO = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[CATPERMISO Unset] CATPERMISO Unset');


/***/ }),

/***/ "PDh6":
/*!**********************************************************!*\
  !*** ./src/app/ReduxStore/actions/CATPROCESO.actions.ts ***!
  \**********************************************************/
/*! exports provided: LoadCATPROCESOS, LoadCATPROCESOSuccess, LoadCATPROCESOError, UnsetCATPROCESO */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadCATPROCESOS", function() { return LoadCATPROCESOS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadCATPROCESOSuccess", function() { return LoadCATPROCESOSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadCATPROCESOError", function() { return LoadCATPROCESOError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UnsetCATPROCESO", function() { return UnsetCATPROCESO; });
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/store */ "l7P3");

const LoadCATPROCESOS = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[CATPROCESO] CATPROCESO Load', Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
const LoadCATPROCESOSuccess = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[CATPROCESO Succes] CATPROCESO Success', Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
const LoadCATPROCESOError = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[CATPROCESO Error] CATPROCESO Errors', Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
const UnsetCATPROCESO = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[CATPROCESO Unset] CATPROCESO Unset');


/***/ }),

/***/ "QAO4":
/*!********************************************************************!*\
  !*** ./src/app/ReduxStore/reducers/catalogos/catalogos.reducer.ts ***!
  \********************************************************************/
/*! exports provided: catalogosState, catalogosReducer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "catalogosState", function() { return catalogosState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "catalogosReducer", function() { return catalogosReducer; });
/* harmony import */ var _actions_catalogos_catalogos_actions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../actions/catalogos/catalogos.actions */ "UKHW");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ngrx/store */ "l7P3");
/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../actions */ "p8Vo");



const catalogosState = {
    catalogos: [],
    loading: false,
    error: null,
};
const _catalogosReducer = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_1__["createReducer"])(catalogosState, Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_1__["on"])(_actions__WEBPACK_IMPORTED_MODULE_2__["cargarCatalogos"], (state) => (Object.assign(Object.assign({}, state), { loading: true }))), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_1__["on"])(_actions_catalogos_catalogos_actions__WEBPACK_IMPORTED_MODULE_0__["caragarCatalogosSucces"], (state, { catalogos }) => (Object.assign(Object.assign({}, state), { loading: false, catalogos: [...catalogos], error: null }))), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_1__["on"])(_actions_catalogos_catalogos_actions__WEBPACK_IMPORTED_MODULE_0__["unSetCatalogos"], (state) => (Object.assign(Object.assign({}, state), { catalogos: null, loading: false, error: null }))), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_1__["on"])(_actions_catalogos_catalogos_actions__WEBPACK_IMPORTED_MODULE_0__["caragarCatalogosError"], (state, { payload }) => (Object.assign(Object.assign({}, state), { loading: false, error: {
        url: payload.url,
        name: payload.name,
        message: payload.message,
    } }))));
let catalogosReducer = (state, action) => _catalogosReducer(state, action);


/***/ }),

/***/ "Sy1n":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./services/auth.service */ "lGQG");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");



class AppComponent {
    constructor(authService) {
        this.authService = authService;
    }
    ngAfterViewInit() {
        this.authService.initAuthData();
    }
}
AppComponent.ɵfac = function AppComponent_Factory(t) { return new (t || AppComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_services_auth_service__WEBPACK_IMPORTED_MODULE_1__["AuthService"])); };
AppComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: AppComponent, selectors: [["app-root"]], decls: 1, vars: 0, template: function AppComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "router-outlet");
    } }, directives: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterOutlet"]], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhcHAuY29tcG9uZW50LmNzcyJ9 */"] });


/***/ }),

/***/ "UKHW":
/*!*******************************************************************!*\
  !*** ./src/app/ReduxStore/actions/catalogos/catalogos.actions.ts ***!
  \*******************************************************************/
/*! exports provided: cargarCatalogos, caragarCatalogosSucces, caragarCatalogosError, unSetCatalogos */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cargarCatalogos", function() { return cargarCatalogos; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "caragarCatalogosSucces", function() { return caragarCatalogosSucces; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "caragarCatalogosError", function() { return caragarCatalogosError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "unSetCatalogos", function() { return unSetCatalogos; });
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/store */ "l7P3");

const cargarCatalogos = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[Catalogos] Cargar Catalogos');
const caragarCatalogosSucces = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[Catalogos] Cargar Catalogos Success', Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
const caragarCatalogosError = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[Catalogos] Cargar Catalogos Error', Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
const unSetCatalogos = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[Catalogos] unSetCatalogos');


/***/ }),

/***/ "Wbeu":
/*!*************************************************************************!*\
  !*** ./src/app/ReduxStore/reducers/AUDGENEJECUCIONESPROCESO.reducer.ts ***!
  \*************************************************************************/
/*! exports provided: AUDGENEJECUCIONESPROCESOState, AUDGENEJECUCIONESPROCESOReducer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AUDGENEJECUCIONESPROCESOState", function() { return AUDGENEJECUCIONESPROCESOState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AUDGENEJECUCIONESPROCESOReducer", function() { return AUDGENEJECUCIONESPROCESOReducer; });
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/store */ "l7P3");
/* harmony import */ var _actions_AUDGENEJECUCIONESPROCESO_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../actions/AUDGENEJECUCIONESPROCESO.actions */ "eWzz");


const AUDGENEJECUCIONESPROCESOState = {
    AUDGENEJECUCIONESPROCESO: null,
    consult: null,
    error: null,
};
const _AUDGENEJECUCIONESPROCESOReducer = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createReducer"])(AUDGENEJECUCIONESPROCESOState, Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions_AUDGENEJECUCIONESPROCESO_actions__WEBPACK_IMPORTED_MODULE_1__["LoadAUDGENEJECUCIONESPROCESO"], (state, { consult }) => (Object.assign({}, state))), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions_AUDGENEJECUCIONESPROCESO_actions__WEBPACK_IMPORTED_MODULE_1__["LoadAUDGENEJECUCIONPROCESOSuccess"], (state, { AUDGENEJECUCIONESPROCESO }) => (Object.assign(Object.assign({}, state), { AUDGENEJECUCIONESPROCESO: Object.assign({}, AUDGENEJECUCIONESPROCESO), error: null }))), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions_AUDGENEJECUCIONESPROCESO_actions__WEBPACK_IMPORTED_MODULE_1__["UnsetAUDGENEJECUCIONPROCESO"], (state) => (Object.assign(Object.assign({}, state), { AUDGENEJECUCIONESPROCESO: null, error: null, consult: null }))), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions_AUDGENEJECUCIONESPROCESO_actions__WEBPACK_IMPORTED_MODULE_1__["LoadAUDGENEJECUCIONPROCESOError"], (state, { payload }) => (Object.assign(Object.assign({}, state), { error: payload }))));
let AUDGENEJECUCIONESPROCESOReducer = (state, action) => _AUDGENEJECUCIONESPROCESOReducer(state, action);


/***/ }),

/***/ "Xdh/":
/*!***********************************************************!*\
  !*** ./src/app/ReduxStore/reducers/CATPROCESO.reducer.ts ***!
  \***********************************************************/
/*! exports provided: CATPROCESOState, CATPROCESOReducer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CATPROCESOState", function() { return CATPROCESOState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CATPROCESOReducer", function() { return CATPROCESOReducer; });
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/store */ "l7P3");
/* harmony import */ var _actions_CATPROCESO_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../actions/CATPROCESO.actions */ "PDh6");


const CATPROCESOState = {
    CATPROCESOS: [],
    consult: null,
    error: null,
};
const _CATPROCESOReducer = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createReducer"])(CATPROCESOState, Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions_CATPROCESO_actions__WEBPACK_IMPORTED_MODULE_1__["LoadCATPROCESOS"], (state, { consult }) => (Object.assign({}, state))), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions_CATPROCESO_actions__WEBPACK_IMPORTED_MODULE_1__["LoadCATPROCESOSuccess"], (state, { CATPROCESOS }) => (Object.assign(Object.assign({}, state), { CATPROCESOS: [...CATPROCESOS], error: null }))), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions_CATPROCESO_actions__WEBPACK_IMPORTED_MODULE_1__["UnsetCATPROCESO"], (state) => (Object.assign(Object.assign({}, state), { CATPROCESOS: null, error: null, consult: null }))), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions_CATPROCESO_actions__WEBPACK_IMPORTED_MODULE_1__["LoadCATPROCESOError"], (state, { payload }) => (Object.assign(Object.assign({}, state), { error: payload }))));
let CATPROCESOReducer = (state, action) => _CATPROCESOReducer(state, action);


/***/ }),

/***/ "ZAI4":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "jhN1");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _aws_amplify_ui_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @aws-amplify/ui-angular */ "Z63c");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngrx/store */ "l7P3");
/* harmony import */ var aws_amplify__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! aws-amplify */ "AL3R");
/* harmony import */ var aws_amplify_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! aws-amplify-angular */ "YD7i");
/* harmony import */ var _aws_exports__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../aws-exports */ "rzrB");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app-routing.module */ "vY5A");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./app.component */ "Sy1n");
/* harmony import */ var _pages_login_login_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./pages/login/login.component */ "D8EZ");
/* harmony import */ var _ReduxStore_app_reducers__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./ReduxStore/app.reducers */ "nueM");
/* harmony import */ var _ngrx_store_devtools__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ngrx/store-devtools */ "agSv");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../environments/environment */ "AytR");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ngrx/effects */ "9jGm");
/* harmony import */ var _ReduxStore_effects__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./ReduxStore/effects */ "AMCz");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "1kSV");
/* harmony import */ var ngx_pagination__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ngx-pagination */ "oOf3");
/* harmony import */ var ng_multiselect_dropdown__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ng-multiselect-dropdown */ "Egam");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/platform-browser/animations */ "R1ws");
/* harmony import */ var _angular_common_locales_es_MX__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! @angular/common/locales/es-MX */ "LMmM");
/* harmony import */ var _angular_common_locales_es_MX__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(_angular_common_locales_es_MX__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var ngx_toastr__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ngx-toastr */ "5eHb");



/* import AmplifyUIAngularModule  */




















// importar locales








/* Configure Amplify resources */
aws_amplify__WEBPACK_IMPORTED_MODULE_5__["default"].configure(_aws_exports__WEBPACK_IMPORTED_MODULE_7__["default"]);
// registrar los locales con el nombre que quieras utilizar a la hora de proveer
Object(_angular_common__WEBPACK_IMPORTED_MODULE_2__["registerLocaleData"])(_angular_common_locales_es_MX__WEBPACK_IMPORTED_MODULE_21___default.a, 'es-MX');
class AppModule {
}
AppModule.ɵfac = function AppModule_Factory(t) { return new (t || AppModule)(); };
AppModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({ type: AppModule, bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_9__["AppComponent"]] });
AppModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({ providers: [
        aws_amplify_angular__WEBPACK_IMPORTED_MODULE_6__["AmplifyService"],
        _angular_common__WEBPACK_IMPORTED_MODULE_2__["DatePipe"],
        { provide: _angular_core__WEBPACK_IMPORTED_MODULE_0__["LOCALE_ID"], useValue: 'es-MX' },
    ], imports: [[
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
            ngx_pagination__WEBPACK_IMPORTED_MODULE_17__["NgxPaginationModule"],
            _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_20__["BrowserAnimationsModule"],
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _app_routing_module__WEBPACK_IMPORTED_MODULE_8__["AppRoutingModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_19__["HttpClientModule"],
            /* configure app with AmplifyUIAngularModule */
            _aws_amplify_ui_angular__WEBPACK_IMPORTED_MODULE_3__["AmplifyUIAngularModule"],
            ngx_toastr__WEBPACK_IMPORTED_MODULE_22__["ToastrModule"].forRoot({
                preventDuplicates: true
            }),
            ng_multiselect_dropdown__WEBPACK_IMPORTED_MODULE_18__["NgMultiSelectDropDownModule"].forRoot(),
            _ngrx_store__WEBPACK_IMPORTED_MODULE_4__["StoreModule"].forRoot(_ReduxStore_app_reducers__WEBPACK_IMPORTED_MODULE_11__["appReducers"]),
            _ngrx_effects__WEBPACK_IMPORTED_MODULE_14__["EffectsModule"].forRoot(_ReduxStore_effects__WEBPACK_IMPORTED_MODULE_15__["EffectsArrays"]),
            _ngrx_store_devtools__WEBPACK_IMPORTED_MODULE_12__["StoreDevtoolsModule"].instrument({
                maxAge: 25,
                logOnly: _environments_environment__WEBPACK_IMPORTED_MODULE_13__["environment"].production,
            }),
            _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_16__["NgbModule"],
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](AppModule, { declarations: [_app_component__WEBPACK_IMPORTED_MODULE_9__["AppComponent"], _pages_login_login_component__WEBPACK_IMPORTED_MODULE_10__["LoginComponent"]], imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
        ngx_pagination__WEBPACK_IMPORTED_MODULE_17__["NgxPaginationModule"],
        _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_20__["BrowserAnimationsModule"],
        _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
        _app_routing_module__WEBPACK_IMPORTED_MODULE_8__["AppRoutingModule"],
        _angular_common_http__WEBPACK_IMPORTED_MODULE_19__["HttpClientModule"],
        /* configure app with AmplifyUIAngularModule */
        _aws_amplify_ui_angular__WEBPACK_IMPORTED_MODULE_3__["AmplifyUIAngularModule"], ngx_toastr__WEBPACK_IMPORTED_MODULE_22__["ToastrModule"], ng_multiselect_dropdown__WEBPACK_IMPORTED_MODULE_18__["NgMultiSelectDropDownModule"], _ngrx_store__WEBPACK_IMPORTED_MODULE_4__["StoreRootModule"], _ngrx_effects__WEBPACK_IMPORTED_MODULE_14__["EffectsRootModule"], _ngrx_store_devtools__WEBPACK_IMPORTED_MODULE_12__["StoreDevtoolsModule"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_16__["NgbModule"]] }); })();


/***/ }),

/***/ "dwxx":
/*!*******************************************************!*\
  !*** ./src/app/ReduxStore/actions/usuario.actions.ts ***!
  \*******************************************************/
/*! exports provided: setUser, setUserRol, setUserArea, unSetUser */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setUser", function() { return setUser; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setUserRol", function() { return setUserRol; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setUserArea", function() { return setUserArea; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "unSetUser", function() { return unSetUser; });
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/store */ "l7P3");

const setUser = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[Auth] setUser', Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
const setUserRol = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[Auth] setUserRol', Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
const setUserArea = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[Auth] setUserArea', Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
const unSetUser = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[Auth] unSetUser');


/***/ }),

/***/ "eHm2":
/*!**********************************************!*\
  !*** ./src/app/ReduxStore/reducers/index.ts ***!
  \**********************************************/
/*! exports provided: initialState, authReducer, AUDGENPROCESOState, AUDGENPROCESOReducer, ListaUsuariosState, ListadoUsuariosReducer, InitialProcesoCambiosState, ProcesoCambiosReducer, AUDGENESTADOPROCESOtate, AUDGENESTADOPROCESOReducer, AUDGENEJECUCIONESPROCESOState, AUDGENEJECUCIONESPROCESOReducer, CATPROCESOState, CATPROCESOReducer, CATPERMISOState, CATPERMISOReducer, estadoInicial, NotificacionesReducer, catalogosState, catalogosReducer, DetailCatalogosState, DetailCatologosReducer, AUDGENUSUARIOSState, AUDGENUSUARIOReducer, notificacionSelectState, notificacionSelectReducer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _usuario_reducer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./usuario.reducer */ "ppOk");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "initialState", function() { return _usuario_reducer__WEBPACK_IMPORTED_MODULE_0__["initialState"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "authReducer", function() { return _usuario_reducer__WEBPACK_IMPORTED_MODULE_0__["authReducer"]; });

/* harmony import */ var _AUDGENPROCESO_reducer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./AUDGENPROCESO.reducer */ "0rus");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "AUDGENPROCESOState", function() { return _AUDGENPROCESO_reducer__WEBPACK_IMPORTED_MODULE_1__["AUDGENPROCESOState"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "AUDGENPROCESOReducer", function() { return _AUDGENPROCESO_reducer__WEBPACK_IMPORTED_MODULE_1__["AUDGENPROCESOReducer"]; });

/* harmony import */ var _listaUsuarios_reducer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./listaUsuarios.reducer */ "FDLz");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ListaUsuariosState", function() { return _listaUsuarios_reducer__WEBPACK_IMPORTED_MODULE_2__["ListaUsuariosState"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ListadoUsuariosReducer", function() { return _listaUsuarios_reducer__WEBPACK_IMPORTED_MODULE_2__["ListadoUsuariosReducer"]; });

/* harmony import */ var _loaderProcesoCambios_reducer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./loaderProcesoCambios.reducer */ "oYdr");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "InitialProcesoCambiosState", function() { return _loaderProcesoCambios_reducer__WEBPACK_IMPORTED_MODULE_3__["InitialProcesoCambiosState"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ProcesoCambiosReducer", function() { return _loaderProcesoCambios_reducer__WEBPACK_IMPORTED_MODULE_3__["ProcesoCambiosReducer"]; });

/* harmony import */ var _AUDGENESTADOPROCESO_reducer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./AUDGENESTADOPROCESO.reducer */ "MYY7");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "AUDGENESTADOPROCESOtate", function() { return _AUDGENESTADOPROCESO_reducer__WEBPACK_IMPORTED_MODULE_4__["AUDGENESTADOPROCESOtate"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "AUDGENESTADOPROCESOReducer", function() { return _AUDGENESTADOPROCESO_reducer__WEBPACK_IMPORTED_MODULE_4__["AUDGENESTADOPROCESOReducer"]; });

/* harmony import */ var _AUDGENEJECUCIONESPROCESO_reducer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./AUDGENEJECUCIONESPROCESO.reducer */ "Wbeu");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "AUDGENEJECUCIONESPROCESOState", function() { return _AUDGENEJECUCIONESPROCESO_reducer__WEBPACK_IMPORTED_MODULE_5__["AUDGENEJECUCIONESPROCESOState"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "AUDGENEJECUCIONESPROCESOReducer", function() { return _AUDGENEJECUCIONESPROCESO_reducer__WEBPACK_IMPORTED_MODULE_5__["AUDGENEJECUCIONESPROCESOReducer"]; });

/* harmony import */ var _CATPROCESO_reducer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./CATPROCESO.reducer */ "Xdh/");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "CATPROCESOState", function() { return _CATPROCESO_reducer__WEBPACK_IMPORTED_MODULE_6__["CATPROCESOState"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "CATPROCESOReducer", function() { return _CATPROCESO_reducer__WEBPACK_IMPORTED_MODULE_6__["CATPROCESOReducer"]; });

/* harmony import */ var _CATPERMISOS_reducer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./CATPERMISOS.reducer */ "sOXL");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "CATPERMISOState", function() { return _CATPERMISOS_reducer__WEBPACK_IMPORTED_MODULE_7__["CATPERMISOState"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "CATPERMISOReducer", function() { return _CATPERMISOS_reducer__WEBPACK_IMPORTED_MODULE_7__["CATPERMISOReducer"]; });

/* harmony import */ var _notificaciones_reducer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./notificaciones.reducer */ "kOpQ");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "estadoInicial", function() { return _notificaciones_reducer__WEBPACK_IMPORTED_MODULE_8__["estadoInicial"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "NotificacionesReducer", function() { return _notificaciones_reducer__WEBPACK_IMPORTED_MODULE_8__["NotificacionesReducer"]; });

/* harmony import */ var _catalogos_catalogos_reducer__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./catalogos/catalogos.reducer */ "QAO4");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "catalogosState", function() { return _catalogos_catalogos_reducer__WEBPACK_IMPORTED_MODULE_9__["catalogosState"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "catalogosReducer", function() { return _catalogos_catalogos_reducer__WEBPACK_IMPORTED_MODULE_9__["catalogosReducer"]; });

/* harmony import */ var _catalogos_catalogoDetail_reducer__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./catalogos/catalogoDetail.reducer */ "/6nF");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "DetailCatalogosState", function() { return _catalogos_catalogoDetail_reducer__WEBPACK_IMPORTED_MODULE_10__["DetailCatalogosState"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "DetailCatologosReducer", function() { return _catalogos_catalogoDetail_reducer__WEBPACK_IMPORTED_MODULE_10__["DetailCatologosReducer"]; });

/* harmony import */ var _usuarios_AUDGENUSUARIOS_reducer__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./usuarios/AUDGENUSUARIOS.reducer */ "qJvj");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "AUDGENUSUARIOSState", function() { return _usuarios_AUDGENUSUARIOS_reducer__WEBPACK_IMPORTED_MODULE_11__["AUDGENUSUARIOSState"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "AUDGENUSUARIOReducer", function() { return _usuarios_AUDGENUSUARIOS_reducer__WEBPACK_IMPORTED_MODULE_11__["AUDGENUSUARIOReducer"]; });

/* harmony import */ var _notificacionSelect_notificacionSelect_reducer__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./notificacionSelect/notificacionSelect.reducer */ "oNqj");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "notificacionSelectState", function() { return _notificacionSelect_notificacionSelect_reducer__WEBPACK_IMPORTED_MODULE_12__["notificacionSelectState"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "notificacionSelectReducer", function() { return _notificacionSelect_notificacionSelect_reducer__WEBPACK_IMPORTED_MODULE_12__["notificacionSelectReducer"]; });
















/***/ }),

/***/ "eWzz":
/*!************************************************************************!*\
  !*** ./src/app/ReduxStore/actions/AUDGENEJECUCIONESPROCESO.actions.ts ***!
  \************************************************************************/
/*! exports provided: LoadAUDGENEJECUCIONESPROCESO, LoadAUDGENEJECUCIONPROCESOSuccess, LoadAUDGENEJECUCIONPROCESOError, UnsetAUDGENEJECUCIONPROCESO */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadAUDGENEJECUCIONESPROCESO", function() { return LoadAUDGENEJECUCIONESPROCESO; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadAUDGENEJECUCIONPROCESOSuccess", function() { return LoadAUDGENEJECUCIONPROCESOSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadAUDGENEJECUCIONPROCESOError", function() { return LoadAUDGENEJECUCIONPROCESOError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UnsetAUDGENEJECUCIONPROCESO", function() { return UnsetAUDGENEJECUCIONPROCESO; });
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/store */ "l7P3");

const LoadAUDGENEJECUCIONESPROCESO = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[AUDGENEJECUCIONPROCESO] AUDGENEJECUCIONPROCESO Load', Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
const LoadAUDGENEJECUCIONPROCESOSuccess = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[AUDGENEJECUCIONPROCESO Succes] AUDGENEJECUCIONPROCESO Success', Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
const LoadAUDGENEJECUCIONPROCESOError = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[AUDGENEJECUCIONPROCESO Error] AUDGENEJECUCIONPROCESO Errors', Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
const UnsetAUDGENEJECUCIONPROCESO = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[AUDGENEJECUCIONPROCESO Unset] AUDGENEJECUCIONPROCESO Unset');


/***/ }),

/***/ "eaYr":
/*!**************************************************************!*\
  !*** ./src/app/ReduxStore/actions/notificaciones.actions.ts ***!
  \**************************************************************/
/*! exports provided: setnotificaciones, crearnotificacione, unSetnotificaciones */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setnotificaciones", function() { return setnotificaciones; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "crearnotificacione", function() { return crearnotificacione; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "unSetnotificaciones", function() { return unSetnotificaciones; });
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/store */ "l7P3");

const setnotificaciones = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[notificaciones] Setnotificaciones', Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
const crearnotificacione = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[notificaciones] Crearnotificaciones', Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
const unSetnotificaciones = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[notificaciones] unSetnotificaciones');


/***/ }),

/***/ "i2/L":
/*!*************************************************************!*\
  !*** ./src/app/ReduxStore/actions/listaUsuarios.actions.ts ***!
  \*************************************************************/
/*! exports provided: LoadListaUsuarios, LoadListaUsuariosSuccess, LoadListaUsuariosError, UnsetListaUsuarios */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadListaUsuarios", function() { return LoadListaUsuarios; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadListaUsuariosSuccess", function() { return LoadListaUsuariosSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadListaUsuariosError", function() { return LoadListaUsuariosError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UnsetListaUsuarios", function() { return UnsetListaUsuarios; });
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/store */ "l7P3");

const LoadListaUsuarios = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[ListaUsuarios] ListaUsuarios Load', Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
const LoadListaUsuariosSuccess = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[ListaUsuarios Succes] ListaUsuarios Success', Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
const LoadListaUsuariosError = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[ListaUsuarios Error] ListaUsuarios Errors', Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
const UnsetListaUsuarios = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[ListaUsuarios Unset] ListaUsuarios Unset');


/***/ }),

/***/ "iO9l":
/*!********************************!*\
  !*** ./src/app/API.service.ts ***!
  \********************************/
/*! exports provided: APIService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "APIService", function() { return APIService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @aws-amplify/api-graphql */ "Vh5H");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");



class APIService {
    constructor() {
        this.OnCreateSiaGenAudEstadoProcesosDevListener = _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(`subscription OnCreateSiaGenAudEstadoProcesosDev {
        onCreateSiaGenAudEstadoProcesosDev {
          __typename
          ESTADO_EJECUCION
          ETAPA_INICIAL_ESTADO_INICIAL
          ETAPA_INICIAL_ESTADO_FINAL
          ETAPA_INICIAL_FECHA_INICIAL
          ETAPA_INICIAL_FECHA_FINAL
          ETAPA_FINAL_ESTADO_INICIAL
          ETAPA_FINAL_ESTADO_FINAL
          ETAPA_FINAL_FECHA_INICIAL
          ETAPA_FINAL_FECHA_FINAL
          ETAPA_PROCESAMIENTO_ESTADO_INICIAL
          ETAPA_PROCESAMIENTO_ESTADO_FINAL
          ETAPA_PROCESAMIENTO_FECHA_INICIAL
          ETAPA_PROCESAMIENTO_FECHA_FINAL
          FECHA_ACTUALIZACION
          FECHA_CREADO
          FECHA_FINALIZADO
          ID_PROCESO
          INSUMO
          INTERFAZ
          TIPO_PROCESO
          RESPONSABLE_ERROR
          ORIGEN_ERROR
        }
      }`));
        this.OnUpdateSiaGenAudEstadoProcesosDevListener = _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(`subscription OnUpdateSiaGenAudEstadoProcesosDev {
        onUpdateSiaGenAudEstadoProcesosDev {
          __typename
          ESTADO_EJECUCION
          ETAPA_INICIAL_ESTADO_INICIAL
          ETAPA_INICIAL_ESTADO_FINAL
          ETAPA_INICIAL_FECHA_INICIAL
          ETAPA_INICIAL_FECHA_FINAL
          ETAPA_FINAL_ESTADO_INICIAL
          ETAPA_FINAL_ESTADO_FINAL
          ETAPA_FINAL_FECHA_INICIAL
          ETAPA_FINAL_FECHA_FINAL
          ETAPA_PROCESAMIENTO_ESTADO_INICIAL
          ETAPA_PROCESAMIENTO_ESTADO_FINAL
          ETAPA_PROCESAMIENTO_FECHA_INICIAL
          ETAPA_PROCESAMIENTO_FECHA_FINAL
          FECHA_ACTUALIZACION
          FECHA_CREADO
          FECHA_FINALIZADO
          ID_PROCESO
          INSUMO
          INTERFAZ
          TIPO_PROCESO
          RESPONSABLE_ERROR
          ORIGEN_ERROR
        }
      }`));
        this.OnDeleteSiaGenAudEstadoProcesosDevListener = _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(`subscription OnDeleteSiaGenAudEstadoProcesosDev {
        onDeleteSiaGenAudEstadoProcesosDev {
          __typename
          ESTADO_EJECUCION
          ETAPA_INICIAL_ESTADO_INICIAL
          ETAPA_INICIAL_ESTADO_FINAL
          ETAPA_INICIAL_FECHA_INICIAL
          ETAPA_INICIAL_FECHA_FINAL
          ETAPA_FINAL_ESTADO_INICIAL
          ETAPA_FINAL_ESTADO_FINAL
          ETAPA_FINAL_FECHA_INICIAL
          ETAPA_FINAL_FECHA_FINAL
          ETAPA_PROCESAMIENTO_ESTADO_INICIAL
          ETAPA_PROCESAMIENTO_ESTADO_FINAL
          ETAPA_PROCESAMIENTO_FECHA_INICIAL
          ETAPA_PROCESAMIENTO_FECHA_FINAL
          FECHA_ACTUALIZACION
          FECHA_CREADO
          FECHA_FINALIZADO
          ID_PROCESO
          INSUMO
          INTERFAZ
          TIPO_PROCESO
          RESPONSABLE_ERROR
          ORIGEN_ERROR
        }
      }`));
    }
    CreateAUDGENPROCESOS(input) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const statement = `mutation CreateAUDGENPROCESOS($input: CreateAUDGENPROCESOSInput!) {
        createAUDGENPROCESOS(input: $input) {
          __typename
          DESTINO
          ETAPA
          FECHA
          ID_PROCESO
          ID_REGISTRO
          INSUMO
          INTERFAZ
          MENSAJE_NEGOCIO
          MENSAJE_SOPORTE
          NEGOCIO
          PROCESO {
            __typename
            EJECUCION
            TIPO
          }
          SERVICIOAWS
          USUARIO {
            __typename
            CORREO
            ROL
          }
          TIPO
          NIVEL
          STEP
          ACTIVIDAD
        }
      }`;
            const gqlAPIServiceArguments = {
                input
            };
            const response = (yield _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments)));
            return response.data.createAUDGENPROCESOS;
        });
    }
    UpdateAUDGENPROCESOS(input) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const statement = `mutation UpdateAUDGENPROCESOS($input: UpdateAUDGENPROCESOSInput!) {
        updateAUDGENPROCESOS(input: $input) {
          __typename
          DESTINO
          ETAPA
          FECHA
          ID_PROCESO
          ID_REGISTRO
          INSUMO
          INTERFAZ
          MENSAJE_NEGOCIO
          MENSAJE_SOPORTE
          NEGOCIO
          PROCESO {
            __typename
            EJECUCION
            TIPO
          }
          SERVICIOAWS
          USUARIO {
            __typename
            CORREO
            ROL
          }
          TIPO
          NIVEL
          STEP
          ACTIVIDAD
        }
      }`;
            const gqlAPIServiceArguments = {
                input
            };
            const response = (yield _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments)));
            return response.data.updateAUDGENPROCESOS;
        });
    }
    DeleteAUDGENPROCESOS(input) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const statement = `mutation DeleteAUDGENPROCESOS($input: DeleteAUDGENPROCESOSInput!) {
        deleteAUDGENPROCESOS(input: $input) {
          __typename
          DESTINO
          ETAPA
          FECHA
          ID_PROCESO
          ID_REGISTRO
          INSUMO
          INTERFAZ
          MENSAJE_NEGOCIO
          MENSAJE_SOPORTE
          NEGOCIO
          PROCESO {
            __typename
            EJECUCION
            TIPO
          }
          SERVICIOAWS
          USUARIO {
            __typename
            CORREO
            ROL
          }
          TIPO
          NIVEL
          STEP
          ACTIVIDAD
        }
      }`;
            const gqlAPIServiceArguments = {
                input
            };
            const response = (yield _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments)));
            return response.data.deleteAUDGENPROCESOS;
        });
    }
    CreateCATPROCESOS(input) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const statement = `mutation CreateCATPROCESOS($input: CreateCATPROCESOSInput!) {
        createCATPROCESOS(input: $input) {
          __typename
          PROCESO
          ARRANQUE
          DESCRIPCION
          NEGOCIO
          TIPO
        }
      }`;
            const gqlAPIServiceArguments = {
                input
            };
            const response = (yield _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments)));
            return response.data.createCATPROCESOS;
        });
    }
    UpdateCATPROCESOS(input) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const statement = `mutation UpdateCATPROCESOS($input: UpdateCATPROCESOSInput!) {
        updateCATPROCESOS(input: $input) {
          __typename
          PROCESO
          ARRANQUE
          DESCRIPCION
          NEGOCIO
          TIPO
        }
      }`;
            const gqlAPIServiceArguments = {
                input
            };
            const response = (yield _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments)));
            return response.data.updateCATPROCESOS;
        });
    }
    DeleteCATPROCESOS(input) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const statement = `mutation DeleteCATPROCESOS($input: DeleteCATPROCESOSInput!) {
        deleteCATPROCESOS(input: $input) {
          __typename
          PROCESO
          ARRANQUE
          DESCRIPCION
          NEGOCIO
          TIPO
        }
      }`;
            const gqlAPIServiceArguments = {
                input
            };
            const response = (yield _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments)));
            return response.data.deleteCATPROCESOS;
        });
    }
    CreateCATPERMISOS(input) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const statement = `mutation CreateCATPERMISOS($input: CreateCATPERMISOSInput!) {
        createCATPERMISOS(input: $input) {
          __typename
          ID
          AREA
          AUDITORIA {
            __typename
            ARCHIVOS
            CATALOGOS
            PROCESOS
          }
          CATALOGOS {
            __typename
            ACTUALIZAR
            BORRAR
            CONSULTAR
            CREAR
          }
          FLUJO
          PROCESOS {
            __typename
            DETENER
            INICIAR
            MONITOREAR
          }
          ROL
          USUARIOS {
            __typename
            ACTUALIZAR
            BORRAR
            CONSULTAR
          }
          NEGOCIO
        }
      }`;
            const gqlAPIServiceArguments = {
                input
            };
            const response = (yield _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments)));
            return response.data.createCATPERMISOS;
        });
    }
    UpdateCATPERMISOS(input) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const statement = `mutation UpdateCATPERMISOS($input: UpdateCATPERMISOSInput!) {
        updateCATPERMISOS(input: $input) {
          __typename
          ID
          AREA
          AUDITORIA {
            __typename
            ARCHIVOS
            CATALOGOS
            PROCESOS
          }
          CATALOGOS {
            __typename
            ACTUALIZAR
            BORRAR
            CONSULTAR
            CREAR
          }
          FLUJO
          PROCESOS {
            __typename
            DETENER
            INICIAR
            MONITOREAR
          }
          ROL
          USUARIOS {
            __typename
            ACTUALIZAR
            BORRAR
            CONSULTAR
          }
          NEGOCIO
        }
      }`;
            const gqlAPIServiceArguments = {
                input
            };
            const response = (yield _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments)));
            return response.data.updateCATPERMISOS;
        });
    }
    DeleteCATPERMISOS(input) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const statement = `mutation DeleteCATPERMISOS($input: DeleteCATPERMISOSInput!) {
        deleteCATPERMISOS(input: $input) {
          __typename
          ID
          AREA
          AUDITORIA {
            __typename
            ARCHIVOS
            CATALOGOS
            PROCESOS
          }
          CATALOGOS {
            __typename
            ACTUALIZAR
            BORRAR
            CONSULTAR
            CREAR
          }
          FLUJO
          PROCESOS {
            __typename
            DETENER
            INICIAR
            MONITOREAR
          }
          ROL
          USUARIOS {
            __typename
            ACTUALIZAR
            BORRAR
            CONSULTAR
          }
          NEGOCIO
        }
      }`;
            const gqlAPIServiceArguments = {
                input
            };
            const response = (yield _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments)));
            return response.data.deleteCATPERMISOS;
        });
    }
    CreateSiaGenAudEstadoProcesosDev(input) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const statement = `mutation CreateSiaGenAudEstadoProcesosDev($input: CreateSiaGenAudEstadoProcesosDevInput!) {
        createSiaGenAudEstadoProcesosDev(input: $input) {
          __typename
          ESTADO_EJECUCION
          ETAPA_INICIAL_ESTADO_INICIAL
          ETAPA_INICIAL_ESTADO_FINAL
          ETAPA_INICIAL_FECHA_INICIAL
          ETAPA_INICIAL_FECHA_FINAL
          ETAPA_FINAL_ESTADO_INICIAL
          ETAPA_FINAL_ESTADO_FINAL
          ETAPA_FINAL_FECHA_INICIAL
          ETAPA_FINAL_FECHA_FINAL
          ETAPA_PROCESAMIENTO_ESTADO_INICIAL
          ETAPA_PROCESAMIENTO_ESTADO_FINAL
          ETAPA_PROCESAMIENTO_FECHA_INICIAL
          ETAPA_PROCESAMIENTO_FECHA_FINAL
          FECHA_ACTUALIZACION
          FECHA_CREADO
          FECHA_FINALIZADO
          ID_PROCESO
          INSUMO
          INTERFAZ
          TIPO_PROCESO
          RESPONSABLE_ERROR
          ORIGEN_ERROR
        }
      }`;
            const gqlAPIServiceArguments = {
                input
            };
            const response = (yield _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments)));
            return (response.data.createSiaGenAudEstadoProcesosDev);
        });
    }
    UpdateSiaGenAudEstadoProcesosDev(input) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const statement = `mutation UpdateSiaGenAudEstadoProcesosDev($input: UpdateSiaGenAudEstadoProcesosDevInput!) {
        updateSiaGenAudEstadoProcesosDev(input: $input) {
          __typename
          ESTADO_EJECUCION
          ETAPA_INICIAL_ESTADO_INICIAL
          ETAPA_INICIAL_ESTADO_FINAL
          ETAPA_INICIAL_FECHA_INICIAL
          ETAPA_INICIAL_FECHA_FINAL
          ETAPA_FINAL_ESTADO_INICIAL
          ETAPA_FINAL_ESTADO_FINAL
          ETAPA_FINAL_FECHA_INICIAL
          ETAPA_FINAL_FECHA_FINAL
          ETAPA_PROCESAMIENTO_ESTADO_INICIAL
          ETAPA_PROCESAMIENTO_ESTADO_FINAL
          ETAPA_PROCESAMIENTO_FECHA_INICIAL
          ETAPA_PROCESAMIENTO_FECHA_FINAL
          FECHA_ACTUALIZACION
          FECHA_CREADO
          FECHA_FINALIZADO
          ID_PROCESO
          INSUMO
          INTERFAZ
          TIPO_PROCESO
          RESPONSABLE_ERROR
          ORIGEN_ERROR
        }
      }`;
            const gqlAPIServiceArguments = {
                input
            };
            const response = (yield _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments)));
            return (response.data.updateSiaGenAudEstadoProcesosDev);
        });
    }
    DeleteSiaGenAudEstadoProcesosDev(input) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const statement = `mutation DeleteSiaGenAudEstadoProcesosDev($input: DeleteSiaGenAudEstadoProcesosDevInput!) {
        deleteSiaGenAudEstadoProcesosDev(input: $input) {
          __typename
          ESTADO_EJECUCION
          ETAPA_INICIAL_ESTADO_INICIAL
          ETAPA_INICIAL_ESTADO_FINAL
          ETAPA_INICIAL_FECHA_INICIAL
          ETAPA_INICIAL_FECHA_FINAL
          ETAPA_FINAL_ESTADO_INICIAL
          ETAPA_FINAL_ESTADO_FINAL
          ETAPA_FINAL_FECHA_INICIAL
          ETAPA_FINAL_FECHA_FINAL
          ETAPA_PROCESAMIENTO_ESTADO_INICIAL
          ETAPA_PROCESAMIENTO_ESTADO_FINAL
          ETAPA_PROCESAMIENTO_FECHA_INICIAL
          ETAPA_PROCESAMIENTO_FECHA_FINAL
          FECHA_ACTUALIZACION
          FECHA_CREADO
          FECHA_FINALIZADO
          ID_PROCESO
          INSUMO
          INTERFAZ
          TIPO_PROCESO
          RESPONSABLE_ERROR
          ORIGEN_ERROR
        }
      }`;
            const gqlAPIServiceArguments = {
                input
            };
            const response = (yield _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments)));
            return (response.data.deleteSiaGenAudEstadoProcesosDev);
        });
    }
    CreateSiaGenAdmDiccionarioCatalogosDev(input) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const statement = `mutation CreateSiaGenAdmDiccionarioCatalogosDev($input: CreateSiaGenAdmDiccionarioCatalogosDevInput!) {
        createSiaGenAdmDiccionarioCatalogosDev(input: $input) {
          __typename
          AREA
          ARN
          DESCRIPCION
          INTERFAZ
          NEGOCIO
          NOMBRE
          NOMBRE_NEGOCIO
          PRIV_CONTABILIDAD
          PRIV_CUSTODIA
          PRIV_RIESGOS
          PRIV_SOPORTE
          PRIV_TESORERIA
          STATUS
        }
      }`;
            const gqlAPIServiceArguments = {
                input
            };
            const response = (yield _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments)));
            return (response.data.createSiaGenAdmDiccionarioCatalogosDev);
        });
    }
    UpdateSiaGenAdmDiccionarioCatalogosDev(input) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const statement = `mutation UpdateSiaGenAdmDiccionarioCatalogosDev($input: UpdateSiaGenAdmDiccionarioCatalogosDevInput!) {
        updateSiaGenAdmDiccionarioCatalogosDev(input: $input) {
          __typename
          AREA
          ARN
          DESCRIPCION
          INTERFAZ
          NEGOCIO
          NOMBRE
          NOMBRE_NEGOCIO
          PRIV_CONTABILIDAD
          PRIV_CUSTODIA
          PRIV_RIESGOS
          PRIV_SOPORTE
          PRIV_TESORERIA
          STATUS
        }
      }`;
            const gqlAPIServiceArguments = {
                input
            };
            const response = (yield _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments)));
            return (response.data.updateSiaGenAdmDiccionarioCatalogosDev);
        });
    }
    DeleteSiaGenAdmDiccionarioCatalogosDev(input) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const statement = `mutation DeleteSiaGenAdmDiccionarioCatalogosDev($input: DeleteSiaGenAdmDiccionarioCatalogosDevInput!) {
        deleteSiaGenAdmDiccionarioCatalogosDev(input: $input) {
          __typename
          AREA
          ARN
          DESCRIPCION
          INTERFAZ
          NEGOCIO
          NOMBRE
          NOMBRE_NEGOCIO
          PRIV_CONTABILIDAD
          PRIV_CUSTODIA
          PRIV_RIESGOS
          PRIV_SOPORTE
          PRIV_TESORERIA
          STATUS
        }
      }`;
            const gqlAPIServiceArguments = {
                input
            };
            const response = (yield _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments)));
            return (response.data.deleteSiaGenAdmDiccionarioCatalogosDev);
        });
    }
    GetAUDGENUSUARIOS(ID) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const statement = `query GetAUDGENUSUARIOS($ID: String!) {
        getAUDGENUSUARIOS(ID: $ID) {
          __typename
          ID
          FECHA
          CORREO
          AREA_NEGOCIO
          MODULO
          ROL
          USUARIO {
            __typename
            NOMBRE
            INICIO_SESION
            FIN_SESION
            APELLIDO_PATERNO
          }
          SECCION {
            __typename
            NOMBRE
            ACCION
            SUBSECCION
          }
          PROCESOS {
            __typename
            ID_PROCESO
            SIGLA
            NOMBRE
            ACCION
            DESCRIPCION
            ESTADO
            TIPO
          }
          CATALOGOS {
            __typename
            ACCION
            DESCRIPCION
            DETALLE_MODIFICACIONES {
              __typename
              valorAnterior
              valorNuevo
            }
            ESTADO
            NOMBRE
          }
          PERMISOS_USUARIOS {
            __typename
            ACCION
            APELLIDO_MATERNO
            APELLIDO_PATERNO
            CORREO
            DETALLE_MODIFICACIONES {
              __typename
              valorAnterior
              valorNuevo
            }
            ESTADO
            NOMBRE
            ROL
          }
        }
      }`;
            const gqlAPIServiceArguments = {
                ID
            };
            const response = (yield _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments)));
            return response.data.getAUDGENUSUARIOS;
        });
    }
    ListAUDGENUSUARIOS(MODULO) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const statement = `query ListAUDGENUSUARIOS($MODULO: String) {
        listAUDGENUSUARIOS(MODULO: $MODULO) {
          __typename
          items {
            __typename
            ID
            FECHA
            CORREO
            AREA_NEGOCIO
            MODULO
            ROL
            USUARIO {
              __typename
              NOMBRE
              INICIO_SESION
              FIN_SESION
              APELLIDO_PATERNO
            }
            SECCION {
              __typename
              NOMBRE
              ACCION
              SUBSECCION
            }
            PROCESOS {
              __typename
              ID_PROCESO
              SIGLA
              NOMBRE
              ACCION
              DESCRIPCION
              ESTADO
              TIPO
            }
            CATALOGOS {
              __typename
              ACCION
              DESCRIPCION
              DETALLE_MODIFICACIONES {
                __typename
                valorAnterior
                valorNuevo
              }
              ESTADO
              NOMBRE
            }
            PERMISOS_USUARIOS {
              __typename
              ACCION
              APELLIDO_MATERNO
              APELLIDO_PATERNO
              CORREO
              DETALLE_MODIFICACIONES {
                __typename
                valorAnterior
                valorNuevo
              }
              ESTADO
              NOMBRE
              ROL
            }
          }
          nextToken
        }
      }`;
            const gqlAPIServiceArguments = {};
            if (MODULO) {
                gqlAPIServiceArguments.MODULO = MODULO;
            }
            const response = (yield _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments)));
            return response.data.listAUDGENUSUARIOS;
        });
    }
    GetAUDGENPROCESOS(ID_PROCESO) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const statement = `query GetAUDGENPROCESOS($ID_PROCESO: String!) {
        getAUDGENPROCESOS(ID_PROCESO: $ID_PROCESO) {
          __typename
          DESTINO
          ETAPA
          FECHA
          ID_PROCESO
          ID_REGISTRO
          INSUMO
          INTERFAZ
          MENSAJE_NEGOCIO
          MENSAJE_SOPORTE
          NEGOCIO
          PROCESO {
            __typename
            EJECUCION
            TIPO
          }
          SERVICIOAWS
          USUARIO {
            __typename
            CORREO
            ROL
          }
          TIPO
          NIVEL
          STEP
          ACTIVIDAD
        }
      }`;
            const gqlAPIServiceArguments = {
                ID_PROCESO
            };
            const response = (yield _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments)));
            return response.data.getAUDGENPROCESOS;
        });
    }
    ListAUDGENPROCESOS(ID_PROCESO, FECHA) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const statement = `query ListAUDGENPROCESOS($ID_PROCESO: String, $FECHA: String) {
        listAUDGENPROCESOS(ID_PROCESO: $ID_PROCESO, FECHA: $FECHA) {
          __typename
          items {
            __typename
            DESTINO
            ETAPA
            FECHA
            ID_PROCESO
            ID_REGISTRO
            INSUMO
            INTERFAZ
            MENSAJE_NEGOCIO
            MENSAJE_SOPORTE
            NEGOCIO
            PROCESO {
              __typename
              EJECUCION
              TIPO
            }
            SERVICIOAWS
            USUARIO {
              __typename
              CORREO
              ROL
            }
            TIPO
            NIVEL
            STEP
            ACTIVIDAD
          }
          nextToken
        }
      }`;
            const gqlAPIServiceArguments = {};
            if (ID_PROCESO) {
                gqlAPIServiceArguments.ID_PROCESO = ID_PROCESO;
            }
            if (FECHA) {
                gqlAPIServiceArguments.FECHA = FECHA;
            }
            const response = (yield _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments)));
            return response.data.listAUDGENPROCESOS;
        });
    }
    GetCATPROCESOS(PROCESO) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const statement = `query GetCATPROCESOS($PROCESO: String!) {
        getCATPROCESOS(PROCESO: $PROCESO) {
          __typename
          PROCESO
          ARRANQUE
          DESCRIPCION
          NEGOCIO
          TIPO
        }
      }`;
            const gqlAPIServiceArguments = {
                PROCESO
            };
            const response = (yield _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments)));
            return response.data.getCATPROCESOS;
        });
    }
    ListCATPROCESOS(filter, limit, nextToken) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const statement = `query ListCATPROCESOS($filter: TableCATPROCESOSFilterInput, $limit: Int, $nextToken: String) {
        listCATPROCESOS(filter: $filter, limit: $limit, nextToken: $nextToken) {
          __typename
          items {
            __typename
            PROCESO
            ARRANQUE
            DESCRIPCION
            NEGOCIO
            TIPO
          }
          nextToken
        }
      }`;
            const gqlAPIServiceArguments = {};
            if (filter) {
                gqlAPIServiceArguments.filter = filter;
            }
            if (limit) {
                gqlAPIServiceArguments.limit = limit;
            }
            if (nextToken) {
                gqlAPIServiceArguments.nextToken = nextToken;
            }
            const response = (yield _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments)));
            return response.data.listCATPROCESOS;
        });
    }
    GetCATPERMISOS(ID) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const statement = `query GetCATPERMISOS($ID: String!) {
        getCATPERMISOS(ID: $ID) {
          __typename
          ID
          AREA
          AUDITORIA {
            __typename
            ARCHIVOS
            CATALOGOS
            PROCESOS
          }
          CATALOGOS {
            __typename
            ACTUALIZAR
            BORRAR
            CONSULTAR
            CREAR
          }
          FLUJO
          PROCESOS {
            __typename
            DETENER
            INICIAR
            MONITOREAR
          }
          ROL
          USUARIOS {
            __typename
            ACTUALIZAR
            BORRAR
            CONSULTAR
          }
          NEGOCIO
        }
      }`;
            const gqlAPIServiceArguments = {
                ID
            };
            const response = (yield _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments)));
            return response.data.getCATPERMISOS;
        });
    }
    ListCATPERMISOS(NEGOCIOS, AREA, ROL) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const statement = `query ListCATPERMISOS($NEGOCIOS: [String], $AREA: String, $ROL: String) {
        listCATPERMISOS(NEGOCIOS: $NEGOCIOS, AREA: $AREA, ROL: $ROL) {
          __typename
          items {
            __typename
            ID
            AREA
            AUDITORIA {
              __typename
              ARCHIVOS
              CATALOGOS
              PROCESOS
            }
            CATALOGOS {
              __typename
              ACTUALIZAR
              BORRAR
              CONSULTAR
              CREAR
            }
            FLUJO
            PROCESOS {
              __typename
              DETENER
              INICIAR
              MONITOREAR
            }
            ROL
            USUARIOS {
              __typename
              ACTUALIZAR
              BORRAR
              CONSULTAR
            }
            NEGOCIO
          }
          nextToken
        }
      }`;
            const gqlAPIServiceArguments = {};
            if (NEGOCIOS) {
                gqlAPIServiceArguments.NEGOCIOS = NEGOCIOS;
            }
            if (AREA) {
                gqlAPIServiceArguments.AREA = AREA;
            }
            if (ROL) {
                gqlAPIServiceArguments.ROL = ROL;
            }
            const response = (yield _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments)));
            return response.data.listCATPERMISOS;
        });
    }
    GetSiaGenAudEstadoProcesosDev(ID_PROCESO) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const statement = `query GetSiaGenAudEstadoProcesosDev($ID_PROCESO: String!) {
        getSiaGenAudEstadoProcesosDev(ID_PROCESO: $ID_PROCESO) {
          __typename
          ESTADO_EJECUCION
          ETAPA_INICIAL_ESTADO_INICIAL
          ETAPA_INICIAL_ESTADO_FINAL
          ETAPA_INICIAL_FECHA_INICIAL
          ETAPA_INICIAL_FECHA_FINAL
          ETAPA_FINAL_ESTADO_INICIAL
          ETAPA_FINAL_ESTADO_FINAL
          ETAPA_FINAL_FECHA_INICIAL
          ETAPA_FINAL_FECHA_FINAL
          ETAPA_PROCESAMIENTO_ESTADO_INICIAL
          ETAPA_PROCESAMIENTO_ESTADO_FINAL
          ETAPA_PROCESAMIENTO_FECHA_INICIAL
          ETAPA_PROCESAMIENTO_FECHA_FINAL
          FECHA_ACTUALIZACION
          FECHA_CREADO
          FECHA_FINALIZADO
          ID_PROCESO
          INSUMO
          INTERFAZ
          TIPO_PROCESO
          RESPONSABLE_ERROR
          ORIGEN_ERROR
        }
      }`;
            const gqlAPIServiceArguments = {
                ID_PROCESO
            };
            const response = (yield _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments)));
            return (response.data.getSiaGenAudEstadoProcesosDev);
        });
    }
    ListSiaGenAudEstadoProcesosDevs(INTERFAZ, FECHA_INICIO, FECHA_FIN, ID_PROCESO) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const statement = `query ListSiaGenAudEstadoProcesosDevs($INTERFAZ: String, $FECHA_INICIO: String, $FECHA_FIN: String, $ID_PROCESO: String) {
        listSiaGenAudEstadoProcesosDevs(INTERFAZ: $INTERFAZ, FECHA_INICIO: $FECHA_INICIO, FECHA_FIN: $FECHA_FIN, ID_PROCESO: $ID_PROCESO) {
          __typename
          items {
            __typename
            ESTADO_EJECUCION
            ETAPA_INICIAL_ESTADO_INICIAL
            ETAPA_INICIAL_ESTADO_FINAL
            ETAPA_INICIAL_FECHA_INICIAL
            ETAPA_INICIAL_FECHA_FINAL
            ETAPA_FINAL_ESTADO_INICIAL
            ETAPA_FINAL_ESTADO_FINAL
            ETAPA_FINAL_FECHA_INICIAL
            ETAPA_FINAL_FECHA_FINAL
            ETAPA_PROCESAMIENTO_ESTADO_INICIAL
            ETAPA_PROCESAMIENTO_ESTADO_FINAL
            ETAPA_PROCESAMIENTO_FECHA_INICIAL
            ETAPA_PROCESAMIENTO_FECHA_FINAL
            FECHA_ACTUALIZACION
            FECHA_CREADO
            FECHA_FINALIZADO
            ID_PROCESO
            INSUMO
            INTERFAZ
            TIPO_PROCESO
            RESPONSABLE_ERROR
            ORIGEN_ERROR
          }
          nextToken
        }
      }`;
            const gqlAPIServiceArguments = {};
            if (INTERFAZ) {
                gqlAPIServiceArguments.INTERFAZ = INTERFAZ;
            }
            if (FECHA_INICIO) {
                gqlAPIServiceArguments.FECHA_INICIO = FECHA_INICIO;
            }
            if (FECHA_FIN) {
                gqlAPIServiceArguments.FECHA_FIN = FECHA_FIN;
            }
            if (ID_PROCESO) {
                gqlAPIServiceArguments.ID_PROCESO = ID_PROCESO;
            }
            const response = (yield _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments)));
            return (response.data.listSiaGenAudEstadoProcesosDevs);
        });
    }
    QuerySiaGenAudEstadoProcesosDevsByINTERFAZIndex(INTERFAZ, first, after) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const statement = `query QuerySiaGenAudEstadoProcesosDevsByINTERFAZIndex($INTERFAZ: String!, $first: Int, $after: String) {
        querySiaGenAudEstadoProcesosDevsByINTERFAZIndex(INTERFAZ: $INTERFAZ, first: $first, after: $after) {
          __typename
          items {
            __typename
            ESTADO_EJECUCION
            ETAPA_INICIAL_ESTADO_INICIAL
            ETAPA_INICIAL_ESTADO_FINAL
            ETAPA_INICIAL_FECHA_INICIAL
            ETAPA_INICIAL_FECHA_FINAL
            ETAPA_FINAL_ESTADO_INICIAL
            ETAPA_FINAL_ESTADO_FINAL
            ETAPA_FINAL_FECHA_INICIAL
            ETAPA_FINAL_FECHA_FINAL
            ETAPA_PROCESAMIENTO_ESTADO_INICIAL
            ETAPA_PROCESAMIENTO_ESTADO_FINAL
            ETAPA_PROCESAMIENTO_FECHA_INICIAL
            ETAPA_PROCESAMIENTO_FECHA_FINAL
            FECHA_ACTUALIZACION
            FECHA_CREADO
            FECHA_FINALIZADO
            ID_PROCESO
            INSUMO
            INTERFAZ
            TIPO_PROCESO
            RESPONSABLE_ERROR
            ORIGEN_ERROR
          }
          nextToken
        }
      }`;
            const gqlAPIServiceArguments = {
                INTERFAZ
            };
            if (first) {
                gqlAPIServiceArguments.first = first;
            }
            if (after) {
                gqlAPIServiceArguments.after = after;
            }
            const response = (yield _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments)));
            return (response.data.querySiaGenAudEstadoProcesosDevsByINTERFAZIndex);
        });
    }
    ListSiaGenAudEstadoProcesosDevsPorFecha(FECHA) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const statement = `query ListSiaGenAudEstadoProcesosDevsPorFecha($FECHA: String) {
        listSiaGenAudEstadoProcesosDevsPorFecha(FECHA: $FECHA) {
          __typename
          items {
            __typename
            ESTADO_EJECUCION
            ETAPA_INICIAL_ESTADO_INICIAL
            ETAPA_INICIAL_ESTADO_FINAL
            ETAPA_INICIAL_FECHA_INICIAL
            ETAPA_INICIAL_FECHA_FINAL
            ETAPA_FINAL_ESTADO_INICIAL
            ETAPA_FINAL_ESTADO_FINAL
            ETAPA_FINAL_FECHA_INICIAL
            ETAPA_FINAL_FECHA_FINAL
            ETAPA_PROCESAMIENTO_ESTADO_INICIAL
            ETAPA_PROCESAMIENTO_ESTADO_FINAL
            ETAPA_PROCESAMIENTO_FECHA_INICIAL
            ETAPA_PROCESAMIENTO_FECHA_FINAL
            FECHA_ACTUALIZACION
            FECHA_CREADO
            FECHA_FINALIZADO
            ID_PROCESO
            INSUMO
            INTERFAZ
            TIPO_PROCESO
            RESPONSABLE_ERROR
            ORIGEN_ERROR
          }
          nextToken
        }
      }`;
            const gqlAPIServiceArguments = {};
            if (FECHA) {
                gqlAPIServiceArguments.FECHA = FECHA;
            }
            const response = (yield _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments)));
            return (response.data.listSiaGenAudEstadoProcesosDevsPorFecha);
        });
    }
    GetSiaGenAdmDiccionarioCatalogosDev(NOMBRE, NOMBRE_NEGOCIO) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const statement = `query GetSiaGenAdmDiccionarioCatalogosDev($NOMBRE: String!, $NOMBRE_NEGOCIO: String!) {
        getSiaGenAdmDiccionarioCatalogosDev(NOMBRE: $NOMBRE, NOMBRE_NEGOCIO: $NOMBRE_NEGOCIO) {
          __typename
          AREA
          ARN
          DESCRIPCION
          INTERFAZ
          NEGOCIO
          NOMBRE
          NOMBRE_NEGOCIO
          PRIV_CONTABILIDAD
          PRIV_CUSTODIA
          PRIV_RIESGOS
          PRIV_SOPORTE
          PRIV_TESORERIA
          STATUS
        }
      }`;
            const gqlAPIServiceArguments = {
                NOMBRE,
                NOMBRE_NEGOCIO
            };
            const response = (yield _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments)));
            return (response.data.getSiaGenAdmDiccionarioCatalogosDev);
        });
    }
    ListSiaGenAdmDiccionarioCatalogosDevs(filter, limit, nextToken) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const statement = `query ListSiaGenAdmDiccionarioCatalogosDevs($filter: TableSiaGenAdmDiccionarioCatalogosDevFilterInput, $limit: Int, $nextToken: String) {
        listSiaGenAdmDiccionarioCatalogosDevs(filter: $filter, limit: $limit, nextToken: $nextToken) {
          __typename
          items {
            __typename
            AREA
            ARN
            DESCRIPCION
            INTERFAZ
            NEGOCIO
            NOMBRE
            NOMBRE_NEGOCIO
            PRIV_CONTABILIDAD
            PRIV_CUSTODIA
            PRIV_RIESGOS
            PRIV_SOPORTE
            PRIV_TESORERIA
            STATUS
          }
          nextToken
        }
      }`;
            const gqlAPIServiceArguments = {};
            if (filter) {
                gqlAPIServiceArguments.filter = filter;
            }
            if (limit) {
                gqlAPIServiceArguments.limit = limit;
            }
            if (nextToken) {
                gqlAPIServiceArguments.nextToken = nextToken;
            }
            const response = (yield _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments)));
            return (response.data.listSiaGenAdmDiccionarioCatalogosDevs);
        });
    }
    QuerySiaGenAdmDiccionarioCatalogosDevsByNOMBREAREAIndex(NOMBRE, first, after) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const statement = `query QuerySiaGenAdmDiccionarioCatalogosDevsByNOMBREAREAIndex($NOMBRE: String!, $first: Int, $after: String) {
        querySiaGenAdmDiccionarioCatalogosDevsByNOMBREAREAIndex(NOMBRE: $NOMBRE, first: $first, after: $after) {
          __typename
          items {
            __typename
            AREA
            ARN
            DESCRIPCION
            INTERFAZ
            NEGOCIO
            NOMBRE
            NOMBRE_NEGOCIO
            PRIV_CONTABILIDAD
            PRIV_CUSTODIA
            PRIV_RIESGOS
            PRIV_SOPORTE
            PRIV_TESORERIA
            STATUS
          }
          nextToken
        }
      }`;
            const gqlAPIServiceArguments = {
                NOMBRE
            };
            if (first) {
                gqlAPIServiceArguments.first = first;
            }
            if (after) {
                gqlAPIServiceArguments.after = after;
            }
            const response = (yield _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments)));
            return (response.data.querySiaGenAdmDiccionarioCatalogosDevsByNOMBREAREAIndex);
        });
    }
    OnCreateAUDGENPROCESOSListener(ID_REGISTRO) {
        const statement = `subscription OnCreateAUDGENPROCESOS($ID_REGISTRO: String) {
        onCreateAUDGENPROCESOS(ID_REGISTRO: $ID_REGISTRO) {
          __typename
          DESTINO
          ETAPA
          FECHA
          ID_PROCESO
          ID_REGISTRO
          INSUMO
          INTERFAZ
          MENSAJE_NEGOCIO
          MENSAJE_SOPORTE
          NEGOCIO
          PROCESO {
            __typename
            EJECUCION
            TIPO
          }
          SERVICIOAWS
          USUARIO {
            __typename
            CORREO
            ROL
          }
          TIPO
          NIVEL
          STEP
          ACTIVIDAD
        }
      }`;
        const gqlAPIServiceArguments = {};
        if (ID_REGISTRO) {
            gqlAPIServiceArguments.ID_REGISTRO = ID_REGISTRO;
        }
        return _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments));
    }
    OnUpdateAUDGENPROCESOSListener(ID_REGISTRO) {
        const statement = `subscription OnUpdateAUDGENPROCESOS($ID_REGISTRO: String) {
        onUpdateAUDGENPROCESOS(ID_REGISTRO: $ID_REGISTRO) {
          __typename
          DESTINO
          ETAPA
          FECHA
          ID_PROCESO
          ID_REGISTRO
          INSUMO
          INTERFAZ
          MENSAJE_NEGOCIO
          MENSAJE_SOPORTE
          NEGOCIO
          PROCESO {
            __typename
            EJECUCION
            TIPO
          }
          SERVICIOAWS
          USUARIO {
            __typename
            CORREO
            ROL
          }
          TIPO
          NIVEL
          STEP
          ACTIVIDAD
        }
      }`;
        const gqlAPIServiceArguments = {};
        if (ID_REGISTRO) {
            gqlAPIServiceArguments.ID_REGISTRO = ID_REGISTRO;
        }
        return _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments));
    }
    OnDeleteAUDGENPROCESOSListener(ID_REGISTRO) {
        const statement = `subscription OnDeleteAUDGENPROCESOS($ID_REGISTRO: String) {
        onDeleteAUDGENPROCESOS(ID_REGISTRO: $ID_REGISTRO) {
          __typename
          DESTINO
          ETAPA
          FECHA
          ID_PROCESO
          ID_REGISTRO
          INSUMO
          INTERFAZ
          MENSAJE_NEGOCIO
          MENSAJE_SOPORTE
          NEGOCIO
          PROCESO {
            __typename
            EJECUCION
            TIPO
          }
          SERVICIOAWS
          USUARIO {
            __typename
            CORREO
            ROL
          }
          TIPO
          NIVEL
          STEP
          ACTIVIDAD
        }
      }`;
        const gqlAPIServiceArguments = {};
        if (ID_REGISTRO) {
            gqlAPIServiceArguments.ID_REGISTRO = ID_REGISTRO;
        }
        return _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments));
    }
    OnCreateCATPROCESOSListener(PROCESO) {
        const statement = `subscription OnCreateCATPROCESOS($PROCESO: String) {
        onCreateCATPROCESOS(PROCESO: $PROCESO) {
          __typename
          PROCESO
          ARRANQUE
          DESCRIPCION
          NEGOCIO
          TIPO
        }
      }`;
        const gqlAPIServiceArguments = {};
        if (PROCESO) {
            gqlAPIServiceArguments.PROCESO = PROCESO;
        }
        return _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments));
    }
    OnUpdateCATPROCESOSListener(PROCESO) {
        const statement = `subscription OnUpdateCATPROCESOS($PROCESO: String) {
        onUpdateCATPROCESOS(PROCESO: $PROCESO) {
          __typename
          PROCESO
          ARRANQUE
          DESCRIPCION
          NEGOCIO
          TIPO
        }
      }`;
        const gqlAPIServiceArguments = {};
        if (PROCESO) {
            gqlAPIServiceArguments.PROCESO = PROCESO;
        }
        return _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments));
    }
    OnDeleteCATPROCESOSListener(PROCESO) {
        const statement = `subscription OnDeleteCATPROCESOS($PROCESO: String) {
        onDeleteCATPROCESOS(PROCESO: $PROCESO) {
          __typename
          PROCESO
          ARRANQUE
          DESCRIPCION
          NEGOCIO
          TIPO
        }
      }`;
        const gqlAPIServiceArguments = {};
        if (PROCESO) {
            gqlAPIServiceArguments.PROCESO = PROCESO;
        }
        return _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments));
    }
    OnCreateCATPERMISOSListener(ID) {
        const statement = `subscription OnCreateCATPERMISOS($ID: String) {
        onCreateCATPERMISOS(ID: $ID) {
          __typename
          ID
          AREA
          AUDITORIA {
            __typename
            ARCHIVOS
            CATALOGOS
            PROCESOS
          }
          CATALOGOS {
            __typename
            ACTUALIZAR
            BORRAR
            CONSULTAR
            CREAR
          }
          FLUJO
          PROCESOS {
            __typename
            DETENER
            INICIAR
            MONITOREAR
          }
          ROL
          USUARIOS {
            __typename
            ACTUALIZAR
            BORRAR
            CONSULTAR
          }
          NEGOCIO
        }
      }`;
        const gqlAPIServiceArguments = {};
        if (ID) {
            gqlAPIServiceArguments.ID = ID;
        }
        return _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments));
    }
    OnUpdateCATPERMISOSListener(ID) {
        const statement = `subscription OnUpdateCATPERMISOS($ID: String) {
        onUpdateCATPERMISOS(ID: $ID) {
          __typename
          ID
          AREA
          AUDITORIA {
            __typename
            ARCHIVOS
            CATALOGOS
            PROCESOS
          }
          CATALOGOS {
            __typename
            ACTUALIZAR
            BORRAR
            CONSULTAR
            CREAR
          }
          FLUJO
          PROCESOS {
            __typename
            DETENER
            INICIAR
            MONITOREAR
          }
          ROL
          USUARIOS {
            __typename
            ACTUALIZAR
            BORRAR
            CONSULTAR
          }
          NEGOCIO
        }
      }`;
        const gqlAPIServiceArguments = {};
        if (ID) {
            gqlAPIServiceArguments.ID = ID;
        }
        return _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments));
    }
    OnDeleteCATPERMISOSListener(ID) {
        const statement = `subscription OnDeleteCATPERMISOS($ID: String) {
        onDeleteCATPERMISOS(ID: $ID) {
          __typename
          ID
          AREA
          AUDITORIA {
            __typename
            ARCHIVOS
            CATALOGOS
            PROCESOS
          }
          CATALOGOS {
            __typename
            ACTUALIZAR
            BORRAR
            CONSULTAR
            CREAR
          }
          FLUJO
          PROCESOS {
            __typename
            DETENER
            INICIAR
            MONITOREAR
          }
          ROL
          USUARIOS {
            __typename
            ACTUALIZAR
            BORRAR
            CONSULTAR
          }
          NEGOCIO
        }
      }`;
        const gqlAPIServiceArguments = {};
        if (ID) {
            gqlAPIServiceArguments.ID = ID;
        }
        return _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments));
    }
    OnCreateSiaGenAdmDiccionarioCatalogosDevListener(AREA, ARN, DESCRIPCION, INTERFAZ, NEGOCIO) {
        const statement = `subscription OnCreateSiaGenAdmDiccionarioCatalogosDev($AREA: String, $ARN: String, $DESCRIPCION: String, $INTERFAZ: String, $NEGOCIO: String) {
        onCreateSiaGenAdmDiccionarioCatalogosDev(AREA: $AREA, ARN: $ARN, DESCRIPCION: $DESCRIPCION, INTERFAZ: $INTERFAZ, NEGOCIO: $NEGOCIO) {
          __typename
          AREA
          ARN
          DESCRIPCION
          INTERFAZ
          NEGOCIO
          NOMBRE
          NOMBRE_NEGOCIO
          PRIV_CONTABILIDAD
          PRIV_CUSTODIA
          PRIV_RIESGOS
          PRIV_SOPORTE
          PRIV_TESORERIA
          STATUS
        }
      }`;
        const gqlAPIServiceArguments = {};
        if (AREA) {
            gqlAPIServiceArguments.AREA = AREA;
        }
        if (ARN) {
            gqlAPIServiceArguments.ARN = ARN;
        }
        if (DESCRIPCION) {
            gqlAPIServiceArguments.DESCRIPCION = DESCRIPCION;
        }
        if (INTERFAZ) {
            gqlAPIServiceArguments.INTERFAZ = INTERFAZ;
        }
        if (NEGOCIO) {
            gqlAPIServiceArguments.NEGOCIO = NEGOCIO;
        }
        return _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments));
    }
    OnUpdateSiaGenAdmDiccionarioCatalogosDevListener(AREA, ARN, DESCRIPCION, INTERFAZ, NEGOCIO) {
        const statement = `subscription OnUpdateSiaGenAdmDiccionarioCatalogosDev($AREA: String, $ARN: String, $DESCRIPCION: String, $INTERFAZ: String, $NEGOCIO: String) {
        onUpdateSiaGenAdmDiccionarioCatalogosDev(AREA: $AREA, ARN: $ARN, DESCRIPCION: $DESCRIPCION, INTERFAZ: $INTERFAZ, NEGOCIO: $NEGOCIO) {
          __typename
          AREA
          ARN
          DESCRIPCION
          INTERFAZ
          NEGOCIO
          NOMBRE
          NOMBRE_NEGOCIO
          PRIV_CONTABILIDAD
          PRIV_CUSTODIA
          PRIV_RIESGOS
          PRIV_SOPORTE
          PRIV_TESORERIA
          STATUS
        }
      }`;
        const gqlAPIServiceArguments = {};
        if (AREA) {
            gqlAPIServiceArguments.AREA = AREA;
        }
        if (ARN) {
            gqlAPIServiceArguments.ARN = ARN;
        }
        if (DESCRIPCION) {
            gqlAPIServiceArguments.DESCRIPCION = DESCRIPCION;
        }
        if (INTERFAZ) {
            gqlAPIServiceArguments.INTERFAZ = INTERFAZ;
        }
        if (NEGOCIO) {
            gqlAPIServiceArguments.NEGOCIO = NEGOCIO;
        }
        return _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments));
    }
    OnDeleteSiaGenAdmDiccionarioCatalogosDevListener(AREA, ARN, DESCRIPCION, INTERFAZ, NEGOCIO) {
        const statement = `subscription OnDeleteSiaGenAdmDiccionarioCatalogosDev($AREA: String, $ARN: String, $DESCRIPCION: String, $INTERFAZ: String, $NEGOCIO: String) {
        onDeleteSiaGenAdmDiccionarioCatalogosDev(AREA: $AREA, ARN: $ARN, DESCRIPCION: $DESCRIPCION, INTERFAZ: $INTERFAZ, NEGOCIO: $NEGOCIO) {
          __typename
          AREA
          ARN
          DESCRIPCION
          INTERFAZ
          NEGOCIO
          NOMBRE
          NOMBRE_NEGOCIO
          PRIV_CONTABILIDAD
          PRIV_CUSTODIA
          PRIV_RIESGOS
          PRIV_SOPORTE
          PRIV_TESORERIA
          STATUS
        }
      }`;
        const gqlAPIServiceArguments = {};
        if (AREA) {
            gqlAPIServiceArguments.AREA = AREA;
        }
        if (ARN) {
            gqlAPIServiceArguments.ARN = ARN;
        }
        if (DESCRIPCION) {
            gqlAPIServiceArguments.DESCRIPCION = DESCRIPCION;
        }
        if (INTERFAZ) {
            gqlAPIServiceArguments.INTERFAZ = INTERFAZ;
        }
        if (NEGOCIO) {
            gqlAPIServiceArguments.NEGOCIO = NEGOCIO;
        }
        return _aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["default"].graphql(Object(_aws_amplify_api_graphql__WEBPACK_IMPORTED_MODULE_1__["graphqlOperation"])(statement, gqlAPIServiceArguments));
    }
}
APIService.ɵfac = function APIService_Factory(t) { return new (t || APIService)(); };
APIService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({ token: APIService, factory: APIService.ɵfac, providedIn: "root" });


/***/ }),

/***/ "kOpQ":
/*!***************************************************************!*\
  !*** ./src/app/ReduxStore/reducers/notificaciones.reducer.ts ***!
  \***************************************************************/
/*! exports provided: estadoInicial, NotificacionesReducer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "estadoInicial", function() { return estadoInicial; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotificacionesReducer", function() { return NotificacionesReducer; });
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/store */ "l7P3");
/* harmony import */ var _actions_notificaciones_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../actions/notificaciones.actions */ "eaYr");


const estadoInicial = {
    notificaciones: [],
};
const _NotificacionesReducer = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createReducer"])(estadoInicial, Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions_notificaciones_actions__WEBPACK_IMPORTED_MODULE_1__["crearnotificacione"], (state, { notificacion }) => (Object.assign(Object.assign({}, state), { notificaciones: [...state.notificaciones, notificacion] }))), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions_notificaciones_actions__WEBPACK_IMPORTED_MODULE_1__["setnotificaciones"], (state, { notificaciones }) => (Object.assign(Object.assign({}, state), { notificaciones: notificaciones }))), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions_notificaciones_actions__WEBPACK_IMPORTED_MODULE_1__["unSetnotificaciones"], (state) => (Object.assign(Object.assign({}, state), { notificaciones: null }))));
let NotificacionesReducer = (state, action) => {
    return _NotificacionesReducer(state, action);
};


/***/ }),

/***/ "kl1M":
/*!*******************************!*\
  !*** ./src/app/model/user.ts ***!
  \*******************************/
/*! exports provided: User */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "User", function() { return User; });
class User {
    constructor(cognitoUser) {
        this.cognitoUser = cognitoUser;
        // get user claims from the id token
        this._attributes = this.cognitoUser && this.cognitoUser.getSignInUserSession()
            && this.cognitoUser.getSignInUserSession().isValid()
            && this.cognitoUser.getSignInUserSession().getIdToken().decodePayload();
    }
    get groups() {
        return this.attributes["cognito:groups"] || [];
    }
    get attributes() {
        return this._attributes || {};
    }
    get name() {
        return this.attributes["name"];
    }
    get email() {
        return this.attributes["email"];
    }
}


/***/ }),

/***/ "lGQG":
/*!******************************************!*\
  !*** ./src/app/services/auth.service.ts ***!
  \******************************************/
/*! exports provided: AuthService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthService", function() { return AuthService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../environments/environment */ "AytR");
/* harmony import */ var aws_amplify__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! aws-amplify */ "AL3R");
/* harmony import */ var rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/observable/fromPromise */ "3gwn");
/* harmony import */ var rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var _ReduxStore_actions_usuario_actions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../ReduxStore/actions/usuario.actions */ "dwxx");
/* harmony import */ var _model_user__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../model/user */ "kl1M");
/* harmony import */ var _model_usuario_model__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../model/usuario.model */ "4rUU");
/* harmony import */ var _validators_roles__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../validators/roles */ "r6zK");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ngrx/store */ "l7P3");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/router */ "tyNb");














try {
    aws_amplify__WEBPACK_IMPORTED_MODULE_3__["default"].configure(_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].amplifyConfig);
}
catch (e) {
    console.log('Error Amplify Configuration: ', e);
}
class AuthService {
    constructor(store, router) {
        this.store = store;
        this.router = router;
        this.initAuthData = () => {
            aws_amplify__WEBPACK_IMPORTED_MODULE_3__["Auth"].currentAuthenticatedUser()
                .then((result) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                //console.log("AUTH SERVICE");
                //console.log('Usser result: ',JSON.stringify(result));
                if (result.getSignInUserSession().isValid()) {
                    const user = _model_usuario_model__WEBPACK_IMPORTED_MODULE_8__["Usuario"].fromAmplify(new _model_user__WEBPACK_IMPORTED_MODULE_7__["User"](result));
                    localStorage.setItem('access', (yield aws_amplify__WEBPACK_IMPORTED_MODULE_3__["Auth"].currentSession())
                        .getAccessToken()
                        .getJwtToken()
                        .toString());
                    const areas = [
                        _validators_roles__WEBPACK_IMPORTED_MODULE_9__["EArea"].Tesoreria,
                        _validators_roles__WEBPACK_IMPORTED_MODULE_9__["EArea"].Inversiones_Riesgos,
                        _validators_roles__WEBPACK_IMPORTED_MODULE_9__["EArea"].Contabilidad,
                        _validators_roles__WEBPACK_IMPORTED_MODULE_9__["EArea"].Custodia,
                        _validators_roles__WEBPACK_IMPORTED_MODULE_9__["EArea"].Soporte,
                    ];
                    let areasStore = [];
                    user.attributes['cognito:groups'].forEach((e) => {
                        if (areas.includes(e)) {
                            areasStore.push(e);
                        }
                    });
                    //console.log("user", user);
                    if (areasStore.includes(_validators_roles__WEBPACK_IMPORTED_MODULE_9__["EArea"].Soporte)) {
                        user.attributes['custom:rol'] = _validators_roles__WEBPACK_IMPORTED_MODULE_9__["ERole"].Administrador;
                    }
                    if (!user.attributes.given_name) {
                        user.attributes.given_name = user.name + ' - Guest';
                    }
                    localStorage.setItem('area', areasStore.toString());
                    // console.log('negocio', user.attributes['custom:negocio']);
                    localStorage.setItem('negocio', user.attributes['custom:negocio']);
                    this.store.dispatch(_ReduxStore_actions_usuario_actions__WEBPACK_IMPORTED_MODULE_6__["setUser"]({ user }));
                    let area = this.obtenerArea();
                    //console.log(area)
                    this.store.dispatch(Object(_ReduxStore_actions_usuario_actions__WEBPACK_IMPORTED_MODULE_6__["setUserArea"])({
                        area: area,
                    }));
                }
                else {
                    this.store.dispatch(_ReduxStore_actions_usuario_actions__WEBPACK_IMPORTED_MODULE_6__["unSetUser"]());
                }
            }))
                .catch(() => this.store.dispatch(_ReduxStore_actions_usuario_actions__WEBPACK_IMPORTED_MODULE_6__["unSetUser"]()));
        };
        this.signIn = () => {
            window.location.assign(_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].urlExternalLogin);
        };
        this.refreshToken = () => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.initAuthData();
            // try {
            //   const cognitoUser = await Auth.currentAuthenticatedUser({bypassCache: true});
            //   console.log(cognitoUser)
            //   const currentSession = await Auth.currentSession();
            //   console.log(currentSession)
            //   cognitoUser.refreshSession(currentSession.getRefreshToken(), (err, session) => {
            //     console.log('session', err, session);
            //     const { idToken, refreshToken, accessToken } = session;
            //     // do whatever you want to do now :)
            //   });
            // } catch (e) {
            //   console.log('Unable to refresh Token', e);
            // }
            // console.log((await Auth.currentSession()).getRefreshToken())
        });
        this.isAuth = () => {
            return Object(rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_4__["fromPromise"])(this.userPromise()).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["map"])((user) => user != null));
        };
        this.userPromise = () => {
            return new Promise((resolve) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                return yield aws_amplify__WEBPACK_IMPORTED_MODULE_3__["Auth"].currentAuthenticatedUser()
                    .then((result) => {
                    if (result.getSignInUserSession().isValid()) {
                        resolve(result);
                    }
                    else {
                        resolve(null);
                    }
                })
                    .catch(() => resolve(null));
            }));
        };
        this.signOut = () => {
            localStorage.clear();
            this.cleanStates();
            this.router.navigate(['/login']);
        };
        this.cleanStates = () => {
            this.store.dispatch(_ReduxStore_actions_usuario_actions__WEBPACK_IMPORTED_MODULE_6__["unSetUser"]());
        };
        this.getToken = () => {
            return localStorage.getItem('access');
        };
        this.login = () => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield aws_amplify__WEBPACK_IMPORTED_MODULE_3__["Auth"].federatedSignIn({ customProvider: 'SAML' });
        });
        this.rolesValids = (User, roles, Area) => {
            let flagValidate = false;
            if (!User.attributes.hasOwnProperty('custom:rol')) {
                return flagValidate;
            }
            else {
                if (Area) {
                    if (roles.includes(User.attributes['custom:rol']) && Area == 'SOPORTE')
                        console.log('entre al area');
                    flagValidate = true;
                }
                else if (roles.includes(User.attributes['custom:rol'])) {
                    flagValidate = true;
                }
            }
            return flagValidate;
        };
        this.perfilValido = (User, roles) => {
            //console.log("perfilValido");
            let flagValidate = false;
            let arrayTempArea = [];
            let Areas = [
                _validators_roles__WEBPACK_IMPORTED_MODULE_9__["EArea"].Contabilidad,
                _validators_roles__WEBPACK_IMPORTED_MODULE_9__["EArea"].Custodia,
                _validators_roles__WEBPACK_IMPORTED_MODULE_9__["EArea"].Inversiones_Riesgos,
                _validators_roles__WEBPACK_IMPORTED_MODULE_9__["EArea"].Tesoreria,
                _validators_roles__WEBPACK_IMPORTED_MODULE_9__["EArea"].Soporte,
            ];
            User.groups.forEach((area) => {
                Areas.forEach((areaDef) => {
                    if (area === areaDef) {
                        arrayTempArea.push(area);
                    }
                });
            });
            if (arrayTempArea.length > 0) {
                //console.log(arrayTempArea[0]);
                if (arrayTempArea[0] === 'Soporte') {
                    flagValidate = true;
                }
                else {
                    if (!User.attributes.hasOwnProperty('custom:rol')) {
                        flagValidate = false;
                    }
                    else {
                        if (roles.includes(User.attributes['custom:rol'])) {
                            flagValidate = true;
                        }
                    }
                }
            }
            else {
                flagValidate = false;
            }
            return flagValidate;
        };
    }
    userHeaders() {
        return new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpHeaders"]({
            authorization: 'Bearer ' + this.getToken(),
            'content-type': 'application/json',
        });
    }
    obtenerArea() {
        let area = '';
        let arrayTempArea = [];
        let areas = [
            _validators_roles__WEBPACK_IMPORTED_MODULE_9__["EArea"].Contabilidad,
            _validators_roles__WEBPACK_IMPORTED_MODULE_9__["EArea"].Custodia,
            _validators_roles__WEBPACK_IMPORTED_MODULE_9__["EArea"].Inversiones_Riesgos,
            _validators_roles__WEBPACK_IMPORTED_MODULE_9__["EArea"].Tesoreria,
            _validators_roles__WEBPACK_IMPORTED_MODULE_9__["EArea"].Soporte,
        ];
        this.store
            .select(({ usuario }) => usuario.user)
            .subscribe((res) => {
            if (res) {
                res.groups.forEach((item) => {
                    if (areas.includes(item)) {
                        arrayTempArea.push(item);
                    }
                });
            }
        });
        area = arrayTempArea.join(', ');
        return area;
    }
}
AuthService.ɵfac = function AuthService_Factory(t) { return new (t || AuthService)(_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵinject"](_ngrx_store__WEBPACK_IMPORTED_MODULE_11__["Store"]), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_12__["Router"])); };
AuthService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineInjectable"]({ token: AuthService, factory: AuthService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ "mwaT":
/*!**************************************!*\
  !*** ./src/app/Guards/auth.guard.ts ***!
  \**************************************/
/*! exports provided: AuthGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthGuard", function() { return AuthGuard; });
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/auth.service */ "lGQG");




class AuthGuard {
    constructor(_router, authService) {
        this._router = _router;
        this.authService = authService;
    }
    canLoad() {
        return this.authService.isAuth().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_0__["tap"])((user) => {
            if (!user) {
                this._router.navigate(['/login']);
            }
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_0__["take"])(1));
    }
}
AuthGuard.ɵfac = function AuthGuard_Factory(t) { return new (t || AuthGuard)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_services_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"])); };
AuthGuard.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: AuthGuard, factory: AuthGuard.ɵfac, providedIn: 'root' });


/***/ }),

/***/ "n68H":
/*!***********************************************************************!*\
  !*** ./src/app/ReduxStore/actions/usuarios/AUDGENUSUARIOS.actions.ts ***!
  \***********************************************************************/
/*! exports provided: LoadAUDGENUSUARIOS, LoadAUDGENUSUARIOSuccess, LoadAUDGENUSUARIOError, UnsetAUDGENUSUARIO */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadAUDGENUSUARIOS", function() { return LoadAUDGENUSUARIOS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadAUDGENUSUARIOSuccess", function() { return LoadAUDGENUSUARIOSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadAUDGENUSUARIOError", function() { return LoadAUDGENUSUARIOError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UnsetAUDGENUSUARIO", function() { return UnsetAUDGENUSUARIO; });
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/store */ "l7P3");

const LoadAUDGENUSUARIOS = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[AUDGENUSUARIO] AUDGENUSUARIO Load', Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
const LoadAUDGENUSUARIOSuccess = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[AUDGENUSUARIO Succes] AUDGENUSUARIO Success', Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
const LoadAUDGENUSUARIOError = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[AUDGENUSUARIO Error] AUDGENUSUARIO Errors', Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
const UnsetAUDGENUSUARIO = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[AUDGENUSUARIO Unset] AUDGENUSUARIO Unset');


/***/ }),

/***/ "nPwh":
/*!***************************************!*\
  !*** ./src/app/Guards/guest.guard.ts ***!
  \***************************************/
/*! exports provided: GuestGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GuestGuard", function() { return GuestGuard; });
/* harmony import */ var _aws_amplify_auth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @aws-amplify/auth */ "AO/9");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");



class GuestGuard {
    constructor(_router) {
        this._router = _router;
    }
    canActivate() {
        return _aws_amplify_auth__WEBPACK_IMPORTED_MODULE_0__["Auth"].currentAuthenticatedUser()
            .then((result) => {
            if (result.getSignInUserSession().isValid()) {
                this._router.navigate(['/']);
                return false;
            }
            else {
                return true;
            }
        })
            .catch(() => {
            return true;
        });
    }
}
GuestGuard.ɵfac = function GuestGuard_Factory(t) { return new (t || GuestGuard)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"])); };
GuestGuard.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: GuestGuard, factory: GuestGuard.ɵfac, providedIn: 'root' });


/***/ }),

/***/ "nueM":
/*!********************************************!*\
  !*** ./src/app/ReduxStore/app.reducers.ts ***!
  \********************************************/
/*! exports provided: appReducers */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "appReducers", function() { return appReducers; });
/* harmony import */ var _reducers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./reducers */ "eHm2");

const appReducers = {
    usuario: _reducers__WEBPACK_IMPORTED_MODULE_0__["authReducer"],
    AUDGENPROCESOS: _reducers__WEBPACK_IMPORTED_MODULE_0__["AUDGENPROCESOReducer"],
    ListaUsuarios: _reducers__WEBPACK_IMPORTED_MODULE_0__["ListadoUsuariosReducer"],
    ProcesoCambios: _reducers__WEBPACK_IMPORTED_MODULE_0__["ProcesoCambiosReducer"],
    AUDGENESTADOPROCESOS: _reducers__WEBPACK_IMPORTED_MODULE_0__["AUDGENESTADOPROCESOReducer"],
    AUDGENEJECUCIONESPROCESO: _reducers__WEBPACK_IMPORTED_MODULE_0__["AUDGENEJECUCIONESPROCESOReducer"],
    CATPROCESOS: _reducers__WEBPACK_IMPORTED_MODULE_0__["CATPROCESOReducer"],
    CATPERMISOS: _reducers__WEBPACK_IMPORTED_MODULE_0__["CATPERMISOReducer"],
    notificaciones: _reducers__WEBPACK_IMPORTED_MODULE_0__["NotificacionesReducer"],
    catalogos: _reducers__WEBPACK_IMPORTED_MODULE_0__["catalogosReducer"],
    DetailCatalogos: _reducers__WEBPACK_IMPORTED_MODULE_0__["DetailCatologosReducer"],
    AUDGENUSUARIOS: _reducers__WEBPACK_IMPORTED_MODULE_0__["AUDGENUSUARIOReducer"],
    notificacionSelect: _reducers__WEBPACK_IMPORTED_MODULE_0__["notificacionSelectReducer"]
};


/***/ }),

/***/ "oNqj":
/*!**************************************************************************************!*\
  !*** ./src/app/ReduxStore/reducers/notificacionSelect/notificacionSelect.reducer.ts ***!
  \**************************************************************************************/
/*! exports provided: notificacionSelectState, notificacionSelectReducer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "notificacionSelectState", function() { return notificacionSelectState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "notificacionSelectReducer", function() { return notificacionSelectReducer; });
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/store */ "l7P3");
/* harmony import */ var _actions_notificacionSelect_notificacionSelect_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../actions/notificacionSelect/notificacionSelect.actions */ "2CCq");


const notificacionSelectState = {
    notificacionSelect: null,
};
const _notificacionSelectReducer = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createReducer"])(notificacionSelectState, Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions_notificacionSelect_notificacionSelect_actions__WEBPACK_IMPORTED_MODULE_1__["notificacionSelect"], (state, { notificacionSelect }) => (Object.assign(Object.assign({}, state), { notificacionSelect: notificacionSelect }))));
let notificacionSelectReducer = (state, action) => _notificacionSelectReducer(state, action);


/***/ }),

/***/ "oYdr":
/*!*********************************************************************!*\
  !*** ./src/app/ReduxStore/reducers/loaderProcesoCambios.reducer.ts ***!
  \*********************************************************************/
/*! exports provided: InitialProcesoCambiosState, ProcesoCambiosReducer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InitialProcesoCambiosState", function() { return InitialProcesoCambiosState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProcesoCambiosReducer", function() { return ProcesoCambiosReducer; });
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/store */ "l7P3");
/* harmony import */ var _actions_loaderProcesoCambios_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../actions/loaderProcesoCambios.actions */ "tONv");


const InitialProcesoCambiosState = {
    terminado: false
};
const _ProcesoCambiosReducer = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createReducer"])(InitialProcesoCambiosState, Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions_loaderProcesoCambios_actions__WEBPACK_IMPORTED_MODULE_1__["ProcesoTerminado"], (state) => (Object.assign(Object.assign({}, state), { terminado: true }))), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions_loaderProcesoCambios_actions__WEBPACK_IMPORTED_MODULE_1__["ProcesoLimpiar"], (state) => (Object.assign(Object.assign({}, state), { terminado: false }))));
let ProcesoCambiosReducer = (state, action) => _ProcesoCambiosReducer(state, action);


/***/ }),

/***/ "p8Vo":
/*!*********************************************!*\
  !*** ./src/app/ReduxStore/actions/index.ts ***!
  \*********************************************/
/*! exports provided: setUser, setUserRol, setUserArea, unSetUser, LoadAUDGENPROCESOS, LoadAUDGENPROCESOSuccess, LoadAUDGENPROCESOError, UnsetAUDGENPROCESO, LoadListaUsuarios, LoadListaUsuariosSuccess, LoadListaUsuariosError, UnsetListaUsuarios, ProcesoTerminado, ProcesoLimpiar, LoadAUDGENESTADOPROCESOS, LoadAUDGENESTADOPROCESOSuccess, LoadAUDGENESTADOPROCESOError, UnsetAUDGENESTADOPROCESO, LoadAUDGENEJECUCIONESPROCESO, LoadAUDGENEJECUCIONPROCESOSuccess, LoadAUDGENEJECUCIONPROCESOError, UnsetAUDGENEJECUCIONPROCESO, LoadCATPROCESOS, LoadCATPROCESOSuccess, LoadCATPROCESOError, UnsetCATPROCESO, LoadCATPERMISOS, LoadCATPERMISOSuccess, LoadCATPERMISOError, UnsetCATPERMISO, setnotificaciones, crearnotificacione, unSetnotificaciones, cargarCatalogos, caragarCatalogosSucces, caragarCatalogosError, unSetCatalogos, loadingDetailCatalogos, cargarDetailCatalogos, caragarDetailCatalogosSucces, caragarDetailCatalogosError, unSetDetailCatalogos, LoadAUDGENUSUARIOS, LoadAUDGENUSUARIOSuccess, LoadAUDGENUSUARIOError, UnsetAUDGENUSUARIO, notificacionSelect */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _usuario_actions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./usuario.actions */ "dwxx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "setUser", function() { return _usuario_actions__WEBPACK_IMPORTED_MODULE_0__["setUser"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "setUserRol", function() { return _usuario_actions__WEBPACK_IMPORTED_MODULE_0__["setUserRol"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "setUserArea", function() { return _usuario_actions__WEBPACK_IMPORTED_MODULE_0__["setUserArea"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "unSetUser", function() { return _usuario_actions__WEBPACK_IMPORTED_MODULE_0__["unSetUser"]; });

/* harmony import */ var _AUDGENPROCESO_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./AUDGENPROCESO.actions */ "LB20");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "LoadAUDGENPROCESOS", function() { return _AUDGENPROCESO_actions__WEBPACK_IMPORTED_MODULE_1__["LoadAUDGENPROCESOS"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "LoadAUDGENPROCESOSuccess", function() { return _AUDGENPROCESO_actions__WEBPACK_IMPORTED_MODULE_1__["LoadAUDGENPROCESOSuccess"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "LoadAUDGENPROCESOError", function() { return _AUDGENPROCESO_actions__WEBPACK_IMPORTED_MODULE_1__["LoadAUDGENPROCESOError"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "UnsetAUDGENPROCESO", function() { return _AUDGENPROCESO_actions__WEBPACK_IMPORTED_MODULE_1__["UnsetAUDGENPROCESO"]; });

/* harmony import */ var _listaUsuarios_actions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./listaUsuarios.actions */ "i2/L");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "LoadListaUsuarios", function() { return _listaUsuarios_actions__WEBPACK_IMPORTED_MODULE_2__["LoadListaUsuarios"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "LoadListaUsuariosSuccess", function() { return _listaUsuarios_actions__WEBPACK_IMPORTED_MODULE_2__["LoadListaUsuariosSuccess"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "LoadListaUsuariosError", function() { return _listaUsuarios_actions__WEBPACK_IMPORTED_MODULE_2__["LoadListaUsuariosError"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "UnsetListaUsuarios", function() { return _listaUsuarios_actions__WEBPACK_IMPORTED_MODULE_2__["UnsetListaUsuarios"]; });

/* harmony import */ var _loaderProcesoCambios_actions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./loaderProcesoCambios.actions */ "tONv");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ProcesoTerminado", function() { return _loaderProcesoCambios_actions__WEBPACK_IMPORTED_MODULE_3__["ProcesoTerminado"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ProcesoLimpiar", function() { return _loaderProcesoCambios_actions__WEBPACK_IMPORTED_MODULE_3__["ProcesoLimpiar"]; });

/* harmony import */ var _AUDGENESTADOPROCESO_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./AUDGENESTADOPROCESO.actions */ "v+gz");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "LoadAUDGENESTADOPROCESOS", function() { return _AUDGENESTADOPROCESO_actions__WEBPACK_IMPORTED_MODULE_4__["LoadAUDGENESTADOPROCESOS"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "LoadAUDGENESTADOPROCESOSuccess", function() { return _AUDGENESTADOPROCESO_actions__WEBPACK_IMPORTED_MODULE_4__["LoadAUDGENESTADOPROCESOSuccess"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "LoadAUDGENESTADOPROCESOError", function() { return _AUDGENESTADOPROCESO_actions__WEBPACK_IMPORTED_MODULE_4__["LoadAUDGENESTADOPROCESOError"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "UnsetAUDGENESTADOPROCESO", function() { return _AUDGENESTADOPROCESO_actions__WEBPACK_IMPORTED_MODULE_4__["UnsetAUDGENESTADOPROCESO"]; });

/* harmony import */ var _AUDGENEJECUCIONESPROCESO_actions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./AUDGENEJECUCIONESPROCESO.actions */ "eWzz");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "LoadAUDGENEJECUCIONESPROCESO", function() { return _AUDGENEJECUCIONESPROCESO_actions__WEBPACK_IMPORTED_MODULE_5__["LoadAUDGENEJECUCIONESPROCESO"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "LoadAUDGENEJECUCIONPROCESOSuccess", function() { return _AUDGENEJECUCIONESPROCESO_actions__WEBPACK_IMPORTED_MODULE_5__["LoadAUDGENEJECUCIONPROCESOSuccess"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "LoadAUDGENEJECUCIONPROCESOError", function() { return _AUDGENEJECUCIONESPROCESO_actions__WEBPACK_IMPORTED_MODULE_5__["LoadAUDGENEJECUCIONPROCESOError"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "UnsetAUDGENEJECUCIONPROCESO", function() { return _AUDGENEJECUCIONESPROCESO_actions__WEBPACK_IMPORTED_MODULE_5__["UnsetAUDGENEJECUCIONPROCESO"]; });

/* harmony import */ var _CATPROCESO_actions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./CATPROCESO.actions */ "PDh6");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "LoadCATPROCESOS", function() { return _CATPROCESO_actions__WEBPACK_IMPORTED_MODULE_6__["LoadCATPROCESOS"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "LoadCATPROCESOSuccess", function() { return _CATPROCESO_actions__WEBPACK_IMPORTED_MODULE_6__["LoadCATPROCESOSuccess"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "LoadCATPROCESOError", function() { return _CATPROCESO_actions__WEBPACK_IMPORTED_MODULE_6__["LoadCATPROCESOError"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "UnsetCATPROCESO", function() { return _CATPROCESO_actions__WEBPACK_IMPORTED_MODULE_6__["UnsetCATPROCESO"]; });

/* harmony import */ var _CATPERMISOS_actions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./CATPERMISOS.actions */ "NHAl");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "LoadCATPERMISOS", function() { return _CATPERMISOS_actions__WEBPACK_IMPORTED_MODULE_7__["LoadCATPERMISOS"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "LoadCATPERMISOSuccess", function() { return _CATPERMISOS_actions__WEBPACK_IMPORTED_MODULE_7__["LoadCATPERMISOSuccess"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "LoadCATPERMISOError", function() { return _CATPERMISOS_actions__WEBPACK_IMPORTED_MODULE_7__["LoadCATPERMISOError"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "UnsetCATPERMISO", function() { return _CATPERMISOS_actions__WEBPACK_IMPORTED_MODULE_7__["UnsetCATPERMISO"]; });

/* harmony import */ var _notificaciones_actions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./notificaciones.actions */ "eaYr");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "setnotificaciones", function() { return _notificaciones_actions__WEBPACK_IMPORTED_MODULE_8__["setnotificaciones"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "crearnotificacione", function() { return _notificaciones_actions__WEBPACK_IMPORTED_MODULE_8__["crearnotificacione"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "unSetnotificaciones", function() { return _notificaciones_actions__WEBPACK_IMPORTED_MODULE_8__["unSetnotificaciones"]; });

/* harmony import */ var _catalogos_catalogos_actions__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./catalogos/catalogos.actions */ "UKHW");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "cargarCatalogos", function() { return _catalogos_catalogos_actions__WEBPACK_IMPORTED_MODULE_9__["cargarCatalogos"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "caragarCatalogosSucces", function() { return _catalogos_catalogos_actions__WEBPACK_IMPORTED_MODULE_9__["caragarCatalogosSucces"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "caragarCatalogosError", function() { return _catalogos_catalogos_actions__WEBPACK_IMPORTED_MODULE_9__["caragarCatalogosError"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "unSetCatalogos", function() { return _catalogos_catalogos_actions__WEBPACK_IMPORTED_MODULE_9__["unSetCatalogos"]; });

/* harmony import */ var _catalogos_catalogoDetail_actions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./catalogos/catalogoDetail.actions */ "5zl/");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "loadingDetailCatalogos", function() { return _catalogos_catalogoDetail_actions__WEBPACK_IMPORTED_MODULE_10__["loadingDetailCatalogos"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "cargarDetailCatalogos", function() { return _catalogos_catalogoDetail_actions__WEBPACK_IMPORTED_MODULE_10__["cargarDetailCatalogos"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "caragarDetailCatalogosSucces", function() { return _catalogos_catalogoDetail_actions__WEBPACK_IMPORTED_MODULE_10__["caragarDetailCatalogosSucces"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "caragarDetailCatalogosError", function() { return _catalogos_catalogoDetail_actions__WEBPACK_IMPORTED_MODULE_10__["caragarDetailCatalogosError"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "unSetDetailCatalogos", function() { return _catalogos_catalogoDetail_actions__WEBPACK_IMPORTED_MODULE_10__["unSetDetailCatalogos"]; });

/* harmony import */ var _usuarios_AUDGENUSUARIOS_actions__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./usuarios/AUDGENUSUARIOS.actions */ "n68H");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "LoadAUDGENUSUARIOS", function() { return _usuarios_AUDGENUSUARIOS_actions__WEBPACK_IMPORTED_MODULE_11__["LoadAUDGENUSUARIOS"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "LoadAUDGENUSUARIOSuccess", function() { return _usuarios_AUDGENUSUARIOS_actions__WEBPACK_IMPORTED_MODULE_11__["LoadAUDGENUSUARIOSuccess"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "LoadAUDGENUSUARIOError", function() { return _usuarios_AUDGENUSUARIOS_actions__WEBPACK_IMPORTED_MODULE_11__["LoadAUDGENUSUARIOError"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "UnsetAUDGENUSUARIO", function() { return _usuarios_AUDGENUSUARIOS_actions__WEBPACK_IMPORTED_MODULE_11__["UnsetAUDGENUSUARIO"]; });

/* harmony import */ var _notificacionSelect_notificacionSelect_actions__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./notificacionSelect/notificacionSelect.actions */ "2CCq");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "notificacionSelect", function() { return _notificacionSelect_notificacionSelect_actions__WEBPACK_IMPORTED_MODULE_12__["notificacionSelect"]; });
















/***/ }),

/***/ "ppOk":
/*!********************************************************!*\
  !*** ./src/app/ReduxStore/reducers/usuario.reducer.ts ***!
  \********************************************************/
/*! exports provided: initialState, authReducer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initialState", function() { return initialState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "authReducer", function() { return authReducer; });
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/store */ "l7P3");
/* harmony import */ var _actions_usuario_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../actions/usuario.actions */ "dwxx");


const initialState = {
    user: null,
    rol: null,
    area: null,
};
const _authReducer = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createReducer"])(initialState, Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions_usuario_actions__WEBPACK_IMPORTED_MODULE_1__["setUser"], (state, { user }) => (Object.assign(Object.assign({}, state), { user: Object.assign({}, user), rol: null, area: null }))), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions_usuario_actions__WEBPACK_IMPORTED_MODULE_1__["setUserRol"], (state, { rol }) => (Object.assign(Object.assign({}, state), { rol: rol, area: null }))), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions_usuario_actions__WEBPACK_IMPORTED_MODULE_1__["setUserArea"], (state, { area }) => (Object.assign(Object.assign({}, state), { rol: null, area: area }))), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions_usuario_actions__WEBPACK_IMPORTED_MODULE_1__["unSetUser"], (state) => (Object.assign(Object.assign({}, state), { user: null }))));
let authReducer = (state, action) => {
    return _authReducer(state, action);
};


/***/ }),

/***/ "qJvj":
/*!************************************************************************!*\
  !*** ./src/app/ReduxStore/reducers/usuarios/AUDGENUSUARIOS.reducer.ts ***!
  \************************************************************************/
/*! exports provided: AUDGENUSUARIOSState, AUDGENUSUARIOReducer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AUDGENUSUARIOSState", function() { return AUDGENUSUARIOSState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AUDGENUSUARIOReducer", function() { return AUDGENUSUARIOReducer; });
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/store */ "l7P3");
/* harmony import */ var _actions_usuarios_AUDGENUSUARIOS_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../actions/usuarios/AUDGENUSUARIOS.actions */ "n68H");


const AUDGENUSUARIOSState = {
    AUDGENUSUARIOS: [],
    consult: null,
    error: null,
};
const _AUDGENUSUARIOReducer = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createReducer"])(AUDGENUSUARIOSState, Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions_usuarios_AUDGENUSUARIOS_actions__WEBPACK_IMPORTED_MODULE_1__["LoadAUDGENUSUARIOS"], (state, { consult }) => (Object.assign({}, state))), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions_usuarios_AUDGENUSUARIOS_actions__WEBPACK_IMPORTED_MODULE_1__["LoadAUDGENUSUARIOSuccess"], (state, { AUDGENUSUARIOS }) => (Object.assign(Object.assign({}, state), { AUDGENUSUARIOS: [...AUDGENUSUARIOS], error: null }))), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions_usuarios_AUDGENUSUARIOS_actions__WEBPACK_IMPORTED_MODULE_1__["UnsetAUDGENUSUARIO"], (state) => (Object.assign(Object.assign({}, state), { AUDGENUSUARIOS: null, error: null, consult: null }))), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions_usuarios_AUDGENUSUARIOS_actions__WEBPACK_IMPORTED_MODULE_1__["LoadAUDGENUSUARIOError"], (state, { payload }) => (Object.assign(Object.assign({}, state), { error: payload }))));
let AUDGENUSUARIOReducer = (state, action) => _AUDGENUSUARIOReducer(state, action);


/***/ }),

/***/ "r6zK":
/*!*************************************!*\
  !*** ./src/app/validators/roles.ts ***!
  \*************************************/
/*! exports provided: ERole, ENegocio, EArea */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ERole", function() { return ERole; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ENegocio", function() { return ENegocio; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EArea", function() { return EArea; });
// callbackAwsDetalle --> var rol = data['UserAttributes'].find((el) => el.Name == 'custom:rol')['Value'];
var ERole;
(function (ERole) {
    ERole["Administrador"] = "Administrador";
    ERole["Monitor"] = "Monitor";
    ERole["Soporte"] = "Soporte";
})(ERole || (ERole = {}));
// callbackAwsDetalle --> var negocio = data['UserAttributes'].find((el) => el.Name == 'custom:negocio')['Value'];
var ENegocio;
(function (ENegocio) {
    ENegocio["Afore"] = "Afore";
    ENegocio["Fondos"] = "Fondos";
})(ENegocio || (ENegocio = {}));
// DataUser --> user.usuario.groups
var EArea;
(function (EArea) {
    EArea["Tesoreria"] = "Tesoreria";
    EArea["Inversiones_Riesgos"] = "Riesgos";
    EArea["Contabilidad"] = "Contabilidad";
    EArea["Custodia"] = "Custodia";
    EArea["Soporte"] = "Soporte";
})(EArea || (EArea = {}));


/***/ }),

/***/ "rhVg":
/*!**************************************************************!*\
  !*** ./src/app/ReduxStore/effects/AUDGENPROCESOS.effects.ts ***!
  \**************************************************************/
/*! exports provided: AUDGENPROCESOSEfffects */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AUDGENPROCESOSEfffects", function() { return AUDGENPROCESOSEfffects; });
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/effects */ "9jGm");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/observable/fromPromise */ "3gwn");
/* harmony import */ var rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _actions_AUDGENPROCESO_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../actions/AUDGENPROCESO.actions */ "LB20");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _API_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./../../API.service */ "iO9l");








class AUDGENPROCESOSEfffects {
    constructor(actions$, api) {
        this.actions$ = actions$;
        this.api = api;
        this.loadAUDGENPROCESO$ = Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_0__["createEffect"])(() => this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_0__["ofType"])(_actions_AUDGENPROCESO_actions__WEBPACK_IMPORTED_MODULE_4__["LoadAUDGENPROCESOS"]), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["mergeMap"])(({ consult }) => {
            if (consult) {
                return Object(rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3__["fromPromise"])(this.api.ListAUDGENPROCESOS(consult.ID_PROCESO, consult.FECHA)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])(({ items }) => _actions_AUDGENPROCESO_actions__WEBPACK_IMPORTED_MODULE_4__["LoadAUDGENPROCESOSuccess"]({
                    AUDGENPROCESOS: items,
                })), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["catchError"])((error) => Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(_actions_AUDGENPROCESO_actions__WEBPACK_IMPORTED_MODULE_4__["LoadAUDGENPROCESOError"]({ payload: error }))));
            }
            else {
                return Object(rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3__["fromPromise"])(this.api.ListAUDGENPROCESOS()).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])(({ items }) => _actions_AUDGENPROCESO_actions__WEBPACK_IMPORTED_MODULE_4__["LoadAUDGENPROCESOSuccess"]({
                    AUDGENPROCESOS: items,
                })), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["catchError"])((error) => Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(_actions_AUDGENPROCESO_actions__WEBPACK_IMPORTED_MODULE_4__["LoadAUDGENPROCESOError"]({ payload: error }))));
            }
        })));
    }
}
AUDGENPROCESOSEfffects.ɵfac = function AUDGENPROCESOSEfffects_Factory(t) { return new (t || AUDGENPROCESOSEfffects)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_ngrx_effects__WEBPACK_IMPORTED_MODULE_0__["Actions"]), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_API_service__WEBPACK_IMPORTED_MODULE_6__["APIService"])); };
AUDGENPROCESOSEfffects.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjectable"]({ token: AUDGENPROCESOSEfffects, factory: AUDGENPROCESOSEfffects.ɵfac });


/***/ }),

/***/ "rzrB":
/*!****************************!*\
  !*** ./src/aws-exports.js ***!
  \****************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* eslint-disable */
// WARNING: DO NOT EDIT. This file is automatically generated by AWS Amplify. It will be overwritten.

const awsmobile = {
    "aws_project_region": "us-east-1",
    "aws_cognito_region": "us-east-1",
    "aws_user_pools_id": "us-east-1_mRG6EmrII",
    "aws_user_pools_web_client_id": "jll4ul3pmr6rb37i0fmtmctf",
    "oauth": {
        "domain": "auth-335672086802-us-east-1.auth.us-east-1.amazoncognito.com"
    },
    "aws_appsync_graphqlEndpoint": "https://z3z4liprmfgfjl4twtn24dambm.appsync-api.us-east-1.amazonaws.com/graphql",
    "aws_appsync_region": "us-east-1",
    "aws_appsync_authenticationType": "AMAZON_COGNITO_USER_POOLS"
};


/* harmony default export */ __webpack_exports__["default"] = (awsmobile);


/***/ }),

/***/ "sOXL":
/*!************************************************************!*\
  !*** ./src/app/ReduxStore/reducers/CATPERMISOS.reducer.ts ***!
  \************************************************************/
/*! exports provided: CATPERMISOState, CATPERMISOReducer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CATPERMISOState", function() { return CATPERMISOState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CATPERMISOReducer", function() { return CATPERMISOReducer; });
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/store */ "l7P3");
/* harmony import */ var _actions_CATPERMISOS_actions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../actions/CATPERMISOS.actions */ "NHAl");


const CATPERMISOState = {
    CATPERMISOS: [],
    consult: null,
    error: null,
};
const _CATPERMISOReducer = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createReducer"])(CATPERMISOState, Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions_CATPERMISOS_actions__WEBPACK_IMPORTED_MODULE_1__["LoadCATPERMISOS"], (state, { consult }) => (Object.assign({}, state))), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions_CATPERMISOS_actions__WEBPACK_IMPORTED_MODULE_1__["LoadCATPERMISOSuccess"], (state, { CATPERMISOS }) => (Object.assign(Object.assign({}, state), { CATPERMISOS: [...CATPERMISOS], error: null }))), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions_CATPERMISOS_actions__WEBPACK_IMPORTED_MODULE_1__["UnsetCATPERMISO"], (state) => (Object.assign(Object.assign({}, state), { AUDGENPROCESOS: null, error: null, consult: null }))), Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["on"])(_actions_CATPERMISOS_actions__WEBPACK_IMPORTED_MODULE_1__["LoadCATPERMISOError"], (state, { payload }) => (Object.assign(Object.assign({}, state), { error: payload }))));
let CATPERMISOReducer = (state, action) => _CATPERMISOReducer(state, action);


/***/ }),

/***/ "sa/g":
/*!************************************************************************!*\
  !*** ./src/app/ReduxStore/effects/catalogos/catalogoDetail.effects.ts ***!
  \************************************************************************/
/*! exports provided: CatalogoDetailEfffects */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CatalogoDetailEfffects", function() { return CatalogoDetailEfffects; });
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/effects */ "9jGm");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/observable/fromPromise */ "3gwn");
/* harmony import */ var rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../actions */ "p8Vo");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _services_catalogos_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../services/catalogos.service */ "4ujS");








//CatalogosService
class CatalogoDetailEfffects {
    constructor(actions$, CatalogosService) {
        this.actions$ = actions$;
        this.CatalogosService = CatalogosService;
        this.cargarDetailCatalogos$ = Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_0__["createEffect"])(() => this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_0__["ofType"])(_actions__WEBPACK_IMPORTED_MODULE_4__["cargarDetailCatalogos"]), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["mergeMap"])(() => Object(rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3__["fromPromise"])(this.CatalogosService.getDetailsCat()).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])(({ registros }) => Object(_actions__WEBPACK_IMPORTED_MODULE_4__["caragarDetailCatalogosSucces"])({ DetailCatalogos: registros })), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["catchError"])((error) => Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(Object(_actions__WEBPACK_IMPORTED_MODULE_4__["caragarDetailCatalogosError"])({ payload: error })))))));
    }
}
CatalogoDetailEfffects.ɵfac = function CatalogoDetailEfffects_Factory(t) { return new (t || CatalogoDetailEfffects)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_ngrx_effects__WEBPACK_IMPORTED_MODULE_0__["Actions"]), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_services_catalogos_service__WEBPACK_IMPORTED_MODULE_6__["CatalogosService"])); };
CatalogoDetailEfffects.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjectable"]({ token: CatalogoDetailEfffects, factory: CatalogoDetailEfffects.ɵfac });


/***/ }),

/***/ "tONv":
/*!********************************************************************!*\
  !*** ./src/app/ReduxStore/actions/loaderProcesoCambios.actions.ts ***!
  \********************************************************************/
/*! exports provided: ProcesoTerminado, ProcesoLimpiar */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProcesoTerminado", function() { return ProcesoTerminado; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProcesoLimpiar", function() { return ProcesoLimpiar; });
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/store */ "l7P3");

const ProcesoTerminado = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[Proceso] Proceso Terminado');
const ProcesoLimpiar = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[Proceso] Proceso Limpiar');


/***/ }),

/***/ "v+gz":
/*!*******************************************************************!*\
  !*** ./src/app/ReduxStore/actions/AUDGENESTADOPROCESO.actions.ts ***!
  \*******************************************************************/
/*! exports provided: LoadAUDGENESTADOPROCESOS, LoadAUDGENESTADOPROCESOSuccess, LoadAUDGENESTADOPROCESOError, UnsetAUDGENESTADOPROCESO */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadAUDGENESTADOPROCESOS", function() { return LoadAUDGENESTADOPROCESOS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadAUDGENESTADOPROCESOSuccess", function() { return LoadAUDGENESTADOPROCESOSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoadAUDGENESTADOPROCESOError", function() { return LoadAUDGENESTADOPROCESOError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UnsetAUDGENESTADOPROCESO", function() { return UnsetAUDGENESTADOPROCESO; });
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/store */ "l7P3");

const LoadAUDGENESTADOPROCESOS = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[AUDGENESTADOPROCESO] AUDGENESTADOPROCESO Load', Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
const LoadAUDGENESTADOPROCESOSuccess = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[AUDGENESTADOPROCESO Succes] AUDGENESTADOPROCESO Success', Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
const LoadAUDGENESTADOPROCESOError = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[AUDGENESTADOPROCESO Error] AUDGENESTADOPROCESO Errors', Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["props"])());
const UnsetAUDGENESTADOPROCESO = Object(_ngrx_store__WEBPACK_IMPORTED_MODULE_0__["createAction"])('[AUDGENESTADOPROCESO Unset] AUDGENESTADOPROCESO Unset');


/***/ }),

/***/ "vUHb":
/*!*******************************************************************!*\
  !*** ./src/app/ReduxStore/effects/catalogos/catalogos.effects.ts ***!
  \*******************************************************************/
/*! exports provided: CatalogosEfffects */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CatalogosEfffects", function() { return CatalogosEfffects; });
/* harmony import */ var _actions_catalogos_catalogos_actions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../actions/catalogos/catalogos.actions */ "UKHW");
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ngrx/effects */ "9jGm");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _services_catalogos_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../services/catalogos.service */ "4ujS");








//CatalogosService
class CatalogosEfffects {
    constructor(actions$, CatalogosService) {
        this.actions$ = actions$;
        this.CatalogosService = CatalogosService;
        this.cargarCatalogos$ = Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_1__["createEffect"])(() => this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_1__["ofType"])(_actions_catalogos_catalogos_actions__WEBPACK_IMPORTED_MODULE_0__["cargarCatalogos"]), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["mergeMap"])(() => this.CatalogosService.getCatalogos().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(({ catalogos }) => Object(_actions_catalogos_catalogos_actions__WEBPACK_IMPORTED_MODULE_0__["caragarCatalogosSucces"])({ catalogos: catalogos })), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["catchError"])((error) => Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(Object(_actions_catalogos_catalogos_actions__WEBPACK_IMPORTED_MODULE_0__["caragarCatalogosError"])({ payload: error })))))));
    }
}
CatalogosEfffects.ɵfac = function CatalogosEfffects_Factory(t) { return new (t || CatalogosEfffects)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"](_ngrx_effects__WEBPACK_IMPORTED_MODULE_1__["Actions"]), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"](_services_catalogos_service__WEBPACK_IMPORTED_MODULE_5__["CatalogosService"])); };
CatalogosEfffects.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjectable"]({ token: CatalogosEfffects, factory: CatalogosEfffects.ɵfac });


/***/ }),

/***/ "vY5A":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _pages_login_login_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pages/login/login.component */ "D8EZ");
/* harmony import */ var _Guards_auth_guard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Guards/auth.guard */ "mwaT");
/* harmony import */ var _Guards_guest_guard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Guards/guest.guard */ "nPwh");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");






const routes = [
    { path: 'login', component: _pages_login_login_component__WEBPACK_IMPORTED_MODULE_1__["LoginComponent"], canActivate: [_Guards_guest_guard__WEBPACK_IMPORTED_MODULE_3__["GuestGuard"]] },
    {
        path: '',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-content-dashboard-dashboard-module */ "pages-content-dashboard-dashboard-module").then(__webpack_require__.bind(null, /*! ./pages/content/dashboard/dashboard.module */ "43PO")).then((m) => m.DashboardModule),
        canLoad: [_Guards_auth_guard__WEBPACK_IMPORTED_MODULE_2__["AuthGuard"]],
    },
    { path: '**', redirectTo: 'login' },
];
// ng generate module dashboard --route dashboard --module app.module
class AppRoutingModule {
}
AppRoutingModule.ɵfac = function AppRoutingModule_Factory(t) { return new (t || AppRoutingModule)(); };
AppRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineNgModule"]({ type: AppRoutingModule });
AppRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forRoot(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsetNgModuleScope"](AppRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] }); })();


/***/ }),

/***/ "vacT":
/*!***********************************************************!*\
  !*** ./src/app/ReduxStore/effects/CATPROCESOS.effects.ts ***!
  \***********************************************************/
/*! exports provided: CATPROCESOSEfffects */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CATPROCESOSEfffects", function() { return CATPROCESOSEfffects; });
/* harmony import */ var _ngrx_effects__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ngrx/effects */ "9jGm");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/observable/fromPromise */ "3gwn");
/* harmony import */ var rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _actions_CATPROCESO_actions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../actions/CATPROCESO.actions */ "PDh6");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _API_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./../../API.service */ "iO9l");








class CATPROCESOSEfffects {
    constructor(actions$, api) {
        this.actions$ = actions$;
        this.api = api;
        this.loadCATPROCESO$ = Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_0__["createEffect"])(() => this.actions$.pipe(Object(_ngrx_effects__WEBPACK_IMPORTED_MODULE_0__["ofType"])(_actions_CATPROCESO_actions__WEBPACK_IMPORTED_MODULE_4__["LoadCATPROCESOS"]), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["mergeMap"])(({ consult }) => {
            if (consult) {
                return Object(rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3__["fromPromise"])(this.api.ListCATPROCESOS(consult.filter, consult.limit)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])(({ items }) => _actions_CATPROCESO_actions__WEBPACK_IMPORTED_MODULE_4__["LoadCATPROCESOSuccess"]({
                    CATPROCESOS: items,
                })), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["catchError"])((error) => Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(_actions_CATPROCESO_actions__WEBPACK_IMPORTED_MODULE_4__["LoadCATPROCESOError"]({ payload: error }))));
            }
            else {
                return Object(rxjs_observable_fromPromise__WEBPACK_IMPORTED_MODULE_3__["fromPromise"])(this.api.ListCATPROCESOS()).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])(({ items }) => _actions_CATPROCESO_actions__WEBPACK_IMPORTED_MODULE_4__["LoadCATPROCESOSuccess"]({
                    CATPROCESOS: items,
                })), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["catchError"])((error) => Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["of"])(_actions_CATPROCESO_actions__WEBPACK_IMPORTED_MODULE_4__["LoadCATPROCESOError"]({ payload: error }))));
            }
        })));
    }
}
CATPROCESOSEfffects.ɵfac = function CATPROCESOSEfffects_Factory(t) { return new (t || CATPROCESOSEfffects)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_ngrx_effects__WEBPACK_IMPORTED_MODULE_0__["Actions"]), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_API_service__WEBPACK_IMPORTED_MODULE_6__["APIService"])); };
CATPROCESOSEfffects.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjectable"]({ token: CATPROCESOSEfffects, factory: CATPROCESOSEfffects.ɵfac });


/***/ }),

/***/ "zUnb":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "jhN1");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "ZAI4");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "AytR");
/* harmony import */ var aws_amplify__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! aws-amplify */ "AL3R");
/* harmony import */ var _aws_exports__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./aws-exports */ "rzrB");






aws_amplify__WEBPACK_IMPORTED_MODULE_4__["default"].configure(_aws_exports__WEBPACK_IMPORTED_MODULE_5__["default"]);
if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["enableProdMode"])();
}
_angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["platformBrowser"]().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(err => console.error(err));


/***/ }),

/***/ "zn8P":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "zn8P";

/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map