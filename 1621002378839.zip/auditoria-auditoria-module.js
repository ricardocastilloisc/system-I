(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["auditoria-auditoria-module"],{

/***/ "+2FF":
/*!**************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/auditoria/auditoria.component.ts ***!
  \**************************************************************************/
/*! exports provided: AuditoriaComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuditoriaComponent", function() { return AuditoriaComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "tyNb");


class AuditoriaComponent {
    constructor() { }
    ngOnInit() {
    }
}
AuditoriaComponent.ɵfac = function AuditoriaComponent_Factory(t) { return new (t || AuditoriaComponent)(); };
AuditoriaComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: AuditoriaComponent, selectors: [["app-auditoria"]], decls: 1, vars: 0, template: function AuditoriaComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "router-outlet");
    } }, directives: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterOutlet"]], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhdWRpdG9yaWEuY29tcG9uZW50LmNzcyJ9 */"] });


/***/ }),

/***/ "werS":
/*!***********************************************************************!*\
  !*** ./src/app/pages/content/dashboard/auditoria/auditoria.module.ts ***!
  \***********************************************************************/
/*! exports provided: AuditoriaModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuditoriaModule", function() { return AuditoriaModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _auditoria_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./auditoria-routing.module */ "zcXF");
/* harmony import */ var _auditoria_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./auditoria.component */ "+2FF");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




class AuditoriaModule {
}
AuditoriaModule.ɵfac = function AuditoriaModule_Factory(t) { return new (t || AuditoriaModule)(); };
AuditoriaModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({ type: AuditoriaModule });
AuditoriaModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
            _auditoria_routing_module__WEBPACK_IMPORTED_MODULE_1__["AuditoriaRoutingModule"]
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](AuditoriaModule, { declarations: [_auditoria_component__WEBPACK_IMPORTED_MODULE_2__["AuditoriaComponent"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
        _auditoria_routing_module__WEBPACK_IMPORTED_MODULE_1__["AuditoriaRoutingModule"]] }); })();


/***/ }),

/***/ "zcXF":
/*!*******************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/auditoria/auditoria-routing.module.ts ***!
  \*******************************************************************************/
/*! exports provided: AuditoriaRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuditoriaRoutingModule", function() { return AuditoriaRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _auditoria_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./auditoria.component */ "+2FF");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");




const routes = [
    {
        path: '',
        component: _auditoria_component__WEBPACK_IMPORTED_MODULE_1__["AuditoriaComponent"],
        children: [
            {
                path: '',
                loadChildren: () => Promise.all(/*! import() | auditoriageneral-auditoriageneral-module */[__webpack_require__.e("default~auditoriageneral-auditoriageneral-module~home-home-module~procesos-pantalla-general-procesos~0807e121"), __webpack_require__.e("common"), __webpack_require__.e("auditoriageneral-auditoriageneral-module")]).then(__webpack_require__.bind(null, /*! ./auditoriageneral/auditoriageneral.module */ "kd5d")).then((m) => m.AuditoriageneralModule),
            },
            {
                path: 'archivos',
                loadChildren: () => __webpack_require__.e(/*! import() | archivos-archivos-module */ "archivos-archivos-module").then(__webpack_require__.bind(null, /*! ./archivos/archivos.module */ "e/GJ")).then((m) => m.ArchivosModule),
            },
            {
                path: 'catalogos',
                loadChildren: () => __webpack_require__.e(/*! import() | catalogos-catalogos-module */ "catalogos-catalogos-module").then(__webpack_require__.bind(null, /*! ./catalogos/catalogos.module */ "/nyp")).then((m) => m.CatalogosModule),
            },
            {
                path: 'procesos',
                loadChildren: () => __webpack_require__.e(/*! import() | procesos-procesos-module */ "procesos-procesos-module").then(__webpack_require__.bind(null, /*! ./procesos/procesos.module */ "oy6u")).then((m) => m.ProcesosModule),
            },
            {
                path: 'usuarios',
                loadChildren: () => Promise.all(/*! import() | usuarios-usuarios-module */[__webpack_require__.e("default~procesos-pantalla-general-procesos-pantalla-general-module~usuarios-usuarios-module"), __webpack_require__.e("usuarios-usuarios-module")]).then(__webpack_require__.bind(null, /*! ./usuarios/usuarios.module */ "aQ0i")).then((m) => m.UsuariosModule),
            },
        ],
    },
];
class AuditoriaRoutingModule {
}
AuditoriaRoutingModule.ɵfac = function AuditoriaRoutingModule_Factory(t) { return new (t || AuditoriaRoutingModule)(); };
AuditoriaRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: AuditoriaRoutingModule });
AuditoriaRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](AuditoriaRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] }); })();


/***/ })

}]);
//# sourceMappingURL=auditoria-auditoria-module.js.map