(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["catalogos-catalogos-module"],{

/***/ "+EFC":
/*!**************************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/administracion/catalogos/catalogos.module.ts ***!
  \**************************************************************************************/
/*! exports provided: CatalogosModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CatalogosModule", function() { return CatalogosModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _catalogos_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./catalogos-routing.module */ "I2N7");
/* harmony import */ var _catalogos_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./catalogos.component */ "08MV");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




class CatalogosModule {
}
CatalogosModule.ɵfac = function CatalogosModule_Factory(t) { return new (t || CatalogosModule)(); };
CatalogosModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({ type: CatalogosModule });
CatalogosModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
            _catalogos_routing_module__WEBPACK_IMPORTED_MODULE_1__["CatalogosRoutingModule"]
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](CatalogosModule, { declarations: [_catalogos_component__WEBPACK_IMPORTED_MODULE_2__["CatalogosComponent"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
        _catalogos_routing_module__WEBPACK_IMPORTED_MODULE_1__["CatalogosRoutingModule"]] }); })();


/***/ }),

/***/ "/nyp":
/*!*********************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/auditoria/catalogos/catalogos.module.ts ***!
  \*********************************************************************************/
/*! exports provided: CatalogosModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CatalogosModule", function() { return CatalogosModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _catalogos_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./catalogos-routing.module */ "NJaF");
/* harmony import */ var _catalogos_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./catalogos.component */ "IxWP");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var ng_multiselect_dropdown__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ng-multiselect-dropdown */ "Egam");
/* harmony import */ var ngx_pagination__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ngx-pagination */ "oOf3");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ngx-spinner */ "JqCM");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ "fXoL");









class CatalogosModule {
}
CatalogosModule.ɵfac = function CatalogosModule_Factory(t) { return new (t || CatalogosModule)(); };
CatalogosModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineNgModule"]({ type: CatalogosModule });
CatalogosModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
            _catalogos_routing_module__WEBPACK_IMPORTED_MODULE_1__["CatalogosRoutingModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            ngx_spinner__WEBPACK_IMPORTED_MODULE_6__["NgxSpinnerModule"],
            ngx_pagination__WEBPACK_IMPORTED_MODULE_5__["NgxPaginationModule"],
            ng_multiselect_dropdown__WEBPACK_IMPORTED_MODULE_4__["NgMultiSelectDropDownModule"].forRoot(),
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵsetNgModuleScope"](CatalogosModule, { declarations: [_catalogos_component__WEBPACK_IMPORTED_MODULE_2__["CatalogosComponent"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
        _catalogos_routing_module__WEBPACK_IMPORTED_MODULE_1__["CatalogosRoutingModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
        ngx_spinner__WEBPACK_IMPORTED_MODULE_6__["NgxSpinnerModule"],
        ngx_pagination__WEBPACK_IMPORTED_MODULE_5__["NgxPaginationModule"], ng_multiselect_dropdown__WEBPACK_IMPORTED_MODULE_4__["NgMultiSelectDropDownModule"]] }); })();


/***/ }),

/***/ "08MV":
/*!*****************************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/administracion/catalogos/catalogos.component.ts ***!
  \*****************************************************************************************/
/*! exports provided: CatalogosComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CatalogosComponent", function() { return CatalogosComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ngrx/store */ "l7P3");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _services_catalogos_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../services/catalogos.service */ "4ujS");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "ofXK");





function CatalogosComponent_div_4_li_12_Template(rf, ctx) { if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "li", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function CatalogosComponent_div_4_li_12_Template_li_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r7); const AforesGen_r5 = ctx.$implicit; const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r6.goDetailCat(AforesGen_r5.NOMBRE_NEGOCIO, AforesGen_r5.NOMBRE); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "span", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function CatalogosComponent_div_4_li_12_Template_span_click_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r7); const AforesGen_r5 = ctx.$implicit; const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r8.goDetailCat(AforesGen_r5.NOMBRE_NEGOCIO, AforesGen_r5.NOMBRE); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const AforesGen_r5 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", AforesGen_r5.NOMBRE_NEGOCIO, "");
} }
function CatalogosComponent_div_4_ul_13_li_5_Template(rf, ctx) { if (rf & 1) {
    const _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "li", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function CatalogosComponent_div_4_ul_13_li_5_Template_li_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r13); const SUBMENU_r11 = ctx.$implicit; const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3); return ctx_r12.goDetailCat(SUBMENU_r11.NOMBRE_NEGOCIO, SUBMENU_r11.NOMBRE); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "span", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function CatalogosComponent_div_4_ul_13_li_5_Template_span_click_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r13); const SUBMENU_r11 = ctx.$implicit; const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3); return ctx_r14.goDetailCat(SUBMENU_r11.NOMBRE_NEGOCIO, SUBMENU_r11.NOMBRE); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const SUBMENU_r11 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", SUBMENU_r11.NOMBRE_NEGOCIO, "");
} }
function CatalogosComponent_div_4_ul_13_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ul", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "li", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "ul", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, CatalogosComponent_div_4_ul_13_li_5_Template, 3, 1, "li", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const AforesSub_r9 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](AforesSub_r9.INTERFAZ);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", AforesSub_r9.SUBMENUS);
} }
function CatalogosComponent_div_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "ul", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "li", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "Afores");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "ul", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](12, CatalogosComponent_div_4_li_12_Template, 3, 1, "li", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](13, CatalogosComponent_div_4_ul_13_Template, 6, 2, "ul", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx_r0.AforesGens);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx_r0.AforesSubs);
} }
function CatalogosComponent_div_5_li_12_Template(rf, ctx) { if (rf & 1) {
    const _r19 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "li", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function CatalogosComponent_div_5_li_12_Template_li_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r19); const FondosGen_r17 = ctx.$implicit; const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r18.goDetailCat(FondosGen_r17.NOMBRE_NEGOCIO, FondosGen_r17.NOMBRE); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "span", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function CatalogosComponent_div_5_li_12_Template_span_click_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r19); const FondosGen_r17 = ctx.$implicit; const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r20.goDetailCat(FondosGen_r17.NOMBRE_NEGOCIO, FondosGen_r17.NOMBRE); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const FondosGen_r17 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", FondosGen_r17.NOMBRE_NEGOCIO, "");
} }
function CatalogosComponent_div_5_ul_13_li_5_Template(rf, ctx) { if (rf & 1) {
    const _r25 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "li", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function CatalogosComponent_div_5_ul_13_li_5_Template_li_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r25); const SUBMENU_r23 = ctx.$implicit; const ctx_r24 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3); return ctx_r24.goDetailCat(SUBMENU_r23.NOMBRE_NEGOCIO, SUBMENU_r23.NOMBRE); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "span", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function CatalogosComponent_div_5_ul_13_li_5_Template_span_click_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r25); const SUBMENU_r23 = ctx.$implicit; const ctx_r26 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](3); return ctx_r26.goDetailCat(SUBMENU_r23.NOMBRE_NEGOCIO, SUBMENU_r23.NOMBRE); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const SUBMENU_r23 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", SUBMENU_r23.NOMBRE_NEGOCIO, "");
} }
function CatalogosComponent_div_5_ul_13_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "ul", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "li", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "ul", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, CatalogosComponent_div_5_ul_13_li_5_Template, 3, 1, "li", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const FondosSub_r21 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate"](FondosSub_r21.INTERFAZ);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", FondosSub_r21.SUBMENUS);
} }
function CatalogosComponent_div_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "ul", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "li", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "Fondos");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "ul", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](12, CatalogosComponent_div_5_li_12_Template, 3, 1, "li", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](13, CatalogosComponent_div_5_ul_13_Template, 6, 2, "ul", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx_r1.FondosGens);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx_r1.FondosSubs);
} }
function CatalogosComponent_div_6_li_12_Template(rf, ctx) { if (rf & 1) {
    const _r30 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "li", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function CatalogosComponent_div_6_li_12_Template_li_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r30); const GenericosGen_r28 = ctx.$implicit; const ctx_r29 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r29.goDetailCat(GenericosGen_r28.NOMBRE_NEGOCIO, GenericosGen_r28.NOMBRE); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "span", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function CatalogosComponent_div_6_li_12_Template_span_click_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r30); const GenericosGen_r28 = ctx.$implicit; const ctx_r31 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2); return ctx_r31.goDetailCat(GenericosGen_r28.NOMBRE_NEGOCIO, GenericosGen_r28.NOMBRE); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const GenericosGen_r28 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", GenericosGen_r28.NOMBRE_NEGOCIO, "");
} }
function CatalogosComponent_div_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "ul", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](8, "li", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "Generales");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "ul", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](12, CatalogosComponent_div_6_li_12_Template, 3, 1, "li", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx_r2.GenericosGens);
} }
class CatalogosComponent {
    constructor(store, router, catalogosSvc) {
        this.store = store;
        this.router = router;
        this.catalogosSvc = catalogosSvc;
        this.AforesGens = [];
        this.AforesSubs = [];
        this.FondosGens = [];
        this.FondosSubs = [];
        this.GenericosGens = [];
        this.goDetailCat = (negocioCat, nameCat) => {
            localStorage.setItem('nameCat', nameCat);
            localStorage.setItem('negocioCat', negocioCat);
            this.router.navigate(['/' + window.location.pathname + '/' + negocioCat]);
        };
    }
    ngOnDestroy() {
        this.catalogos$.unsubscribe();
    }
    ngOnInit() {
        this.catalogos$ = this.store
            .select(({ catalogos }) => catalogos.catalogos)
            .subscribe((res) => {
            this.AforesGens = [];
            this.AforesSubs = [];
            this.FondosGens = [];
            this.FondosSubs = [];
            this.GenericosGens = [];
            if (res) {
                res.forEach((e) => {
                    if (e.INTERFAZ === 'GEN') {
                        this.GenericosGens.push(e);
                    }
                    else {
                        // console.log(e.NEGOCIO);
                        // console.log(e.NEGOCIO.split(','))
                        e.NEGOCIO.split(',').forEach((elementd) => {
                            if (elementd === 'AFORE') {
                                let index = this.AforesSubs.findIndex((x) => x.INTERFAZ === e.INTERFAZ);
                                if (index === -1) {
                                    this.AforesSubs.push({
                                        INTERFAZ: e.INTERFAZ,
                                        SUBMENUS: [e],
                                    });
                                }
                                else {
                                    this.AforesSubs[index].SUBMENUS.push(e);
                                }
                            }
                            else {
                                // console.log('')
                                let index = this.FondosSubs.findIndex((x) => x.INTERFAZ === e.INTERFAZ);
                                if (index === -1) {
                                    this.FondosSubs.push({
                                        INTERFAZ: e.INTERFAZ,
                                        SUBMENUS: [e],
                                    });
                                }
                                else {
                                    this.FondosSubs[index].SUBMENUS.push(e);
                                }
                            }
                        });
                    }
                });
            }
        });
    }
}
CatalogosComponent.ɵfac = function CatalogosComponent_Factory(t) { return new (t || CatalogosComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_ngrx_store__WEBPACK_IMPORTED_MODULE_1__["Store"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_services_catalogos_service__WEBPACK_IMPORTED_MODULE_3__["CatalogosService"])); };
CatalogosComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: CatalogosComponent, selectors: [["app-catalogos"]], decls: 7, vars: 3, consts: [["id", "optionshome"], [1, "container-fluid"], [1, "d-flex", 2, "height", "75vh", "width", "100%"], [1, "row", 2, "width", "100%"], ["class", "col-lg-4 col-md-12 col-sm-12 col-xs-12", 4, "ngIf"], [1, "col-lg-4", "col-md-12", "col-sm-12", "col-xs-12"], [1, "card", "cardAzul", 2, "padding-left", "10px"], [1, "card-body", "cardCatalogos"], [1, "d-flex", "flex-column"], [1, "elementsMenus", "d-flex", "flex-column"], [1, "acomodardorDeLista"], [1, "tituloPrincipalCatalogos"], [1, "spanColorCatalogosListaTituloPricipal"], ["class", "subtitulosCatalogos", 3, "click", 4, "ngFor", "ngForOf"], ["class", "acomodardorDeLista", 4, "ngFor", "ngForOf"], [1, "subtitulosCatalogos", 3, "click"], [3, "click"]], template: function CatalogosComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "section", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](4, CatalogosComponent_div_4_Template, 14, 2, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](5, CatalogosComponent_div_5_Template, 14, 2, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](6, CatalogosComponent_div_6_Template, 13, 1, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.AforesSubs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.FondosSubs.length > 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.GenericosGens.length > 0);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_4__["NgIf"], _angular_common__WEBPACK_IMPORTED_MODULE_4__["NgForOf"]], styles: [".center[_ngcontent-%COMP%] {\r\n    display: block;\r\n    margin-left: auto;\r\n    margin-right: auto;\r\n  }\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhdGFsb2dvcy5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksY0FBYztJQUNkLGlCQUFpQjtJQUNqQixrQkFBa0I7RUFDcEIiLCJmaWxlIjoiY2F0YWxvZ29zLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY2VudGVyIHtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgbWFyZ2luLWxlZnQ6IGF1dG87XHJcbiAgICBtYXJnaW4tcmlnaHQ6IGF1dG87XHJcbiAgfVxyXG4iXX0= */"] });


/***/ }),

/***/ "I2N7":
/*!**********************************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/administracion/catalogos/catalogos-routing.module.ts ***!
  \**********************************************************************************************/
/*! exports provided: CatalogosRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CatalogosRoutingModule", function() { return CatalogosRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _catalogos_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./catalogos.component */ "08MV");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");




const routes = [
    { path: '', component: _catalogos_component__WEBPACK_IMPORTED_MODULE_1__["CatalogosComponent"] },
    { path: ':nombreCatalogo', loadChildren: () => __webpack_require__.e(/*! import() | detalle-catalogo-detalle-catalogo-module */ "detalle-catalogo-detalle-catalogo-module").then(__webpack_require__.bind(null, /*! ./detalle-catalogo/detalle-catalogo.module */ "NIfD")).then(m => m.DetalleCatalogoModule) }
];
class CatalogosRoutingModule {
}
CatalogosRoutingModule.ɵfac = function CatalogosRoutingModule_Factory(t) { return new (t || CatalogosRoutingModule)(); };
CatalogosRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: CatalogosRoutingModule });
CatalogosRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](CatalogosRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] }); })();


/***/ }),

/***/ "IxWP":
/*!************************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/auditoria/catalogos/catalogos.component.ts ***!
  \************************************************************************************/
/*! exports provided: CatalogosComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CatalogosComponent", function() { return CatalogosComponent; });
/* harmony import */ var _ReduxStore_actions_usuarios_AUDGENUSUARIOS_actions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../../../../ReduxStore/actions/usuarios/AUDGENUSUARIOS.actions */ "n68H");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngrx/store */ "l7P3");
/* harmony import */ var _API_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../../API.service */ "iO9l");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "1kSV");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ngx-spinner */ "JqCM");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/auth.service */ "lGQG");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var ng_multiselect_dropdown__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ng-multiselect-dropdown */ "Egam");
/* harmony import */ var ngx_pagination__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ngx-pagination */ "oOf3");












function CatalogosComponent_section_0_div_26_div_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](6, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](7, " No existen registros para esta b\u00FAsqueda.");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} }
function CatalogosComponent_section_0_div_26_div_2_tr_13_Template(rf, ctx) { if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "td", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "td", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "td", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](7, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](8, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](9, "td", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](11, "td", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](12, "center");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](13, "img", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function CatalogosComponent_section_0_div_26_div_2_tr_13_Template_img_click_13_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r14); const itemAuditoria_r11 = ctx.$implicit; const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](4); return ctx_r13.openModal(itemAuditoria_r11); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const itemAuditoria_r11 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"]("", itemAuditoria_r11.CATALOGOS.DESCRIPCION, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate2"]("", itemAuditoria_r11.USUARIO.NOMBRE, " ", itemAuditoria_r11.USUARIO.APELLIDO_PATERNO, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate2"]("", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind2"](7, 6, itemAuditoria_r11.FECHA, "dd/MM/yyyy"), " ", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind2"](8, 9, itemAuditoria_r11.FECHA, "mediumTime"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"]("", itemAuditoria_r11.CATALOGOS.ACCION, " ");
} }
function CatalogosComponent_section_0_div_26_div_2_span_20_Template(rf, ctx) { if (rf & 1) {
    const _r16 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "span", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function CatalogosComponent_section_0_div_26_div_2_span_20_Template_span_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r16); _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵreference"](17); return _r7.previous(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1, " << ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} }
function CatalogosComponent_section_0_div_26_div_2_div_21_span_1_Template(rf, ctx) { if (rf & 1) {
    const _r22 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "span", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function CatalogosComponent_section_0_div_26_div_2_div_21_span_1_Template_span_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r22); const page_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit; _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵreference"](17); return _r7.setCurrent(page_r17.value); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const page_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](page_r17.label);
} }
function CatalogosComponent_section_0_div_26_div_2_div_21_div_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const page_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate"](page_r17.label);
} }
function CatalogosComponent_section_0_div_26_div_2_div_21_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](1, CatalogosComponent_section_0_div_26_div_2_div_21_span_1_Template, 2, 1, "span", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](2, CatalogosComponent_section_0_div_26_div_2_div_21_div_2_Template, 3, 1, "div", 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const page_r17 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵreference"](17);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵclassProp"]("current", _r7.getCurrent() === page_r17.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", _r7.getCurrent() !== page_r17.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", _r7.getCurrent() === page_r17.value);
} }
function CatalogosComponent_section_0_div_26_div_2_span_23_Template(rf, ctx) { if (rf & 1) {
    const _r26 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "span", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function CatalogosComponent_section_0_div_26_div_2_span_23_Template_span_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r26); _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵreference"](17); return _r7.next(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1, " >> ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} }
const _c0 = function (a2) { return { id: "auditoria", itemsPerPage: 10, currentPage: a2 }; };
function CatalogosComponent_section_0_div_26_div_2_Template(rf, ctx) { if (rf & 1) {
    const _r28 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "table", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "th", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](4, "Cat\u00E1logo");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "th", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](6, "Usuario");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](7, "th", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](8, "Fecha");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](9, "th", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](10, "Acci\u00F3n");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](11, "th", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](12, "Detalle");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](13, CatalogosComponent_section_0_div_26_div_2_tr_13_Template, 14, 12, "tr", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](14, "paginate");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](15, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](16, "pagination-template", 34, 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("pageChange", function CatalogosComponent_section_0_div_26_div_2_Template_pagination_template_pageChange_16_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r28); const ctx_r27 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](3); return ctx_r27.paginaActual = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](18, "div", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](19, "div", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](20, CatalogosComponent_section_0_div_26_div_2_span_20_Template, 2, 0, "span", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](21, CatalogosComponent_section_0_div_26_div_2_div_21_Template, 3, 4, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](22, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](23, CatalogosComponent_section_0_div_26_div_2_span_23_Template, 2, 0, "span", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵreference"](17);
    const ListadoPantalla_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().ngIf;
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind2"](14, 8, ListadoPantalla_r3, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction1"](11, _c0, ctx_r5.paginaActual)));
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵclassProp"]("disabled", _r7.isFirstPage());
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", !_r7.isFirstPage());
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", _r7.pages);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵclassProp"]("disabled", _r7.isLastPage());
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", !_r7.isLastPage());
} }
function CatalogosComponent_section_0_div_26_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](1, CatalogosComponent_section_0_div_26_div_1_Template, 8, 0, "div", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](2, CatalogosComponent_section_0_div_26_div_2_Template, 24, 13, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ListadoPantalla_r3 = ctx.ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ListadoPantalla_r3.length === 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ListadoPantalla_r3.length !== 0);
} }
const _c1 = function () { return { standalone: true }; };
function CatalogosComponent_section_0_Template(rf, ctx) { if (rf & 1) {
    const _r31 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "section");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "ngx-spinner", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "p", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](3, " Cargando... ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](6, "Buscar por");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](7, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](8, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](9, "a", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function CatalogosComponent_section_0_Template_a_click_9_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r31); const ctx_r30 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); return ctx_r30.limpirarFiltro(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](10, "Eliminar Filtro ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](11, "img", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](12, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](13, "section", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](14, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](15, "ng-multiselect-dropdown", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function CatalogosComponent_section_0_Template_ng_multiselect_dropdown_ngModelChange_15_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r31); const ctx_r32 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); return ctx_r32.selectedItemsFiltroCatalogo = $event; })("onSelect", function CatalogosComponent_section_0_Template_ng_multiselect_dropdown_onSelect_15_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r31); const ctx_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); return ctx_r33.cambiarEtiquetaSeleccionadaGeneral("filtroCatalogo"); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](16, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](17, "ng-multiselect-dropdown", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function CatalogosComponent_section_0_Template_ng_multiselect_dropdown_ngModelChange_17_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r31); const ctx_r34 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); return ctx_r34.selectedItemsFiltroAccion = $event; })("onSelect", function CatalogosComponent_section_0_Template_ng_multiselect_dropdown_onSelect_17_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r31); const ctx_r35 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); return ctx_r35.cambiarEtiquetaSeleccionadaGeneral("filtroAccion"); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](18, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](19, "ng-multiselect-dropdown", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function CatalogosComponent_section_0_Template_ng_multiselect_dropdown_ngModelChange_19_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r31); const ctx_r36 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); return ctx_r36.selectedItemsFiltroCorreo = $event; })("onSelect", function CatalogosComponent_section_0_Template_ng_multiselect_dropdown_onSelect_19_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r31); const ctx_r37 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); return ctx_r37.cambiarEtiquetaSeleccionadaGeneral("filtroCorreo"); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](20, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](21, "input", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](22, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](23, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](24, "button", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function CatalogosComponent_section_0_Template_button_click_24_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r31); const ctx_r38 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); return ctx_r38.filtrar(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](25, "Buscar");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](26, CatalogosComponent_section_0_div_26_Template, 3, 2, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("fullScreen", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](11);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("formGroup", ctx_r0.filtroAuditoriaCatalogosForm);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("placeholder", "Cat\u00E1logo")("settings", ctx_r0.SettingsFiltroDeCatalogo)("data", ctx_r0.dropdownListFiltroCatalogo)("ngModel", ctx_r0.selectedItemsFiltroCatalogo)("ngModelOptions", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction0"](23, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("placeholder", "Acci\u00F3n")("settings", ctx_r0.SettingsFiltroDeAccion)("data", ctx_r0.dropdownListFiltroAccion)("ngModel", ctx_r0.selectedItemsFiltroAccion)("ngModelOptions", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction0"](24, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("placeholder", "Correo electr\u00F3nico")("settings", ctx_r0.SettingsFiltroDeCorreo)("data", ctx_r0.dropdownListFiltroCorreo)("ngModel", ctx_r0.selectedItemsFiltroCorreo)("ngModelOptions", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction0"](25, _c1));
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpropertyInterpolate"]("max", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind2"](22, 20, ctx_r0.maxDate, "yyyy-MM-dd"));
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("value", ctx_r0.maxDate);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx_r0.ListadoPantalla);
} }
function CatalogosComponent_section_1_tr_20_td_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "td", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r40 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"]("", item_r40.valor, " ");
} }
function CatalogosComponent_section_1_tr_20_td_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "td", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r40 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"]("", item_r40.antes, " ");
} }
function CatalogosComponent_section_1_tr_20_td_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "td", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r40 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"]("", item_r40.despues, " ");
} }
function CatalogosComponent_section_1_tr_20_td_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "td", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r40 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"]("", item_r40.valor, " ");
} }
function CatalogosComponent_section_1_tr_20_td_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "td", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r40 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"]("", item_r40.antes, " ");
} }
function CatalogosComponent_section_1_tr_20_td_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "td", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r40 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"]("", item_r40.despues, " ");
} }
function CatalogosComponent_section_1_tr_20_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](1, CatalogosComponent_section_1_tr_20_td_1_Template, 2, 1, "td", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](2, CatalogosComponent_section_1_tr_20_td_2_Template, 2, 1, "td", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](3, CatalogosComponent_section_1_tr_20_td_3_Template, 2, 1, "td", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](4, CatalogosComponent_section_1_tr_20_td_4_Template, 2, 1, "td", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](5, CatalogosComponent_section_1_tr_20_td_5_Template, 2, 1, "td", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](6, CatalogosComponent_section_1_tr_20_td_6_Template, 2, 1, "td", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r40 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", item_r40.cambio);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", item_r40.cambio);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", item_r40.cambio);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", !item_r40.cambio);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", !item_r40.cambio);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", !item_r40.cambio);
} }
function CatalogosComponent_section_1_Template(rf, ctx) { if (rf & 1) {
    const _r54 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "section");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](3, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "p", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](7, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](8, "p", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](10, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipe"](11, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](12, "table", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](13, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](14, "th", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](15, "Campo");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](16, "th", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](17, "Valor previo");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](18, "th", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](19, "Valor actual");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](20, CatalogosComponent_section_1_tr_20_Template, 7, 6, "tr", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](21, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](22, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](23, "button", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function CatalogosComponent_section_1_Template_button_click_23_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r54); const ctx_r53 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); return ctx_r53.ocultarModal(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](24, " Cerrar ");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"]("Detalle de cambios sobre ", ctx_r1.detalleCambios.catalogo, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate3"](" Realizados por ", ctx_r1.detalleCambios.usuario, " el ", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind2"](10, 5, ctx_r1.detalleCambios.fecha, "dd/MM/yyyy"), " a las ", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpipeBind2"](11, 8, ctx_r1.detalleCambios.fecha, "mediumTime"), " hrs.");
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](11);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", ctx_r1.itemsTabla);
} }
class CatalogosComponent {
    constructor(store, api, modalService, spinner, fb, authService) {
        this.store = store;
        this.api = api;
        this.modalService = modalService;
        this.spinner = spinner;
        this.fb = fb;
        this.authService = authService;
        this.itemsCorreos = [];
        this.itemsCatalogos = [];
        this.itemsAcciones = [];
        this.itemsTabla = [];
        this.dropdownListFiltroCatalogo = [];
        this.SettingsFiltroDeCatalogo = {};
        this.selectedItemsFiltroCatalogo = [];
        this.dropdownListFiltroAccion = [];
        this.SettingsFiltroDeAccion = {};
        this.selectedItemsFiltroAccion = [];
        this.dropdownListFiltroCorreo = [];
        this.SettingsFiltroDeCorreo = {};
        this.selectedItemsFiltroCorreo = [];
        this.paginaActual = 1;
        this.verModal = false;
        this.ListadoPantalla = [];
        this.ListadoOriginal = [];
        this.initSelects = () => {
            this.maxDate = new Date();
            this.filtroAuditoriaCatalogosForm = this.fb.group({
                filtroFecha: []
            });
            if (this.itemsCatalogos.length > 0) {
                let arregloCatalogos = [];
                for (let i in this.itemsCatalogos) {
                    arregloCatalogos.push({ item_id: this.itemsCatalogos[i], item_text: this.itemsCatalogos[i] });
                }
                this.dropdownListFiltroCatalogo = arregloCatalogos;
            }
            if (this.itemsAcciones.length > 0) {
                let arregloAcciones = [];
                for (let i in this.itemsAcciones) {
                    arregloAcciones.push({ item_id: this.itemsAcciones[i], item_text: this.itemsAcciones[i] });
                }
                this.dropdownListFiltroAccion = arregloAcciones;
            }
            if (this.itemsCorreos.length > 0) {
                let arregloCorreos = [];
                for (let i in this.itemsCorreos) {
                    arregloCorreos.push({ item_id: this.itemsCorreos[i], item_text: this.itemsCorreos[i] });
                }
                this.dropdownListFiltroCorreo = arregloCorreos;
            }
            this.SettingsFiltroDeCatalogo = {
                singleSelection: false,
                idField: 'item_id',
                textField: 'item_text',
                allowSearchFilter: false,
                clearSearchFilter: false,
                enableCheckAll: false,
                maxHeight: 200,
                itemsShowLimit: 3,
            };
            this.SettingsFiltroDeAccion = {
                singleSelection: false,
                idField: 'item_id',
                textField: 'item_text',
                allowSearchFilter: false,
                clearSearchFilter: false,
                enableCheckAll: false,
                maxHeight: 200,
                itemsShowLimit: 3,
            };
            this.SettingsFiltroDeCorreo = {
                singleSelection: false,
                idField: 'item_id',
                textField: 'item_text',
                allowSearchFilter: false,
                clearSearchFilter: false,
                enableCheckAll: false,
                maxHeight: 200,
                itemsShowLimit: 3,
            };
        };
        this.limpirarFiltro = () => {
            this.selectedItemsFiltroCatalogo = [];
            this.selectedItemsFiltroAccion = [];
            this.selectedItemsFiltroCorreo = [];
            this.ListadoPantalla = this.ListadoOriginal;
            this.filtroAuditoriaCatalogosForm.reset();
        };
        this.filtrar = () => {
            this.spinner.show();
            let FiltrarCatalogo = null;
            let FiltrarAccion = null;
            let FiltrarCorreo = null;
            let FiltrarFecha = this.filtroAuditoriaCatalogosForm.get('filtroFecha').value; //yyyy-mm-dd
            if (this.selectedItemsFiltroCatalogo.length !== 0) {
                let arrayFiltroCatalogo = [];
                this.selectedItemsFiltroCatalogo.forEach((e) => {
                    arrayFiltroCatalogo.push(e.item_id);
                });
                FiltrarCatalogo = arrayFiltroCatalogo;
            }
            console.log(this.selectedItemsFiltroAccion);
            if (this.selectedItemsFiltroAccion.length !== 0) {
                let arrayFiltroAccion = [];
                this.selectedItemsFiltroAccion.forEach((e) => {
                    arrayFiltroAccion.push(e.item_id);
                });
                FiltrarAccion = arrayFiltroAccion;
            }
            if (this.selectedItemsFiltroCorreo.length !== 0) {
                let arrayFiltroCorreo = [];
                this.selectedItemsFiltroCorreo.forEach((e) => {
                    arrayFiltroCorreo.push(e.item_id);
                });
                FiltrarCorreo = arrayFiltroCorreo;
            }
            this.ListadoPantalla = this.filtrarCatalogosConAtributos(this.ListadoOriginal, FiltrarCatalogo, FiltrarAccion, FiltrarCorreo, FiltrarFecha);
            setTimeout(() => {
                this.spinner.hide();
            }, 300);
        };
    }
    ngOnDestroy() {
        this.store.dispatch(Object(_ReduxStore_actions_usuarios_AUDGENUSUARIOS_actions__WEBPACK_IMPORTED_MODULE_0__["UnsetAUDGENUSUARIO"])());
    }
    enProceso() {
        return false;
    }
    mostrarDetalle() {
        return this.verModal;
    }
    cambiarEtiquetaSeleccionadaGeneral(elemento) {
        setTimeout(() => {
            $('#' + elemento)
                .find('.selected-item')
                .attr('class', 'etiquetasCatalogos');
        }, 1);
    }
    ngOnInit() {
        this.AUDGENUSUARIOS$ = this.store.select(({ AUDGENUSUARIOS }) => AUDGENUSUARIOS.AUDGENUSUARIOS).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])(res => {
            if (res === null)
                return res;
            else
                return res.slice().sort(function (a, b) { return new Date(b.FECHA).getTime() - new Date(a.FECHA).getTime(); });
        }));
        this.store.select(({ AUDGENUSUARIOS }) => AUDGENUSUARIOS.AUDGENUSUARIOS).subscribe(res => {
            for (let i in res) {
                if (!this.itemsCorreos.includes(res[i].CORREO)) {
                    this.itemsCorreos.push(res[i].CORREO);
                }
            }
            for (let i in res) {
                if (!this.itemsCatalogos.includes(res[i].CATALOGOS.DESCRIPCION)) {
                    this.itemsCatalogos.push(res[i].CATALOGOS.DESCRIPCION);
                }
            }
            for (let i in res) {
                if (!this.itemsAcciones.includes(res[i].CATALOGOS.ACCION)) {
                    this.itemsAcciones.push(res[i].CATALOGOS.ACCION);
                }
            }
            this.itemsCatalogos.sort();
            this.itemsAcciones.sort();
            this.itemsCorreos.sort();
            if (res === null) {
                //console.log("response", res)
            }
            else {
                let resp = res.slice().sort(function (a, b) { return new Date(b.FECHA).getTime() - new Date(a.FECHA).getTime(); });
                //console.log("response slice", resp)
                this.ListadoOriginal = resp;
            }
            this.ListadoPantalla = this.ListadoOriginal;
            this.initSelects();
        });
        this.store.dispatch(Object(_ReduxStore_actions_usuarios_AUDGENUSUARIOS_actions__WEBPACK_IMPORTED_MODULE_0__["LoadAUDGENUSUARIOS"])({ consult: { MODULO: 'CATALOGOS' } }));
        /*
        this.api.ListAUDGENUSUARIOS('CATALOGOS').then(res => {
          //console.log("Response ListAUDGENUSUARIOS", res)
        })
        */
    }
    ocultarModal() {
        this.verModal = false;
    }
    openModal(objetoDetalle) {
        this.itemsTabla = [];
        let accion = objetoDetalle.CATALOGOS.ACCION;
        let valores = [];
        let tabla = [];
        let arregloAntes = [];
        let arregloDespues = [];
        let cambiosAntes = objetoDetalle.CATALOGOS.DETALLE_MODIFICACIONES[0].valorAnterior;
        let cambiosDespues = objetoDetalle.CATALOGOS.DETALLE_MODIFICACIONES[0].valorNuevo;
        let valorAntes;
        let valorDespues;
        let banderaCambio = false;
        this.detalleCambios = {
            catalogo: objetoDetalle.CATALOGOS.DESCRIPCION,
            usuario: objetoDetalle.USUARIO.NOMBRE + ' ' + objetoDetalle.USUARIO.APELLIDO_PATERNO,
            fecha: objetoDetalle.FECHA
        };
        if (cambiosAntes !== null) {
            cambiosAntes = cambiosAntes.replace('{', '');
            cambiosAntes = cambiosAntes.replace('}', '');
        }
        if (cambiosDespues !== null) {
            cambiosDespues = cambiosDespues.replace('{', '');
            cambiosDespues = cambiosDespues.replace('}', '');
        }
        if (accion === 'ELIMINAR') {
            let getValor = cambiosAntes.split(',');
            for (let i in getValor) {
                if (getValor) {
                    let valor = getValor[i].toString().split('=');
                    valores.push(valor[0]);
                }
            }
            arregloAntes = cambiosAntes.split(',');
        }
        else {
            let getValor = cambiosDespues.split(',');
            for (let i in getValor) {
                if (getValor) {
                    let valor = getValor[i].toString().split('=');
                    valores.push(valor[0]);
                }
            }
            if (cambiosAntes !== null) {
                arregloAntes = cambiosAntes.split(',');
                arregloDespues = cambiosDespues.split(',');
            }
            else {
                arregloDespues = cambiosDespues.split(',');
            }
        }
        if (valores !== null) {
            for (let i in valores) {
                if (valores) {
                    if (arregloAntes.length > 0) {
                        valorAntes = arregloAntes.find(e => e.includes(valores[i])).split('=')[1];
                    }
                    else {
                        valorAntes = '';
                    }
                    if (arregloDespues.length > 0) {
                        valorDespues = arregloDespues.find(e => e.includes(valores[i])).split('=')[1];
                    }
                    else {
                        valorDespues = '';
                    }
                    if (valorAntes === valorDespues) {
                        banderaCambio = false;
                    }
                    else {
                        banderaCambio = true;
                    }
                    tabla.push({ valor: valores[i], antes: valorAntes, despues: valorDespues, cambio: banderaCambio });
                }
            }
        }
        this.itemsTabla = tabla;
        this.verModal = true;
    }
    filtrarCatalogosConAtributos(ListadoOriginal, FiltrarCatalogo, FiltrarAccion, FiltrarCorreo, FiltrarFecha) {
        let response = ListadoOriginal;
        if (FiltrarCatalogo != null) {
            let arrayTempPermiso = [];
            FiltrarCatalogo.forEach((FiltrarCatalogo) => {
                arrayTempPermiso = [
                    ...arrayTempPermiso,
                    ...response.filter((e) => e.CATALOGOS.DESCRIPCION === FiltrarCatalogo),
                ];
            });
            response = arrayTempPermiso;
        }
        if (FiltrarAccion != null) {
            let arrayTempPermiso = [];
            FiltrarAccion.forEach((FiltrarAccion) => {
                arrayTempPermiso = [
                    ...arrayTempPermiso,
                    ...response.filter((e) => e.CATALOGOS.ACCION === FiltrarAccion),
                ];
            });
            response = arrayTempPermiso;
        }
        if (FiltrarCorreo != null) {
            let arrayTempPermiso = [];
            FiltrarCorreo.forEach((FiltrarCorreo) => {
                arrayTempPermiso = [
                    ...arrayTempPermiso,
                    ...response.filter((e) => e.CORREO === FiltrarCorreo),
                ];
            });
            response = arrayTempPermiso;
        }
        if (FiltrarFecha != null) {
            let arrayTempFecha = [];
            arrayTempFecha = response.filter((e) => e.FECHA.includes(FiltrarFecha));
            response = arrayTempFecha;
        }
        const uniqueArr = [...new Set(response.map(data => data.ID))];
        //console.log(uniqueArr)
        return response;
    }
}
CatalogosComponent.ɵfac = function CatalogosComponent_Factory(t) { return new (t || CatalogosComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_ngrx_store__WEBPACK_IMPORTED_MODULE_3__["Store"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_API_service__WEBPACK_IMPORTED_MODULE_4__["APIService"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_5__["NgbModal"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_6__["NgxSpinnerService"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormBuilder"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_8__["AuthService"])); };
CatalogosComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({ type: CatalogosComponent, selectors: [["app-catalogos"]], decls: 2, vars: 2, consts: [[4, "ngIf"], ["bdColor", "rgba(0,0,0,0.5)", "size", "default", "color", "#fff", "type", "ball-scale-ripple", 3, "fullScreen"], [2, "color", "white"], [1, "card-busqueda"], [1, "mt-4"], [2, "text-align", "right", "width", "100%", "justify-content", "flex-end", "direction", "rtl"], [2, "margin-right", "10%"], [1, "limpiarFiltro", 3, "click"], ["src", "assets/icons/Eliminar.svg", 1, "tamanioFiltroIcono"], ["name", "filtros", 3, "formGroup"], [1, "mt-3"], [1, "col2-row2"], ["id", "filtroCatalogo", 2, "width", "80%", "padding-left", "10px", 3, "placeholder", "settings", "data", "ngModel", "ngModelOptions", "ngModelChange", "onSelect"], ["id", "filtroAccion", 2, "width", "80%", 3, "placeholder", "settings", "data", "ngModel", "ngModelOptions", "ngModelChange", "onSelect"], ["id", "filtroCorreo", 2, "width", "80%", "padding-left", "10px", 3, "placeholder", "settings", "data", "ngModel", "ngModelOptions", "ngModelChange", "onSelect"], ["type", "date", "placeholder", "dd-MM-yyyy", "onfocus", "(this.type='date')", "id", "filtroFecha", "formControlName", "filtroFecha", "name", "filtroFecha", 2, "width", "80%", "padding-left", "10px", 3, "value", "max"], [2, "cursor", "pointer", 3, "click"], ["class", "d-flex col-md-12 col-sm-12 col-xs-12 col-lg-12 col-xl-12 justify-content-center", 4, "ngIf"], [1, "d-flex", "col-md-12", "col-sm-12", "col-xs-12", "col-lg-12", "col-xl-12", "justify-content-center"], ["class", "row justify-content-center", 4, "ngIf"], ["class", "card-lista-design-general", "style", "overflow-x: auto", 4, "ngIf"], [1, "row", "justify-content-center"], [1, "align-self-center"], [1, "d-flex", "flex-column", 2, "width", "504px"], [1, "descripcionNoAuditoria", 2, "margin-top", "34px"], [1, "row"], [1, "col-12"], [1, "card-lista-design-general", 2, "overflow-x", "auto"], [1, "table", "listado-design-general"], [2, "padding-left", "40px", "max-width", "300px"], [2, "padding-left", "30px", "max-width", "300px"], [2, "padding-left", "30px", "max-width", "150px"], [4, "ngFor", "ngForOf"], [1, "paginator", "align-items-left"], ["id", "auditoria", 1, "ngx-pagination", 3, "pageChange"], ["p", "paginationApi"], [1, "custom-pagination"], [1, "pagination-previous"], [3, "click", 4, "ngIf"], ["class", "page-number", 3, "current", 4, "ngFor", "ngForOf"], [1, "pagination-next"], [1, "justify-content-center", 2, "width", "200px"], [1, "detalle-icon", 2, "cursor", "pointer", 3, "click"], [3, "click"], [1, "page-number"], [1, "titulo-modal"], [1, "texto-modal"], [1, "btn", "bottonCerrarModal", 3, "click"], ["style", "padding-left: 30px; max-width: 150px; background-color:#0091DA; color: #ffffff", 4, "ngIf"], ["style", "padding-left: 30px; max-width: 150px", 4, "ngIf"], [2, "padding-left", "30px", "max-width", "150px", "background-color", "#0091DA", "color", "#ffffff"]], template: function CatalogosComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](0, CatalogosComponent_section_0_Template, 27, 26, "section", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](1, CatalogosComponent_section_1_Template, 25, 11, "section", 0);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", !ctx.mostrarDetalle());
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.mostrarDetalle());
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_9__["NgIf"], ngx_spinner__WEBPACK_IMPORTED_MODULE_6__["NgxSpinnerComponent"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormGroupDirective"], ng_multiselect_dropdown__WEBPACK_IMPORTED_MODULE_10__["MultiSelectComponent"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__["NgModel"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormControlName"], _angular_common__WEBPACK_IMPORTED_MODULE_9__["NgForOf"], ngx_pagination__WEBPACK_IMPORTED_MODULE_11__["PaginationControlsDirective"]], pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_9__["DatePipe"], ngx_pagination__WEBPACK_IMPORTED_MODULE_11__["PaginatePipe"]], styles: [".center[_ngcontent-%COMP%] {\r\n  display: block;\r\n  margin-left: auto;\r\n  margin-right: auto;\r\n}\r\n\r\n.wrapper[_ngcontent-%COMP%] {\r\n  display: flex;\r\n  flex-wrap: wrap;\r\n}\r\n\r\n.content[_ngcontent-%COMP%] {\r\n  width: 100%;\r\n  display: flex;\r\n  flex-wrap: wrap;\r\n  flex-direction: column;\r\n}\r\n\r\ndiv.card-busqueda[_ngcontent-%COMP%] {\r\n  width: 90%;\r\n  background: #ffffff 0% 0% no-repeat padding-box;\r\n  border-radius: 30px;\r\n  opacity: 1;\r\n  display: flex;\r\n  margin: 25px 0;\r\n  margin-right: 5%;\r\n  margin-left: 5%;\r\n  flex-direction: column;\r\n  align-items: center;\r\n  border-radius: 25px;\r\n  border-left: 10px solid #035fa4;\r\n  box-shadow: 4px 4px 10px #00000033;\r\n}\r\n\r\n.card-busqueda[_ngcontent-%COMP%]   div[_ngcontent-%COMP%] {\r\n  color: #035fa4;\r\n  border: black;\r\n  height: auto;\r\n  width: auto;\r\n  flex-grow: 1;\r\n  display: flex;\r\n  align-items: center;\r\n  font: bold 20px FS Elliot Pro;\r\n}\r\n\r\n.card-busqueda[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]    > button[_ngcontent-%COMP%] {\r\n  background-color: #0091da;\r\n  color: white;\r\n  width: 296px;\r\n  height: 50px;\r\n  border-radius: 25px;\r\n  font: bold 20px FS Elliot Pro;\r\n  border: none;\r\n}\r\n\r\ndiv.card-lista-design-general[_ngcontent-%COMP%] {\r\n  width: auto;\r\n  min-width: 477px;\r\n  flex: auto;\r\n  display: flex;\r\n  flex-wrap: wrap;\r\n  vertical-align: middle;\r\n}\r\n\r\ntable.listado-design-general[_ngcontent-%COMP%]   th[_ngcontent-%COMP%] {\r\n  background-color: #035fa4;\r\n  font: bold 18px FS Elliot Pro;\r\n  height: 40px;\r\n  height: 40px;\r\n  font: bold 18px FS Elliot Pro;\r\n}\r\n\r\nsection[_ngcontent-%COMP%] {\r\n  display: flex;\r\n  flex-wrap: wrap;\r\n  justify-content: space-between;\r\n}\r\n\r\n.col2-row2[_ngcontent-%COMP%] {\r\n  display: flex;\r\n  justify-content: center;\r\n  align-items: center;\r\n  flex-grow: 0;\r\n  flex-shrink: 0;\r\n  flex-basis: 50%;\r\n  margin-bottom: 1.5%;\r\n}\r\n\r\n.selectList[_ngcontent-%COMP%] {\r\n  text-align: left;\r\n  font: normal normal normal 18px/45px FS Elliot Pro;\r\n  letter-spacing: 0px;\r\n  color: #707070;\r\n  width: 296px;\r\n  height: 35px;\r\n  font: bold 18px FS Elliot Pro;\r\n  background: #ffffff 0% 0% no-repeat padding-box;\r\n  border: 1px solid #d6d6d6;\r\n  border-radius: 9px;\r\n  opacity: 1;\r\n}\r\n\r\n#correo[_ngcontent-%COMP%] {\r\n  width: 100%;\r\n}\r\n\r\n#correo[_ngcontent-%COMP%]   .selected-item[_ngcontent-%COMP%] {\r\n  width: 200px !important;\r\n}\r\n\r\n.limpiarFiltro[_ngcontent-%COMP%] {\r\n  text-align: right;\r\n  text-decoration: underline;\r\n  font: normal normal normal 14px/22px FS Elliot Pro;\r\n  letter-spacing: 0px;\r\n  -webkit-text-decoration: underline #0091da !important;\r\n          text-decoration: underline #0091da !important;\r\n  color: #0091da !important;\r\n}\r\n\r\n.limpiarFiltro[_ngcontent-%COMP%]:hover {\r\n  cursor: pointer;\r\n}\r\n\r\n.tamanioFiltroIcono[_ngcontent-%COMP%] {\r\n  width: 12px;\r\n  height: 12px;\r\n  margin-top: -4px;\r\n}\r\n\r\n.modal-content[_ngcontent-%COMP%] {\r\n  background-color: red !important;\r\n}\r\n\r\n.detalle-icon[_ngcontent-%COMP%] {\r\n  background: transparent url(\"/../../../../assets/icons/icono-detalle.svg\") 0%\r\n    0% no-repeat padding-box;\r\n  width: 30px;\r\n  height: 30px;\r\n  opacity: 1;\r\n  margin: 0 15px;\r\n  padding: 15px;\r\n}\r\n\r\n.bottonCerrarModal[_ngcontent-%COMP%] {\r\n  border: 2px solid #0091da;\r\n  border-radius: 30px;\r\n  opacity: 1;\r\n  width: 184px;\r\n  text-decoration: none;\r\n  height: 48px;\r\n  color: #0091da;\r\n  margin-right: 22px;\r\n  margin-top: 15px;\r\n  margin-bottom: 15px;\r\n  font: normal normal bold 20px/25px FS Elliot Pro;\r\n}\r\n\r\n.titulo[_ngcontent-%COMP%] {\r\n  font: bold 18px FS Elliot Pro;\r\n  color: #035fa4;\r\n}\r\n\r\n.titulo-modal[_ngcontent-%COMP%] {\r\n  font: bold 24px FS Elliot Pro;\r\n  color: #035fa4;\r\n}\r\n\r\n.texto-modal[_ngcontent-%COMP%] {\r\n  font: 18px FS Elliot Pro;\r\n  color: #035fa4;\r\n}\r\n\r\n.paginator[_ngcontent-%COMP%] {\r\n  margin-left: 5%;\r\n  margin-right: 5%;\r\n  margin-bottom: 5%;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhdGFsb2dvcy5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsY0FBYztFQUNkLGlCQUFpQjtFQUNqQixrQkFBa0I7QUFDcEI7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsZUFBZTtBQUNqQjs7QUFFQTtFQUNFLFdBQVc7RUFDWCxhQUFhO0VBQ2IsZUFBZTtFQUNmLHNCQUFzQjtBQUN4Qjs7QUFFQTtFQUNFLFVBQVU7RUFDViwrQ0FBK0M7RUFDL0MsbUJBQW1CO0VBQ25CLFVBQVU7RUFDVixhQUFhO0VBQ2IsY0FBYztFQUNkLGdCQUFnQjtFQUNoQixlQUFlO0VBQ2Ysc0JBQXNCO0VBQ3RCLG1CQUFtQjtFQUNuQixtQkFBbUI7RUFDbkIsK0JBQStCO0VBQy9CLGtDQUFrQztBQUNwQzs7QUFFQTtFQUNFLGNBQWM7RUFDZCxhQUFhO0VBQ2IsWUFBWTtFQUNaLFdBQVc7RUFDWCxZQUFZO0VBQ1osYUFBYTtFQUNiLG1CQUFtQjtFQUNuQiw2QkFBNkI7QUFDL0I7O0FBRUE7RUFDRSx5QkFBeUI7RUFDekIsWUFBWTtFQUNaLFlBQVk7RUFDWixZQUFZO0VBQ1osbUJBQW1CO0VBQ25CLDZCQUE2QjtFQUM3QixZQUFZO0FBQ2Q7O0FBRUE7RUFDRSxXQUFXO0VBQ1gsZ0JBQWdCO0VBQ2hCLFVBQVU7RUFDVixhQUFhO0VBQ2IsZUFBZTtFQUNmLHNCQUFzQjtBQUN4Qjs7QUFFQTtFQUNFLHlCQUF5QjtFQUN6Qiw2QkFBNkI7RUFDN0IsWUFBWTtFQUNaLFlBQVk7RUFDWiw2QkFBNkI7QUFDL0I7O0FBRUE7RUFDRSxhQUFhO0VBQ2IsZUFBZTtFQUNmLDhCQUE4QjtBQUNoQzs7QUFFQTtFQUNFLGFBQWE7RUFDYix1QkFBdUI7RUFDdkIsbUJBQW1CO0VBQ25CLFlBQVk7RUFDWixjQUFjO0VBQ2QsZUFBZTtFQUNmLG1CQUFtQjtBQUNyQjs7QUFFQTtFQUNFLGdCQUFnQjtFQUNoQixrREFBa0Q7RUFDbEQsbUJBQW1CO0VBQ25CLGNBQWM7RUFDZCxZQUFZO0VBQ1osWUFBWTtFQUNaLDZCQUE2QjtFQUM3QiwrQ0FBK0M7RUFDL0MseUJBQXlCO0VBQ3pCLGtCQUFrQjtFQUNsQixVQUFVO0FBQ1o7O0FBRUE7RUFDRSxXQUFXO0FBQ2I7O0FBRUE7RUFDRSx1QkFBdUI7QUFDekI7O0FBRUE7RUFDRSxpQkFBaUI7RUFDakIsMEJBQTBCO0VBQzFCLGtEQUFrRDtFQUNsRCxtQkFBbUI7RUFDbkIscURBQTZDO1VBQTdDLDZDQUE2QztFQUM3Qyx5QkFBeUI7QUFDM0I7O0FBRUE7RUFDRSxlQUFlO0FBQ2pCOztBQUVBO0VBQ0UsV0FBVztFQUNYLFlBQVk7RUFDWixnQkFBZ0I7QUFDbEI7O0FBRUE7RUFDRSxnQ0FBZ0M7QUFDbEM7O0FBRUE7RUFDRTs0QkFDMEI7RUFDMUIsV0FBVztFQUNYLFlBQVk7RUFDWixVQUFVO0VBQ1YsY0FBYztFQUNkLGFBQWE7QUFDZjs7QUFFQTtFQUNFLHlCQUF5QjtFQUN6QixtQkFBbUI7RUFDbkIsVUFBVTtFQUNWLFlBQVk7RUFDWixxQkFBcUI7RUFDckIsWUFBWTtFQUNaLGNBQWM7RUFDZCxrQkFBa0I7RUFDbEIsZ0JBQWdCO0VBQ2hCLG1CQUFtQjtFQUNuQixnREFBZ0Q7QUFDbEQ7O0FBRUE7RUFDRSw2QkFBNkI7RUFDN0IsY0FBYztBQUNoQjs7QUFFQTtFQUNFLDZCQUE2QjtFQUM3QixjQUFjO0FBQ2hCOztBQUVBO0VBQ0Usd0JBQXdCO0VBQ3hCLGNBQWM7QUFDaEI7O0FBRUE7RUFDRSxlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLGlCQUFpQjtBQUNuQiIsImZpbGUiOiJjYXRhbG9nb3MuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jZW50ZXIge1xyXG4gIGRpc3BsYXk6IGJsb2NrO1xyXG4gIG1hcmdpbi1sZWZ0OiBhdXRvO1xyXG4gIG1hcmdpbi1yaWdodDogYXV0bztcclxufVxyXG5cclxuLndyYXBwZXIge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC13cmFwOiB3cmFwO1xyXG59XHJcblxyXG4uY29udGVudCB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LXdyYXA6IHdyYXA7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxufVxyXG5cclxuZGl2LmNhcmQtYnVzcXVlZGEge1xyXG4gIHdpZHRoOiA5MCU7XHJcbiAgYmFja2dyb3VuZDogI2ZmZmZmZiAwJSAwJSBuby1yZXBlYXQgcGFkZGluZy1ib3g7XHJcbiAgYm9yZGVyLXJhZGl1czogMzBweDtcclxuICBvcGFjaXR5OiAxO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgbWFyZ2luOiAyNXB4IDA7XHJcbiAgbWFyZ2luLXJpZ2h0OiA1JTtcclxuICBtYXJnaW4tbGVmdDogNSU7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIGJvcmRlci1yYWRpdXM6IDI1cHg7XHJcbiAgYm9yZGVyLWxlZnQ6IDEwcHggc29saWQgIzAzNWZhNDtcclxuICBib3gtc2hhZG93OiA0cHggNHB4IDEwcHggIzAwMDAwMDMzO1xyXG59XHJcblxyXG4uY2FyZC1idXNxdWVkYSBkaXYge1xyXG4gIGNvbG9yOiAjMDM1ZmE0O1xyXG4gIGJvcmRlcjogYmxhY2s7XHJcbiAgaGVpZ2h0OiBhdXRvO1xyXG4gIHdpZHRoOiBhdXRvO1xyXG4gIGZsZXgtZ3JvdzogMTtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgZm9udDogYm9sZCAyMHB4IEZTIEVsbGlvdCBQcm87XHJcbn1cclxuXHJcbi5jYXJkLWJ1c3F1ZWRhIGRpdiA+IGJ1dHRvbiB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzAwOTFkYTtcclxuICBjb2xvcjogd2hpdGU7XHJcbiAgd2lkdGg6IDI5NnB4O1xyXG4gIGhlaWdodDogNTBweDtcclxuICBib3JkZXItcmFkaXVzOiAyNXB4O1xyXG4gIGZvbnQ6IGJvbGQgMjBweCBGUyBFbGxpb3QgUHJvO1xyXG4gIGJvcmRlcjogbm9uZTtcclxufVxyXG5cclxuZGl2LmNhcmQtbGlzdGEtZGVzaWduLWdlbmVyYWwge1xyXG4gIHdpZHRoOiBhdXRvO1xyXG4gIG1pbi13aWR0aDogNDc3cHg7XHJcbiAgZmxleDogYXV0bztcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtd3JhcDogd3JhcDtcclxuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xyXG59XHJcblxyXG50YWJsZS5saXN0YWRvLWRlc2lnbi1nZW5lcmFsIHRoIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDM1ZmE0O1xyXG4gIGZvbnQ6IGJvbGQgMThweCBGUyBFbGxpb3QgUHJvO1xyXG4gIGhlaWdodDogNDBweDtcclxuICBoZWlnaHQ6IDQwcHg7XHJcbiAgZm9udDogYm9sZCAxOHB4IEZTIEVsbGlvdCBQcm87XHJcbn1cclxuXHJcbnNlY3Rpb24ge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC13cmFwOiB3cmFwO1xyXG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxufVxyXG5cclxuLmNvbDItcm93MiB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIGZsZXgtZ3JvdzogMDtcclxuICBmbGV4LXNocmluazogMDtcclxuICBmbGV4LWJhc2lzOiA1MCU7XHJcbiAgbWFyZ2luLWJvdHRvbTogMS41JTtcclxufVxyXG5cclxuLnNlbGVjdExpc3Qge1xyXG4gIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgZm9udDogbm9ybWFsIG5vcm1hbCBub3JtYWwgMThweC80NXB4IEZTIEVsbGlvdCBQcm87XHJcbiAgbGV0dGVyLXNwYWNpbmc6IDBweDtcclxuICBjb2xvcjogIzcwNzA3MDtcclxuICB3aWR0aDogMjk2cHg7XHJcbiAgaGVpZ2h0OiAzNXB4O1xyXG4gIGZvbnQ6IGJvbGQgMThweCBGUyBFbGxpb3QgUHJvO1xyXG4gIGJhY2tncm91bmQ6ICNmZmZmZmYgMCUgMCUgbm8tcmVwZWF0IHBhZGRpbmctYm94O1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkICNkNmQ2ZDY7XHJcbiAgYm9yZGVyLXJhZGl1czogOXB4O1xyXG4gIG9wYWNpdHk6IDE7XHJcbn1cclxuXHJcbiNjb3JyZW8ge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG59XHJcblxyXG4jY29ycmVvIC5zZWxlY3RlZC1pdGVtIHtcclxuICB3aWR0aDogMjAwcHggIWltcG9ydGFudDtcclxufVxyXG5cclxuLmxpbXBpYXJGaWx0cm8ge1xyXG4gIHRleHQtYWxpZ246IHJpZ2h0O1xyXG4gIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xyXG4gIGZvbnQ6IG5vcm1hbCBub3JtYWwgbm9ybWFsIDE0cHgvMjJweCBGUyBFbGxpb3QgUHJvO1xyXG4gIGxldHRlci1zcGFjaW5nOiAwcHg7XHJcbiAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmUgIzAwOTFkYSAhaW1wb3J0YW50O1xyXG4gIGNvbG9yOiAjMDA5MWRhICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5saW1waWFyRmlsdHJvOmhvdmVyIHtcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbi50YW1hbmlvRmlsdHJvSWNvbm8ge1xyXG4gIHdpZHRoOiAxMnB4O1xyXG4gIGhlaWdodDogMTJweDtcclxuICBtYXJnaW4tdG9wOiAtNHB4O1xyXG59XHJcblxyXG4ubW9kYWwtY29udGVudCB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogcmVkICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5kZXRhbGxlLWljb24ge1xyXG4gIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50IHVybChcIi8uLi8uLi8uLi8uLi9hc3NldHMvaWNvbnMvaWNvbm8tZGV0YWxsZS5zdmdcIikgMCVcclxuICAgIDAlIG5vLXJlcGVhdCBwYWRkaW5nLWJveDtcclxuICB3aWR0aDogMzBweDtcclxuICBoZWlnaHQ6IDMwcHg7XHJcbiAgb3BhY2l0eTogMTtcclxuICBtYXJnaW46IDAgMTVweDtcclxuICBwYWRkaW5nOiAxNXB4O1xyXG59XHJcblxyXG4uYm90dG9uQ2VycmFyTW9kYWwge1xyXG4gIGJvcmRlcjogMnB4IHNvbGlkICMwMDkxZGE7XHJcbiAgYm9yZGVyLXJhZGl1czogMzBweDtcclxuICBvcGFjaXR5OiAxO1xyXG4gIHdpZHRoOiAxODRweDtcclxuICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbiAgaGVpZ2h0OiA0OHB4O1xyXG4gIGNvbG9yOiAjMDA5MWRhO1xyXG4gIG1hcmdpbi1yaWdodDogMjJweDtcclxuICBtYXJnaW4tdG9wOiAxNXB4O1xyXG4gIG1hcmdpbi1ib3R0b206IDE1cHg7XHJcbiAgZm9udDogbm9ybWFsIG5vcm1hbCBib2xkIDIwcHgvMjVweCBGUyBFbGxpb3QgUHJvO1xyXG59XHJcblxyXG4udGl0dWxvIHtcclxuICBmb250OiBib2xkIDE4cHggRlMgRWxsaW90IFBybztcclxuICBjb2xvcjogIzAzNWZhNDtcclxufVxyXG5cclxuLnRpdHVsby1tb2RhbCB7XHJcbiAgZm9udDogYm9sZCAyNHB4IEZTIEVsbGlvdCBQcm87XHJcbiAgY29sb3I6ICMwMzVmYTQ7XHJcbn1cclxuXHJcbi50ZXh0by1tb2RhbCB7XHJcbiAgZm9udDogMThweCBGUyBFbGxpb3QgUHJvO1xyXG4gIGNvbG9yOiAjMDM1ZmE0O1xyXG59XHJcblxyXG4ucGFnaW5hdG9yIHtcclxuICBtYXJnaW4tbGVmdDogNSU7XHJcbiAgbWFyZ2luLXJpZ2h0OiA1JTtcclxuICBtYXJnaW4tYm90dG9tOiA1JTtcclxufVxyXG4iXX0= */"] });


/***/ }),

/***/ "NJaF":
/*!*****************************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/auditoria/catalogos/catalogos-routing.module.ts ***!
  \*****************************************************************************************/
/*! exports provided: CatalogosRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CatalogosRoutingModule", function() { return CatalogosRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _catalogos_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./catalogos.component */ "IxWP");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");




const routes = [{ path: '', component: _catalogos_component__WEBPACK_IMPORTED_MODULE_1__["CatalogosComponent"] }];
class CatalogosRoutingModule {
}
CatalogosRoutingModule.ɵfac = function CatalogosRoutingModule_Factory(t) { return new (t || CatalogosRoutingModule)(); };
CatalogosRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: CatalogosRoutingModule });
CatalogosRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](CatalogosRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] }); })();


/***/ })

}]);
//# sourceMappingURL=catalogos-catalogos-module.js.map