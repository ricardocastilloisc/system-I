(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["procesos-procesos-module"],{

/***/ "+U3K":
/*!************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/procesos/procesos.component.ts ***!
  \************************************************************************/
/*! exports provided: ProcesosComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProcesosComponent", function() { return ProcesosComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "tyNb");


class ProcesosComponent {
    constructor() { }
    ngOnInit() {
    }
}
ProcesosComponent.ɵfac = function ProcesosComponent_Factory(t) { return new (t || ProcesosComponent)(); };
ProcesosComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: ProcesosComponent, selectors: [["app-procesos"]], decls: 1, vars: 0, template: function ProcesosComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "router-outlet");
    } }, directives: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterOutlet"]], styles: [".wrapper[_ngcontent-%COMP%] {\r\n    display: flex;\r\n    flex-wrap: wrap;\r\n  }\r\n\r\n  .content[_ngcontent-%COMP%] {\r\n    width: 100%;\r\n    display: flex;\r\n    flex-wrap: wrap;\r\n    flex-direction: column;\r\n  }\r\n\r\n  div.container-selector-proceso[_ngcontent-%COMP%] {\r\n    width: auto;\r\n    height: 45px;\r\n\r\n    margin-bottom: 50px;\r\n    margin-top: 50px;\r\n  }\r\n\r\n  .selector-proceso[_ngcontent-%COMP%] {\r\n    width: auto;\r\n    height: 45px;\r\n    border-radius: 25px;\r\n    min-width: 328px;\r\n    margin-bottom: 50px;\r\n    margin-top: 50px;\r\n  }\r\n\r\n  .selector-proceso[_ngcontent-%COMP%]    > button[_ngcontent-%COMP%] {\r\n    width: 50%;\r\n    height: 45px;\r\n    height: 100%;\r\n    border: none;\r\n    background: white;\r\n    color: #464E7E;\r\n    font: bold 20px FS Elliot Pro;\r\n  }\r\n\r\n  .selector-proceso[_ngcontent-%COMP%]    > button[_ngcontent-%COMP%]:focus {\r\n    background-color: #7C69C3;\r\n    color: white;\r\n    transition: background 0.2s linear;\r\n    box-shadow: 3px 3px 5px #464E7E;\r\n  }\r\n\r\n  #right-button[_ngcontent-%COMP%] {\r\n    border-top-right-radius: 25px 25px;\r\n    border-bottom-right-radius: 25px 25px;\r\n  }\r\n\r\n  #left-button[_ngcontent-%COMP%] {\r\n    border-top-left-radius: 25px 25px;\r\n    border-bottom-left-radius: 25px 25px;\r\n  }\r\n\r\n  .botonActivado[_ngcontent-%COMP%]{\r\n    background-color: #035fa4;\r\n    color: white;\r\n  }\r\n\r\n  .container-procesos[_ngcontent-%COMP%] {\r\n    background: red;\r\n    display: flex;\r\n    flex: 1;\r\n    flex-wrap: wrap;\r\n    flex-direction: row;\r\n    align-content: center;\r\n    justify-content: center;\r\n    border-radius: 25px;\r\n    margin: 25px 0;\r\n    width: 95%;\r\n  }\r\n\r\n  div.card-calendario[_ngcontent-%COMP%] {\r\n    background: white;\r\n    display: flex;\r\n    width: 100%;\r\n    height: 285px;\r\n    min-width: 420px;\r\n    \r\n    margin: 25px 0;\r\n    margin-right: 5%;\r\n    margin-left: 5%;\r\n    flex-direction: column;\r\n    color: white;\r\n    align-items: center;\r\n    border-radius: 25px;\r\n    border-left: 10px solid #7C69C3;\r\n    box-shadow: 4px 4px 10px #00000033;\r\n  }\r\n\r\n  .card-calendario[_ngcontent-%COMP%]   div[_ngcontent-%COMP%] {\r\n    color: #464E7E;\r\n    border: black;\r\n    height: auto;\r\n    width: auto;\r\n    flex-grow: 1;\r\n    display: flex;\r\n    align-items: center;\r\n    font: bold 20px FS Elliot Pro;\r\n  }\r\n\r\n  .card-calendario[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]    > button[_ngcontent-%COMP%] {\r\n    background-color: #7C69C3;\r\n    color: white;\r\n    width: 296px;\r\n    height: 50px;\r\n    border-radius: 25px;\r\n    font: bold 20px FS Elliot Pro;\r\n    border: none;\r\n  }\r\n\r\n  div.card-lista-proceso[_ngcontent-%COMP%] {\r\n    width: auto;\r\n\r\n    min-width: 477px;\r\n    flex: auto;\r\n    display: flex;\r\n    flex-wrap: wrap;\r\n    vertical-align: middle;\r\n  }\r\n\r\n  table.listado-proceso[_ngcontent-%COMP%] {\r\n    color: white;\r\n    width: 100%;\r\n    margin: 25px 0;\r\n    margin-left: 5%;\r\n    margin-right: 5%;\r\n    text-align: center;\r\n    border-collapse: separate;\r\n    border-spacing: 0 6px;\r\n  }\r\n\r\n  table.listado-proceso[_ngcontent-%COMP%]   th[_ngcontent-%COMP%] {\r\n    background-color: #7C69C3;\r\n    font: bold 18px FS Elliot Pro;\r\n    height: 40px;\r\n    height: 40px;\r\n    font: bold 18px FS Elliot Pro;\r\n  }\r\n\r\n  table.listado-proceso[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\r\n    text-align: center;\r\n    background-color: white;\r\n    color: #707070;\r\n    font: 18px FS Elliot Pro;\r\n    height: 40px;\r\n    margin: 6px 0px;\r\n  }\r\n\r\n  .listado-proceso[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]:first-of-type {\r\n    border-top-left-radius: 25px;\r\n    border-bottom-left-radius: 25px;\r\n  }\r\n\r\n  .listado-proceso[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]:last-of-type {\r\n    border-top-right-radius: 25px;\r\n    border-bottom-right-radius: 25px;\r\n  }\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2Nlc29zLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxhQUFhO0lBQ2IsZUFBZTtFQUNqQjs7RUFFQTtJQUNFLFdBQVc7SUFDWCxhQUFhO0lBQ2IsZUFBZTtJQUNmLHNCQUFzQjtFQUN4Qjs7RUFFQTtJQUNFLFdBQVc7SUFDWCxZQUFZOztJQUVaLG1CQUFtQjtJQUNuQixnQkFBZ0I7RUFDbEI7O0VBRUE7SUFDRSxXQUFXO0lBQ1gsWUFBWTtJQUNaLG1CQUFtQjtJQUNuQixnQkFBZ0I7SUFDaEIsbUJBQW1CO0lBQ25CLGdCQUFnQjtFQUNsQjs7RUFFQTtJQUNFLFVBQVU7SUFDVixZQUFZO0lBQ1osWUFBWTtJQUNaLFlBQVk7SUFDWixpQkFBaUI7SUFDakIsY0FBYztJQUNkLDZCQUE2QjtFQUMvQjs7RUFDQTtJQUNFLHlCQUF5QjtJQUN6QixZQUFZO0lBQ1osa0NBQWtDO0lBQ2xDLCtCQUErQjtFQUNqQzs7RUFDQTtJQUNFLGtDQUFrQztJQUNsQyxxQ0FBcUM7RUFDdkM7O0VBRUE7SUFDRSxpQ0FBaUM7SUFDakMsb0NBQW9DO0VBQ3RDOztFQUVBO0lBQ0UseUJBQXlCO0lBQ3pCLFlBQVk7RUFDZDs7RUFFQTtJQUNFLGVBQWU7SUFDZixhQUFhO0lBQ2IsT0FBTztJQUNQLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIscUJBQXFCO0lBQ3JCLHVCQUF1QjtJQUN2QixtQkFBbUI7SUFDbkIsY0FBYztJQUNkLFVBQVU7RUFDWjs7RUFFQTtJQUNFLGlCQUFpQjtJQUNqQixhQUFhO0lBQ2IsV0FBVztJQUNYLGFBQWE7SUFDYixnQkFBZ0I7O0lBRWhCLGNBQWM7SUFDZCxnQkFBZ0I7SUFDaEIsZUFBZTtJQUNmLHNCQUFzQjtJQUN0QixZQUFZO0lBQ1osbUJBQW1CO0lBQ25CLG1CQUFtQjtJQUNuQiwrQkFBK0I7SUFDL0Isa0NBQWtDO0VBQ3BDOztFQUVBO0lBQ0UsY0FBYztJQUNkLGFBQWE7SUFDYixZQUFZO0lBQ1osV0FBVztJQUNYLFlBQVk7SUFDWixhQUFhO0lBQ2IsbUJBQW1CO0lBQ25CLDZCQUE2QjtFQUMvQjs7RUFFQTtJQUNFLHlCQUF5QjtJQUN6QixZQUFZO0lBQ1osWUFBWTtJQUNaLFlBQVk7SUFDWixtQkFBbUI7SUFDbkIsNkJBQTZCO0lBQzdCLFlBQVk7RUFDZDs7RUFFQTtJQUNFLFdBQVc7O0lBRVgsZ0JBQWdCO0lBQ2hCLFVBQVU7SUFDVixhQUFhO0lBQ2IsZUFBZTtJQUNmLHNCQUFzQjtFQUN4Qjs7RUFFQTtJQUNFLFlBQVk7SUFDWixXQUFXO0lBQ1gsY0FBYztJQUNkLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsa0JBQWtCO0lBQ2xCLHlCQUF5QjtJQUN6QixxQkFBcUI7RUFDdkI7O0VBRUE7SUFDRSx5QkFBeUI7SUFDekIsNkJBQTZCO0lBQzdCLFlBQVk7SUFDWixZQUFZO0lBQ1osNkJBQTZCO0VBQy9COztFQUNBO0lBQ0Usa0JBQWtCO0lBQ2xCLHVCQUF1QjtJQUN2QixjQUFjO0lBQ2Qsd0JBQXdCO0lBQ3hCLFlBQVk7SUFDWixlQUFlO0VBQ2pCOztFQUNBO0lBQ0UsNEJBQTRCO0lBQzVCLCtCQUErQjtFQUNqQzs7RUFDQTtJQUNFLDZCQUE2QjtJQUM3QixnQ0FBZ0M7RUFDbEMiLCJmaWxlIjoicHJvY2Vzb3MuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi53cmFwcGVyIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LXdyYXA6IHdyYXA7XHJcbiAgfVxyXG5cclxuICAuY29udGVudCB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LXdyYXA6IHdyYXA7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gIH1cclxuXHJcbiAgZGl2LmNvbnRhaW5lci1zZWxlY3Rvci1wcm9jZXNvIHtcclxuICAgIHdpZHRoOiBhdXRvO1xyXG4gICAgaGVpZ2h0OiA0NXB4O1xyXG5cclxuICAgIG1hcmdpbi1ib3R0b206IDUwcHg7XHJcbiAgICBtYXJnaW4tdG9wOiA1MHB4O1xyXG4gIH1cclxuXHJcbiAgLnNlbGVjdG9yLXByb2Nlc28ge1xyXG4gICAgd2lkdGg6IGF1dG87XHJcbiAgICBoZWlnaHQ6IDQ1cHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiAyNXB4O1xyXG4gICAgbWluLXdpZHRoOiAzMjhweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDUwcHg7XHJcbiAgICBtYXJnaW4tdG9wOiA1MHB4O1xyXG4gIH1cclxuXHJcbiAgLnNlbGVjdG9yLXByb2Nlc28gPiBidXR0b24ge1xyXG4gICAgd2lkdGg6IDUwJTtcclxuICAgIGhlaWdodDogNDVweDtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIGJvcmRlcjogbm9uZTtcclxuICAgIGJhY2tncm91bmQ6IHdoaXRlO1xyXG4gICAgY29sb3I6ICM0NjRFN0U7XHJcbiAgICBmb250OiBib2xkIDIwcHggRlMgRWxsaW90IFBybztcclxuICB9XHJcbiAgLnNlbGVjdG9yLXByb2Nlc28gPiBidXR0b246Zm9jdXMge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzdDNjlDMztcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIHRyYW5zaXRpb246IGJhY2tncm91bmQgMC4ycyBsaW5lYXI7XHJcbiAgICBib3gtc2hhZG93OiAzcHggM3B4IDVweCAjNDY0RTdFO1xyXG4gIH1cclxuICAjcmlnaHQtYnV0dG9uIHtcclxuICAgIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiAyNXB4IDI1cHg7XHJcbiAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMjVweCAyNXB4O1xyXG4gIH1cclxuXHJcbiAgI2xlZnQtYnV0dG9uIHtcclxuICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDI1cHggMjVweDtcclxuICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDI1cHggMjVweDtcclxuICB9XHJcblxyXG4gIC5ib3RvbkFjdGl2YWRve1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzAzNWZhNDtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICB9XHJcblxyXG4gIC5jb250YWluZXItcHJvY2Vzb3Mge1xyXG4gICAgYmFja2dyb3VuZDogcmVkO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGZsZXg6IDE7XHJcbiAgICBmbGV4LXdyYXA6IHdyYXA7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xyXG4gICAgYWxpZ24tY29udGVudDogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBib3JkZXItcmFkaXVzOiAyNXB4O1xyXG4gICAgbWFyZ2luOiAyNXB4IDA7XHJcbiAgICB3aWR0aDogOTUlO1xyXG4gIH1cclxuXHJcbiAgZGl2LmNhcmQtY2FsZW5kYXJpbyB7XHJcbiAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGhlaWdodDogMjg1cHg7XHJcbiAgICBtaW4td2lkdGg6IDQyMHB4O1xyXG4gICAgXHJcbiAgICBtYXJnaW46IDI1cHggMDtcclxuICAgIG1hcmdpbi1yaWdodDogNSU7XHJcbiAgICBtYXJnaW4tbGVmdDogNSU7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGJvcmRlci1yYWRpdXM6IDI1cHg7XHJcbiAgICBib3JkZXItbGVmdDogMTBweCBzb2xpZCAjN0M2OUMzO1xyXG4gICAgYm94LXNoYWRvdzogNHB4IDRweCAxMHB4ICMwMDAwMDAzMztcclxuICB9XHJcblxyXG4gIC5jYXJkLWNhbGVuZGFyaW8gZGl2IHtcclxuICAgIGNvbG9yOiAjNDY0RTdFO1xyXG4gICAgYm9yZGVyOiBibGFjaztcclxuICAgIGhlaWdodDogYXV0bztcclxuICAgIHdpZHRoOiBhdXRvO1xyXG4gICAgZmxleC1ncm93OiAxO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBmb250OiBib2xkIDIwcHggRlMgRWxsaW90IFBybztcclxuICB9XHJcblxyXG4gIC5jYXJkLWNhbGVuZGFyaW8gZGl2ID4gYnV0dG9uIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICM3QzY5QzM7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICB3aWR0aDogMjk2cHg7XHJcbiAgICBoZWlnaHQ6IDUwcHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiAyNXB4O1xyXG4gICAgZm9udDogYm9sZCAyMHB4IEZTIEVsbGlvdCBQcm87XHJcbiAgICBib3JkZXI6IG5vbmU7XHJcbiAgfVxyXG5cclxuICBkaXYuY2FyZC1saXN0YS1wcm9jZXNvIHtcclxuICAgIHdpZHRoOiBhdXRvO1xyXG5cclxuICAgIG1pbi13aWR0aDogNDc3cHg7XHJcbiAgICBmbGV4OiBhdXRvO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGZsZXgtd3JhcDogd3JhcDtcclxuICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XHJcbiAgfVxyXG5cclxuICB0YWJsZS5saXN0YWRvLXByb2Nlc28ge1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBtYXJnaW46IDI1cHggMDtcclxuICAgIG1hcmdpbi1sZWZ0OiA1JTtcclxuICAgIG1hcmdpbi1yaWdodDogNSU7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBib3JkZXItY29sbGFwc2U6IHNlcGFyYXRlO1xyXG4gICAgYm9yZGVyLXNwYWNpbmc6IDAgNnB4O1xyXG4gIH1cclxuXHJcbiAgdGFibGUubGlzdGFkby1wcm9jZXNvIHRoIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICM3QzY5QzM7XHJcbiAgICBmb250OiBib2xkIDE4cHggRlMgRWxsaW90IFBybztcclxuICAgIGhlaWdodDogNDBweDtcclxuICAgIGhlaWdodDogNDBweDtcclxuICAgIGZvbnQ6IGJvbGQgMThweCBGUyBFbGxpb3QgUHJvO1xyXG4gIH1cclxuICB0YWJsZS5saXN0YWRvLXByb2Nlc28gdGQge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgICBjb2xvcjogIzcwNzA3MDtcclxuICAgIGZvbnQ6IDE4cHggRlMgRWxsaW90IFBybztcclxuICAgIGhlaWdodDogNDBweDtcclxuICAgIG1hcmdpbjogNnB4IDBweDtcclxuICB9XHJcbiAgLmxpc3RhZG8tcHJvY2VzbyB0ciB0ZDpmaXJzdC1vZi10eXBlIHtcclxuICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDI1cHg7XHJcbiAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiAyNXB4O1xyXG4gIH1cclxuICAubGlzdGFkby1wcm9jZXNvIHRyIHRkOmxhc3Qtb2YtdHlwZSB7XHJcbiAgICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogMjVweDtcclxuICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAyNXB4O1xyXG4gIH1cclxuIl19 */"] });


/***/ }),

/***/ "GIVk":
/*!*********************************************************************!*\
  !*** ./src/app/pages/content/dashboard/procesos/procesos.module.ts ***!
  \*********************************************************************/
/*! exports provided: ProcesosModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProcesosModule", function() { return ProcesosModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _procesos_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./procesos-routing.module */ "oKwr");
/* harmony import */ var _procesos_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./procesos.component */ "+U3K");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




class ProcesosModule {
}
ProcesosModule.ɵfac = function ProcesosModule_Factory(t) { return new (t || ProcesosModule)(); };
ProcesosModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({ type: ProcesosModule });
ProcesosModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
            _procesos_routing_module__WEBPACK_IMPORTED_MODULE_1__["ProcesosRoutingModule"]
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](ProcesosModule, { declarations: [_procesos_component__WEBPACK_IMPORTED_MODULE_2__["ProcesosComponent"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
        _procesos_routing_module__WEBPACK_IMPORTED_MODULE_1__["ProcesosRoutingModule"]] }); })();


/***/ }),

/***/ "OGP1":
/*!**********************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/auditoria/procesos/procesos.component.ts ***!
  \**********************************************************************************/
/*! exports provided: ProcesosComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProcesosComponent", function() { return ProcesosComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");

class ProcesosComponent {
    constructor() { }
    ngOnInit() {
    }
}
ProcesosComponent.ɵfac = function ProcesosComponent_Factory(t) { return new (t || ProcesosComponent)(); };
ProcesosComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: ProcesosComponent, selectors: [["app-procesos"]], decls: 11, vars: 0, consts: [["id", "optionshome"], [1, "container-fluid"], [1, "row", "justify-content-center", 2, "height", "60vh", "width", "100%"], [1, "align-self-center"], [1, "d-flex", "flex-column", 2, "width", "504px"], [1, "descripcionPrimerLogin", 2, "margin-top", "34px"], [1, "row"], [1, "col-10"], ["src", "assets/icons/ico-residencial.png", "width", "30%", 1, "center"]], template: function ProcesosComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "section", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](6, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](7, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "img", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](10, "Esta p\u00E1gina se encuentra en construcci\u00F3n.");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, styles: [".center[_ngcontent-%COMP%] {\r\n    display: block;\r\n    margin-left: auto;\r\n    margin-right: auto;\r\n  }\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2Nlc29zLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxjQUFjO0lBQ2QsaUJBQWlCO0lBQ2pCLGtCQUFrQjtFQUNwQiIsImZpbGUiOiJwcm9jZXNvcy5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNlbnRlciB7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIG1hcmdpbi1sZWZ0OiBhdXRvO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xyXG4gIH0iXX0= */"] });


/***/ }),

/***/ "Wvdv":
/*!***************************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/auditoria/procesos/procesos-routing.module.ts ***!
  \***************************************************************************************/
/*! exports provided: ProcesosRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProcesosRoutingModule", function() { return ProcesosRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _procesos_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./procesos.component */ "OGP1");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");




const routes = [{ path: '', component: _procesos_component__WEBPACK_IMPORTED_MODULE_1__["ProcesosComponent"] }];
class ProcesosRoutingModule {
}
ProcesosRoutingModule.ɵfac = function ProcesosRoutingModule_Factory(t) { return new (t || ProcesosRoutingModule)(); };
ProcesosRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: ProcesosRoutingModule });
ProcesosRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](ProcesosRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] }); })();


/***/ }),

/***/ "g5FI":
/*!*******************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/procesos/proceso/proceso.component.ts ***!
  \*******************************************************************************/
/*! exports provided: ProcesoComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProcesoComponent", function() { return ProcesoComponent; });
/* harmony import */ var _ReduxStore_actions_AUDGENPROCESO_actions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../../../../ReduxStore/actions/AUDGENPROCESO.actions */ "LB20");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var _validators_roles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../validators/roles */ "r6zK");
/* harmony import */ var src_app_ReduxStore_actions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/ReduxStore/actions */ "p8Vo");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngrx/store */ "l7P3");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/auth.service */ "lGQG");
/* harmony import */ var _API_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../API.service */ "iO9l");
/* harmony import */ var _services_usuarios_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../../services/usuarios.service */ "ESM5");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "1kSV");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var ngx_pagination__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ngx-pagination */ "oOf3");














const _c0 = ["modalEstado"];
const _c1 = ["ejecucionesInexistentes"];
function ProcesoComponent_div_0_div_1_div_4_Template(rf, ctx) { if (rf & 1) {
    const _r15 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4, "Buscar por");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "form", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "section", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](9, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](11, "input", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](12, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](13, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](14, "input", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](15, "div", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](16, "button", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ProcesoComponent_div_0_div_1_div_4_Template_button_click_16_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r15); const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](3); return ctx_r14.busquedaFiltros(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](17, "Buscar");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](18, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](19, "div", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](20, "div", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](21, "a", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ProcesoComponent_div_0_div_1_div_4_Template_a_click_21_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r15); const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](3); return ctx_r16.recargarEjecuciones(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](22, "Eliminar Filtro ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](23, "img", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("formGroup", ctx_r8.filtroEjecucionesForm);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpropertyInterpolate"]("max", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind2"](12, 3, ctx_r8.maxDate, "yyyy-MM-dd"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("value", ctx_r8.maxDate);
} }
const _c2 = function (a0) { return { "error-log": a0 }; };
function ProcesoComponent_div_0_div_1_div_5_tr_15_Template(rf, ctx) { if (rf & 1) {
    const _r22 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "tr", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ProcesoComponent_div_0_div_1_div_5_tr_15_Template_tr_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r22); const AUDGENESTADOPROCESO_r19 = ctx.$implicit; const ctx_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](4); return ctx_r21.consultarDetalle(AUDGENESTADOPROCESO_r19.ID_PROCESO, AUDGENESTADOPROCESO_r19.FECHA_CREADO); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](5, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](6, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "td", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const AUDGENESTADOPROCESO_r19 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](AUDGENESTADOPROCESO_r19.ID_PROCESO);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate2"]("", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind2"](5, 5, AUDGENESTADOPROCESO_r19.FECHA_ACTUALIZACION, "dd/MM/yyyy"), " ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind2"](6, 8, AUDGENESTADOPROCESO_r19.FECHA_ACTUALIZACION, "mediumTime"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction1"](11, _c2, AUDGENESTADOPROCESO_r19.ESTADO == "FALLIDO"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", AUDGENESTADOPROCESO_r19.ESTADO, "");
} }
function ProcesoComponent_div_0_div_1_div_5_pagination_template_18_span_4_Template(rf, ctx) { if (rf & 1) {
    const _r28 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "span", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ProcesoComponent_div_0_div_1_div_5_pagination_template_18_span_4_Template_span_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r28); _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); const _r23 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](1); return _r23.previous(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ProcesoComponent_div_0_div_1_div_5_pagination_template_18_div_5_span_1_Template(rf, ctx) { if (rf & 1) {
    const _r34 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "span", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ProcesoComponent_div_0_div_1_div_5_pagination_template_18_div_5_span_1_Template_span_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r34); const page_r29 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().$implicit; _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); const _r23 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](1); return _r23.setCurrent(page_r29.value); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const page_r29 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](page_r29.label);
} }
function ProcesoComponent_div_0_div_1_div_5_pagination_template_18_div_5_div_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const page_r29 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](page_r29.label);
} }
function ProcesoComponent_div_0_div_1_div_5_pagination_template_18_div_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](1, ProcesoComponent_div_0_div_1_div_5_pagination_template_18_div_5_span_1_Template, 2, 1, "span", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](2, ProcesoComponent_div_0_div_1_div_5_pagination_template_18_div_5_div_2_Template, 3, 1, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const page_r29 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    const _r23 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵclassProp"]("current", _r23.getCurrent() === page_r29.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", _r23.getCurrent() !== page_r29.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", _r23.getCurrent() === page_r29.value);
} }
function ProcesoComponent_div_0_div_1_div_5_pagination_template_18_span_7_Template(rf, ctx) { if (rf & 1) {
    const _r38 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "span", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ProcesoComponent_div_0_div_1_div_5_pagination_template_18_span_7_Template_span_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r38); _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); const _r23 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](1); return _r23.next(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " >> ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ProcesoComponent_div_0_div_1_div_5_pagination_template_18_Template(rf, ctx) { if (rf & 1) {
    const _r40 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "pagination-template", 42, 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("pageChange", function ProcesoComponent_div_0_div_1_div_5_pagination_template_18_Template_pagination_template_pageChange_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r40); const ctx_r39 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](4); return ctx_r39.paginaActualEjecucionesProceso = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](4, ProcesoComponent_div_0_div_1_div_5_pagination_template_18_span_4_Template, 1, 0, "span", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](5, ProcesoComponent_div_0_div_1_div_5_pagination_template_18_div_5_Template, 3, 4, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](7, ProcesoComponent_div_0_div_1_div_5_pagination_template_18_span_7_Template, 2, 0, "span", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const _r23 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵclassProp"]("disabled", _r23.isFirstPage());
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !_r23.isFirstPage());
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", _r23.pages);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵclassProp"]("disabled", _r23.isLastPage());
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !_r23.isLastPage());
} }
const _c3 = function (a0, a1) { return { "show-ejecuciones": a0, "hide-ejecuciones": a1 }; };
const _c4 = function (a2) { return { id: "ejecucionesProceso", itemsPerPage: 10, currentPage: a2 }; };
function ProcesoComponent_div_0_div_1_div_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "span", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "Listado de ejecuciones");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "table", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "thead");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](9, "ID Ejecucion");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](11, "Hora");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](12, "th", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](13, "Resultado ejecuci\u00F3n");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](14, "tbody");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](15, ProcesoComponent_div_0_div_1_div_5_tr_15_Template, 9, 13, "tr", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](16, "paginate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](17, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](18, ProcesoComponent_div_0_div_1_div_5_pagination_template_18_Template, 8, 7, "pagination-template", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const AUDGENESTADOPROCESOS_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().ngIf;
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction2"](6, _c3, ctx_r9.mostrarEjecucionesProcesos == true, ctx_r9.mostrarEjecucionesProcesos == false));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind2"](16, 3, AUDGENESTADOPROCESOS_r7, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction1"](9, _c4, ctx_r9.paginaActualEjecucionesProceso)));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", AUDGENESTADOPROCESOS_r7.length > 10);
} }
function ProcesoComponent_div_0_div_1_div_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 52);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 53);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 54);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 55);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "div", 56);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7, " No existen registros de ejecuci\u00F3n para este proceso.");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ProcesoComponent_div_0_div_1_span_10_Template(rf, ctx) { if (rf & 1) {
    const _r43 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "span", 57);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ProcesoComponent_div_0_div_1_span_10_Template_span_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r43); const ctx_r42 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](3); return ctx_r42.recargarEjecuciones(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, "Regresar");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ProcesoComponent_div_0_div_1_div_11_div_7_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, "Completado");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ProcesoComponent_div_0_div_1_div_11_div_8_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " En Proceso");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ProcesoComponent_div_0_div_1_div_11_div_9_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " Error");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ProcesoComponent_div_0_div_1_div_11_div_14_div_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " Completado");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ProcesoComponent_div_0_div_1_div_11_div_14_div_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " En Proceso");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ProcesoComponent_div_0_div_1_div_11_div_14_div_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " Error");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ProcesoComponent_div_0_div_1_div_11_div_14_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](1, "div", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](2, ProcesoComponent_div_0_div_1_div_11_div_14_div_2_Template, 2, 0, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](3, ProcesoComponent_div_0_div_1_div_11_div_14_div_3_Template, 2, 0, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](4, ProcesoComponent_div_0_div_1_div_11_div_14_div_4_Template, 2, 0, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const AUDGENEJECUCIONPROCESO_r44 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ETAPA) === "FINAL" && (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ESTADO) === "EXITOSO" || (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ETAPA) === "PROCESAMIENTO" && (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ESTADO) === "EXITOSO");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ETAPA) === "PROCESAMIENTO" && (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ESTADO_EJECUCION) === "INICIADO");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ETAPA) === "PROCESAMIENTO" && (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ESTADO) === "FALLIDO");
} }
function ProcesoComponent_div_0_div_1_div_11_div_19_div_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " Completado");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ProcesoComponent_div_0_div_1_div_11_div_19_div_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " En Proceso");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ProcesoComponent_div_0_div_1_div_11_div_19_div_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " Error");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ProcesoComponent_div_0_div_1_div_11_div_19_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](1, "div", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](2, ProcesoComponent_div_0_div_1_div_11_div_19_div_2_Template, 2, 0, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](3, ProcesoComponent_div_0_div_1_div_11_div_19_div_3_Template, 2, 0, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](4, ProcesoComponent_div_0_div_1_div_11_div_19_div_4_Template, 2, 0, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const AUDGENEJECUCIONPROCESO_r44 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ESTADO) === "EXITOSO" && (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ETAPA) === "FINAL");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ETAPA) === "FINAL" && (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ESTADO_EJECUCION) === "INICIADO");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ETAPA) === "FINAL" && (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ESTADO) === "FALLIDO");
} }
const _c5 = function (a0, a1) { return { "step-completado": a0, "step-incompleto": a1 }; };
const _c6 = function (a0, a1, a2, a3) { return { "step-proceso-disabled": a0, "step-proceso-enabled": a1, "step-completado": a2, "step-incompleto": a3 }; };
const _c7 = function (a0, a1, a2, a3) { return { "step-proceso-disabled": a0, "step-proceso-enabled": a1, "step-completado-final": a2, "step-incompleto": a3 }; };
function ProcesoComponent_div_0_div_1_div_11_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 58, 59);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 60);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5, "INICIAL");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](6, "div", 61);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](7, ProcesoComponent_div_0_div_1_div_11_div_7_Template, 2, 0, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](8, ProcesoComponent_div_0_div_1_div_11_div_8_Template, 2, 0, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](9, ProcesoComponent_div_0_div_1_div_11_div_9_Template, 2, 0, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "div", 62);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](12, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](13, "PROCESAMIENTO");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](14, ProcesoComponent_div_0_div_1_div_11_div_14_Template, 5, 3, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](15, "div", 63);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](16, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](17, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](18, "FINAL");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](19, ProcesoComponent_div_0_div_1_div_11_div_19_Template, 5, 3, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const AUDGENEJECUCIONPROCESO_r44 = ctx.ngIf;
    const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction2"](9, _c3, ctx_r12.mostrarEjecucionesProcesos == false, ctx_r12.mostrarEjecucionesProcesos == true));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction2"](12, _c5, (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ETAPA) != "INICIAL", (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ESTADO) == "FALLIDO" && (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ETAPA) == "INICIAL"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ETAPA) !== "INICIAL");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ETAPA) === "INICIAL" && (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ESTADO_EJECUCION) === "INICIADO");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ETAPA) === "INICIAL" && (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ESTADO) === "FALLIDO");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction4"](15, _c6, (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ETAPA) == "INICIAL", (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ETAPA) == "PROCESAMIENTO" || (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ETAPA) == "FINAL", (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ETAPA) == "FINAL" || (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ESTADO_EJECUCION) == "FINALIZADO" && (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ETAPA) == "PROCESAMIENTO", (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ESTADO) == "FALLIDO" && (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ETAPA) == "PROCESAMIENTO"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ETAPA) !== "INICIAL");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction4"](20, _c7, (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ETAPA) != "FINAL", (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ETAPA) === "FINAL", (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ESTADO) == "EXITOSO" && (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ETAPA) == "FINAL", (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ESTADO) == "FALLIDO" && (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ETAPA) == "FINAL"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", (AUDGENEJECUCIONPROCESO_r44[0] == null ? null : AUDGENEJECUCIONPROCESO_r44[0].ETAPA) === "FINAL");
} }
const _c8 = function (a0, a1, a2) { return { "error-log": a0, "info-log": a1, "debug-log": a2 }; };
function ProcesoComponent_div_0_div_1_div_13_div_4_tr_13_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "td", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](7, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](8, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](9, "td", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const AUDGENPROCESO_r64 = ctx.$implicit;
    const i_r65 = ctx.index;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](i_r65 + 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction3"](13, _c8, AUDGENPROCESO_r64.NIVEL === "FALLIDO", AUDGENPROCESO_r64.NIVEL === "INFO", AUDGENPROCESO_r64.NIVEL === "DEBUG"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", AUDGENPROCESO_r64.NIVEL, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate2"]("", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind2"](7, 7, AUDGENPROCESO_r64.FECHA, "dd/MM/yyyy"), " ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind2"](8, 10, AUDGENPROCESO_r64.FECHA, "mediumTime"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction1"](17, _c2, AUDGENPROCESO_r64.NIVEL === "FALLIDO"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", AUDGENPROCESO_r64.MENSAJE_SOPORTE, "");
} }
const _c9 = function (a2) { return { id: "detalleEjecucion", itemsPerPage: 10, currentPage: a2 }; };
function ProcesoComponent_div_0_div_1_div_13_div_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "table", 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "thead");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5, "#");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7, "Tipo");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](9, "Hora");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "th", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](11, "Mensaje");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](12, "tbody");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](13, ProcesoComponent_div_0_div_1_div_13_div_4_tr_13_Template, 11, 19, "tr", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](14, "paginate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const AUDGENPROCESOS_r59 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().ngIf;
    const ctx_r60 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](13);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind2"](14, 1, AUDGENPROCESOS_r59, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction1"](4, _c9, ctx_r60.paginaActualProceso)));
} }
function ProcesoComponent_div_0_div_1_div_13_div_5_tr_11_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](5, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](6, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "td", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const AUDGENPROCESO_r68 = ctx.$implicit;
    const i_r69 = ctx.index;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](i_r69 + 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate2"]("", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind2"](5, 5, AUDGENPROCESO_r68.FECHA, "dd/MM/yyyy"), " ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind2"](6, 8, AUDGENPROCESO_r68.FECHA, "mediumTime"), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction1"](11, _c2, AUDGENPROCESO_r68.NIVEL === "FALLIDO"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", AUDGENPROCESO_r68.MENSAJE_NEGOCIO, "");
} }
function ProcesoComponent_div_0_div_1_div_13_div_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "table", 66);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "thead");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5, "#");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7, "Hora");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "th", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](9, "Mensaje");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "tbody");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](11, ProcesoComponent_div_0_div_1_div_13_div_5_tr_11_Template, 9, 13, "tr", 67);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](12, "paginate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const AUDGENPROCESOS_r59 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().ngIf;
    const ctx_r61 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](11);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind2"](12, 1, AUDGENPROCESOS_r59, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction1"](4, _c9, ctx_r61.paginaActualProceso)));
} }
function ProcesoComponent_div_0_div_1_div_13_pagination_template_7_span_4_Template(rf, ctx) { if (rf & 1) {
    const _r76 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "span", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ProcesoComponent_div_0_div_1_div_13_pagination_template_7_span_4_Template_span_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r76); _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); const _r71 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](1); return _r71.previous(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ProcesoComponent_div_0_div_1_div_13_pagination_template_7_div_5_span_1_Template(rf, ctx) { if (rf & 1) {
    const _r82 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "span", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ProcesoComponent_div_0_div_1_div_13_pagination_template_7_div_5_span_1_Template_span_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r82); const page_r77 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().$implicit; _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); const _r71 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](1); return _r71.setCurrent(page_r77.value); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const page_r77 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](page_r77.label);
} }
function ProcesoComponent_div_0_div_1_div_13_pagination_template_7_div_5_div_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const page_r77 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](page_r77.label);
} }
function ProcesoComponent_div_0_div_1_div_13_pagination_template_7_div_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 50);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](1, ProcesoComponent_div_0_div_1_div_13_pagination_template_7_div_5_span_1_Template, 2, 1, "span", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](2, ProcesoComponent_div_0_div_1_div_13_pagination_template_7_div_5_div_2_Template, 3, 1, "div", 51);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const page_r77 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    const _r71 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵclassProp"]("current", _r71.getCurrent() === page_r77.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", _r71.getCurrent() !== page_r77.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", _r71.getCurrent() === page_r77.value);
} }
function ProcesoComponent_div_0_div_1_div_13_pagination_template_7_span_7_Template(rf, ctx) { if (rf & 1) {
    const _r86 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "span", 49);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ProcesoComponent_div_0_div_1_div_13_pagination_template_7_span_7_Template_span_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r86); _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); const _r71 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](1); return _r71.next(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1, " >> ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ProcesoComponent_div_0_div_1_div_13_pagination_template_7_Template(rf, ctx) { if (rf & 1) {
    const _r88 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "pagination-template", 68, 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("pageChange", function ProcesoComponent_div_0_div_1_div_13_pagination_template_7_Template_pagination_template_pageChange_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r88); const ctx_r87 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](4); return ctx_r87.paginaActualProceso = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](4, ProcesoComponent_div_0_div_1_div_13_pagination_template_7_span_4_Template, 1, 0, "span", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](5, ProcesoComponent_div_0_div_1_div_13_pagination_template_7_div_5_Template, 3, 4, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "div", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](7, ProcesoComponent_div_0_div_1_div_13_pagination_template_7_span_7_Template, 2, 0, "span", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const _r71 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵclassProp"]("disabled", _r71.isFirstPage());
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !_r71.isFirstPage());
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", _r71.pages);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵclassProp"]("disabled", _r71.isLastPage());
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !_r71.isLastPage());
} }
const _c10 = function (a0) { return [a0]; };
function ProcesoComponent_div_0_div_1_div_13_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "span", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "Monitoreo de actividades ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](4, ProcesoComponent_div_0_div_1_div_13_div_4_Template, 15, 6, "div", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](5, ProcesoComponent_div_0_div_1_div_13_div_5_Template, 13, 6, "div", 64);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](7, ProcesoComponent_div_0_div_1_div_13_pagination_template_7_Template, 8, 7, "pagination-template", 65);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const AUDGENPROCESOS_r59 = ctx.ngIf;
    const DataUser_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2).ngIf;
    const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction2"](4, _c3, ctx_r13.mostrarEjecucionesProcesos == false, ctx_r13.mostrarEjecucionesProcesos == true));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r13.area == "SOPORTE");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r13.usuario.validarRolUsuario() && ctx_r13.rolesValids(DataUser_r1, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction1"](7, _c10, ctx_r13.Administrador)) && ctx_r13.area != "SOPORTE");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", AUDGENPROCESOS_r59.length > 10);
} }
function ProcesoComponent_div_0_div_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](4, ProcesoComponent_div_0_div_1_div_4_Template, 24, 6, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](5, ProcesoComponent_div_0_div_1_div_5_Template, 19, 11, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](6, ProcesoComponent_div_0_div_1_div_6_Template, 8, 0, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](7, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "div", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](9, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](10, ProcesoComponent_div_0_div_1_span_10_Template, 2, 0, "span", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](11, ProcesoComponent_div_0_div_1_div_11_Template, 20, 25, "div", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](12, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](13, ProcesoComponent_div_0_div_1_div_13_Template, 8, 9, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](14, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const AUDGENESTADOPROCESOS_r7 = ctx.ngIf;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx_r2.titulo);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !ctx_r2.ocultarbusqueda);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", AUDGENESTADOPROCESOS_r7.length !== 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", AUDGENESTADOPROCESOS_r7.length === 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction2"](12, _c3, ctx_r2.mostrarEjecucionesProcesos == false, ctx_r2.mostrarEjecucionesProcesos == true));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !ctx_r2.mostrarEjecucionesProcesos);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](12, 8, ctx_r2.AUDGENEJECUCIONPROCESO$));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](14, 10, ctx_r2.AUDGENPROCESOS$));
} }
function ProcesoComponent_div_0_ng_template_3_Template(rf, ctx) { if (rf & 1) {
    const _r92 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4, "Busqueda por filtro");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "div", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "div", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7, "Ingresa un valor para realizar la busqueda");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "div", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](9, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "button", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ProcesoComponent_div_0_ng_template_3_Template_button_click_10_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r92); const ctx_r91 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2); return ctx_r91.cerrarModales(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](11, "Aceptar");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ProcesoComponent_div_0_ng_template_5_Template(rf, ctx) { if (rf & 1) {
    const _r95 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 69);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "div", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 71);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](4, "Consulta de ejecuciones");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "div", 72);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "div", 73);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7, "No existen ejecuciones para este proceso ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "div", 70);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](9, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "button", 74);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function ProcesoComponent_div_0_ng_template_5_Template_button_click_10_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r95); const ctx_r94 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2); return ctx_r94.cerrarModales(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](11, "Continuar");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} }
function ProcesoComponent_div_0_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](1, ProcesoComponent_div_0_div_1_Template, 15, 15, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](3, ProcesoComponent_div_0_ng_template_3_Template, 12, 0, "ng-template", 3, 4, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](5, ProcesoComponent_div_0_ng_template_5_Template, 12, 0, "ng-template", 5, 6, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](2, 1, ctx_r0.AUDGENESTADOPROCESOS$));
} }
class ProcesoComponent {
    constructor(store, rutaActiva, authService, api, usuario, fb, modalService, datepipe) {
        this.store = store;
        this.rutaActiva = rutaActiva;
        this.authService = authService;
        this.api = api;
        this.usuario = usuario;
        this.fb = fb;
        this.modalService = modalService;
        this.datepipe = datepipe;
        this.Areas = [
            _validators_roles__WEBPACK_IMPORTED_MODULE_2__["EArea"].Contabilidad,
            _validators_roles__WEBPACK_IMPORTED_MODULE_2__["EArea"].Custodia,
            _validators_roles__WEBPACK_IMPORTED_MODULE_2__["EArea"].Inversiones_Riesgos,
            _validators_roles__WEBPACK_IMPORTED_MODULE_2__["EArea"].Tesoreria,
            _validators_roles__WEBPACK_IMPORTED_MODULE_2__["EArea"].Soporte
        ];
        this.PROCESOS = new Array();
        this.ocultarbusqueda = false;
        this.paginaActualEjecucionesProceso = 1;
        this.paginaActualProceso = 1;
        this.mostrarEjecucionesProcesos = true;
        this.Administrador = _validators_roles__WEBPACK_IMPORTED_MODULE_2__["ERole"].Administrador;
        this.Ejecutor = _validators_roles__WEBPACK_IMPORTED_MODULE_2__["ERole"].Monitor;
        this.rolesValids = (User, roles) => {
            return this.authService.rolesValids(User, roles);
        };
        this.cerrarModales = () => {
            this.modalService.dismissAll();
        };
    }
    ngOnDestroy() {
        this.store.dispatch(Object(_ReduxStore_actions_AUDGENPROCESO_actions__WEBPACK_IMPORTED_MODULE_0__["UnsetAUDGENPROCESO"])());
        this.store.dispatch(Object(src_app_ReduxStore_actions__WEBPACK_IMPORTED_MODULE_3__["UnsetAUDGENESTADOPROCESO"])());
        this.store.dispatch(Object(src_app_ReduxStore_actions__WEBPACK_IMPORTED_MODULE_3__["UnsetAUDGENEJECUCIONPROCESO"])());
    }
    ngAfterViewInit() {
        // this.rutaActiva.queryParams
        //   .subscribe(res =>{ console.log(res); this.titulo = res['titulo'] || 0 })
        //   console.log('titulo', this.titulo)
    }
    ngOnInit() {
        this.titulo = JSON.parse(localStorage.getItem('Titulo'));
        // this.rutaActiva.queryParams
        //   .subscribe(res =>{ console.log(res); this.titulo = res['titulo'] || 0 })
        //   console.log('titulo', this.titulo)
        this.ocultarbusqueda = false;
        this.paginaActualProceso = 1;
        this.paginaActualEjecucionesProceso = 1;
        this.filtroEjecucionesForm = this.fb.group({
            fechaFiltrar: [],
            idProceso: []
        });
        // this.api.OnUpdateAUDGENESTADOPROCESOListener().subscribe(res => 
        //   console.log(res)
        //   )
        this.maxDate = new Date();
        this.DataUser$ = this.store.select(({ usuario }) => usuario.user);
        this.DataUser$.subscribe(res => this.DataUser = res).unsubscribe();
        console.log(this.DataUser.attributes['custom:negocio']);
        this.AUDGENESTADOPROCESOS$ = this.store.select(({ AUDGENESTADOPROCESOS }) => AUDGENESTADOPROCESOS.AUDGENESTADOPROCESO).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])(res => {
            if (res === null)
                return res;
            else
                return res.slice().sort(function (a, b) { return new Date(b.FECHA_ACTUALIZACION).getTime() - new Date(a.FECHA_ACTUALIZACION).getTime(); }).filter((item, i, res) => {
                    return res.indexOf(res.find(t => t.ID_PROCESO === item.ID_PROCESO)) === i;
                }).filter(item => {
                    return item.ETAPA != "";
                });
        }));
        /*
            this.store.select(
              ({ AUDGENESTADOPROCESOS }) => AUDGENESTADOPROCESOS.AUDGENESTADOPROCESO
            ).subscribe(res => console.log('que hay',res))
        */
        this.store.select(({ AUDGENPROCESOS }) => AUDGENPROCESOS.AUDGENPROCESOS);
        this.store.select(({ AUDGENESTADOPROCESOS }) => AUDGENESTADOPROCESOS.AUDGENESTADOPROCESO);
        let body = {
            filter: { INTERFAZ: { eq: this.rutaActiva.snapshot.params.id } },
            limit: 999999999
        };
        this.store.dispatch(Object(src_app_ReduxStore_actions__WEBPACK_IMPORTED_MODULE_3__["LoadAUDGENESTADOPROCESOS"])({ consult: body }));
        // this.llenarTabla(this.page);
        this.AUDGENESTADOPROCESOS$.subscribe(res => {
            if (res && res.length === 0) {
                this.ejecucionesInexistentesModal();
                //this.modalService.open(this.templateRefEjecuciones, { ariaLabelledBy: 'modal-basic-title' });
            }
            else
                this.cerrarModales();
        });
    }
    openModal() {
        this.modalService.open(this.templateRef, { ariaLabelledBy: 'modal-basic-title' });
    }
    obtenerArea() {
        let arrayTempArea = [];
        this.DataUser.groups.forEach((area) => {
            this.Areas.forEach(areaDef => {
                if (area === areaDef) {
                    arrayTempArea.push(area);
                }
            });
        });
        if (arrayTempArea.length > 0)
            return arrayTempArea[0].toUpperCase();
        else
            "N/D";
    }
    recargarEjecuciones() {
        if (this.mostrarEjecucionesProcesos == false) {
            this.mostrarEjecucionesProcesos = !this.mostrarEjecucionesProcesos;
        }
        this.ocultarbusqueda = false;
        this.AUDGENESTADOPROCESOS$ = this.store.select(({ AUDGENESTADOPROCESOS }) => AUDGENESTADOPROCESOS.AUDGENESTADOPROCESO).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])(res => {
            if (res === null)
                return res;
            else
                return res.slice().sort(function (a, b) { return new Date(b.FECHA_ACTUALIZACION).getTime() - new Date(a.FECHA_ACTUALIZACION).getTime(); }).filter((item, i, res) => {
                    return res.indexOf(res.find(t => t.ID_PROCESO === item.ID_PROCESO)) === i;
                }).filter(item => {
                    return item.ETAPA != "";
                });
        }));
        let body = {
            filter: { INTERFAZ: { eq: this.rutaActiva.snapshot.params.id } },
            limit: 999999999
        };
        this.store.dispatch(Object(src_app_ReduxStore_actions__WEBPACK_IMPORTED_MODULE_3__["LoadAUDGENESTADOPROCESOS"])({ consult: body }));
        this.filtroEjecucionesForm.reset();
    }
    consultarDetalle(idProceso, fecha) {
        this.area = this.obtenerArea();
        console.log(this.area);
        this.ocultarbusqueda = true;
        console.log(fecha);
        let format = this.datepipe.transform(fecha, 'yyyy-MM-dd');
        console.log(format);
        this.paginaActualProceso = 1;
        this.api.ListAUDGENPROCESOS(idProceso, format).then(res => console.log('Resultado', res));
        this.AUDGENEJECUCIONPROCESO$ = this.store.select(({ AUDGENEJECUCIONESPROCESO }) => AUDGENEJECUCIONESPROCESO.AUDGENEJECUCIONESPROCESO).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])(res => {
            if (res == null)
                return res;
            else
                return res.filter((item, i, res) => {
                    return res.indexOf(res.find(t => t.ID_PROCESO === item.ID_PROCESO)) === i;
                });
        }));
        this.store.select(({ AUDGENEJECUCIONESPROCESO }) => AUDGENEJECUCIONESPROCESO.AUDGENEJECUCIONESPROCESO).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])(res => {
            if (res == null)
                return res;
            else
                return res.filter((item, i, res) => {
                    return res.indexOf(res.find(t => t.ID_PROCESO === item.ID_PROCESO)) === i;
                });
        })).subscribe(res => console.log(res));
        this.store.select(({ AUDGENPROCESOS }) => AUDGENPROCESOS.AUDGENPROCESOS).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])(res => {
            if (res === null)
                return res;
            else
                return res.slice().sort(function (a, b) { return new Date(b.FECHA).getTime() - new Date(a.FECHA).getTime(); });
        })).subscribe(res => console.log(res));
        if (this.rolesValids(this.DataUser, [this.Administrador]) && this.area == 'SOPORTE') {
            this.AUDGENPROCESOS$ = this.store.select(({ AUDGENPROCESOS }) => AUDGENPROCESOS.AUDGENPROCESOS).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])(res => {
                if (res === null)
                    return res;
                else
                    return res.slice().sort(function (a, b) { return new Date(b.FECHA).getTime() - new Date(a.FECHA).getTime(); });
            }));
        }
        else if (this.rolesValids(this.DataUser, [this.Administrador])) {
            console.log('entre al admin');
            this.AUDGENPROCESOS$ = this.store.select(({ AUDGENPROCESOS }) => AUDGENPROCESOS.AUDGENPROCESOS).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])(res => {
                if (res === null)
                    return res;
                else
                    return res.slice().sort(function (a, b) { return new Date(b.FECHA).getTime() - new Date(a.FECHA).getTime(); })
                        .filter(item => {
                        return item.MENSAJE_NEGOCIO != "";
                    });
            }));
        }
        else {
            this.AUDGENPROCESOS$ = this.store.select(({ AUDGENPROCESOS }) => AUDGENPROCESOS.AUDGENPROCESOS).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])(res => {
                if (res === null)
                    return res;
                else
                    return res.slice().sort(function (a, b) { return new Date(b.FECHA).getTime() - new Date(a.FECHA).getTime(); });
            }));
        }
        let body = {
            filter: { ID_PROCESO: { eq: idProceso } },
            limit: 999999999
        };
        let bodyProcesos = {
            ID_PROCESO: idProceso,
            FECHA: format
        };
        this.store.dispatch(Object(src_app_ReduxStore_actions__WEBPACK_IMPORTED_MODULE_3__["LoadAUDGENEJECUCIONESPROCESO"])({ consult: body }));
        this.store.dispatch(Object(_ReduxStore_actions_AUDGENPROCESO_actions__WEBPACK_IMPORTED_MODULE_0__["LoadAUDGENPROCESOS"])({ consult: bodyProcesos }));
        this.mostrarEjecucionesProcesos = false;
    }
    busquedaFiltros() {
        this.paginaActualEjecucionesProceso = 1;
        if (this.filtroEjecucionesForm.valid) {
            let fechaFiltro = this.filtroEjecucionesForm.get('fechaFiltrar').value;
            console.log(this.filtroEjecucionesForm.get('fechaFiltrar').value);
            let idProceso = this.filtroEjecucionesForm.get('idProceso').value;
            console.log(this.filtroEjecucionesForm.get('idProceso').value);
            this.AUDGENESTADOPROCESOS$ = this.store.select(({ AUDGENESTADOPROCESOS }) => AUDGENESTADOPROCESOS.AUDGENESTADOPROCESO).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])(res => {
                if (res === null)
                    return res;
                else
                    return res.slice().sort(function (a, b) { return new Date(b.FECHA_ACTUALIZACION).getTime() - new Date(a.FECHA_ACTUALIZACION).getTime(); }).filter((item, i, res) => {
                        return res.indexOf(res.find(t => t.ID_PROCESO === item.ID_PROCESO)) === i;
                    }).filter(item => {
                        return item.ETAPA != "";
                    });
            }));
            this.store.select(({ AUDGENEJECUCIONESPROCESO }) => AUDGENEJECUCIONESPROCESO.AUDGENEJECUCIONESPROCESO).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])(res => {
                if (res == null)
                    return res;
                else
                    return res.filter((item, i, res) => {
                        return res.indexOf(res.find(t => t.ID_PROCESO === item.ID_PROCESO)) === i;
                    });
            })).subscribe(res => console.log(res));
            if (fechaFiltro === null && idProceso === null) {
                this.openModal();
            }
            else if (fechaFiltro === null && idProceso !== null) {
                let body = {
                    filter: { ID_PROCESO: { eq: idProceso } },
                    limit: 999999999
                };
                this.store.dispatch(Object(src_app_ReduxStore_actions__WEBPACK_IMPORTED_MODULE_3__["LoadAUDGENESTADOPROCESOS"])({ consult: body }));
            }
            else if (fechaFiltro !== null && idProceso === null) {
                let body = {
                    filter: { FECHA_ACTUALIZACION: { contains: fechaFiltro }, INTERFAZ: { eq: this.rutaActiva.snapshot.params.id } },
                    limit: 999999999
                };
                this.store.dispatch(Object(src_app_ReduxStore_actions__WEBPACK_IMPORTED_MODULE_3__["LoadAUDGENESTADOPROCESOS"])({ consult: body }));
            }
            else {
                console.log('else');
                console.log(idProceso);
                let body = {
                    filter: { FECHA_ACTUALIZACION: { contains: fechaFiltro }, ID_PROCESO: { eq: idProceso } },
                    limit: 999999999
                };
                this.store.dispatch(Object(src_app_ReduxStore_actions__WEBPACK_IMPORTED_MODULE_3__["LoadAUDGENESTADOPROCESOS"])({ consult: body }));
            }
        }
    }
    ejecucionesInexistentesModal() {
        this.modalService.open(this.templateRefEjecuciones, { ariaLabelledBy: 'modal-basic-title' });
    }
    obtenerNotificaciones(fechaInicioSesion) {
        if (fechaInicioSesion) {
            let body = {
                filter: { FECHA_ACTUALIZACION: { gt: fechaInicioSesion } },
                limit: 1000
            };
            this.store.dispatch(Object(src_app_ReduxStore_actions__WEBPACK_IMPORTED_MODULE_3__["LoadAUDGENESTADOPROCESOS"])({ consult: body }));
        }
    }
}
ProcesoComponent.ɵfac = function ProcesoComponent_Factory(t) { return new (t || ProcesoComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_ngrx_store__WEBPACK_IMPORTED_MODULE_5__["Store"]), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_6__["ActivatedRoute"]), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_7__["AuthService"]), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_API_service__WEBPACK_IMPORTED_MODULE_8__["APIService"]), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_services_usuarios_service__WEBPACK_IMPORTED_MODULE_9__["UsuariosService"]), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_forms__WEBPACK_IMPORTED_MODULE_10__["FormBuilder"]), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_11__["NgbModal"]), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_12__["DatePipe"])); };
ProcesoComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({ type: ProcesoComponent, selectors: [["app-proceso"]], viewQuery: function ProcesoComponent_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵviewQuery"](_c0, 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵviewQuery"](_c1, 1);
    } if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵloadQuery"]()) && (ctx.templateRef = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵloadQuery"]()) && (ctx.templateRefEjecuciones = _t.first);
    } }, decls: 2, vars: 3, consts: [["class", "container-fluid", 4, "ngIf"], [1, "container-fluid"], ["class", "flex-row-reverse justify-content-center", "style", "height: 50vh; width: 100%", 4, "ngIf"], ["id", "modalFiltro"], ["modalEstado", ""], ["id", "ejecucionesInexistentes"], ["ejecucionesInexistentes", ""], [1, "flex-row-reverse", "justify-content-center", 2, "height", "50vh", "width", "100%"], [1, "row", "justify-content-center"], [1, "titulo-proceso"], ["class", "row justify-content-center", 4, "ngIf"], ["class", "row justify-content-center container-referencias-log", 3, "ngClass", 4, "ngIf"], ["class", "row justify-content-center container-referencias-log", 4, "ngIf"], [1, "row", "justify-content-center", "hide-div", 3, "ngClass"], [1, "d-flex", "col-md-9", "col-xs-9", "col-sm-9", "col-lg-9", "mr-9", "col-9", "align-items-center", "justify-content-center"], [1, "show-info"], ["class", "show-info-button", 3, "click", 4, "ngIf"], ["class", "d-flex col-md-9 col-xs-9 col-sm-9 col-lg-9 mr-9 col-9 align-items-center justify-content-center container-progeso show-ejecuciones", "style", "height: 45px;", 3, "ngClass", 4, "ngIf"], [1, "card-calendario"], [1, "mt-4"], [3, "formGroup"], [1, "mt-3"], [1, "row", "align-items-center", "justify-content-center"], [1, "col-11", "inputs-busqueda"], [1, "col-4"], ["type", "date", "placeholder", "dd-MM-yyyy", "onfocus", "(this.type='date')", "formControlName", "fechaFiltrar", "id", "fechaFiltrar", "name", "fechaFiltrar", 2, "width", "100%", "padding-left", "10px", 3, "value", "max"], ["type", "text", "placeholder", "ID de ejecuci\u00F3n", "formControlName", "idProceso", "id", "idProceso", "name", "", 2, "width", "100%", "padding-left", "10px"], [1, "clickable", 3, "click"], [1, "row"], [2, "text-align", "right", "width", "100%", "justify-content", "flex-end", "direction", "rtl", "margin-bottom", "10px"], [2, "margin-right", "10%"], [1, "limpiarFiltro", "clickable", 3, "click"], ["src", "assets/icons/Eliminar.svg", 1, "tamanioFiltroIcono"], [1, "row", "justify-content-center", "container-referencias-log", 3, "ngClass"], [1, "d-flex", "col-md-9", "col-xs-9", "col-sm-9", "col-lg-9", "mr-9", "col-9", "align-items-left", "justify-content-left"], [1, "title-log-table"], [1, "listado-log", "listado-ejecuciones"], ["colspan", "12"], ["class", "clickable", 3, "click", 4, "ngFor", "ngForOf"], [1, "d-flex", "col-md-9", "col-xs-9", "col-sm-9", "col-lg-9", "mr-9", "col-9", "align-items-left"], ["id", "ejecucionesProceso", "class", "ngx-pagination", 3, "pageChange", 4, "ngIf"], [3, "ngClass"], ["id", "ejecucionesProceso", 1, "ngx-pagination", 3, "pageChange"], ["p", "paginationApi"], [1, "custom-pagination"], [1, "pagination-previous"], [3, "click", 4, "ngIf"], ["class", "page-number", 3, "current", 4, "ngFor", "ngForOf"], [1, "pagination-next"], [3, "click"], [1, "page-number"], [4, "ngIf"], [1, "row", "justify-content-center", "container-referencias-log"], [1, "align-self-center"], [1, "d-flex", "flex-column", 2, "width", "504px"], [1, "descripcionNoEjecuciones", 2, "margin-top", "34px"], [1, "col-12"], [1, "show-info-button", 3, "click"], [1, "d-flex", "col-md-9", "col-xs-9", "col-sm-9", "col-lg-9", "mr-9", "col-9", "align-items-center", "justify-content-center", "container-progeso", "show-ejecuciones", 2, "height", "45px", 3, "ngClass"], ["detalleProceso", ""], [1, "step-proceso", "step-proceso-enabled", 2, "margin-left", "-0px", 3, "ngClass"], [1, "separador-titulos"], [1, "step-1-proceso", 3, "ngClass"], [1, "step-4-proceso", 3, "ngClass"], ["class", "d-flex col-md-9 col-xs-9 col-sm-9 col-lg-9 mr-9 col-9 align-items-center justify-content-center", 4, "ngIf"], ["id", "detalleEjecucion", "class", "ngx-pagination", 3, "pageChange", 4, "ngIf"], [1, "listado-log"], [4, "ngFor", "ngForOf"], ["id", "detalleEjecucion", 1, "ngx-pagination", 3, "pageChange"], [1, "modal-body"], [1, "col-12", "row", "justify-content-center", "align-items-center", 2, "height", "120px"], [1, "textoConfirmacionModalUsuarios"], [1, "col-12", "row"], [1, "col-12", "descripcionConfirmacionEjecucionProceso"], [1, "btn", "bottonConfirmarEjecucionProceso", 3, "click"]], template: function ProcesoComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](0, ProcesoComponent_div_0_Template, 7, 3, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](1, "async");
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](1, 1, ctx.DataUser$));
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_12__["NgIf"], _angular_common__WEBPACK_IMPORTED_MODULE_12__["NgClass"], _angular_forms__WEBPACK_IMPORTED_MODULE_10__["ɵangular_packages_forms_forms_ba"], _angular_forms__WEBPACK_IMPORTED_MODULE_10__["NgControlStatusGroup"], _angular_forms__WEBPACK_IMPORTED_MODULE_10__["FormGroupDirective"], _angular_forms__WEBPACK_IMPORTED_MODULE_10__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_10__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_10__["FormControlName"], _angular_common__WEBPACK_IMPORTED_MODULE_12__["NgForOf"], ngx_pagination__WEBPACK_IMPORTED_MODULE_13__["PaginationControlsDirective"]], pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_12__["AsyncPipe"], _angular_common__WEBPACK_IMPORTED_MODULE_12__["DatePipe"], ngx_pagination__WEBPACK_IMPORTED_MODULE_13__["PaginatePipe"]], styles: [".container-progeso[_ngcontent-%COMP%] {\r\n    margin-top: 25px;\r\n    margin-left: auto;\r\n    margin-right: auto;\r\n    width: 100%;\r\n}\r\n \r\n.step-proceso[_ngcontent-%COMP%]{\r\n    background: #7C69C3;\r\n    width: auto;\r\n    border-radius: 50px;\r\n    height: 63px;\r\n    display: flex; \r\n    justify-content: center;\r\n    align-items: center;\r\n    font:  16px FS Elliot Pro;\r\n    color: white;\r\n    z-index: 6;\r\n    box-shadow: 3px 3px 5px #00000033;\r\n    padding: 0px !important;\r\n}\r\n \r\n.step-incompleto[_ngcontent-%COMP%]{\r\n    background: #FF9231 !important;\r\n}\r\n \r\n.step-completado[_ngcontent-%COMP%]{\r\n    background: #7C69C3 !important;\r\n}\r\n \r\n.step-completado-final[_ngcontent-%COMP%]{\r\n    background: #464E7E !important;\r\n}\r\n \r\n.step-proceso-disabled[_ngcontent-%COMP%]{\r\n    margin-left: -25px;\r\n    background: #D6D6D6;\r\n    border-top-right-radius: 50px;\r\n    border-bottom-right-radius: 50px;\r\n    width: 100%;\r\n    min-width: 200px;\r\n    height: 63px;\r\n    display: flex; \r\n    justify-content: center;\r\n    align-items: center;\r\n    font: 16px FS Elliot Pro;\r\n    color: white;\r\n    padding: 30px;\r\n}\r\n \r\n.step-proceso-enabled[_ngcontent-%COMP%]{\r\n    margin-left: -50px;\r\n    background: #7C69C3;\r\n    width: 100%;\r\n    min-width: 200px;\r\n    border-radius: 50px;\r\n    border-top-left-radius: -50px;\r\n    border-bottom-left-radius: -50px;\r\n    height: 63px;\r\n    display: flex; \r\n    justify-content: center;\r\n    align-items: center;\r\n    font:  16px FS Elliot Pro;\r\n    color: white;\r\n    box-shadow: 3px 3px 5px #00000033;\r\n    padding-left: 60px;\r\n    padding-right: 25px;\r\n\r\n}\r\n \r\n.step-1-proceso[_ngcontent-%COMP%]{\r\n    z-index: 4;\r\n}\r\n \r\n.step-2-proceso[_ngcontent-%COMP%]{\r\n    z-index: 3;\r\n}\r\n \r\n.step-3-proceso[_ngcontent-%COMP%]{\r\n    z-index: 2;\r\n}\r\n \r\n.step-4-proceso[_ngcontent-%COMP%]{\r\n    z-index: 1;\r\n}\r\n \r\n.step-4-proceso-finalizado[_ngcontent-%COMP%]{\r\n    z-index: 1;\r\n    background: #464E7E;\r\n}\r\n \r\n.container-referencias-log[_ngcontent-%COMP%]{\r\n    margin-top: 30px;   \r\n}\r\n \r\n.show-ejecuciones[_ngcontent-%COMP%]{\r\n    visibility: visible;\r\n    max-height: 30px;\r\n    opacity: 1;\r\n    transition: visibility 0.3s, opacity 0.3s, max-height 0.5s linear;\r\n}\r\n \r\n.hide-ejecuciones[_ngcontent-%COMP%]{\r\n    visibility: hidden;\r\n    max-height: 0px;\r\n    opacity: 0;\r\n    transition: visibility 0.3s, opacity 0.3s, max-height 0.3s linear;\r\n  \r\n  }\r\n \r\n.container-referencias-log[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\r\n    font: 20px FS Elliot Pro;\r\n}\r\n \r\n.container-referencias-log[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover {\r\n    color: #7C69C3;\r\n    text-decoration: underline ;\r\n}\r\n \r\n.title-log-table[_ngcontent-%COMP%]{\r\n    font: normal normal bold 18px/45px FS Elliot Pro;\r\n \r\n}\r\n \r\ntable.listado-log[_ngcontent-%COMP%]{\r\n    background: #FFFFFF 0% 0% no-repeat padding-box;\r\n    align-content: left;\r\n    width: 100%;\r\n    margin: 15px 0;\r\n    border-spacing: 0 6px;\r\n    text-align: center;\r\n    font: normal normal normal 15px/18px FS Elliot Pro ;\r\n}\r\n \r\ntable.listado-log[_ngcontent-%COMP%]   th[_ngcontent-%COMP%]{\r\n    color: white;\r\n    padding-left: 20px;\r\n    margin-left: 20px;\r\n    background-color: #464E7E ;\r\n    font: bold 18px FS Elliot Pro;\r\n    height: 40px;\r\n    height: 40px;\r\n    font: bold 18px FS Elliot Pro;\r\n    table-layout:fixed;\r\n    text-align: left;\r\n    align-content: center;\r\n}\r\n \r\ntable.listado-log[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]{\r\n    padding-left: 20px;\r\n    margin-left: 20px;\r\n    background-color: #FFFFFF ;\r\n    color: #707070;\r\n    font: 15px FS Elliot Pro;\r\n    height: 40px;\r\n    margin: 6px 0px;\r\n    text-align: left;\r\n    align-content: center;\r\n    vertical-align: middle;\r\n}\r\n \r\ntable.listado-log[_ngcontent-%COMP%]   td.wideRow[_ngcontent-%COMP%], table[_ngcontent-%COMP%]   th.wideRow[_ngcontent-%COMP%]{\r\n    width: 300px;\r\n    }\r\n \r\n.error-log[_ngcontent-%COMP%]{\r\n    color: #C00000 !important;\r\n}\r\n \r\n.warning-log[_ngcontent-%COMP%]{\r\n    color: #FF7000 !important;\r\n}\r\n \r\n.info-log[_ngcontent-%COMP%]{\r\n    color: #1791DA !important;\r\n}\r\n \r\n.debug-log[_ngcontent-%COMP%]{\r\n    color: #FF7000 !important;\r\n}\r\n \r\ntable.listado-ejecuciones[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]:hover   td[_ngcontent-%COMP%] {\r\n    background-color: #c5c5c5;\r\n    text-decoration: none;\r\n    transition: all 0.3s;\r\n}\r\n \r\n.clickable[_ngcontent-%COMP%] {\r\n    \r\n    cursor: pointer;\r\n  }\r\n \r\n.titulo-proceso[_ngcontent-%COMP%]{\r\n    color: #464E7E;\r\n    font: normal normal bold 20px/20px FS Elliot Pro;\r\n    letter-spacing: 0px;\r\n    margin-top: 10px;\r\n}\r\n \r\n.show-info[_ngcontent-%COMP%]{\r\n    width: 80%;\r\n    height: 1px;\r\n    margin-right: 5px;\r\n    \r\n    background: #a0a0a0  !important;\r\n}\r\n \r\n.show-info-button[_ngcontent-%COMP%]:hover {\r\n    cursor: pointer\r\n\r\n}\r\n \r\n.hide-div[_ngcontent-%COMP%] {\r\n    margin: 0;\r\n}\r\n \r\ndiv.card-calendario[_ngcontent-%COMP%]{\r\n    width: 100%;\r\n    background: #ffffff 0% 0% no-repeat padding-box;\r\n    border-radius: 30px;\r\n    opacity: 1;\r\n    display: flex;\r\n    margin: 25px 0;\r\n    flex-direction: column;\r\n    align-items: center;\r\n    border-radius: 25px;\r\n    border-left: 10px solid #464E7E;\r\n    box-shadow: 4px 4px 10px #00000033;\r\n  }\r\n \r\n.card-calendario[_ngcontent-%COMP%]   div[_ngcontent-%COMP%] {\r\n    color: #464E7E;\r\n    border: black;\r\n    height: auto;\r\n    width: auto;\r\n    flex-grow: 1;\r\n    display: flex;\r\n    align-items: center;\r\n    font: bold 20px FS Elliot Pro;\r\n  }\r\n \r\n.card-calendario[_ngcontent-%COMP%]   div[_ngcontent-%COMP%]    > button[_ngcontent-%COMP%] {\r\n    background-color: #7C69C3;\r\n    color: white;\r\n    width: 296px;\r\n    height: 45px;\r\n    border-radius: 25px;\r\n    font: bold 20px FS Elliot Pro;\r\n    border: none;\r\n  }\r\n \r\n.inputs-busqueda[_ngcontent-%COMP%] {\r\n    margin-bottom: 25px;\r\n  }\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2Nlc28uY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLGdCQUFnQjtJQUNoQixpQkFBaUI7SUFDakIsa0JBQWtCO0lBQ2xCLFdBQVc7QUFDZjs7QUFFQTtJQUNJLG1CQUFtQjtJQUNuQixXQUFXO0lBQ1gsbUJBQW1CO0lBQ25CLFlBQVk7SUFDWixhQUFhO0lBQ2IsdUJBQXVCO0lBQ3ZCLG1CQUFtQjtJQUNuQix5QkFBeUI7SUFDekIsWUFBWTtJQUNaLFVBQVU7SUFDVixpQ0FBaUM7SUFDakMsdUJBQXVCO0FBQzNCOztBQUdBO0lBQ0ksOEJBQThCO0FBQ2xDOztBQUVBO0lBQ0ksOEJBQThCO0FBQ2xDOztBQUVBO0lBQ0ksOEJBQThCO0FBQ2xDOztBQUNBO0lBQ0ksa0JBQWtCO0lBQ2xCLG1CQUFtQjtJQUNuQiw2QkFBNkI7SUFDN0IsZ0NBQWdDO0lBQ2hDLFdBQVc7SUFDWCxnQkFBZ0I7SUFDaEIsWUFBWTtJQUNaLGFBQWE7SUFDYix1QkFBdUI7SUFDdkIsbUJBQW1CO0lBQ25CLHdCQUF3QjtJQUN4QixZQUFZO0lBQ1osYUFBYTtBQUNqQjs7QUFFQTtJQUNJLGtCQUFrQjtJQUNsQixtQkFBbUI7SUFDbkIsV0FBVztJQUNYLGdCQUFnQjtJQUNoQixtQkFBbUI7SUFDbkIsNkJBQTZCO0lBQzdCLGdDQUFnQztJQUNoQyxZQUFZO0lBQ1osYUFBYTtJQUNiLHVCQUF1QjtJQUN2QixtQkFBbUI7SUFDbkIseUJBQXlCO0lBQ3pCLFlBQVk7SUFDWixpQ0FBaUM7SUFDakMsa0JBQWtCO0lBQ2xCLG1CQUFtQjs7QUFFdkI7O0FBRUE7SUFDSSxVQUFVO0FBQ2Q7O0FBRUE7SUFDSSxVQUFVO0FBQ2Q7O0FBRUE7SUFDSSxVQUFVO0FBQ2Q7O0FBRUE7SUFDSSxVQUFVO0FBQ2Q7O0FBQ0E7SUFDSSxVQUFVO0lBQ1YsbUJBQW1CO0FBQ3ZCOztBQUdBO0lBQ0ksZ0JBQWdCO0FBQ3BCOztBQUVBO0lBQ0ksbUJBQW1CO0lBQ25CLGdCQUFnQjtJQUNoQixVQUFVO0lBQ1YsaUVBQWlFO0FBQ3JFOztBQUdBO0lBQ0ksa0JBQWtCO0lBQ2xCLGVBQWU7SUFDZixVQUFVO0lBQ1YsaUVBQWlFOztFQUVuRTs7QUFDRjtJQUNJLHdCQUF3QjtBQUM1Qjs7QUFDQTtJQUNJLGNBQWM7SUFDZCwyQkFBMkI7QUFDL0I7O0FBRUE7SUFDSSxnREFBZ0Q7O0FBRXBEOztBQUNBO0lBQ0ksK0NBQStDO0lBQy9DLG1CQUFtQjtJQUNuQixXQUFXO0lBQ1gsY0FBYztJQUNkLHFCQUFxQjtJQUNyQixrQkFBa0I7SUFDbEIsbURBQW1EO0FBQ3ZEOztBQUVBO0lBQ0ksWUFBWTtJQUNaLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsMEJBQTBCO0lBQzFCLDZCQUE2QjtJQUM3QixZQUFZO0lBQ1osWUFBWTtJQUNaLDZCQUE2QjtJQUM3QixrQkFBa0I7SUFDbEIsZ0JBQWdCO0lBQ2hCLHFCQUFxQjtBQUN6Qjs7QUFDQTtJQUNJLGtCQUFrQjtJQUNsQixpQkFBaUI7SUFDakIsMEJBQTBCO0lBQzFCLGNBQWM7SUFDZCx3QkFBd0I7SUFDeEIsWUFBWTtJQUNaLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIscUJBQXFCO0lBQ3JCLHNCQUFzQjtBQUMxQjs7QUFFQTtJQUNJLFlBQVk7SUFDWjs7QUFHSjtJQUNJLHlCQUF5QjtBQUM3Qjs7QUFFQTtJQUNJLHlCQUF5QjtBQUM3Qjs7QUFFQTtJQUNJLHlCQUF5QjtBQUM3Qjs7QUFFQTtJQUNJLHlCQUF5QjtBQUM3Qjs7QUFHQTtJQUNJLHlCQUF5QjtJQUN6QixxQkFBcUI7SUFDckIsb0JBQW9CO0FBQ3hCOztBQUNBOztJQUVJLGVBQWU7RUFDakI7O0FBRUY7SUFDSSxjQUFjO0lBQ2QsZ0RBQWdEO0lBQ2hELG1CQUFtQjtJQUNuQixnQkFBZ0I7QUFDcEI7O0FBRUE7SUFDSSxVQUFVO0lBQ1YsV0FBVztJQUNYLGlCQUFpQjs7SUFFakIsK0JBQStCO0FBQ25DOztBQUVBO0lBQ0k7O0FBRUo7O0FBQ0E7SUFDSSxTQUFTO0FBQ2I7O0FBRUE7SUFDSSxXQUFXO0lBQ1gsK0NBQStDO0lBQy9DLG1CQUFtQjtJQUNuQixVQUFVO0lBQ1YsYUFBYTtJQUNiLGNBQWM7SUFDZCxzQkFBc0I7SUFDdEIsbUJBQW1CO0lBQ25CLG1CQUFtQjtJQUNuQiwrQkFBK0I7SUFDL0Isa0NBQWtDO0VBQ3BDOztBQUVBO0lBQ0UsY0FBYztJQUNkLGFBQWE7SUFDYixZQUFZO0lBQ1osV0FBVztJQUNYLFlBQVk7SUFDWixhQUFhO0lBQ2IsbUJBQW1CO0lBQ25CLDZCQUE2QjtFQUMvQjs7QUFFQTtJQUNFLHlCQUF5QjtJQUN6QixZQUFZO0lBQ1osWUFBWTtJQUNaLFlBQVk7SUFDWixtQkFBbUI7SUFDbkIsNkJBQTZCO0lBQzdCLFlBQVk7RUFDZDs7QUFFQTtJQUNFLG1CQUFtQjtFQUNyQiIsImZpbGUiOiJwcm9jZXNvLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY29udGFpbmVyLXByb2dlc28ge1xyXG4gICAgbWFyZ2luLXRvcDogMjVweDtcclxuICAgIG1hcmdpbi1sZWZ0OiBhdXRvO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbn1cclxuIFxyXG4uc3RlcC1wcm9jZXNve1xyXG4gICAgYmFja2dyb3VuZDogIzdDNjlDMztcclxuICAgIHdpZHRoOiBhdXRvO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTBweDtcclxuICAgIGhlaWdodDogNjNweDtcclxuICAgIGRpc3BsYXk6IGZsZXg7IFxyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgZm9udDogIDE2cHggRlMgRWxsaW90IFBybztcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIHotaW5kZXg6IDY7XHJcbiAgICBib3gtc2hhZG93OiAzcHggM3B4IDVweCAjMDAwMDAwMzM7XHJcbiAgICBwYWRkaW5nOiAwcHggIWltcG9ydGFudDtcclxufVxyXG5cclxuXHJcbi5zdGVwLWluY29tcGxldG97XHJcbiAgICBiYWNrZ3JvdW5kOiAjRkY5MjMxICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5zdGVwLWNvbXBsZXRhZG97XHJcbiAgICBiYWNrZ3JvdW5kOiAjN0M2OUMzICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5zdGVwLWNvbXBsZXRhZG8tZmluYWx7XHJcbiAgICBiYWNrZ3JvdW5kOiAjNDY0RTdFICFpbXBvcnRhbnQ7XHJcbn1cclxuLnN0ZXAtcHJvY2Vzby1kaXNhYmxlZHtcclxuICAgIG1hcmdpbi1sZWZ0OiAtMjVweDtcclxuICAgIGJhY2tncm91bmQ6ICNENkQ2RDY7XHJcbiAgICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogNTBweDtcclxuICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiA1MHB4O1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBtaW4td2lkdGg6IDIwMHB4O1xyXG4gICAgaGVpZ2h0OiA2M3B4O1xyXG4gICAgZGlzcGxheTogZmxleDsgXHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBmb250OiAxNnB4IEZTIEVsbGlvdCBQcm87XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBwYWRkaW5nOiAzMHB4O1xyXG59XHJcblxyXG4uc3RlcC1wcm9jZXNvLWVuYWJsZWR7XHJcbiAgICBtYXJnaW4tbGVmdDogLTUwcHg7XHJcbiAgICBiYWNrZ3JvdW5kOiAjN0M2OUMzO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBtaW4td2lkdGg6IDIwMHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTBweDtcclxuICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IC01MHB4O1xyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogLTUwcHg7XHJcbiAgICBoZWlnaHQ6IDYzcHg7XHJcbiAgICBkaXNwbGF5OiBmbGV4OyBcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGZvbnQ6ICAxNnB4IEZTIEVsbGlvdCBQcm87XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBib3gtc2hhZG93OiAzcHggM3B4IDVweCAjMDAwMDAwMzM7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDYwcHg7XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiAyNXB4O1xyXG5cclxufVxyXG5cclxuLnN0ZXAtMS1wcm9jZXNve1xyXG4gICAgei1pbmRleDogNDtcclxufVxyXG5cclxuLnN0ZXAtMi1wcm9jZXNve1xyXG4gICAgei1pbmRleDogMztcclxufVxyXG5cclxuLnN0ZXAtMy1wcm9jZXNve1xyXG4gICAgei1pbmRleDogMjtcclxufVxyXG5cclxuLnN0ZXAtNC1wcm9jZXNve1xyXG4gICAgei1pbmRleDogMTtcclxufVxyXG4uc3RlcC00LXByb2Nlc28tZmluYWxpemFkb3tcclxuICAgIHotaW5kZXg6IDE7XHJcbiAgICBiYWNrZ3JvdW5kOiAjNDY0RTdFO1xyXG59XHJcblxyXG5cclxuLmNvbnRhaW5lci1yZWZlcmVuY2lhcy1sb2d7XHJcbiAgICBtYXJnaW4tdG9wOiAzMHB4OyAgIFxyXG59XHJcblxyXG4uc2hvdy1lamVjdWNpb25lc3tcclxuICAgIHZpc2liaWxpdHk6IHZpc2libGU7XHJcbiAgICBtYXgtaGVpZ2h0OiAzMHB4O1xyXG4gICAgb3BhY2l0eTogMTtcclxuICAgIHRyYW5zaXRpb246IHZpc2liaWxpdHkgMC4zcywgb3BhY2l0eSAwLjNzLCBtYXgtaGVpZ2h0IDAuNXMgbGluZWFyO1xyXG59XHJcblxyXG5cclxuLmhpZGUtZWplY3VjaW9uZXN7XHJcbiAgICB2aXNpYmlsaXR5OiBoaWRkZW47XHJcbiAgICBtYXgtaGVpZ2h0OiAwcHg7XHJcbiAgICBvcGFjaXR5OiAwO1xyXG4gICAgdHJhbnNpdGlvbjogdmlzaWJpbGl0eSAwLjNzLCBvcGFjaXR5IDAuM3MsIG1heC1oZWlnaHQgMC4zcyBsaW5lYXI7XHJcbiAgXHJcbiAgfVxyXG4uY29udGFpbmVyLXJlZmVyZW5jaWFzLWxvZyAgYSB7XHJcbiAgICBmb250OiAyMHB4IEZTIEVsbGlvdCBQcm87XHJcbn1cclxuLmNvbnRhaW5lci1yZWZlcmVuY2lhcy1sb2cgIGE6aG92ZXIge1xyXG4gICAgY29sb3I6ICM3QzY5QzM7XHJcbiAgICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZSA7XHJcbn1cclxuXHJcbi50aXRsZS1sb2ctdGFibGV7XHJcbiAgICBmb250OiBub3JtYWwgbm9ybWFsIGJvbGQgMThweC80NXB4IEZTIEVsbGlvdCBQcm87XHJcbiBcclxufVxyXG50YWJsZS5saXN0YWRvLWxvZ3tcclxuICAgIGJhY2tncm91bmQ6ICNGRkZGRkYgMCUgMCUgbm8tcmVwZWF0IHBhZGRpbmctYm94O1xyXG4gICAgYWxpZ24tY29udGVudDogbGVmdDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgbWFyZ2luOiAxNXB4IDA7XHJcbiAgICBib3JkZXItc3BhY2luZzogMCA2cHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBmb250OiBub3JtYWwgbm9ybWFsIG5vcm1hbCAxNXB4LzE4cHggRlMgRWxsaW90IFBybyA7XHJcbn1cclxuXHJcbnRhYmxlLmxpc3RhZG8tbG9nICB0aHtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIHBhZGRpbmctbGVmdDogMjBweDtcclxuICAgIG1hcmdpbi1sZWZ0OiAyMHB4O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzQ2NEU3RSA7XHJcbiAgICBmb250OiBib2xkIDE4cHggRlMgRWxsaW90IFBybztcclxuICAgIGhlaWdodDogNDBweDtcclxuICAgIGhlaWdodDogNDBweDtcclxuICAgIGZvbnQ6IGJvbGQgMThweCBGUyBFbGxpb3QgUHJvO1xyXG4gICAgdGFibGUtbGF5b3V0OmZpeGVkO1xyXG4gICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgIGFsaWduLWNvbnRlbnQ6IGNlbnRlcjtcclxufVxyXG50YWJsZS5saXN0YWRvLWxvZyAgdGR7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDIwcHg7XHJcbiAgICBtYXJnaW4tbGVmdDogMjBweDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNGRkZGRkYgO1xyXG4gICAgY29sb3I6ICM3MDcwNzA7XHJcbiAgICBmb250OiAxNXB4IEZTIEVsbGlvdCBQcm87XHJcbiAgICBoZWlnaHQ6IDQwcHg7XHJcbiAgICBtYXJnaW46IDZweCAwcHg7XHJcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gICAgYWxpZ24tY29udGVudDogY2VudGVyO1xyXG4gICAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcclxufVxyXG5cclxudGFibGUubGlzdGFkby1sb2cgdGQud2lkZVJvdywgdGFibGUgdGgud2lkZVJvd3tcclxuICAgIHdpZHRoOiAzMDBweDtcclxuICAgIH1cclxuXHJcblxyXG4uZXJyb3ItbG9ne1xyXG4gICAgY29sb3I6ICNDMDAwMDAgIWltcG9ydGFudDtcclxufVxyXG5cclxuLndhcm5pbmctbG9ne1xyXG4gICAgY29sb3I6ICNGRjcwMDAgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmluZm8tbG9ne1xyXG4gICAgY29sb3I6ICMxNzkxREEgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmRlYnVnLWxvZ3tcclxuICAgIGNvbG9yOiAjRkY3MDAwICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcblxyXG50YWJsZS5saXN0YWRvLWVqZWN1Y2lvbmVzIHRyOmhvdmVyIHRkIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNjNWM1YzU7XHJcbiAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbiAgICB0cmFuc2l0aW9uOiBhbGwgMC4zcztcclxufVxyXG4uY2xpY2thYmxlIHtcclxuICAgIFxyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gIH1cclxuXHJcbi50aXR1bG8tcHJvY2Vzb3tcclxuICAgIGNvbG9yOiAjNDY0RTdFO1xyXG4gICAgZm9udDogbm9ybWFsIG5vcm1hbCBib2xkIDIwcHgvMjBweCBGUyBFbGxpb3QgUHJvO1xyXG4gICAgbGV0dGVyLXNwYWNpbmc6IDBweDtcclxuICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbn1cclxuXHJcbi5zaG93LWluZm97XHJcbiAgICB3aWR0aDogODAlO1xyXG4gICAgaGVpZ2h0OiAxcHg7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDVweDtcclxuICAgIFxyXG4gICAgYmFja2dyb3VuZDogI2EwYTBhMCAgIWltcG9ydGFudDtcclxufVxyXG5cclxuLnNob3ctaW5mby1idXR0b246aG92ZXIge1xyXG4gICAgY3Vyc29yOiBwb2ludGVyXHJcblxyXG59XHJcbi5oaWRlLWRpdiB7XHJcbiAgICBtYXJnaW46IDA7XHJcbn1cclxuXHJcbmRpdi5jYXJkLWNhbGVuZGFyaW97XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGJhY2tncm91bmQ6ICNmZmZmZmYgMCUgMCUgbm8tcmVwZWF0IHBhZGRpbmctYm94O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMzBweDtcclxuICAgIG9wYWNpdHk6IDE7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgbWFyZ2luOiAyNXB4IDA7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGJvcmRlci1yYWRpdXM6IDI1cHg7XHJcbiAgICBib3JkZXItbGVmdDogMTBweCBzb2xpZCAjNDY0RTdFO1xyXG4gICAgYm94LXNoYWRvdzogNHB4IDRweCAxMHB4ICMwMDAwMDAzMztcclxuICB9XHJcbiAgXHJcbiAgLmNhcmQtY2FsZW5kYXJpbyBkaXYge1xyXG4gICAgY29sb3I6ICM0NjRFN0U7XHJcbiAgICBib3JkZXI6IGJsYWNrO1xyXG4gICAgaGVpZ2h0OiBhdXRvO1xyXG4gICAgd2lkdGg6IGF1dG87XHJcbiAgICBmbGV4LWdyb3c6IDE7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGZvbnQ6IGJvbGQgMjBweCBGUyBFbGxpb3QgUHJvO1xyXG4gIH1cclxuICBcclxuICAuY2FyZC1jYWxlbmRhcmlvIGRpdiA+IGJ1dHRvbiB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjN0M2OUMzO1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgd2lkdGg6IDI5NnB4O1xyXG4gICAgaGVpZ2h0OiA0NXB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMjVweDtcclxuICAgIGZvbnQ6IGJvbGQgMjBweCBGUyBFbGxpb3QgUHJvO1xyXG4gICAgYm9yZGVyOiBub25lO1xyXG4gIH1cclxuXHJcbiAgLmlucHV0cy1idXNxdWVkYSB7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAyNXB4O1xyXG4gIH0iXX0= */"] });


/***/ }),

/***/ "oKwr":
/*!*****************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/procesos/procesos-routing.module.ts ***!
  \*****************************************************************************/
/*! exports provided: ProcesosRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProcesosRoutingModule", function() { return ProcesosRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _proceso_proceso_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./proceso/proceso.component */ "g5FI");
/* harmony import */ var _procesos_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./procesos.component */ "+U3K");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");





const routes = [
    {
        path: '',
        component: _procesos_component__WEBPACK_IMPORTED_MODULE_2__["ProcesosComponent"],
        children: [
            {
                path: '',
                loadChildren: () => Promise.all(/*! import() | procesos-pantalla-general-procesos-pantalla-general-module */[__webpack_require__.e("default~auditoriageneral-auditoriageneral-module~home-home-module~procesos-pantalla-general-procesos~0807e121"), __webpack_require__.e("default~procesos-pantalla-general-procesos-pantalla-general-module~usuarios-usuarios-module"), __webpack_require__.e("common"), __webpack_require__.e("procesos-pantalla-general-procesos-pantalla-general-module")]).then(__webpack_require__.bind(null, /*! ./procesos-pantalla-general/procesos-pantalla-general.module */ "yKHc")).then((m) => m.ProcesosPantallaGeneralModule),
            },
            {
                path: ':id', component: _proceso_proceso_component__WEBPACK_IMPORTED_MODULE_1__["ProcesoComponent"]
            },
        ],
    },
];
class ProcesosRoutingModule {
}
ProcesosRoutingModule.ɵfac = function ProcesosRoutingModule_Factory(t) { return new (t || ProcesosRoutingModule)(); };
ProcesosRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({ type: ProcesosRoutingModule });
ProcesosRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](ProcesosRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] }); })();


/***/ }),

/***/ "oy6u":
/*!*******************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/auditoria/procesos/procesos.module.ts ***!
  \*******************************************************************************/
/*! exports provided: ProcesosModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProcesosModule", function() { return ProcesosModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _procesos_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./procesos-routing.module */ "Wvdv");
/* harmony import */ var _procesos_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./procesos.component */ "OGP1");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




class ProcesosModule {
}
ProcesosModule.ɵfac = function ProcesosModule_Factory(t) { return new (t || ProcesosModule)(); };
ProcesosModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({ type: ProcesosModule });
ProcesosModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
            _procesos_routing_module__WEBPACK_IMPORTED_MODULE_1__["ProcesosRoutingModule"]
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](ProcesosModule, { declarations: [_procesos_component__WEBPACK_IMPORTED_MODULE_2__["ProcesosComponent"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
        _procesos_routing_module__WEBPACK_IMPORTED_MODULE_1__["ProcesosRoutingModule"]] }); })();


/***/ })

}]);
//# sourceMappingURL=procesos-procesos-module.js.map