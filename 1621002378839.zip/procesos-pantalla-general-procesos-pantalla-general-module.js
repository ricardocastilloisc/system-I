(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["procesos-pantalla-general-procesos-pantalla-general-module"],{

/***/ "JMRq":
/*!*****************************************************************************!*\
  !*** ./node_modules/ngx-order-pipe/__ivy_ngcc__/fesm2015/ngx-order-pipe.js ***!
  \*****************************************************************************/
/*! exports provided: OrderModule, OrderPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OrderModule", function() { return OrderModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OrderPipe", function() { return OrderPipe; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");



class OrderPipe {
    /**
     * Check if a value is a string
     *
     * @param value
     */
    static isString(value) {
        return typeof value === "string" || value instanceof String;
    }
    /**
     * Sorts values ignoring the case
     *
     * @param a
     * @param b
     */
    static caseInsensitiveSort(a, b) {
        if (OrderPipe.isString(a) && OrderPipe.isString(b)) {
            return a.localeCompare(b);
        }
        return OrderPipe.defaultCompare(a, b);
    }
    /**
     * Default compare method
     *
     * @param a
     * @param b
     */
    static defaultCompare(a, b) {
        if (a && a instanceof Date) {
            a = a.getTime();
        }
        if (b && b instanceof Date) {
            b = b.getTime();
        }
        if (a === b) {
            return 0;
        }
        if (a == null) {
            return 1;
        }
        if (b == null) {
            return -1;
        }
        return a > b ? 1 : -1;
    }
    /**
     * Parse expression, split into items
     * @param expression
     * @returns {string[]}
     */
    static parseExpression(expression) {
        expression = expression.replace(/\[(\w+)\]/g, ".$1");
        expression = expression.replace(/^\./, "");
        return expression.split(".");
    }
    /**
     * Get value by expression
     *
     * @param object
     * @param expression
     * @returns {any}
     */
    static getValue(object, expression) {
        for (let i = 0, n = expression.length; i < n; ++i) {
            if (!object) {
                return;
            }
            const k = expression[i];
            if (!(k in object)) {
                return;
            }
            if (typeof object[k] === "function") {
                object = object[k]();
            }
            else {
                object = object[k];
            }
        }
        return object;
    }
    /**
     * Set value by expression
     *
     * @param object
     * @param value
     * @param expression
     */
    static setValue(object, value, expression) {
        let i;
        for (i = 0; i < expression.length - 1; i++) {
            object = object[expression[i]];
        }
        object[expression[i]] = value;
    }
    transform(value, expression, reverse, isCaseInsensitive = false, comparator) {
        if (!value) {
            return value;
        }
        if (Array.isArray(expression)) {
            return this.multiExpressionTransform(value, expression, reverse, isCaseInsensitive, comparator);
        }
        if (Array.isArray(value)) {
            return this.sortArray(value.slice(), expression, reverse, isCaseInsensitive, comparator);
        }
        if (typeof value === "object") {
            return this.transformObject(Object.assign({}, value), expression, reverse, isCaseInsensitive, comparator);
        }
        return value;
    }
    /**
     * Sort array
     *
     * @param value
     * @param expression
     * @param reverse
     * @param isCaseInsensitive
     * @param comparator
     * @returns {any[]}
     */
    sortArray(value, expression, reverse, isCaseInsensitive, comparator) {
        const isDeepLink = expression && expression.indexOf(".") !== -1;
        if (isDeepLink) {
            expression = OrderPipe.parseExpression(expression);
        }
        let compareFn;
        if (comparator && typeof comparator === "function") {
            compareFn = comparator;
        }
        else {
            compareFn = isCaseInsensitive
                ? OrderPipe.caseInsensitiveSort
                : OrderPipe.defaultCompare;
        }
        const array = value.sort((a, b) => {
            if (!expression) {
                return compareFn(a, b);
            }
            if (!isDeepLink) {
                if (a && b) {
                    return compareFn(a[expression], b[expression]);
                }
                return compareFn(a, b);
            }
            return compareFn(OrderPipe.getValue(a, expression), OrderPipe.getValue(b, expression));
        });
        if (reverse) {
            return array.reverse();
        }
        return array;
    }
    /**
     * Transform Object
     *
     * @param value
     * @param expression
     * @param reverse
     * @param isCaseInsensitive
     * @param comparator
     * @returns {any[]}
     */
    transformObject(value, expression, reverse, isCaseInsensitive, comparator) {
        const parsedExpression = OrderPipe.parseExpression(expression);
        let lastPredicate = parsedExpression.pop();
        let oldValue = OrderPipe.getValue(value, parsedExpression);
        if (!Array.isArray(oldValue)) {
            parsedExpression.push(lastPredicate);
            lastPredicate = null;
            oldValue = OrderPipe.getValue(value, parsedExpression);
        }
        if (!oldValue) {
            return value;
        }
        OrderPipe.setValue(value, this.transform(oldValue, lastPredicate, reverse, isCaseInsensitive), parsedExpression);
        return value;
    }
    /**
     * Apply multiple expressions
     *
     * @param value
     * @param {any[]} expressions
     * @param {boolean} reverse
     * @param {boolean} isCaseInsensitive
     * @param {Function} comparator
     * @returns {any}
     */
    multiExpressionTransform(value, expressions, reverse, isCaseInsensitive = false, comparator) {
        return expressions.reverse().reduce((result, expression) => {
            return this.transform(result, expression, reverse, isCaseInsensitive, comparator);
        }, value);
    }
}
OrderPipe.ɵfac = function OrderPipe_Factory(t) { return new (t || OrderPipe)(); };
OrderPipe.ɵpipe = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefinePipe"]({ name: "orderBy", type: OrderPipe, pure: false });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](OrderPipe, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Pipe"],
        args: [{
                name: "orderBy",
                pure: false
            }]
    }], null, null); })();

/**
 * Created by vadimdez on 20/01/2017.
 */
class OrderModule {
}
OrderModule.ɵfac = function OrderModule_Factory(t) { return new (t || OrderModule)(); };
OrderModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({ type: OrderModule });
OrderModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({ providers: [OrderPipe] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](OrderModule, { declarations: [OrderPipe], exports: [OrderPipe] }); })();
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](OrderModule, [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
        args: [{
                declarations: [OrderPipe],
                exports: [OrderPipe],
                providers: [OrderPipe]
            }]
    }], null, null); })();

/**
 * Generated bundle index. Do not edit.
 */



//# sourceMappingURL=ngx-order-pipe.js.map

/***/ }),

/***/ "g1Z8":
/*!*******************************************************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/procesos/procesos-pantalla-general/procesos-pantalla-general.component.ts ***!
  \*******************************************************************************************************************/
/*! exports provided: ProcesosPantallaGeneralComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProcesosPantallaGeneralComponent", function() { return ProcesosPantallaGeneralComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var src_app_ReduxStore_actions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/ReduxStore/actions */ "p8Vo");
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! uuid */ "4USb");
/* harmony import */ var _validators_roles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./../../../../../validators/roles */ "r6zK");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ngrx_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngrx/store */ "l7P3");
/* harmony import */ var _API_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../../API.service */ "iO9l");
/* harmony import */ var _services_procesos_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../../services/procesos.service */ "WFda");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ngx-spinner */ "JqCM");
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/services/auth.service */ "lGQG");
/* harmony import */ var src_app_services_usuarios_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/services/usuarios.service */ "ESM5");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "1kSV");
/* harmony import */ var ngx_pagination__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ngx-pagination */ "oOf3");
















const _c0 = ["modalEstado"];
function ProcesosPantallaGeneralComponent_div_0_div_9_div_1_table_1_tr_6_img_4_Template(rf, ctx) { if (rf & 1) {
    const _r19 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "img", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function ProcesosPantallaGeneralComponent_div_0_div_9_div_1_table_1_tr_6_img_4_Template_img_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r19); const PROCESO_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().$implicit; _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](3); const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵreference"](7); const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2); return ctx_r18.openModal(_r5, PROCESO_r13.PROCESO); });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} }
function ProcesosPantallaGeneralComponent_div_0_div_9_div_1_table_1_tr_6_img_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](0, "img", 26);
} }
function ProcesosPantallaGeneralComponent_div_0_div_9_div_1_table_1_tr_6_img_6_Template(rf, ctx) { if (rf & 1) {
    const _r23 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "img", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function ProcesosPantallaGeneralComponent_div_0_div_9_div_1_table_1_tr_6_img_6_Template_img_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r23); const PROCESO_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().$implicit; const ctx_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](5); return ctx_r21.consultar(PROCESO_r13.PROCESO, PROCESO_r13.DESCRIPCION); });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} }
function ProcesosPantallaGeneralComponent_div_0_div_9_div_1_table_1_tr_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "td");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](4, ProcesosPantallaGeneralComponent_div_0_div_9_div_1_table_1_tr_6_img_4_Template, 1, 0, "img", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](5, ProcesosPantallaGeneralComponent_div_0_div_9_div_1_table_1_tr_6_img_5_Template, 1, 0, "img", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](6, ProcesosPantallaGeneralComponent_div_0_div_9_div_1_table_1_tr_6_img_6_Template, 1, 0, "img", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const PROCESO_r13 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](PROCESO_r13 == null ? null : PROCESO_r13.DESCRIPCION);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", PROCESO_r13.INICIAR);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", PROCESO_r13.DETENER);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", PROCESO_r13.MONITOREAR);
} }
const _c1 = function (a2) { return { id: "listadoInterfaces", itemsPerPage: 10, currentPage: a2 }; };
function ProcesosPantallaGeneralComponent_div_0_div_9_div_1_table_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "table", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "tr");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, "Proceso");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](4, "th");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](5, "Acci\u00F3n");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](6, ProcesosPantallaGeneralComponent_div_0_div_9_div_1_table_1_tr_6_Template, 7, 4, "tr", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](7, "paginate");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind2"](7, 1, ctx_r10.PROCESOS, _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpureFunction1"](4, _c1, ctx_r10.actualPage)));
} }
function ProcesosPantallaGeneralComponent_div_0_div_9_div_1_pagination_template_3_span_4_Template(rf, ctx) { if (rf & 1) {
    const _r29 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "span", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function ProcesosPantallaGeneralComponent_div_0_div_9_div_1_pagination_template_3_span_4_Template_span_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r29); _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](); const _r24 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵreference"](1); return _r24.previous(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, "<<");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} }
function ProcesosPantallaGeneralComponent_div_0_div_9_div_1_pagination_template_3_div_5_span_1_Template(rf, ctx) { if (rf & 1) {
    const _r35 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "span", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function ProcesosPantallaGeneralComponent_div_0_div_9_div_1_pagination_template_3_div_5_span_1_Template_span_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r35); const page_r30 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().$implicit; _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](); const _r24 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵreference"](1); return _r24.setCurrent(page_r30.value); });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const page_r30 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](page_r30.label);
} }
function ProcesosPantallaGeneralComponent_div_0_div_9_div_1_pagination_template_3_div_5_div_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const page_r30 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](page_r30.label);
} }
function ProcesosPantallaGeneralComponent_div_0_div_9_div_1_pagination_template_3_div_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](1, ProcesosPantallaGeneralComponent_div_0_div_9_div_1_pagination_template_3_div_5_span_1_Template, 2, 1, "span", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](2, ProcesosPantallaGeneralComponent_div_0_div_9_div_1_pagination_template_3_div_5_div_2_Template, 3, 1, "div", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const page_r30 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    const _r24 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵreference"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵclassProp"]("current", _r24.getCurrent() === page_r30.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", _r24.getCurrent() !== page_r30.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", _r24.getCurrent() === page_r30.value);
} }
function ProcesosPantallaGeneralComponent_div_0_div_9_div_1_pagination_template_3_span_7_Template(rf, ctx) { if (rf & 1) {
    const _r39 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "span", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function ProcesosPantallaGeneralComponent_div_0_div_9_div_1_pagination_template_3_span_7_Template_span_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r39); _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](); const _r24 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵreference"](1); return _r24.next(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " >> ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} }
function ProcesosPantallaGeneralComponent_div_0_div_9_div_1_pagination_template_3_Template(rf, ctx) { if (rf & 1) {
    const _r41 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "pagination-template", 28, 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("pageChange", function ProcesosPantallaGeneralComponent_div_0_div_9_div_1_pagination_template_3_Template_pagination_template_pageChange_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r41); const ctx_r40 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](4); return ctx_r40.actualPage = $event; });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "div", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "div", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](4, ProcesosPantallaGeneralComponent_div_0_div_9_div_1_pagination_template_3_span_4_Template, 2, 0, "span", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](5, ProcesosPantallaGeneralComponent_div_0_div_9_div_1_pagination_template_3_div_5_Template, 3, 4, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](6, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](7, ProcesosPantallaGeneralComponent_div_0_div_9_div_1_pagination_template_3_span_7_Template, 2, 0, "span", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const _r24 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵreference"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵclassProp"]("disabled", _r24.isFirstPage());
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", !_r24.isFirstPage());
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", _r24.pages);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵclassProp"]("disabled", _r24.isLastPage());
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", !_r24.isLastPage());
} }
function ProcesosPantallaGeneralComponent_div_0_div_9_div_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](1, ProcesosPantallaGeneralComponent_div_0_div_9_div_1_table_1_Template, 8, 6, "table", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](3, ProcesosPantallaGeneralComponent_div_0_div_9_div_1_pagination_template_3_Template, 8, 7, "pagination-template", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const CATPROCESOS_r9 = ctx.ngIf;
    const CATPERMISOS_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]().ngIf;
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r4.obtenerProcesos(CATPROCESOS_r9, CATPERMISOS_r3));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", CATPERMISOS_r3.length > 10);
} }
function ProcesosPantallaGeneralComponent_div_0_div_9_ng_template_6_Template(rf, ctx) { if (rf & 1) {
    const _r47 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](4, "Confirmar ejecuci\u00F3n de proceso");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](5, "div", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](6, "div", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](7, "Se ejecutara el proceso:");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](8, "div", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](10, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](11, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](12, "button", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function ProcesosPantallaGeneralComponent_div_0_div_9_ng_template_6_Template_button_click_12_listener() { const modal_r43 = ctx.$implicit; return modal_r43.close(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](13, "Cancelar");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](14, "button", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function ProcesosPantallaGeneralComponent_div_0_div_9_ng_template_6_Template_button_click_14_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r47); const DataUser_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2).ngIf; const ctx_r45 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](); return ctx_r45.inciarProceso(DataUser_r1.email, DataUser_r1.attributes["custom:rol"]); });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](15, "Continuar");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx_r6.procesoEjecutar, " ");
} }
function ProcesosPantallaGeneralComponent_div_0_div_9_ng_template_8_Template(rf, ctx) { if (rf & 1) {
    const _r50 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](4, "Ejecuci\u00F3n de proceso");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](5, "div", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](6, "div", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](7, "Resultado de ejecuci\u00F3n:");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](8, "div", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](10, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](11, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](12, "button", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function ProcesosPantallaGeneralComponent_div_0_div_9_ng_template_8_Template_button_click_12_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r50); const ctx_r49 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](3); return ctx_r49.cerrarModales(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](13, "Continuar");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx_r8.mensajeEjecucion, " ");
} }
function ProcesosPantallaGeneralComponent_div_0_div_9_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](1, ProcesosPantallaGeneralComponent_div_0_div_9_div_1_Template, 4, 2, "div", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "ngx-spinner", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](4, "p", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](5, "Cargando...");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](6, ProcesosPantallaGeneralComponent_div_0_div_9_ng_template_6_Template, 16, 1, "ng-template", 12, 13, _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](8, ProcesosPantallaGeneralComponent_div_0_div_9_ng_template_8_Template, 14, 1, "ng-template", 14, 15, _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplateRefExtractor"]);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](2, 2, ctx_r2.CATPROCESOS$));
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("fullScreen", true);
} }
function ProcesosPantallaGeneralComponent_div_0_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "div", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](4, "button", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](5, " Diurnos ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](6, "button", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](7, " Nocturnos ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](8, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](9, ProcesosPantallaGeneralComponent_div_0_div_9_Template, 10, 4, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](10, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngClass", ctx_r0.botonActivado("diurno") ? "botonActivado" : "");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngClass", ctx_r0.botonActivado("nocturno") ? "botonActivado" : "");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](10, 3, ctx_r0.CATPERMISOS$));
} }
class ProcesosPantallaGeneralComponent {
    constructor(router, store, rutaActiva, api, serviciosProcesos, spinner, authService, usuario, modalService, datePipe) {
        this.router = router;
        this.store = store;
        this.rutaActiva = rutaActiva;
        this.api = api;
        this.serviciosProcesos = serviciosProcesos;
        this.spinner = spinner;
        this.authService = authService;
        this.usuario = usuario;
        this.modalService = modalService;
        this.datePipe = datePipe;
        this.Areas = [
            _validators_roles__WEBPACK_IMPORTED_MODULE_4__["EArea"].Contabilidad,
            _validators_roles__WEBPACK_IMPORTED_MODULE_4__["EArea"].Custodia,
            _validators_roles__WEBPACK_IMPORTED_MODULE_4__["EArea"].Inversiones_Riesgos,
            _validators_roles__WEBPACK_IMPORTED_MODULE_4__["EArea"].Tesoreria,
            _validators_roles__WEBPACK_IMPORTED_MODULE_4__["EArea"].Soporte
        ];
        this.inputFecha = Object(_angular_common__WEBPACK_IMPORTED_MODULE_1__["formatDate"])(new Date(), 'yyyy-MM-dd', 'en-US');
        this.actualPage = 1;
        this.negocios = [];
        this.loading = true;
        this.Administrador = _validators_roles__WEBPACK_IMPORTED_MODULE_4__["ERole"].Administrador;
        this.Ejecutor = _validators_roles__WEBPACK_IMPORTED_MODULE_4__["ERole"].Monitor;
        this.PROCESOS = new Array();
        this.botonActivado = (parametocomparar) => {
            return this.rutaActiva.snapshot.params.tipo === parametocomparar
                ? true
                : false;
        };
        this.rolesValids = (User, roles) => {
            return this.authService.rolesValids(User, roles);
        };
        this.cerrarModales = () => {
            this.modalService.dismissAll();
        };
        this.spinner.show();
        setTimeout(() => {
            this.spinner.hide();
        }, 1000);
        this.rutaActiva.paramMap.subscribe(params => {
            this.ngOnInit();
        });
    }
    ngOnDestroy() {
        this.store.dispatch(Object(src_app_ReduxStore_actions__WEBPACK_IMPORTED_MODULE_2__["UnsetCATPROCESO"])());
    }
    ngOnInit() {
        this.actualPage = 1;
        this.DataUser$ = this.store.select(({ usuario }) => usuario.user);
        this.store.select(({ usuario }) => usuario.user).subscribe(res => { this.DataUser = res; });
        this.area = this.obtenerArea();
        //console.log("Negocios", this.DataUser.attributes["custom:negocio"].split(','))
        this.tipo = this.rutaActiva.snapshot.params.tipo;
        this.negocios = this.DataUser.attributes["custom:negocio"].split(',');
        this.negocios = this.negocios.map(negocio => { return negocio.toUpperCase(); });
        let bodyProcesos = {
            filter: { TIPO: { eq: this.tipo.toUpperCase() } },
            limit: 1000
        };
        let bodyPermisos = {
            NEGOCIOS: this.negocios, AREA: this.area, ROL: this.DataUser.attributes["custom:rol"].toUpperCase()
        };
        this.CATPERMISOS$ = this.store.select(({ CATPERMISOS }) => CATPERMISOS.CATPERMISOS);
        // this.store.select(
        //   ({ CATPERMISOS }) => CATPERMISOS.CATPERMISOS
        // ).subscribe(res => this.CATPERMISOS = res)
        this.api.ListCATPERMISOS(this.negocios, this.area, this.DataUser.attributes["custom:rol"].toUpperCase()).then(res => console.log('resultado', res));
        this.store.dispatch(Object(src_app_ReduxStore_actions__WEBPACK_IMPORTED_MODULE_2__["LoadCATPROCESOS"])({ consult: bodyProcesos }));
        // this.store.select(
        //   ({ CATPROCESOS }) => CATPROCESOS.CATPROCESOS
        // ).subscribe( res => this.CATPROCESOS = res)
        this.CATPROCESOS$ = this.store.select(({ CATPROCESOS }) => CATPROCESOS.CATPROCESOS);
        this.store.dispatch(Object(src_app_ReduxStore_actions__WEBPACK_IMPORTED_MODULE_2__["LoadCATPERMISOS"])({ consult: bodyPermisos }));
    }
    obtenerProcesos(catProcesos, catPermisos) {
        let tempArray = new Array();
        //console.log(catProcesos)
        //console.log(catPermisos)
        catProcesos.forEach(proceso => {
            catPermisos.forEach(permiso => {
                if (permiso.FLUJO == proceso.PROCESO)
                    tempArray.push({
                        "DESCRIPCION": proceso.DESCRIPCION,
                        "PROCESO": proceso.PROCESO,
                        "DETENER": permiso.PROCESOS.DETENER,
                        "INICIAR": permiso.PROCESOS.INICIAR,
                        "MONITOREAR": permiso.PROCESOS.MONITOREAR
                    });
            });
        });
        //console.log('tempArray', tempArray)
        this.PROCESOS = tempArray;
        return true;
    }
    obtenerArea() {
        let arrayTempArea = [];
        this.DataUser.groups.forEach((area) => {
            this.Areas.forEach(areaDef => {
                if (area === areaDef) {
                    arrayTempArea.push(area);
                }
            });
        });
        if (arrayTempArea.length > 0)
            return arrayTempArea[0].toUpperCase();
        else
            "N/D";
    }
    refreshComponent() {
        this.router.navigate([this.router.url]);
    }
    consultar(idProceso, titulo) {
        this.guardarDescripcionProceso(titulo);
        this.router.navigate(['/' + window.location.pathname + '/' + idProceso]);
    }
    openModal(content, nombreProceso) {
        this.procesoEjecutar = nombreProceso;
        this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' });
    }
    modalMensaje(content, mensajeEjecucion) {
        this.mensajeEjecucion = mensajeEjecucion;
        this.modalService.open(this.templateRef, { ariaLabelledBy: 'modal-basic-title' });
    }
    inciarProceso(correo, area) {
        var _a, _b;
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            console.log(this.procesoEjecutar);
            let CATESTADOS;
            let todayDate = new Date();
            console.log(this.datePipe.transform(todayDate, "dd-MM-yyyy"));
            this.spinner.show();
            let body = {
                filter: { INTERFAZ: { eq: this.procesoEjecutar } },
                limit: 10000000
            };
            yield this.api.ListSiaGenAudEstadoProcesosDevs(body.filter, body.limit).then(res => {
                this.CATESTADOS = res.items.slice().sort(function (a, b) { return new Date(b.FECHA_ACTUALIZACION).getTime() - new Date(a.FECHA_ACTUALIZACION).getTime(); });
            });
            //console.log('que hay aqui ', this.CATESTADOS)
            if (((_a = this.CATESTADOS[0]) === null || _a === void 0 ? void 0 : _a.ESTADO_EJECUCION) === 'TERMINADO' || this.CATESTADOS === []) {
                let idEjecucion = Object(uuid__WEBPACK_IMPORTED_MODULE_3__["v4"])();
                console.log(this.procesoEjecutar, correo, area, idEjecucion);
                try {
                    const response = yield this.serviciosProcesos.iniciarProceso(this.procesoEjecutar, correo, area);
                    if (response.codigo == 'EXITO') {
                        this.spinner.hide();
                        this.modalMensaje("modalEstado", "Se inicio el proceso");
                    }
                    else if (response.descripcion.includes('401')) {
                        this.spinner.hide();
                        this.modalService.dismissAll();
                        this.authService.signOut();
                    }
                    else {
                        this.spinner.hide();
                        console.log(response);
                        this.modalMensaje("modalEstado", "Error al ejecutar proceso: " + response.descripcion);
                    }
                }
                catch (e) {
                    this.modalMensaje("modalEstado", "Error al ejecutar proceso");
                    console.log(e.message);
                }
            }
            else if (((_b = this.CATESTADOS[0]) === null || _b === void 0 ? void 0 : _b.ESTADO_EJECUCION) === 'INICIADO') {
                this.modalMensaje("modalEstado", "El proceso se encuentra en ejecución");
            }
            else
                (this.modalMensaje("modalEstado", "Error al ejecutar proceso"));
            setTimeout(() => {
                this.spinner.hide();
            }, 300);
        });
    }
    guardarDescripcionProceso(descripcion) {
        localStorage.setItem('Titulo', JSON.stringify(descripcion));
    }
}
ProcesosPantallaGeneralComponent.ɵfac = function ProcesosPantallaGeneralComponent_Factory(t) { return new (t || ProcesosPantallaGeneralComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_ngrx_store__WEBPACK_IMPORTED_MODULE_7__["Store"]), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_6__["ActivatedRoute"]), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_API_service__WEBPACK_IMPORTED_MODULE_8__["APIService"]), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_services_procesos_service__WEBPACK_IMPORTED_MODULE_9__["ProcesosService"]), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](ngx_spinner__WEBPACK_IMPORTED_MODULE_10__["NgxSpinnerService"]), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_11__["AuthService"]), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](src_app_services_usuarios_service__WEBPACK_IMPORTED_MODULE_12__["UsuariosService"]), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_13__["NgbModal"]), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_common__WEBPACK_IMPORTED_MODULE_1__["DatePipe"])); };
ProcesosPantallaGeneralComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({ type: ProcesosPantallaGeneralComponent, selectors: [["app-procesos-pantalla-general"]], viewQuery: function ProcesosPantallaGeneralComponent_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵviewQuery"](_c0, 1);
    } if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵloadQuery"]()) && (ctx.templateRef = _t.first);
    } }, decls: 2, vars: 3, consts: [["class", "container-fluid", 4, "ngIf"], [1, "container-fluid"], [1, "flex-row-reverse", "justify-content-center", 2, "height", "20vh", "width", "100%"], [1, "row", "justify-content-center"], [1, "d-flex", "col-md-4", "col-xs-4", "col-sm-4", "col-lg-4", "mr-4", "col-4", "align-items-center", "selector-proceso", 2, "height", "45px"], ["id", "left-button", "routerLink", "/procesos/diurno", 3, "ngClass"], ["id", "right-button", "routerLink", "/procesos/nocturno", 3, "ngClass"], ["class", "d-flex col-md-6 col-sm-6 col-xs-6 col-lg-6 col-xl-6 justify-content-center", 4, "ngIf"], [1, "d-flex", "col-md-6", "col-sm-6", "col-xs-6", "col-lg-6", "col-xl-6", "justify-content-center"], ["class", "d-flex  row card-lista-proceso", "style", "overflow-x:auto;", 4, "ngIf"], ["bdColor", "rgba(0, 0, 0, 0.8)", "size", "large", "color", "#fff", "type", "ball-climbing-dot", 3, "fullScreen"], [2, "color", "white"], ["id", "confirmacion"], ["confirmacion", ""], ["id", "modalEstado"], ["modalEstado", ""], [1, "d-flex", "row", "card-lista-proceso", 2, "overflow-x", "auto"], ["class", "table  listado-proceso", 4, "ngIf"], [1, "paginator", "align-items-left"], ["id", "listadoInterfaces", "class", "ngx-pagination", 3, "pageChange", 4, "ngIf"], [1, "table", "listado-proceso"], [4, "ngFor", "ngForOf"], ["class", "play-icon", 3, "click", 4, "ngIf"], ["class", "stop-icon", 4, "ngIf"], ["class", "detalle-icon", 3, "click", 4, "ngIf"], [1, "play-icon", 3, "click"], [1, "stop-icon"], [1, "detalle-icon", 3, "click"], ["id", "listadoInterfaces", 1, "ngx-pagination", 3, "pageChange"], ["p", "paginationApi"], [1, "custom-pagination"], [1, "pagination-previous"], [3, "click", 4, "ngIf"], ["class", "page-number", 3, "current", 4, "ngFor", "ngForOf"], [1, "pagination-next"], [3, "click"], [1, "page-number"], [4, "ngIf"], [1, "modal-body"], [1, "col-12", "row", "justify-content-center", "align-items-center", 2, "height", "120px"], [1, "textoConfirmacionModalUsuarios"], [1, "col-12", "row"], [1, "col-12", "descripcionConfirmacionEjecucionProceso"], [1, "btn", "bottonCancelarEjecucionProceso", 3, "click"], [1, "btn", "bottonConfirmarEjecucionProceso", 3, "click"]], template: function ProcesosPantallaGeneralComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](0, ProcesosPantallaGeneralComponent_div_0_Template, 11, 5, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipe"](1, "async");
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵpipeBind1"](1, 1, ctx.DataUser$));
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["NgIf"], _angular_router__WEBPACK_IMPORTED_MODULE_6__["RouterLink"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgClass"], ngx_spinner__WEBPACK_IMPORTED_MODULE_10__["NgxSpinnerComponent"], _angular_common__WEBPACK_IMPORTED_MODULE_1__["NgForOf"], ngx_pagination__WEBPACK_IMPORTED_MODULE_14__["PaginationControlsDirective"]], pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["AsyncPipe"], ngx_pagination__WEBPACK_IMPORTED_MODULE_14__["PaginatePipe"]], styles: [".wrapper[_ngcontent-%COMP%] {\r\n  display: flex;\r\n  flex-wrap: wrap;\r\n}\r\n\r\n.content[_ngcontent-%COMP%] {\r\n  width: 100%;\r\n  display: flex;\r\n  flex-wrap: wrap;\r\n  flex-direction: column;\r\n}\r\n\r\ndiv.container-selector-proceso[_ngcontent-%COMP%] {\r\n  width: auto;\r\n  height: 45px;\r\n\r\n  margin-bottom: 50px;\r\n  margin-top: 50px;\r\n}\r\n\r\n.selector-proceso[_ngcontent-%COMP%] {\r\n  width: auto;\r\n  height: 45px;\r\n  border-radius: 25px;\r\n  min-width: 328px;\r\n  margin-bottom: 50px;\r\n  margin-top: 50px;\r\n}\r\n\r\n.selector-proceso[_ngcontent-%COMP%]    > button[_ngcontent-%COMP%] {\r\n  width: 50%;\r\n  height: 45px;\r\n  height: 100%;\r\n  border: none;\r\n  background: white;\r\n  color: #464E7E;\r\n  font: bold 20px FS Elliot Pro;\r\n  cursor: pointer;\r\n}\r\n\r\n.selector-proceso[_ngcontent-%COMP%]    > button[_ngcontent-%COMP%]:focus {\r\n  background-color: #464E7E;\r\n  color: white;\r\n  transition: background 0.2s linear;\r\n  box-shadow: 3px 3px 5px #464E7E;\r\n}\r\n\r\n#right-button[_ngcontent-%COMP%] {\r\n  border-top-right-radius: 25px 25px;\r\n  border-bottom-right-radius: 25px 25px;\r\n}\r\n\r\n#left-button[_ngcontent-%COMP%] {\r\n  border-top-left-radius: 25px 25px;\r\n  border-bottom-left-radius: 25px 25px;\r\n}\r\n\r\n.container-procesos[_ngcontent-%COMP%] {\r\n  background: red;\r\n  display: flex;\r\n  flex: 1;\r\n  flex-wrap: wrap;\r\n  flex-direction: row;\r\n  align-content: center;\r\n  justify-content: center;\r\n  border-radius: 25px;\r\n  margin: 25px 0;\r\n  width: 95%;\r\n}\r\n\r\ndiv.card-lista-proceso[_ngcontent-%COMP%] {\r\n  width: auto;\r\n  \r\n  min-width: 477px;\r\n  flex: auto;\r\n  display: flex;\r\n  flex-wrap: wrap;\r\n  vertical-align: middle;\r\n}\r\n\r\ntable.listado-proceso[_ngcontent-%COMP%] {\r\n  color: white;\r\n  width: 100%;\r\n  margin: 25px 0;\r\n  margin-left: 5%;\r\n  margin-right: 5%;\r\n  text-align: center;\r\n  border-collapse: separate;\r\n  border-spacing: 0 6px;\r\n}\r\n\r\ntable.listado-proceso[_ngcontent-%COMP%]   th[_ngcontent-%COMP%] {\r\n  background-color: #464E7E;\r\n  font: bold 18px FS Elliot Pro;\r\n  height: 40px;\r\n  font: bold 18px FS Elliot Pro;\r\n}\r\n\r\ntable.listado-proceso[_ngcontent-%COMP%]   td[_ngcontent-%COMP%] {\r\n  text-align: center;\r\n  background-color: white;\r\n  color: #707070;\r\n  font: 18px FS Elliot Pro;\r\n  height: 40px;\r\n  margin: 6px 0px;\r\n  min-width: 210px;\r\n}\r\n\r\n.listado-proceso[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]:first-of-type {\r\n  border-top-left-radius: 25px;\r\n  border-bottom-left-radius: 25px;\r\n}\r\n\r\n.listado-proceso[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]   td[_ngcontent-%COMP%]:last-of-type {\r\n  border-top-right-radius: 25px;\r\n  border-bottom-right-radius: 25px;\r\n}\r\n\r\n.paginator[_ngcontent-%COMP%]{\r\n  margin-left: 5%;\r\n  margin-right: 5%;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2Nlc29zLXBhbnRhbGxhLWdlbmVyYWwuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGFBQWE7RUFDYixlQUFlO0FBQ2pCOztBQUVBO0VBQ0UsV0FBVztFQUNYLGFBQWE7RUFDYixlQUFlO0VBQ2Ysc0JBQXNCO0FBQ3hCOztBQUVBO0VBQ0UsV0FBVztFQUNYLFlBQVk7O0VBRVosbUJBQW1CO0VBQ25CLGdCQUFnQjtBQUNsQjs7QUFFQTtFQUNFLFdBQVc7RUFDWCxZQUFZO0VBQ1osbUJBQW1CO0VBQ25CLGdCQUFnQjtFQUNoQixtQkFBbUI7RUFDbkIsZ0JBQWdCO0FBQ2xCOztBQUVBO0VBQ0UsVUFBVTtFQUNWLFlBQVk7RUFDWixZQUFZO0VBQ1osWUFBWTtFQUNaLGlCQUFpQjtFQUNqQixjQUFjO0VBQ2QsNkJBQTZCO0VBQzdCLGVBQWU7QUFDakI7O0FBQ0E7RUFDRSx5QkFBeUI7RUFDekIsWUFBWTtFQUNaLGtDQUFrQztFQUNsQywrQkFBK0I7QUFDakM7O0FBQ0E7RUFDRSxrQ0FBa0M7RUFDbEMscUNBQXFDO0FBQ3ZDOztBQUVBO0VBQ0UsaUNBQWlDO0VBQ2pDLG9DQUFvQztBQUN0Qzs7QUFFQTtFQUNFLGVBQWU7RUFDZixhQUFhO0VBQ2IsT0FBTztFQUNQLGVBQWU7RUFDZixtQkFBbUI7RUFDbkIscUJBQXFCO0VBQ3JCLHVCQUF1QjtFQUN2QixtQkFBbUI7RUFDbkIsY0FBYztFQUNkLFVBQVU7QUFDWjs7QUFJQTtFQUNFLFdBQVc7O0VBRVgsZ0JBQWdCO0VBQ2hCLFVBQVU7RUFDVixhQUFhO0VBQ2IsZUFBZTtFQUNmLHNCQUFzQjtBQUN4Qjs7QUFFQTtFQUNFLFlBQVk7RUFDWixXQUFXO0VBQ1gsY0FBYztFQUNkLGVBQWU7RUFDZixnQkFBZ0I7RUFDaEIsa0JBQWtCO0VBQ2xCLHlCQUF5QjtFQUN6QixxQkFBcUI7QUFDdkI7O0FBRUE7RUFDRSx5QkFBeUI7RUFDekIsNkJBQTZCO0VBQzdCLFlBQVk7RUFDWiw2QkFBNkI7QUFDL0I7O0FBQ0E7RUFDRSxrQkFBa0I7RUFDbEIsdUJBQXVCO0VBQ3ZCLGNBQWM7RUFDZCx3QkFBd0I7RUFDeEIsWUFBWTtFQUNaLGVBQWU7RUFDZixnQkFBZ0I7QUFDbEI7O0FBQ0E7RUFDRSw0QkFBNEI7RUFDNUIsK0JBQStCO0FBQ2pDOztBQUNBO0VBQ0UsNkJBQTZCO0VBQzdCLGdDQUFnQztBQUNsQzs7QUFFQTtFQUNFLGVBQWU7RUFDZixnQkFBZ0I7QUFDbEIiLCJmaWxlIjoicHJvY2Vzb3MtcGFudGFsbGEtZ2VuZXJhbC5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLndyYXBwZXIge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC13cmFwOiB3cmFwO1xyXG59XHJcblxyXG4uY29udGVudCB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LXdyYXA6IHdyYXA7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxufVxyXG5cclxuZGl2LmNvbnRhaW5lci1zZWxlY3Rvci1wcm9jZXNvIHtcclxuICB3aWR0aDogYXV0bztcclxuICBoZWlnaHQ6IDQ1cHg7XHJcblxyXG4gIG1hcmdpbi1ib3R0b206IDUwcHg7XHJcbiAgbWFyZ2luLXRvcDogNTBweDtcclxufVxyXG5cclxuLnNlbGVjdG9yLXByb2Nlc28ge1xyXG4gIHdpZHRoOiBhdXRvO1xyXG4gIGhlaWdodDogNDVweDtcclxuICBib3JkZXItcmFkaXVzOiAyNXB4O1xyXG4gIG1pbi13aWR0aDogMzI4cHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogNTBweDtcclxuICBtYXJnaW4tdG9wOiA1MHB4O1xyXG59XHJcblxyXG4uc2VsZWN0b3ItcHJvY2VzbyA+IGJ1dHRvbiB7XHJcbiAgd2lkdGg6IDUwJTtcclxuICBoZWlnaHQ6IDQ1cHg7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIGJvcmRlcjogbm9uZTtcclxuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcclxuICBjb2xvcjogIzQ2NEU3RTtcclxuICBmb250OiBib2xkIDIwcHggRlMgRWxsaW90IFBybztcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuLnNlbGVjdG9yLXByb2Nlc28gPiBidXR0b246Zm9jdXMge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICM0NjRFN0U7XHJcbiAgY29sb3I6IHdoaXRlO1xyXG4gIHRyYW5zaXRpb246IGJhY2tncm91bmQgMC4ycyBsaW5lYXI7XHJcbiAgYm94LXNoYWRvdzogM3B4IDNweCA1cHggIzQ2NEU3RTtcclxufVxyXG4jcmlnaHQtYnV0dG9uIHtcclxuICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogMjVweCAyNXB4O1xyXG4gIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAyNXB4IDI1cHg7XHJcbn1cclxuXHJcbiNsZWZ0LWJ1dHRvbiB7XHJcbiAgYm9yZGVyLXRvcC1sZWZ0LXJhZGl1czogMjVweCAyNXB4O1xyXG4gIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDI1cHggMjVweDtcclxufVxyXG5cclxuLmNvbnRhaW5lci1wcm9jZXNvcyB7XHJcbiAgYmFja2dyb3VuZDogcmVkO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleDogMTtcclxuICBmbGV4LXdyYXA6IHdyYXA7XHJcbiAgZmxleC1kaXJlY3Rpb246IHJvdztcclxuICBhbGlnbi1jb250ZW50OiBjZW50ZXI7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgYm9yZGVyLXJhZGl1czogMjVweDtcclxuICBtYXJnaW46IDI1cHggMDtcclxuICB3aWR0aDogOTUlO1xyXG59XHJcblxyXG5cclxuXHJcbmRpdi5jYXJkLWxpc3RhLXByb2Nlc28ge1xyXG4gIHdpZHRoOiBhdXRvO1xyXG4gIFxyXG4gIG1pbi13aWR0aDogNDc3cHg7XHJcbiAgZmxleDogYXV0bztcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtd3JhcDogd3JhcDtcclxuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xyXG59XHJcblxyXG50YWJsZS5saXN0YWRvLXByb2Nlc28ge1xyXG4gIGNvbG9yOiB3aGl0ZTtcclxuICB3aWR0aDogMTAwJTtcclxuICBtYXJnaW46IDI1cHggMDtcclxuICBtYXJnaW4tbGVmdDogNSU7XHJcbiAgbWFyZ2luLXJpZ2h0OiA1JTtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgYm9yZGVyLWNvbGxhcHNlOiBzZXBhcmF0ZTtcclxuICBib3JkZXItc3BhY2luZzogMCA2cHg7XHJcbn1cclxuXHJcbnRhYmxlLmxpc3RhZG8tcHJvY2VzbyB0aCB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzQ2NEU3RTtcclxuICBmb250OiBib2xkIDE4cHggRlMgRWxsaW90IFBybztcclxuICBoZWlnaHQ6IDQwcHg7XHJcbiAgZm9udDogYm9sZCAxOHB4IEZTIEVsbGlvdCBQcm87XHJcbn1cclxudGFibGUubGlzdGFkby1wcm9jZXNvIHRkIHtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgY29sb3I6ICM3MDcwNzA7XHJcbiAgZm9udDogMThweCBGUyBFbGxpb3QgUHJvO1xyXG4gIGhlaWdodDogNDBweDtcclxuICBtYXJnaW46IDZweCAwcHg7XHJcbiAgbWluLXdpZHRoOiAyMTBweDtcclxufVxyXG4ubGlzdGFkby1wcm9jZXNvIHRyIHRkOmZpcnN0LW9mLXR5cGUge1xyXG4gIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDI1cHg7XHJcbiAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogMjVweDtcclxufVxyXG4ubGlzdGFkby1wcm9jZXNvIHRyIHRkOmxhc3Qtb2YtdHlwZSB7XHJcbiAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDI1cHg7XHJcbiAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDI1cHg7XHJcbn1cclxuXHJcbi5wYWdpbmF0b3J7XHJcbiAgbWFyZ2luLWxlZnQ6IDUlO1xyXG4gIG1hcmdpbi1yaWdodDogNSU7XHJcbn1cclxuIl19 */"] });


/***/ }),

/***/ "oyCC":
/*!************************************************************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/procesos/procesos-pantalla-general/procesos-pantalla-general-routing.module.ts ***!
  \************************************************************************************************************************/
/*! exports provided: ProcesosPantallaGeneralRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProcesosPantallaGeneralRoutingModule", function() { return ProcesosPantallaGeneralRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _procesos_pantalla_general_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./procesos-pantalla-general.component */ "g1Z8");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");




const routes = [
    { path: '', component: _procesos_pantalla_general_component__WEBPACK_IMPORTED_MODULE_1__["ProcesosPantallaGeneralComponent"] },
];
class ProcesosPantallaGeneralRoutingModule {
}
ProcesosPantallaGeneralRoutingModule.ɵfac = function ProcesosPantallaGeneralRoutingModule_Factory(t) { return new (t || ProcesosPantallaGeneralRoutingModule)(); };
ProcesosPantallaGeneralRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: ProcesosPantallaGeneralRoutingModule });
ProcesosPantallaGeneralRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](ProcesosPantallaGeneralRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] }); })();


/***/ }),

/***/ "yKHc":
/*!****************************************************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/procesos/procesos-pantalla-general/procesos-pantalla-general.module.ts ***!
  \****************************************************************************************************************/
/*! exports provided: ProcesosPantallaGeneralModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProcesosPantallaGeneralModule", function() { return ProcesosPantallaGeneralModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _procesos_pantalla_general_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./procesos-pantalla-general-routing.module */ "oyCC");
/* harmony import */ var _procesos_pantalla_general_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./procesos-pantalla-general.component */ "g1Z8");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _proceso_proceso_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../proceso/proceso.component */ "g5FI");
/* harmony import */ var ngx_order_pipe__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ngx-order-pipe */ "JMRq");
/* harmony import */ var ngx_pagination__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ngx-pagination */ "oOf3");
/* harmony import */ var _services_procesos_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./../../../../../services/procesos.service */ "WFda");
/* harmony import */ var ngx_spinner__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ngx-spinner */ "JqCM");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ "fXoL");










class ProcesosPantallaGeneralModule {
}
ProcesosPantallaGeneralModule.ɵfac = function ProcesosPantallaGeneralModule_Factory(t) { return new (t || ProcesosPantallaGeneralModule)(); };
ProcesosPantallaGeneralModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineNgModule"]({ type: ProcesosPantallaGeneralModule });
ProcesosPantallaGeneralModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineInjector"]({ providers: [_services_procesos_service__WEBPACK_IMPORTED_MODULE_7__["ProcesosService"]], imports: [[
            ngx_pagination__WEBPACK_IMPORTED_MODULE_6__["NgxPaginationModule"],
            _angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
            _procesos_pantalla_general_routing_module__WEBPACK_IMPORTED_MODULE_1__["ProcesosPantallaGeneralRoutingModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            ngx_order_pipe__WEBPACK_IMPORTED_MODULE_5__["OrderModule"],
            ngx_spinner__WEBPACK_IMPORTED_MODULE_8__["NgxSpinnerModule"],
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵsetNgModuleScope"](ProcesosPantallaGeneralModule, { declarations: [_procesos_pantalla_general_component__WEBPACK_IMPORTED_MODULE_2__["ProcesosPantallaGeneralComponent"],
        _proceso_proceso_component__WEBPACK_IMPORTED_MODULE_4__["ProcesoComponent"]], imports: [ngx_pagination__WEBPACK_IMPORTED_MODULE_6__["NgxPaginationModule"],
        _angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
        _procesos_pantalla_general_routing_module__WEBPACK_IMPORTED_MODULE_1__["ProcesosPantallaGeneralRoutingModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
        ngx_order_pipe__WEBPACK_IMPORTED_MODULE_5__["OrderModule"],
        ngx_spinner__WEBPACK_IMPORTED_MODULE_8__["NgxSpinnerModule"]] }); })();


/***/ })

}]);
//# sourceMappingURL=procesos-pantalla-general-procesos-pantalla-general-module.js.map