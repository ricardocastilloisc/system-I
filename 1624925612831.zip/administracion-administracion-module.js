(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["administracion-administracion-module"],{

/***/ "KvD5":
/*!************************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/administracion/administracion.component.ts ***!
  \************************************************************************************/
/*! exports provided: AdministracionComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdministracionComponent", function() { return AdministracionComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "tyNb");


class AdministracionComponent {
    constructor() { }
    ngOnInit() {
    }
}
AdministracionComponent.ɵfac = function AdministracionComponent_Factory(t) { return new (t || AdministracionComponent)(); };
AdministracionComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: AdministracionComponent, selectors: [["app-administracion"]], decls: 1, vars: 0, template: function AdministracionComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "router-outlet");
    } }, directives: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterOutlet"]], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhZG1pbmlzdHJhY2lvbi5jb21wb25lbnQuY3NzIn0= */"] });


/***/ }),

/***/ "Ulzl":
/*!*****************************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/administracion/administracion-routing.module.ts ***!
  \*****************************************************************************************/
/*! exports provided: AdministracionRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdministracionRoutingModule", function() { return AdministracionRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _administracion_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./administracion.component */ "KvD5");
/* harmony import */ var _Guards_guard_roles_guard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../Guards/guard-roles.guard */ "+elB");
/* harmony import */ var _validators_roles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../validators/roles */ "r6zK");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");






const routes = [
    {
        path: '',
        component: _administracion_component__WEBPACK_IMPORTED_MODULE_1__["AdministracionComponent"],
        children: [
            {
                path: 'catalogos',
                loadChildren: () => __webpack_require__.e(/*! import() | catalogos-catalogos-module */ "catalogos-catalogos-module").then(__webpack_require__.bind(null, /*! ./catalogos/catalogos.module */ "+EFC")).then((m) => m.CatalogosModule),
                canActivate: [_Guards_guard_roles_guard__WEBPACK_IMPORTED_MODULE_2__["GuardRolesGuard"]],
                data: { roles: [_validators_roles__WEBPACK_IMPORTED_MODULE_3__["ERole"].Administrador, _validators_roles__WEBPACK_IMPORTED_MODULE_3__["ERole"].Monitor] },
            },
            {
                path: 'usuarios',
                loadChildren: () => __webpack_require__.e(/*! import() | usuarios-usuarios-module */ "usuarios-usuarios-module").then(__webpack_require__.bind(null, /*! ./usuarios/usuarios.module */ "zBaW")).then(m => m.UsuariosModule),
                canActivate: [_Guards_guard_roles_guard__WEBPACK_IMPORTED_MODULE_2__["GuardRolesGuard"]],
                data: { roles: [_validators_roles__WEBPACK_IMPORTED_MODULE_3__["ERole"].Administrador] },
            },
            {
                path: 'notificaciones',
                loadChildren: () => __webpack_require__.e(/*! import() | notificaciones-notificaciones-module */ "notificaciones-notificaciones-module").then(__webpack_require__.bind(null, /*! ./notificaciones/notificaciones.module */ "Sr2/")).then(m => m.NotificacionesModule),
                canActivate: [_Guards_guard_roles_guard__WEBPACK_IMPORTED_MODULE_2__["GuardRolesGuard"]],
                data: { roles: [_validators_roles__WEBPACK_IMPORTED_MODULE_3__["ERole"].Administrador] },
            },
        ],
    },
];
class AdministracionRoutingModule {
}
AdministracionRoutingModule.ɵfac = function AdministracionRoutingModule_Factory(t) { return new (t || AdministracionRoutingModule)(); };
AdministracionRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineNgModule"]({ type: AdministracionRoutingModule });
AdministracionRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵsetNgModuleScope"](AdministracionRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] }); })();


/***/ }),

/***/ "hpSa":
/*!*********************************************************************************!*\
  !*** ./src/app/pages/content/dashboard/administracion/administracion.module.ts ***!
  \*********************************************************************************/
/*! exports provided: AdministracionModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdministracionModule", function() { return AdministracionModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _administracion_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./administracion-routing.module */ "Ulzl");
/* harmony import */ var _administracion_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./administracion.component */ "KvD5");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




class AdministracionModule {
}
AdministracionModule.ɵfac = function AdministracionModule_Factory(t) { return new (t || AdministracionModule)(); };
AdministracionModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({ type: AdministracionModule });
AdministracionModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
            _administracion_routing_module__WEBPACK_IMPORTED_MODULE_1__["AdministracionRoutingModule"]
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](AdministracionModule, { declarations: [_administracion_component__WEBPACK_IMPORTED_MODULE_2__["AdministracionComponent"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
        _administracion_routing_module__WEBPACK_IMPORTED_MODULE_1__["AdministracionRoutingModule"]] }); })();


/***/ })

}]);
//# sourceMappingURL=administracion-administracion-module.js.map